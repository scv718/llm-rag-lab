/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class SmsARepo implements SmsCodeTableEnumIf {
    private static final int A_U_M_VAL = 1;
    private static final int A_U_S_VAL = 2;
    private static final int A_D_M_VAL = 3;
    private static final int A_D_S_VAL = 4;

    private static final SmsARepo UPC_MAIN = new SmsARepo(A_U_M_VAL);
    private static final SmsARepo UPC_SUB = new SmsARepo(A_U_S_VAL);
    private static final SmsARepo DNC_MAIN = new SmsARepo(A_D_M_VAL);
    private static final SmsARepo DNC_SUB = new SmsARepo(A_D_S_VAL);

    private final int code;

    private SmsARepo(int cd) {
        this.code = cd;
    }

//    public int getCode() {
//        return code;
//    }

    @Override
    public int value() {
        return code;
    }

    public static SmsARepo getUpcMain() {
        return UPC_MAIN;
    }

    public static SmsARepo getUpcSub() {
        return UPC_SUB;
    }

    public static SmsARepo getDncMain() {
        return DNC_MAIN;
    }

    public static SmsARepo getDncSub() {
        return DNC_SUB;
    }
}
