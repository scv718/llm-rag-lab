/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync(proxyTargetClass = true)
public class ExecutorConfig implements AsyncConfigurer{

    private static final int N10 = 10;
    private static final int N20 = 20;

    @Bean(name = "KamdSenderExecutor")
    public TaskExecutor kamdSenderExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(N10);
        executor.setMaxPoolSize(N10);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("KamdSender-");
        executor.initialize();

        return executor;
    }

    @Bean(name = "McrcSenderExecutor")
    public TaskExecutor mcrcSenderExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(N10);
        executor.setMaxPoolSize(N10);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("McrcSender-");
        executor.initialize();

        return executor;
    }

    @Bean(name = "KamdListenerExecutor")
    public TaskExecutor kamdListenerExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(N20);
        executor.setMaxPoolSize(N20);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("KamdListener-");
        executor.initialize();

        return executor;
    }

    @Bean(name = "McrcListenerExecutor")
    public TaskExecutor mcrcListenerExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(N20);
        executor.setMaxPoolSize(N20);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("McrcListener-");
        executor.initialize();

        return executor;
    }
}
