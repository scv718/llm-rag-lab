/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RecvMsgQueueBean {
    private static final int N1000 = 1000;
    private static final AtomicLong LAST_EPOCH_NANO = new AtomicLong(0);
    private static final long CAL_E = 1_000_000_000L;
	private byte[] data;
	private String senderIp;
	private Timestamp insertTime;
	
    public RecvMsgQueueBean(byte[] dataQueue, String senderIpAddr) {
        this.data = Arrays.copyOf(dataQueue, dataQueue.length);
        this.senderIp = senderIpAddr;
        setTime();
    }

    public void setTime() {
        Instant now = Instant.now();
        long nano = now.getEpochSecond() * 1_000_000_000L + now.getNano();

        while (true) {
            long last = LAST_EPOCH_NANO.get();
            long next = (nano > last) ? nano : (last + 1);
            if (LAST_EPOCH_NANO.compareAndSet(last, next)) {
                insertTime = Timestamp.from(
                        Instant.ofEpochSecond(next / CAL_E, next % CAL_E));
                return;
            }
        }
    }

}