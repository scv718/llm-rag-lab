/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanhwa.saws.mediator.common.service.AlarmService;
import com.hanhwa.saws.mediator.miss.msg.FrameHeader;
import com.hanhwa.saws.mediator.miss.msg.McrcSeqBean;
import com.hanhwa.saws.mediator.miss.msg.SequenceHeader;
import com.hanhwa.saws.mediator.miss.service.RasdParseService;
import com.hanhwa.saws.mediator.util.ByteUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class McrcReceiverPoll implements Runnable {
    private static final int N2 = 2;
    private static final int N4 = 4;
    private static final int N10 = 10;
    private static final int N8 = 8;
    private static final int N11000 = 11000;
    private static final int N12000 = 12000;
    private static final int N65535 = 65535;
    private static final int BFFFF = 0xFFFF;
    private boolean isCorrupted = false;

    @Autowired
    @Qualifier("mcrcRecvQueue") 
    private ConcurrentLinkedQueue<byte[]> mcrcRecvQueue;

    @Autowired private AlarmService alarmService;
    @Autowired private RasdParseService rasdParseService;

    @Override
    public void run() {
        while (true) {
            try {
                if (mcrcRecvQueue.size() == 0) {
                    CompletableFuture<Void> delay = new CompletableFuture<>();
                    delay.completeOnTimeout(null, N10, TimeUnit.MILLISECONDS)
                            .join();
                    continue;
                }
                processPacket(mcrcRecvQueue.poll());
            } catch (RuntimeException e) {
                log.warn("McrcReceivPoll error: {}", e.getMessage(), e);
                return;
            }
        }

    }

    private void processPacket(byte[] packet) {
        try {
            ByteBuffer pBuf = null;
            int frameType = 0;
            int frameSeqNo = 0;
            String frameErrMsg = "Frame Type: {}, Frame Size: {}";
            List<McrcSeqBean> sequenceList = null;
            FrameHeader frameHeader = null;

            if (packet.length < N8) {
                log.warn("Invalid packet size: {}", packet.length);
                return;
            }

            pBuf = ByteBuffer.wrap(packet);
            frameHeader = extractFrameHeader(pBuf);
            frameType = frameHeader.getFrameType();
            frameSeqNo = frameHeader.getFrameSequenceNumber();
            log.debug(frameErrMsg, frameType, frameHeader.getFrameSize());

            if ((frameType != N11000) && (frameType != N12000)) {
                throw new IOException("frame type error: " + frameType);
            }

            if ((frameSeqNo < 1) || (frameSeqNo > N65535)) {
                throw new IOException("frame seqno error: " + frameSeqNo);
            }

            sequenceList = extractSequences(pBuf);

            for (McrcSeqBean seq : sequenceList) {
                rasdParseService.parse(seq);
            }

            if (isCorrupted) {
                alarmService.setDataCorruptionAlarm("true");
                log.info("DATA CORRUPTION ALARM CLEAR (MCRC)");
                isCorrupted = false;
            }

        } catch (Exception e) {
            log.warn("Invalid RASD UDP packet skip: {}", e.getMessage(), e);

            // 최초 에러일 때만 알람 전송
            if (!isCorrupted) {
                alarmService.setDataCorruptionAlarm("false");
                log.info("DATA CORRUPTION ALARM MINOR (MCRC)");
                isCorrupted = true;
            }

        }

    }

    private FrameHeader extractFrameHeader(ByteBuffer buffer) {

        int frameType = buffer.getShort() & BFFFF;
        int frameSize = buffer.getShort() & BFFFF;
        int frameSeqNumber = buffer.getShort() & BFFFF;
        int filler = buffer.getShort() & BFFFF;

        return new FrameHeader(frameType, frameSize, frameSeqNumber, filler);
    }

    private SequenceHeader extractSequenceHeader(ByteBuffer bf) {
        byte[] tyBytes = null;
        byte[] siBytes = null;

        int seqType = 0;
        int seqSize = 0;

        String errMsg = "Err Seq Header Buff Posi: {}, Remain: {}, Err: {}";

        try {
            tyBytes = new byte[N2];
            siBytes = new byte[N2];

            bf.get(tyBytes);
            bf.get(siBytes);

            seqType = ByteUtil.byteArrayToInt(ByteUtil.swap2Byte(tyBytes));
            seqSize = ByteUtil.byteArrayToInt(ByteUtil.swap2Byte(siBytes));

            return new SequenceHeader(seqType, seqSize);

        } catch (RuntimeException e) {
            log.warn(errMsg, bf.position(), bf.remaining(), e.getMessage(), e);
            throw e;
        }
    }

    private List<McrcSeqBean> extractSequences(ByteBuffer buffer) {

        List<McrcSeqBean> sequenceList = new ArrayList<>();
        byte[] sequenceData = null;
        McrcSeqBean bean = null;
        String errMsg = "Not enough data in buffer Expected: {}, Available: {}";
        int bodySize = 0;
        SequenceHeader seqHeader = null;

        while (buffer.remaining() >= N4) {
            try {
                seqHeader = extractSequenceHeader(buffer);

                bodySize = seqHeader.getSequenceSize() - N4;
                if (buffer.remaining() < bodySize) {
                    log.warn(errMsg, bodySize, buffer.remaining());
                    break;
                }

                bean = new McrcSeqBean();
                sequenceData = new byte[bodySize];
                buffer.get(sequenceData);

                bean.setSeqHeader(seqHeader);
                bean.setBody(sequenceData);
                sequenceList.add(bean);

            } catch (Exception e2) {
                log.warn("Error processing sequence: {}", e2.getMessage(), e2);
                throw e2;
            }
        }

        return sequenceList;
    }

}