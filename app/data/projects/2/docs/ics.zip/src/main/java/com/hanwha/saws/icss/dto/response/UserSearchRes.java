/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.UserModel;

import lombok.Data;

@Data
public class UserSearchRes {

    private String id;
    private String name;
    @JsonProperty("group_id") private String groupId;
    @JsonProperty("group_name") private String groupName;
    private String phone;
    private String tel;
    private String email;
    private String desc;
    private String deny;
    @JsonProperty("fail_count") private int failCount;

    public void setData(UserModel model) {
        id = model.getUserId();
        name = model.getUserName();
        groupId = model.getGroupId();
        groupName = model.getGroupName();
        phone = model.getMobile();
        tel = model.getTelephone();
        email = model.getEmail();
        desc = model.getDesc64();
        deny = model.getDenyFlag();
        failCount = model.getFailCount();
    }

}
