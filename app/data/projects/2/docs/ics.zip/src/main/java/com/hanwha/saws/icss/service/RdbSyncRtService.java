/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

public interface RdbSyncRtService {

    public void insertQueue(Object qObj, String qType);
}
