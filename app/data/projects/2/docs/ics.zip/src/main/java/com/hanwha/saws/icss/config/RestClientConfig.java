/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;
import java.security.GeneralSecurityException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.DefaultConnectionKeepAliveStrategy;
import org.apache.hc.client5.http.impl.DefaultHttpRequestRetryStrategy;
import org.apache.hc.client5.http.impl.classic.DefaultBackoffStrategy;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.DefaultClientTlsStrategy;
import org.apache.hc.core5.http.impl.DefaultConnectionReuseStrategy;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.apache.hc.core5.util.TimeValue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

@Configuration
public class RestClientConfig {

    private static final int MAX_IDLE_TIME = 2;
    private static final int MAX_RETRIES = 1;
    private static final long RETRY_INTERVAL_IN_SECONDS = 1L;

    @Value("${rest.timeout}") int timeout;
    @Value("${rest.httpConnPoolMaxTotal}") int httpConnPoolMaxTotal;
    @Value("${rest.httpConnPoolDefaultMaxPerRoute}") int cPMaxPerRoute;
    @Value("${rest.tls-op}") boolean isTls;
    
    @Bean
    public RestClient restClient(HttpClient httpClient) {

        RestClient restClient = null;
        var reqFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

        RestClient.Builder builder = RestClient.builder();

        if (httpClient != null) {
            builder = builder.requestFactory(reqFactory);
        }

        restClient = builder.build();

        return restClient;

    }

    @Bean
    public HttpClient httpClient() {

        var builder = HttpClients.custom();

        var reuse = DefaultConnectionReuseStrategy.INSTANCE;
        var keepAlive = new DefaultConnectionKeepAliveStrategy();
        var backoff = new DefaultBackoffStrategy();
        var idle = TimeValue.ofSeconds(MAX_IDLE_TIME);

        if (isTls) {
            builder.setConnectionManager(buildTlsConManager());
        } else {
            builder.setConnectionManager(buildConnManager());
        }

        builder.setConnectionReuseStrategy(reuse);
        builder.setKeepAliveStrategy(keepAlive);
        builder.setRetryStrategy(buildRetryStrategy());
        builder.setConnectionBackoffStrategy(backoff);
        builder.setDefaultRequestConfig(requestConfig());
        builder.evictExpiredConnections();
        builder.evictIdleConnections(idle);

        return builder.build();

    }

    private PoolingHttpClientConnectionManager buildConnManager() {

        var connectionManager = new PoolingHttpClientConnectionManager();
        var builder = ConnectionConfig.custom();        
        var connectionConfig = builder
                .setConnectTimeout(timeout, TimeUnit.SECONDS)
                .build();
        
        // 위 정보는 실험용 .줄바꿈 오류 나나 안나나
        connectionManager.setDefaultConnectionConfig(connectionConfig);
        connectionManager.setMaxTotal(httpConnPoolMaxTotal);
        connectionManager.setDefaultMaxPerRoute(cPMaxPerRoute);

        return connectionManager;
    }
    
    private PoolingHttpClientConnectionManager buildTlsConManager() {
        TrustStrategy truSt = null;
        SSLContext sCon = null;
        HostnameVerifier hNVer = null;
        DefaultClientTlsStrategy tlsStrategy = null;
        ConnectionConfig.Builder cConfB = null;
        ConnectionConfig cCon = null;
        PoolingHttpClientConnectionManagerBuilder pCMB = null;
        
        try {
            truSt = (chain, authType) -> true;

            sCon = SSLContexts.custom().loadTrustMaterial(null, truSt).build();

            hNVer = (host, session) -> true;

            tlsStrategy = new DefaultClientTlsStrategy(sCon, hNVer);

            cConfB = ConnectionConfig.custom();
            cCon = cConfB.setConnectTimeout(timeout, TimeUnit.SECONDS).build();

            pCMB = PoolingHttpClientConnectionManagerBuilder.create();
            pCMB.setTlsSocketStrategy(tlsStrategy);
            pCMB.setDefaultConnectionConfig(cCon);
            pCMB.setMaxConnTotal(httpConnPoolMaxTotal);
            pCMB.setMaxConnPerRoute(cPMaxPerRoute);

            return pCMB.build();

        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Failed to build conn mgr", e);
        }
    }

    private RequestConfig requestConfig() {

        var builder = RequestConfig.custom();

        builder.setResponseTimeout(timeout, TimeUnit.SECONDS);
        builder.setConnectionRequestTimeout(timeout, TimeUnit.SECONDS);

        return builder.build();

    }

    private DefaultHttpRequestRetryStrategy buildRetryStrategy() {

        TimeValue interval = TimeValue.ofSeconds(RETRY_INTERVAL_IN_SECONDS);

        return new DefaultHttpRequestRetryStrategy(MAX_RETRIES, interval);
    }

}
