/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.persistence.model.UserModel;

public interface IcsSyncService {

    public List<StatusModel> getRemoteStatusList();

    public void setRemoteStatus(StatusModel model);

    public void syncRemoteStatus(List<StatusModel> param);

    public void syncRemoteNode(List<NodeModel> param);

    public void syncRemoteUserGroup(List<UserModel> param,
            List<GroupModel> gParam);

    public void syncRemoteThreshold(List<ThresholdModel> param);

    public void syncRemoteCurrAlarm(List<CurrAlarmModel> param);

    public void syncRemoteDefaultCode(List<DefaultCodeModel> codeList);

    void syncMcrcHistBulkInsert(List<McrcHistModel> list);

    void syncKamdHistBulkInsert(List<KamdHistModel> list);
    
    void syncKamdDetailHistBulkInsert(List<KamdHistDetailModel> list);

    void syncRemoteSawInfo(List<SawInfoModel> list);

    void insertAlarmHistInsert(AlarmHistModel param);

    void insertMessageHist(MessageHistModel param);

    void insertAirHist(AirRaidHistModel param);

    void insertEmerHist(EmerHistModel param);

    void insertAirDefWarnHist(AirDefWarnHistModel param);

    public void insertStatusHist(StatusHistModel param);

    void syncMcrcDetailHistBulkInsert(List<McrcHistDetailModel> list);

}
