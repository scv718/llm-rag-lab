/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.msg;

public class FrameHeader {

    private int frType;
    private int frSize;
    private int frameSeqNumber;
    private int filler;

    String toMsg = "FrameHeader { Type: %d, Size: %d, SeqNum: %d, Filler: %d }";

    public FrameHeader(int pType, int pSize, int pNumber, int pFiller) {
        this.frType = pType;
        this.frSize = pSize;
        this.frameSeqNumber = pNumber;
        this.filler = pFiller;
    }

    public int getFrameType() {
        return frType;
    }

    public int getFrameSize() {
        return frSize;
    }

    public int getFrameSequenceNumber() {
        return frameSeqNumber;
    }

    public int getFiller() {
        return filler;
    }

    @Override
    public String toString() {
        return String.format(toMsg, frType, frSize, frameSeqNumber, filler);
    }
}
