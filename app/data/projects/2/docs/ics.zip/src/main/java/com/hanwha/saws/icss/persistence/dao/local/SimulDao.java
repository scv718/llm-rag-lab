/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.KamdSimulModel;
import com.hanwha.saws.icss.persistence.model.McrcSimulModel;

public interface SimulDao {

    public List<McrcSimulModel> selectMcrcSimulList(McrcSimulModel param);

    public List<KamdSimulModel> selectKamdSimulList(KamdSimulModel param);

    public List<McrcSimulModel> selectMcrcSimulRouteList(McrcSimulModel param);

    public List<KamdSimulModel> selectKamdSimulRouteList(KamdSimulModel param);

    public List<McrcSimulModel> selectMcrcSimulNoList();

    public List<KamdSimulModel> selectKamdSimulNoList();

    public void insertMcrcSimul(McrcSimulModel param);

    public void insertKamdSimul(KamdSimulModel param);

    public void insertKamdArrSimul(List<KamdSimulModel> param);

    public void deleteMcrcSimul(McrcSimulModel param);

    public void deleteKamdSimul(KamdSimulModel param);
}
