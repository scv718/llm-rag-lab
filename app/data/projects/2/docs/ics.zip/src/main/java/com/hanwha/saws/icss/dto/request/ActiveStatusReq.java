/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ActiveStatusReq {

    private static final Gson LOG_GSON = createLogGson();

    private String id;
    private int active;

    private static Gson createLogGson() {
        GsonBuilder b = new GsonBuilder();
        
        b.disableHtmlEscaping();
        b.setPrettyPrinting();
        return b.create();
    }

//    public String toJsonString() {
//        return LOG_GSON.toJson(this);
//    }

}
