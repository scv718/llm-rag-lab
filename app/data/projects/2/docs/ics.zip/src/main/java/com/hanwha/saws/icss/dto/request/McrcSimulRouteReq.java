/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class McrcSimulRouteReq {
    @JsonProperty("route") private Integer mcrcRoute;
    @JsonProperty("location_x")private String mcrcLocationX;
    @JsonProperty("location_y") private String mcrcLocationY;
    @JsonProperty("knot") private Integer mcrcKnot;
    @JsonProperty("feet") private Integer mcrcFeet;
    @JsonProperty("create_time") private String createSys;

}
