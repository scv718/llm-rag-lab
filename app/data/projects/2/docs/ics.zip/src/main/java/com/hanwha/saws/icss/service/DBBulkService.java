/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;

public interface DBBulkService {

    public void pushAirTrackQueue(McrcHistModel model);

    public void pushMissleQueue(KamdHistModel model);
}
