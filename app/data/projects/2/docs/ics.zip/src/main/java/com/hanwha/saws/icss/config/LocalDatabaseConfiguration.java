/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@MapperScan(
        value = "com.hanwha.saws.icss.persistence.dao.local",
        sqlSessionFactoryRef = "localSSF")
@EnableTransactionManagement(proxyTargetClass = true)
public class LocalDatabaseConfiguration {

    @Primary
    @Bean(name = "localDS")
    @ConfigurationProperties(prefix = "spring.local.datasource")
    public DataSource localDS() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "localSSF")
    public SqlSessionFactory localSSF(@Qualifier("localDS") DataSource localDS,
            ApplicationContext ctx) throws Exception {

        String xmlPath = "classpath:mappers/local/*.xml";
        String configPath = "classpath:mybatis-config.xml";

        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();

        factoryBean.setDataSource(localDS);
        factoryBean.setMapperLocations(ctx.getResources(xmlPath));
        factoryBean.setConfigLocation(ctx.getResource(configPath));

        return factoryBean.getObject();
    }

    @Bean(name = "localSST")
    public SqlSessionTemplate localSST(SqlSessionFactory localSSF) {

        return new SqlSessionTemplate(localSSF);
    }

    @Bean(name = "localTransactionManager")
    public PlatformTransactionManager localTxManager()
            throws URISyntaxException, ParseException, IOException {
        return new DataSourceTransactionManager(localDS());
    }

}
