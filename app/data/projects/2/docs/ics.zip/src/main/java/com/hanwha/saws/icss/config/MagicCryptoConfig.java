/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import org.springframework.context.annotation.Configuration;

import com.nbware.aria.magiccrypto.MagicCrypto;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class MagicCryptoConfig {

    @PostConstruct
    public void initMagicCrypto() {
        
        int rv = 0;
        
        log.debug("[MC-DEBUG] Spring initialization started...");

        rv = MagicCrypto.INSTANCE.MC_Initialize(null);

        log.debug("[MC-DEBUG] MC_Initialize rv=" + rv);

        if (rv != 0) {
            throw new IllegalStateException(
                    "MagicCrypto initialization failed. rv=" + rv);
        }

        log.debug("[MC-DEBUG] MagicCrypto initialization completed.");
    }
}