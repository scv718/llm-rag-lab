/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UDPPacketListener {

    @Value("${mediator.mode}") private String mode;

    @Autowired
    private McrcReceiver mcrcReceiver;
    @Autowired
    private McrcReceiverPoll mcrcReceiverPoll;
    @Autowired
    private McrcQueueMonitor mcrcQueueMonitor;

    @Autowired @Qualifier("McrcListenerExecutor")
    private TaskExecutor mcrcListenerExecutor;

    @PostConstruct
    public void init() {

        if (!"mcrc".equalsIgnoreCase(mode)) {
            log.debug("MCRC Listener not running. mode: {}", mode);
            return;
        }

        mcrcListenerExecutor.execute(mcrcReceiver);

        mcrcListenerExecutor.execute(mcrcReceiverPoll);

        mcrcListenerExecutor.execute(mcrcQueueMonitor);

    }

}
