/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.MedService;
import com.hanwha.saws.icss.util.LogKeyUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MedBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    private static final int ACTIVE = 1;
    
    @Autowired PropConfig prop;
    @Autowired MedService medService;

    @Scheduled(
            fixedDelayString = "${cron.med-heartbeat}000",
            initialDelayString = "${cron.init-delay}000")
    public void medHeartbeat() throws IOException {

        NodeModel paramModel = null;
        HashMap<Integer, NodeModel> nHash = null;
        
        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("Stand by");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        statusLog.debug("MED HEARTBEAT BATCH START");

        try {
            nHash = prop.getNodeInfoHash();
            paramModel = nHash.get(NodeRepo.getMissA().getCode());
            medService.heartbeatRequest(paramModel);
            
            paramModel = nHash.get(NodeRepo.getMissB().getCode());
            medService.heartbeatRequest(paramModel);

            paramModel = nHash.get(NodeRepo.getKissA().getCode());
            medService.heartbeatRequest(paramModel);

            paramModel = nHash.get(NodeRepo.getKissB().getCode());
            medService.heartbeatRequest(paramModel);

        } catch (NoClassDefFoundError e) {
            log.warn("medHeartbeat() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("medHeartbeat batch " + e.toString());
        }

        statusLog.debug("MED HEARTBEAT BATCH END");

    }

}
