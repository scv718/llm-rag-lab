/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.GroupModel;

import lombok.Data;

@Data
public class GroupSearchRes {

    @JsonProperty("group_id") private String groupId;
    @JsonProperty("group_name") private String groupName;
    private String desc;

    public void setData(GroupModel model) {
        groupId = model.getGroupId();
        groupName = model.getGroupName();
        desc = model.getDesc64();
    }

}
