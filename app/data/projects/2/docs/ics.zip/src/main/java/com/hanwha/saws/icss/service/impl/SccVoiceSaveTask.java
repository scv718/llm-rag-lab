/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SccVoiceSaveTask {
    
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    
    @Async("voiceSaveExecutor") 
    public void save(String fileName, byte[] buffer, String voiceDir) {
        
        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");

        String saveTkTmp = null;
        AudioInputStream aInStream;
        AudioFormat audioFormat;
        ByteArrayInputStream bs;
        long aLen;
        boolean isSupport;
        AudioFileFormat.Type wType = AudioFileFormat.Type.WAVE;
        AudioFileFormat.Type auType = AudioFileFormat.Type.AU;
        String vPath = voiceDir + "/" + fmter.format(LocalDateTime.now());

        if (!Files.exists(Paths.get(vPath))) {
            try {
                Files.createDirectories(Paths.get(vPath));
            } catch (IOException e7) {
                log.warn("create file/dir error " + e7.toString());
            }
        }

        saveTkTmp = vPath + "/" + fileName;

        try (FileOutputStream fos = new FileOutputStream(saveTkTmp)) {
            log.info("File[={}] created in {} size {}", fileName, vPath,
                    buffer.length);

            audioFormat = getAudioFormat();
            bs = new ByteArrayInputStream(buffer);
            aLen = buffer.length / audioFormat.getFrameSize();

            aInStream = new AudioInputStream(bs, audioFormat, aLen);

            isSupport = AudioSystem.isFileTypeSupported(wType, aInStream);

            if (isSupport) {
                AudioSystem.write(aInStream, wType, fos);
            } else if (AudioSystem.isFileTypeSupported(auType, aInStream)) {
                AudioSystem.write(aInStream, auType, fos);
            }

            fos.flush();
            log.info("File[={}] closed.", fileName);

        } catch (RuntimeException | IOException e6) {
            log.warn("save error " + e6.toString());
        }
    }

    private AudioFormat getAudioFormat() {
        
        String SAMPLING = "rate=8000,bits=8,channels=1,signed=false,endian=big";
        String[] sInfo = SAMPLING.split(",");

        String audioTmp = sInfo[0].substring(sInfo[0].indexOf("=") + 1);
        float sRate = Float.parseFloat(audioTmp); // 8000
        int sSizeInBits = 0;
        int ch = 0;
        boolean signed = false;
        boolean bigEndian = false;

        audioTmp = sInfo[1].substring(sInfo[1].indexOf("=") + 1);
        sSizeInBits = Integer.parseInt(audioTmp); // 8

        audioTmp = sInfo[N2].substring(sInfo[N2].indexOf("=") + 1);
        ch = Integer.parseInt(audioTmp); // 1

        audioTmp = sInfo[N3].substring(sInfo[N3].indexOf("=") + 1);
        signed = Boolean.parseBoolean(audioTmp);

        audioTmp = sInfo[N4].substring(sInfo[N4].indexOf("=") + 1);
        bigEndian = (audioTmp.equals("big"));

        return new AudioFormat(sRate, sSizeInBits, ch, signed, bigEndian);
    }
}
