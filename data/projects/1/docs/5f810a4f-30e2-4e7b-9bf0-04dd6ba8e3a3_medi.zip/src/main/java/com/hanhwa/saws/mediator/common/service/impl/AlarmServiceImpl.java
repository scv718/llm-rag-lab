/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.common.service.impl;

import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.hanhwa.saws.mediator.common.service.AlarmService;
import com.hanhwa.saws.mediator.dto.request.AlarmVo;
import com.hanhwa.saws.mediator.util.RestUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AlarmServiceImpl implements AlarmService {

    @Autowired private RestUtil restUtil;
    @Value("${icss.alarm-url}") private String icssAlarmUrl;

    @Override
    public void setNoDataAlarm(String result) {
        AlarmVo alarmVo = new AlarmVo();
        String now = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String errMsg = "Failed to send NO DATA ALARM to ICSS:{}";

        alarmVo.setAlarmType("2");
        alarmVo.setTime(now);

        if (result.equals("true")) {
            alarmVo.setSeverity("CLE");
        } else {
            alarmVo.setSeverity("MIN");
        }

        try {
            log.info("NO DATA ALARM:{}", alarmVo);
            AlarmVo.setList(alarmVo);
            restUtil.sendData(alarmVo, icssAlarmUrl);
        } catch (URISyntaxException e) {
            log.warn(errMsg, e.getMessage(), e);
        }
    }

    @Override
    public void setDataCorruptionAlarm(String result) {
        AlarmVo alarmVo = new AlarmVo();
        String now = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String errMsg = "Failed to send DATA CORRUPTION ALARM to ICSS: {}";

        alarmVo.setAlarmType("3");
        alarmVo.setTime(now);

        if (result.equals("true")) {
            alarmVo.setSeverity("CLE");
        } else {
            alarmVo.setSeverity("MIN");
        }

        try {
            log.info("DATA CORRUPTION ALARM:{}", alarmVo);
            AlarmVo.setList(alarmVo);
            restUtil.sendData(alarmVo, icssAlarmUrl);
        } catch (URISyntaxException e) {
            log.warn(errMsg, e.getMessage(), e);
        }
    }

}
