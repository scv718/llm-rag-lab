/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.MedService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.SwitchRouterService;
import com.hanwha.saws.icss.service.SyncHistInsertService;

import lombok.extern.slf4j.Slf4j;

@Service("SwitchRouterService")
@Slf4j
public class SwitchRouterServiceImpl implements SwitchRouterService {
    private static final int N3000 = 3000;
    
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired RdbSyncRtService rtSync;

    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired AlarmService alarmService;

    @Autowired PropConfig prop;

    @Autowired MedService medService;

    @Override
    public void heartbeatRequest(NodeModel nodeInfo) {

        String ipAddress = nodeInfo.getAddrIp();
        int timeout = N3000;
        List<StatusModel> statusList = null;
        StatusModel model = null;
        int statusCode = -1;
        NodeRepo code = null;
        boolean isPrevConnect = true;
        InetAddress inet = null;
        boolean reachable = false;
        boolean isCon = false;
        StringBuilder sb = new StringBuilder();
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrMin();
        String tmp = "";

        try {

            statusList = statusConfigDao.selectStatusList();

            if ((statusList == null) || (statusList.size() == 0)) {
                log.trace("status list null");
                return;
            }

            model = statusList.get(0);

            code = NodeRepo.from(nodeInfo.getNodeId());

            if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
                statusCode = model.getSwitchA();
            } else if (code.getCode() == NodeRepo.getSwitchB().getCode()) {
                statusCode = model.getSwitchB();
//            } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
//                statusCode = model.getRouterA();
//            } else if (code.getCode() == NodeRepo.getRouterB().getCode()) {
//                statusCode = model.getRouterB();
            } else if (code.getCode() == NodeRepo.getRouterM().getCode()) {
                statusCode = model.getRouterM();
            } else {
                log.debug("NON CODE" + code);
                return;
            }

            if (statusCode == StatusRepo.getUNKNOWN().getCode()) {
                isPrevConnect = false;
            }

            inet = InetAddress.getByName(ipAddress);
            reachable = inet.isReachable(timeout);

            if (reachable) {
                isCon = true;
            } else {
                log.debug(code.getName() + " " + ipAddress + " not connected");
            }

            if (isCon != isPrevConnect) {
                updateStatus(isCon, code, nodeInfo);
            }

            sb.append(nodeInfo.getName() + " ");
            sb.append(nodeInfo.getAddrIp());
            sb.append(" connect problem");

            alarmService.alarmUpdate(isCon, ac, nodeInfo, lv, sb.toString());

        } catch (IOException | RuntimeException e) {

            tmp = "SwitchRouterService heartbeatRequest() {} {}";
            log.warn(tmp, nodeInfo.getName(), e.toString());
        }
    }

    @Override
    public void medMcrcRouterRequest(NodeModel nodeInfo) {
        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
        NodeModel nm = nHash.get(NodeRepo.getMissA().getCode());
        String targetIp = nodeInfo.getAddrIp();
        String senderIp = nm.getAddrIp();
        boolean isCon = false;
        StatusModel model = null;
        List<StatusModel> statusList = null;
        NodeRepo code = null;
        int statusCode = -1;
        boolean isPrevConnect = true;
        StringBuilder sb = new StringBuilder();
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrMin();
        String tmp = "";

        try {
            log.debug("mcrc ip " + senderIp + " target ip : " + targetIp);
            isCon = medService.getMedRouterPing(senderIp, targetIp);

            if (!isCon) {
                nm = nHash.get(NodeRepo.getMissB().getCode());
                senderIp = nm.getAddrIp();
                log.debug("mcrc ip " + senderIp + " target ip : " + targetIp);
                isCon = medService.getMedRouterPing(senderIp, targetIp);
            }

            statusList = statusConfigDao.selectStatusList();

            if ((statusList == null) || (statusList.size() == 0)) {
                log.trace("status list null");
                return;
            }

            model = statusList.get(0);
            statusCode = model.getRouterA(); // MCRC는 ROUTER A
            code = NodeRepo.from(nodeInfo.getNodeId());

            if (statusCode == StatusRepo.getUNKNOWN().getCode()) {
                isPrevConnect = false;
            }

            if (isCon != isPrevConnect) {
                updateStatus(isCon, code, nodeInfo);
            }

            sb.append(nodeInfo.getName() + " ");
            sb.append(nodeInfo.getAddrIp());
            sb.append(" connect problem");

            alarmService.alarmUpdate(isCon, ac, nodeInfo, lv, sb.toString());
        } catch (RuntimeException e) {

            tmp = "SwitchRouterService heartbeatRequest() {} {}";
            log.warn(tmp, nodeInfo.getName(), e.toString());
        }
    }

    @Override
    public void medKamdRouterRequest(NodeModel nodeInfo) {
        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
        NodeModel nm = nHash.get(NodeRepo.getKissA().getCode());
        String targetIp = nodeInfo.getAddrIp();
        String senderIp = nm.getAddrIp();
        boolean isCon = false;
        StatusModel model = null;
        List<StatusModel> statusList = null;
        NodeRepo code = null;
        int statusCode = -1;
        boolean isPrevConnect = true;
        StringBuilder sb = new StringBuilder();
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrMin();
        String tmp = "";

        try {
            log.debug("kamd ip " + senderIp + " target ip : " + targetIp);
            isCon = medService.getMedRouterPing(senderIp, targetIp);

            if (!isCon) {
                nm = nHash.get(NodeRepo.getKissB().getCode());
                senderIp = nm.getAddrIp();
                log.debug("kamd ip " + senderIp + " target ip : " + targetIp);
                isCon = medService.getMedRouterPing(senderIp, targetIp);
            }

            statusList = statusConfigDao.selectStatusList();

            if ((statusList == null) || (statusList.size() == 0)) {
                log.trace("status list null");
                return;
            }

            model = statusList.get(0);
            statusCode = model.getRouterB(); // KAMD는 ROUTER B
            code = NodeRepo.from(nodeInfo.getNodeId());

            if (statusCode == StatusRepo.getUNKNOWN().getCode()) {
                isPrevConnect = false;
            }

            if (isCon != isPrevConnect) {
                updateStatus(isCon, code, nodeInfo);
            }

            sb.append(nodeInfo.getName() + " ");
            sb.append(nodeInfo.getAddrIp());
            sb.append(" connect problem");

            alarmService.alarmUpdate(isCon, ac, nodeInfo, lv, sb.toString());
        } catch (RuntimeException e) {

            tmp = "SwitchRouterService heartbeatRequest() {} {}";
            log.warn(tmp, nodeInfo.getName(), e.toString());
        }

    }

    private void updateStatus(boolean heartBeatStatus, NodeRepo code,
            NodeModel nodeInfo) {
        StatusModel param = new StatusModel();
        int codeKey = 0;

        if (heartBeatStatus) {
            codeKey = StatusRepo.getOK().getCode();
        } else {
            codeKey = StatusRepo.getUNKNOWN().getCode();
        }

        if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
            param.setSwitchA(codeKey);
        } else if (code.getCode() == NodeRepo.getSwitchB().getCode()) {
            param.setSwitchB(codeKey);
        } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
            param.setRouterA(codeKey);
        } else if (code.getCode() == NodeRepo.getRouterB().getCode()) {
            param.setRouterB(codeKey);
        } else if (code.getCode() == NodeRepo.getRouterM().getCode()) {
            param.setRouterM(codeKey);
        } else {
            log.debug("NON CODE" + code);
            return;
        }

        try {
            statusConfigDao.updateStatus(param);
            rtSync.insertQueue(param, "UPDATE");
        } catch (RuntimeException e) {
            log.warn("SwitchRouterService updateStatus() " + e.toString());
        }

    }

}
