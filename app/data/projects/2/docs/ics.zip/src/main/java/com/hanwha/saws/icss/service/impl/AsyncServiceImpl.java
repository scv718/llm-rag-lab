/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.service.AsyncService;

import lombok.extern.slf4j.Slf4j;

@Service("AsyncService")
@Slf4j
public class AsyncServiceImpl implements AsyncService {

    @Async("ASyncExecutor")
    public void resetIcs() {
        try {

            String home = System.getProperty("ICS_HOME");
            ProcessBuilder pb = null;
            String param = home + "/bin/restart.sh";

            pb = new ProcessBuilder("sh", param);

            pb.inheritIO(); // 현재 콘솔에 입출력 연결
            pb.start();

        } catch (IOException e) {
            log.error(e.toString(), e);
        }
    }

    @Async("ASyncExecutor")
    public void diagnosis() {
        try {

            String home = System.getProperty("ICS_HOME");
            ProcessBuilder pb = null;
            String param = home + "/bin/status_report.sh";

            pb = new ProcessBuilder("sh", param);

            pb.inheritIO(); // 현재 콘솔에 입출력 연결
            pb.start();

        } catch (IOException e) {
            log.error(e.toString(), e);
        }
    }

}
