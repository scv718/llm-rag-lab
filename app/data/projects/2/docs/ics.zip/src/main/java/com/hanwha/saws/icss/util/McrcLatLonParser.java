/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.math.BigDecimal;

public class McrcLatLonParser extends LatLonParseConst {

    // 도(degree) -> 라디안(radian) 변환 상수
    private static final double DEGREES_TO_RADIANS = Math.PI / 180.0;

    // WGS-84 기반 타원체 계수들 (conformal latitude 변환용)
    private double coefA; // conformal latitude 변환식 계수 A
    private double coefB; // conformal latitude 변환식 계수 B
    private double coefC; // conformal latitude 변환식 계수 C
    private double coefD; // conformal latitude 변환식 계수 D
    private double coefE; // conformal latitude 변환식 계수 E
    private double coefF; // conformal latitude 변환식 계수 F
    private double coefG; // conformal latitude 변환식 계수 G
    private double coefH; // conformal latitude 변환식 계수 H

    // 지구 타원체 파라미터
    private double earthEccentricity; // 지구 이심률
    private double polarEarthRadius; // 지구 극반경
    private double equatorialRadiusNm; // 지구 적도반경 (Nm 단위)
    private double conformalEarthRadius; // 등각투영에서 사용되는 지구 반경에 해당하는 값
    private double epsilon; // 수렴 오차

    // 기준점(origin) 관련 변수
    private double originConformalRadius; // 기준점 투영 반경
    private double originConformalLat; // 기준 지리 위도(WGS-84)를 등각 위도로 변환한 값
    private double originGeoLat; // 기준 지리 위도
    private double originGeoLon; // 기준 지리 경도
    private double originSinConformalLat; // 기준점의 등각 위도의 사인값
    private double originCosConformalLat; // 기준점의 등각 위도의 코사인값

    // 투영 공식에 쓰는 전용 상수(구면 정사각의 변형 공식)
    private double scaledRadius4; // 4*등각 투영 반경
    private double scaledRadius4Sq; // 4*투영식에서 x,y 변환 연산의 기준 제곱 반경
    private double scaledRadius4CosOrigin; // GPS 변환 식 위도 보정 상수
    private double scaledRadius4SinOrigin; // GPS 변환 식 경도 보정 상수

    public McrcLatLonParser() {
        initDaegu();
        initOsan();
    }

    /*
     * 생성 및 초기화. 기준좌표 경도 도,분,초 위도 도,분,초 
     * 지역 투영(지구곡면->평면 변환 기준 데이터) 초기화 3D->2D로 변환
     */
//    public McrcLatLonParser(
//            int lonD, int lonM, int lonS, int latD, int latM, int latS) {
//
//        initializeProjection(lonD, lonM, lonS, latD, latM, latS);
//
//    }
    
    public void initDaegu() {
        initializeProjection(
                DAEGU[N0], DAEGU[N1], DAEGU[N2], DAEGU[N3], DAEGU[N4], DAEGU[N5]
        );
    }

    public void initOsan() {
        initializeProjection(
                OSAN[N0], OSAN[N1], OSAN[N2], OSAN[N3], OSAN[N4], OSAN[N5]
        );
    }

    // FIRST_NEGATIVE_NBR_IN_X_POSITION
    public float systemAirCoordinate(float coord) {

        float system_coord;

        if (coord >= FIRST_NEG_X) {
            system_coord = (coord - (float) (Math.pow(D2, D12) - D1));
        } else {
            system_coord = coord;
        }

        return system_coord * SCALE_IN_SITE_INCREMENTS * YARD_TO_NM;
    }

    private void initializeProjection(int lonD, int lonM, int lonS, int latD,
            int latM, int latS) {

        double originLatRad = 0;
        double originLonRad = 0;
        double originConformalLatRad = 0;
        // 기준점 좌표 세팅
        double originLatitudeDeg = latD + (latM / MIN) + (latS / HOUR);
        double originLongitudeDeg = lonD + (lonM / MIN) + (lonS / HOUR);

        conformalEarthRadius = CONFORMAL_SPHERE_RADIUS;
        epsilon = NUMERIC_EPSILON;
        equatorialRadiusNm = EARTH_EQUATORIAL_RADIUS_NM;

        computeEllipsoid(equatorialRadiusNm, EARTH_FLATTENING);

        originLatRad = originLatitudeDeg * DEGREES_TO_RADIANS;

        originConformalLatRad = toConformalLatRad(originLatRad);

        originLonRad = originLongitudeDeg * DEGREES_TO_RADIANS;

        initProjectionOrigin(
                conformalEarthRadius, originLonRad, originConformalLatRad
        );
    }

    // f : 편평률(flatness)
    private void computeEllipsoid(double eqRadiusNm, double f) {
        this.earthEccentricity = Math.sqrt((D2 * f) - (f * f));
        this.polarEarthRadius = eqRadiusNm * (D1 - f);
        // 2) A~H 계수 계산
        computeCoefficients(this.earthEccentricity);
    }

    private void computeCoefficients(double ecc) {

        double numH = 0;

        double e2 = ecc * ecc;
        double e4 = e2 * e2;
        double e6 = e4 * e2;

        double a = D1 - e2;

        double b = (D1 / D3) * ((D1 - e4) - Math.pow((D1 - e2), D3));

        double c = (D1 / D5) * (D1 - e6) 
                 - (D1 / D3) * Math.pow((D1 - e2), D2) * (D1 - e4) 
                 + (D2 / D15) * Math.pow((D1 - e2), D5);

        double d = (D1 / D7) * (D1 - e2 * e6) 
                 - (D1 / D9) * (D1 - e2) * Math.pow((D1 - e4), D2) 
                 - (D1 / D5) * Math.pow((D1 - e2), D2) * (D1 - e6) 
                 + (D2 / D9) * Math.pow((D1 - e2), D4) * (D1 - e4) 
                 - (D17 / D315) * Math.pow((D1 - e2), D7);

        coefA = a;
        coefB = b;
        coefC = c;
        coefD = d;

        numH = 0; // 줄바꿈방지용 임시

        if (a == D0) {
            this.coefE = D0;
        } else {
            this.coefE = D1 / a;
        }
        coefF = -b / Math.pow(a, D4);
        coefG = ((D3 * b * b) - (a * c)) / Math.pow(a, D7);
        numH = (D8 * a * b * c) - (d * a * a) - (D12 * b * b * b);
        coefH = numH / Math.pow(a, D10);

    }

    private void initProjectionOrigin(double sphereRad, double originLonRad,
            double originConfLatRad) {

        originConformalRadius = sphereRad;
        originConformalLat = originConfLatRad;
        originGeoLon = originLonRad;
        originGeoLat = conformalLatToGeoLat(originConfLatRad);

        originSinConformalLat = Math.sin(originConformalLat);
        originCosConformalLat = Math.cos(originConformalLat);

        scaledRadius4 = D4 * sphereRad;
        scaledRadius4Sq = D4 * originConformalRadius * originConformalRadius;
        scaledRadius4CosOrigin = scaledRadius4 * originCosConformalLat;
        scaledRadius4SinOrigin = scaledRadius4 * originSinConformalLat;
    }

    // phi 지오데시 표준
    private double toConformalLatRad(double phi) {
        double s = Math.sin(phi);
        double s2 = s * s;
        double s4 = s2 * s2;
        double s6 = s4 * s2;

        double poly = coefA + coefB * s2 + coefC * s4 + coefD * s6;

        return Math.asin(poly * s);
    }

//    chi(χ) 등각 위도
    private double conformalLatToGeoLat(double chi) {
        double s = Math.sin(chi);
        double s2 = s * s;
        double s4 = s2 * s2;
        double s6 = s4 * s2;

        double poly = coefE + coefF * s2 + coefG * s4 + coefH * s6;

        return Math.asin(poly * s);
    }

    public void xyToDegLatLon(double x, double y, double[] out) {

        double[] rad = new double[N2];
        
        xyToRadLatLon(x, y, rad);

        out[N0] = Math.toDegrees(rad[N0]); // lat
        out[N1] = Math.toDegrees(rad[N1]); // lon
    }

    public void xyToRadLatLon(double x, double y, double[] out) {

        double x2 = x * x;
        double y2 = y * y;

        double latF = scaledRadius4Sq + x2 + y2;
        double genF = scaledRadius4Sq - x2 - y2;

        double num = (scaledRadius4CosOrigin * y) 
                + (genF * originSinConformalLat);

        double chi = 0.0;
        double lon = 0.0;
        double lat = 0.0;

        if (latF < epsilon) {
            chi = D0;
        } else {
            chi = Math.asin(num / latF);
        }

        lon = originGeoLon + Math.atan2(
                scaledRadius4 * x,
                (genF * originCosConformalLat) - (scaledRadius4SinOrigin * y)
        );

        lat = conformalLatToGeoLat(chi);

        out[0] = lat;
        out[1] = lon;
    }

}
