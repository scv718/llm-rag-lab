/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.LoginHistModel;

import lombok.Data;

@Data
public class LoginHistRes {

    private int idx;
    private String id;
    private String name;
    @JsonProperty("group_id") private String groupId;
    @JsonProperty("group_name") private String groupName;
    private String ip;
    private String type;
    private String result;
    @JsonProperty("login_time") private String loginTime;

    public void setData(LoginHistModel param) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");

        idx = param.getIdx();
        id = param.getUserId();
        name = param.getUserName();
        groupId = param.getGroupId();
        groupName = param.getGroupName();
        ip = param.getUserIp();
        type = param.getOperationType();
        result = param.getOperationResult();
        loginTime = formatter.format(param.getLoginTime());

    }
}
