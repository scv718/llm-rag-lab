/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class StatusModel {

    private Integer statusId;
    private Integer icssA;
    private Integer icssB;
    private Integer smsA;
    private Integer smsB;
    private Integer missA;
    private Integer missB;
    private Integer kissA;
    private Integer kissB;
    private Integer sccA;
    private Integer sccB;
    private Integer switchA;
    private Integer switchB;
    private Integer routerA;
    private Integer routerB;
    private Integer routerM;
    private Date updateTime;

}
