/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.request.SccStatusReq;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class ServerHistStatModel {
    
    private static final int N8 = 8;
    private static final int N100 = 100;
    
    private String trackNumberEnc;
    private byte[] trackNumberHash;
    private String identityEnc;
    private byte[] identityHash;    
    private long cnt;
    private Date updateTime;
    
    private Timestamp startTime;
    private Timestamp endTime;
    
    private int idx;
    private int rowCount;
    private int startIdx;
    
    private String st;
    private String ed;

    public void parseStartTime(LocalDateTime st) {
        startTime = Timestamp.valueOf(st);
    }

    public void parseEndTime(LocalDateTime ed) {
        endTime = Timestamp.valueOf(ed);
    }
    
//    public void setPage(Integer page, Integer listCount) {
//        
//        if (page == null || page == 0) {
//            page = 1;
//        }
//        
//        if (listCount == null || listCount == 0) {
//            listCount = N100;
//        }
//        
//        startIdx = (page - 1) * listCount;
//        rowCount = listCount;
//    }
//    
//    public void setDetailParam(SccStatusReq body, String uk, int pSize,
//            int lSize) throws InvalidKeyException, NoSuchAlgorithmException {
//        
//        st = normalizeDateParam(body.getStartTime());
//        ed = normalizeDateParam(body.getEndTime());
//        setPage(pSize, lSize);
//        
//        if (body.getTrackNumber() != null) {
//            trackNumberHash = hmacSha256(body.getTrackNumber(), uk);
//        }
//    }

    public void setDetailParam(SccStatusReq body, String uk)
            throws InvalidKeyException, NoSuchAlgorithmException {
        
        st = normalizeDateParam(body.getStartTime());
        ed = normalizeDateParam(body.getEndTime());        
        
        if (body.getTrackNumber() != null) {
            trackNumberHash = hmacSha256(body.getTrackNumber(), uk);
        }
    }
    
    public void setDetailMcrcParam(SccStatusReq body, String uk)
            throws InvalidKeyException, NoSuchAlgorithmException {
        
        st = normalizeDateParam(body.getStartTime());
        ed = normalizeDateParam(body.getEndTime());        
        
        if (body.getIdentity() != null) {
            identityHash = hmacSha256(body.getIdentity() + "", uk);
        }
    }
    
    // 3항을 분리했습니다 의도가 맞는지 확인이 필요합니다.
    private String normalizeDateParam(String v) {
        
        if (v == null || (v.trim()).isEmpty()) {
            return null;
        }
        
        return v.substring(0, Math.min(N8, v.length()));
    }

    private byte[] hmacSha256(String data, String key)
            throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] rawHmac = null;

        mac.init(new SecretKeySpec(key.getBytes(), "HmacSHA256"));
        rawHmac = mac.doFinal(data.getBytes());

        return rawHmac;
    }
}
