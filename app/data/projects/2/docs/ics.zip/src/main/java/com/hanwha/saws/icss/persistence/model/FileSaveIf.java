/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.time.LocalDateTime;

public interface FileSaveIf {

    public LocalDateTime getInsertTimeToSave();

    public String getDataToSave();

    public String getFilePathToSave();

    public String getFileNameToSave();
}
