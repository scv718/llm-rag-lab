/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.persistence.model.FileSaveIf;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DBBulkMissFileSaveMgr {
    
    @Value("${ics.hist-data-file-dir.default}") String defaultDataDir;
    @Value("${ics.hist-data-file-dir.mcrc}") String mcrcDataDir;

    @Autowired
    @Qualifier("missFileQueue")
    private ConcurrentLinkedQueue<McrcHistModel> missFileQueue;
   
    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {
        try {
            if (missFileQueue.size() != 0) {
                saveMissDataFile();
            }

        } catch (RuntimeException e) {
            log.warn("missFileSaveThread " + e.toString());
        }

    }

    private void saveMissDataFile() {
        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter fmterH = DateTimeFormatter.ofPattern("yyyyMMddHH");

        String prevHour = null;
        ArrayList<FileSaveIf> hourArr = new ArrayList<>();
        McrcHistModel bean = null;
        LocalDateTime lDTime = null;
        String dStr = null;
        String fileName = null;

        while (!missFileQueue.isEmpty()) {

            bean = missFileQueue.poll();
            MDC.put("LOG_KEY", bean.getLogKInfo());

            lDTime = bean.getInsertTime().toLocalDateTime();
      
            dStr = fmter.format(lDTime);
            fileName = fmterH.format(lDTime);
            bean.setFilePath(dStr);
            bean.setFileName(fileName);

            if ((prevHour == null) || (prevHour.equals(fileName))) {

                hourArr.add(bean);
                prevHour = fileName;

                continue;
            } else if (!prevHour.equals(fileName)) {
                fileWrite(hourArr, defaultDataDir + "/" + mcrcDataDir);
                hourArr.clear();
                hourArr.add(bean);
                prevHour = fileName;
            }
        }

        if (hourArr.size() > 0) {
            fileWrite(hourArr, (defaultDataDir + "/" + mcrcDataDir));
            hourArr.clear();
        }
    }

    private void fileWrite(ArrayList<FileSaveIf> hourArr, String dir) {

        String path = null;
        String fName = null;
        String fullFileName = null;
        StringBuilder sb = new StringBuilder();

        if (hourArr.size() == 0) {
            log.trace("fileWrite none");
            return;
        }

        path = hourArr.get(0).getFilePathToSave();
        fName = hourArr.get(0).getFileNameToSave();
        fullFileName = (dir + "/" + path + "/" + fName);

        try {

            if (!Files.exists(Paths.get(dir + "/" + path))) {
                Files.createDirectories(Paths.get(dir + "/" + path));
            }

            if (!Files.exists(Paths.get(fullFileName))) {
                Files.createFile(Paths.get(fullFileName));
            }

        } catch (IOException | RuntimeException e) {
            log.warn("fileWrite() createFile/Dir " + e.toString());
        }

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(fullFileName, true))) {

            for (FileSaveIf histModel : hourArr) {
                sb = new StringBuilder();
                sb.append(histModel.getInsertTimeToSave().toString());
                sb.append(",");
                sb.append(histModel.getDataToSave());

                writer.write(sb.toString());
                writer.newLine();
            }

        } catch (IOException | RuntimeException e2) {
            log.warn("fileWrite() write " + e2.toString());
        }

    }
}
