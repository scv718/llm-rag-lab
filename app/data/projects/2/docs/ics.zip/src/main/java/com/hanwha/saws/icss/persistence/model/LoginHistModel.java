/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class LoginHistModel {

    private long seqNo;
    private int idx;
    private int totalPage;
    private String userId;
    private String userIp;
    private String userName;
    private int nodeId;
    private String operationType;
    private String operationResult;
    private Date loginTime;
    private Date insertTime;

    private String groupId;
    private String groupName;

    private String startTime;
    private String endTime;
    private int rowCount;
    private int startIdx;

    public void setPage(int page, int listCount) {
        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }

    public void setSearchOPType(String opType) {
        if (opType != null) {
            operationType = opType.toUpperCase();
        }

    }
}
