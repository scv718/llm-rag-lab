/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.util;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MulticastSenderUtil {

    private static final int DEFAULT_MULTICAST_TTL = 10;
    private MulticastSocket socket;
    private InetAddress group;
    private int port;
    private NetworkInterface netIf;

    public MulticastSenderUtil(String mIp, int mPort, String localIp)
            throws IOException {
        InetAddress localAddr = InetAddress.getByName(localIp);
        this.port = mPort;
        this.group = InetAddress.getByName(mIp);
        this.socket = new MulticastSocket();
        this.socket.setTimeToLive(DEFAULT_MULTICAST_TTL);

        this.netIf = NetworkInterface.getByInetAddress(localAddr);

        if (this.netIf == null) {
            throw new IOException("No NetInterface :" + localIp);
        }

        this.socket.setNetworkInterface(netIf);
    }

    public void send(byte[] data) {
        if ((socket == null) || socket.isClosed()) {
            log.warn("Msocket is not available, reinitialize...");

            try {
                this.socket = new MulticastSocket();
                this.socket.setTimeToLive(DEFAULT_MULTICAST_TTL);
                this.socket.setNetworkInterface(netIf);
            } catch (IOException e) {
                log.warn("Failed reinitialize socket: {}", e.getMessage(), e);
                return;
            }
        }

        try {
            DatagramPacket packet = new DatagramPacket(
                    data, data.length, group, port
                );

            socket.send(packet);
        } catch (IOException e) {
            log.warn("Multicast send failed: {}", e.getMessage(), e);
            if ((socket != null) && (!socket.isClosed())) {
                socket.close();
            }
        }
    }

}
