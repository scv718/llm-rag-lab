/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.SmsRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.endpoint.SmsClient;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.SmsEService;
import com.hanwha.saws.icss.service.SmsService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.LogKeyUtil;

import lombok.extern.slf4j.Slf4j;

@Service("SmsEService")
@Slf4j
public class SmsEServiceImpl implements SmsEService {

    private static final int N900 = 900;
    private static final int N1000 = 1000;
    private static final byte EVENT_CLEAR = 0x00;
    
    private static final int ACTIVE = 1;

    @Autowired PropConfig prop;

    @Autowired StatusConfigDao stConfDao;
    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired NonSyncHistDao nonSyncHistDao;

    @Autowired RdbSyncRtService rtSync;

    @Autowired AlarmService alarmService;

    @Value("${prop.host-name}") String hostName;
    @Autowired SmsService smsService;
    @Autowired
    private SmsClient smsClientMgr; // 인터페이스만 의존
    
    @Override
    public void eventHandle(SmsTcpEventBean event) {
        SmsRepo smsCd = SmsRepo.from(event.getOpCode());
        short sK = 0;

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("its standby");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        sK = smsCd.getCode();

        if (sK == SmsRepo.getEventModemStatus().getCode()) {
            modemStatusChange(event);
        } else if (sK == SmsRepo.getEventConvClockChange().getCode()) {
            modelClockChange(event);
        } else if (sK == SmsRepo.getEventFaultControl().getCode()) {
            eventControlFault(event);
        } else if (sK == SmsRepo.getEventRestartControl().getCode()) {
            eventControlRestart(event);
        } else if (sK == SmsRepo.getEventFaultModem().getCode()) {
            eventModemFault(event);
        } else if (sK == SmsRepo.getEventFaultBerThresModem().getCode()) {
            eventModemBerThres(event);
        } else if (sK == SmsRepo.getEventFaultConv().getCode()) {
            eventConvFault(event);
        } else if (sK == SmsRepo.getEventFaultSmoduleOff().getCode()) {
            eventSModuleOffFault(event);
        } else if (sK == SmsRepo.getEventFaultSmoduleDelete().getCode()) {
            eventSModuleDeleteFault(event);
        } else if (sK == SmsRepo.getEventFaultSmodule().getCode()) {
            eventSModuleFault(event);
        } else if (sK == SmsRepo.getEventFaultPower().getCode()) {
            eventPowerFault(event);
        } else if (sK == SmsRepo.getEventFaultTraffic().getCode()) {
            eventTrafficFault(event);
        } else {
            log.info("sms event non type code " + event.getOpCode());
        }

    }

    private void eventTrafficFault(SmsTcpEventBean event) {
        String tMsg = "SMS event Traffic jam fault alarm : {} {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summary = "Send Traffic jam fault";
        AlarmRepo ac = AlarmRepo.getAlmSmsTraffic();

        log.debug(tMsg, node.getName(), event.getDate(), summary);

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summary);
    }

    private void eventPowerFault(SmsTcpEventBean event) {
        String summary = "";
        String tMsg = "SMS event Power fault alarm : {} {} {}";
        boolean isClr = ((event.getServerity() == EVENT_CLEAR) ? true : false);
        AlarmRepo alarmLevel = event.getServerityCode();
        AlarmRepo ac = AlarmRepo.getAlmSmsPwr();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());

        if (event.getPBit() != null) {
            summary = event.getPBit().getAlarmInfo();
        }

        log.debug(tMsg, node.getName(), event.getDate(), summary);

        alarmService.alarmUpdate(isClr, ac, node, alarmLevel, summary);
    }

    private void eventSModuleFault(SmsTcpEventBean event) {

        String summary = "";
        String tMsg = "SMS event SModule fault alarm : {} {} {}";
        boolean isClr = ((event.getServerity() == EVENT_CLEAR) ? true : false);
        AlarmRepo alarmLevel = event.getServerityCode();
        AlarmRepo lv = AlarmRepo.getAlmSmsCrypto();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());

        if (event.getSBit() != null) {
            summary = event.getSBit().getAlarmInfo();
        }

        log.debug(tMsg, node.getName(), event.getDate(), summary);

        alarmService.alarmUpdate(isClr, lv, node, alarmLevel, summary);
    }

    private void eventSModuleDeleteFault(SmsTcpEventBean event) {
        String tMsg = "SMS event SModule Crypto delete fault alarm : {} {} {}";
        boolean isClr = ((event.getServerity() == EVENT_CLEAR) ? true : false);
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summary = "Crypto Delete";
        AlarmRepo ac = AlarmRepo.getAlmSmsCryptoDelete();

        log.debug(tMsg, node.getName(), event.getDate(), summary);

        alarmService.alarmUpdate(isClr, ac, node, alarmLevel, summary);
    }

    private void eventSModuleOffFault(SmsTcpEventBean event) {
        String tMsg = "SMS event SModule Off fault alarm : {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summary = "Crypto Off";
        AlarmRepo ac = AlarmRepo.getAlmSmsCryptoOff();

        log.debug(tMsg, node.getName(), event.getDate());

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summary);
    }

    private void eventConvFault(SmsTcpEventBean event) {

        String msg = "";
        String tMsg = "SMS event control fault alarm : {} {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summary = "";
        AlarmRepo ac = AlarmRepo.getAlmSmsConv();

        if (event.getIBit() != null) {
            msg = event.getIBit().getErrCode();
        }

        log.debug(tMsg, node.getName(), event.getDate(), msg);

        if (!isClear && (event.getIBit() != null)) {
            summary = event.getIBit().getAlarmInfo();
        }

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summary);
    }

    private void eventModemBerThres(SmsTcpEventBean event) {
        String tMsg = "SMS event control fault alarm : {} {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summary = "modulation threshold " + event.getBerCount();
        AlarmRepo ac = AlarmRepo.getAlmSmsModemBerFault();

        log.debug(tMsg, node.getName(), event.getDate(), event.getBerCount());

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summary);
    }

    private void eventModemFault(SmsTcpEventBean event) {
        String msg = "";
        String tMsg = "SMS event modulation fault alarm : {} {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        String summery = "";
        boolean isAlarmClear = false;
        AlarmRepo ac = AlarmRepo.getAlmSmsModem();

        if (event.getTBit() != null) {
            msg = event.getTBit().getErrCode();
        }

        log.debug(tMsg, node.getName(), event.getDate(), msg);

        if (!isClear && event.getTBit() != null) {
            summery = event.getTBit().getAlarmInfo();
            isAlarmClear = ((summery == null) ? true : false);
            isClear = isAlarmClear;
        }

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summery);
    }

    private void eventControlRestart(SmsTcpEventBean event) {
        String tMsg = "SMS event control restart alarm : {} {} {}";
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        String summary = "control restart";
        AlarmRepo ac = AlarmRepo.getAlmSmsControlRestart();

        log.debug(tMsg, node.getName(), event.getDate(), event.getServerity());
        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summary);

    }

    private void eventControlFault(SmsTcpEventBean event) {
        String msg = "";
        String tMsg = "SMS event control fault alarm : {} {} {}";
        boolean isClear = (event.getServerity() == EVENT_CLEAR) ? true : false;
        AlarmRepo alarmLevel = event.getServerityCode();
        NodeModel node = prop.getNodeInfoHash().get(event.getCode().getCode());
        boolean isAlarmClear = false;
        String summery = "";
        AlarmRepo ac = AlarmRepo.getAlmSmsControl();

        if (event.getCBit() != null) {
            msg = event.getCBit().getErrCode();
        }

        log.debug(tMsg,node.getName(), event.getDate(), msg);

        if (!isClear && (event.getCBit() != null)) {
            summery = event.getCBit().getAlarmInfo();
            isAlarmClear = ((summery == null) ? true : false);
            isClear = isAlarmClear;
        }

        alarmService.alarmUpdate(isClear, ac, node, alarmLevel, summery);
    }

    private void modemStatusChange(SmsTcpEventBean event) {

        StatusRepo lCode = null;
        StatusModel param = new StatusModel();
        String summaryLog = null;
        AlarmRepo ac = AlarmRepo.getAlmFailover();
        AlarmRepo lv = AlarmRepo.getSvrInfo();

        try {

            if (event.isActive()) {
                lCode = StatusRepo.getACTIVE();
            } else {
                if (event.isWarn()) {
                    lCode = StatusRepo.getWARNING();
                } else {
                    lCode = StatusRepo.getSTANDBY();
                }
            }

            log.debug("EVENT_MODEM_STATUS " + event.getCode().getName() + "  " +
                    lCode.getName());

            if (event.getCode().getCode() == NodeRepo.getSmsA().getCode()) {
                param.setSmsA(lCode.getCode());
            } else {
                param.setSmsB(lCode.getCode());
            }

            log.debug("UPDATE NODE STATUS " + event.getCode().getName() + "  " +
                    lCode.getName());

//            stConfDao.updateStatus(param);
//            rtSync.insertQueue(param, "UPDATE");

            summaryLog = "EVENT_MODEM_STATUS " + event.getCode().getName() 
                       + "  " + lCode.getName();
            
            eventModeStatusChangeUpdate(param, lCode, event.getCode(),
                    summaryLog);
            
            smsActiveFailoverBeat();
            //여기서 직접 수정하는게 아니라 ALARM HEARTBEAT에서 알람 등록할때 까지 놔둠
            //상태만 업데이트 함 
            //월요일 와서 INFO가 아니라 WARN조건도 포함하는 뭔가 넣어야 할 거 같음 그리고 테스트 필요 
//            insertAlarmHist(event.getCode(), ac, lv, summaryLog);
            
        } catch (RuntimeException | IOException e) {
            log.warn("modemStatusChange() " + event.getCode() + " " + lCode);
        }

    }
    
    private void eventModeStatusChangeUpdate(StatusModel param,
            StatusRepo lCode, NodeRepo tNode,String summaryLog) {
        
        String tLogMsg = "";
        List<StatusModel> statusList = null;
        Integer targetCode = 0;
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrInfo();
        
        if (lCode.getCode() == SmsRepo.getStatusUnknown().getCode()) {
            tLogMsg = tNode.getName() + " heartbeat ";
            log.debug(tLogMsg + "UNKNOWN");   
            smsClientMgr.addUnknownCount(tNode);
        }else {
            smsClientMgr.setUnknownInit(tNode);
        }
        insertAlarmHist(tNode, ac, lv, summaryLog);
        
        statusList = stConfDao.selectStatusList();
        
        if ((statusList == null) || (statusList.size() == 0)) {
            return;
        }
        
        if (tNode.getCode() == NodeRepo.getSmsA().getCode()) {
            targetCode = statusList.get(0).getSmsA();
        } else {
            targetCode = statusList.get(0).getSmsB();
        }
        
        //변경 건 업데이트 해야함 
        if (targetCode != lCode.getCode()) {
            stConfDao.updateStatus(param);
            rtSync.insertQueue(param, "UPDATE");
        }
        
    }

    private void modelClockChange(SmsTcpEventBean event) {

        StatusRepo lCode = null;
        String summaryLog = null;
        String tMsg = "EVENT MODEM CLOCK CHANGE {} {}";
        AlarmRepo ac = AlarmRepo.getAlmSmsClockChange();
        AlarmRepo lv = AlarmRepo.getSvrInfo();

        try {

            if (event.isActive()) {
                lCode = StatusRepo.getACTIVE();
            } else {
                lCode = StatusRepo.getSTANDBY();
            }

            log.debug(tMsg, event.getCode(), lCode);
            summaryLog = event.getCode().getName() + " " +
                    event.getInternalMsg();

            insertAlarmHist(event.getCode(), ac, lv, summaryLog);
        } catch (RuntimeException e) {
            log.warn("modelClockChange() " + event.getCode() + " " + lCode);
        }

    }

    private void insertAlarmHist(NodeRepo nodeCode, AlarmRepo code,
            AlarmRepo svrLevel, String summaryMsg) {

        NodeModel node = prop.getNodeInfoHash().get(nodeCode.getCode());
        AlarmHistModel aHMBean = new AlarmHistModel();

        aHMBean.setTime();
        aHMBean.setCurrUuid(UUID.randomUUID().toString().replace("-", ""));
        aHMBean.setNodeId(node.getNodeId());
        aHMBean.setNodeName(node.getName());
        aHMBean.setAddrIp(node.getAddrIp());
        aHMBean.setAlarmId(code.getCode());
        aHMBean.setAlarmName(code.getMsg());
        aHMBean.setServerity(svrLevel.getCode());
        aHMBean.setLocation(node.getAddrIp());
        aHMBean.setSummary(summaryMsg);
        aHMBean.setRecoverReason(null);
        aHMBean.setRecoverTime(null);
        aHMBean.setTally(1);
        aHMBean.setFirstOccurrence(new Date());
        aHMBean.setLastOccurrence(new Date());
        syncHistInsertService.insertAlarmHist(aHMBean);

    }

    private void smsActiveFailoverBeat() throws IOException {
        
        boolean isSmsAUnknown = false;
        boolean isSmsBUnknown = false;
        
        boolean isSmsAStandby = false;
        boolean isSmsBStandby = false;    
        
        boolean isSmsAActive = false;
        boolean isSmsBActive = false;
        
        boolean isChange = false;
        NodeModel tNode = null;
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        List<StatusModel> statusList = null;
        int smsAMode = 0;
        int smsBMode = 0;
      
        try {                        
            statusList = stConfDao.selectStatusList();
            if ((statusList == null) || (statusList.size() == 0)) {
                return;
            }

            nH.get(NodeRepo.getSmsA().getCode())
                    .setActiveMode(statusList.get(0).getSmsA());
            nH.get(NodeRepo.getSmsB().getCode())
                    .setActiveMode(statusList.get(0).getSmsB());
          
            smsAMode = statusList.get(0).getSmsA();
            smsBMode = statusList.get(0).getSmsB();
            
            tNode = nH.get(NodeRepo.getSmsA().getCode());
            
            if (smsAMode == StatusRepo.getUNKNOWN().getCode() 
                    || smsAMode == StatusRepo.getWARNING().getCode()) {
                isSmsAUnknown = true;
            } else if (smsAMode == SmsRepo.getStatusStandby().getCode()) {
                isSmsAStandby = true;
            } else if (smsAMode == SmsRepo.getStatusActive().getCode()) {
                isSmsAActive = true;
            }

            tNode = nH.get(NodeRepo.getSmsB().getCode());

            if (smsBMode == StatusRepo.getUNKNOWN().getCode() 
                    || smsBMode == StatusRepo.getWARNING().getCode()) {
                isSmsBUnknown = true;
            } else if (smsBMode == SmsRepo.getStatusStandby().getCode()) {
                isSmsBStandby = true;
            } else if (smsBMode == SmsRepo.getStatusActive().getCode()) {
                isSmsBActive = true;
            }
            
            if (prop.isModemSendMode()) {
                if (isSmsAUnknown && isSmsBStandby) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(),
                            tNode.getNodeId());
                    isChange = true;
                } else if (isSmsBUnknown && isSmsAStandby) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(),
                            tNode.getNodeId());
                    isChange = true;
                }
                
                if (isSmsAStandby && isSmsBStandby) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(), tNode.getNodeId()
                    );
                    isChange = true;
                }
              
                if (isSmsAActive && isSmsBActive) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                    isChange = true;
                }
            } else {
                if (isSmsAActive) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                    isChange = true;
                }
                
                if (isSmsBActive) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                    isChange = true;
                }
                
            }
            
            if (isChange) {
                log.debug("EVENT STATUS CHANGE");
                smsService.heartbeat(NodeRepo.getSmsA());
                smsService.heartbeat(NodeRepo.getSmsB());
            }
            
        } catch (NoClassDefFoundError e) {
            log.warn("smsActiveFailoverBeat() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("smsActiveFailoverBeat " + e.toString(), e);
        }

    }
}
