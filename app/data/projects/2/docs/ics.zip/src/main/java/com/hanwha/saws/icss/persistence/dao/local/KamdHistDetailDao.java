/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;

public interface KamdHistDetailDao {
    public void insertKamdHistDetailBulkInsert(List<KamdHistDetailModel> list);

    public List<KamdHistDetailModel>
            selectKamdDetailHistList(KamdHistDetailModel param);
    
    public long selectKamdDetailHistTotalCount(KamdHistDetailModel param);

}
