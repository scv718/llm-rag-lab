/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Scope("prototype")
@Slf4j
public class KamdClientHandler implements Runnable {

    private static final int N4 = 4;
    private static final int N99 = 99;
    private static final String HB_STARTER = "AMD0090";

    private Socket socket;
    private AtomicLong lastReceivedTime;
    private Consumer<String> kamdRecvQueue;

    public KamdClientHandler init(Socket socket, AtomicLong lastReceivedTime,
            ConcurrentLinkedQueue<String> queue) {
        this.socket = socket;
        this.lastReceivedTime = lastReceivedTime;

        this.kamdRecvQueue = queue::offer;

        return this;
    }

    @Override
    public void run() {
        String errSockMsg = "Error closing client socket: {}";

        try (var is = new DataInputStream(socket.getInputStream())) {
            byte[] temp = new byte[N4];
            String tempS = null;
            is.readFully(temp);
            tempS = new String(temp);

            if ((!tempS.equals("0603")) && (!tempS.equals("8282"))) {
                return;
            }

            while (true) {
                int type = is.readInt();
                int size = is.readInt();
                byte[] buffer = null;
                String data = null;
                if (type == N99) {
                    break;
                }

                buffer = new byte[size];
                is.readFully(buffer);

                /*
                 * // String rawStr = new String(buffer); 
                 * // 디코딩 charset 필요시 명시
                 * (ex: UTF-8) // log.info("KAMD RAW STRING: '{}'", rawStr);
                 */
                if (type != 0) {
                    continue;
                }

                data = new String(buffer);

                if (!data.contains(HB_STARTER)) {
                    log.info("KAMD RECEIVED DATA({} bytes) from {}", size,
                            socket.getRemoteSocketAddress());
                }
//                kamdRecvQueue.offer(data);
                kamdRecvQueue.accept(data);
                lastReceivedTime.set(System.currentTimeMillis());

            }

        } catch (IOException e) {
            log.warn("Error reading client data: {}", e.getMessage(), e);
        }
        if (socket != null) {
            try {
                log.debug("Client disconn: {}",
                        socket.getRemoteSocketAddress());
                socket.close();
            } catch (IOException e) {
                log.warn(errSockMsg, e.getMessage(), e);
            }
        }
    }

}