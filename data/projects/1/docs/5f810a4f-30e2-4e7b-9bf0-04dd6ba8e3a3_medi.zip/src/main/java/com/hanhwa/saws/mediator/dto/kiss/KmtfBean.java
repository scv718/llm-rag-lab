/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.kiss;

import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class KmtfBean {

    private static final String TOKEN = "/";
    private static final String LINE_TERMINATOR = "//";
    private static final String SPACE = "-";
    private static final String ESCAPE = "\\";

    private static final String TAG_INTRO = "INTRO//";
    private static final String TAG_BODY = "BODY//";
    private static final String TAG_CLOSE = "CLOSE//";

    private static final String HEADER_MAN = "KMTF";
    private static final String HEADER_OPT = "EDX";
    private static final String MODE_OPER = "OPER";
    private static final String MODE_EXER = "EXER";
    private static final int HEARTBEAT_CONTENT_COUNT = 3;

    private static final String DATE_FORMAT = "yyyyMMddhhmmss";

    private static final int CONTENT_COUNT = 26;
    private static final int N2 = 2;
    private static final String HB_STARTER = "AMD0090";
    private static final String SIMUL_HB = "S";

    private String ntpDate = null;
    private boolean heartBeat = false;

    private List<KmtfSegment> segmentList = new ArrayList<>();

    public void decode(List<String> kmtfData) {

        boolean detected = false;
        String tag = null;
        String[] contents = null;
        String modLine = null;
        int lineIndex = 0;
        KmtfSegment segment = null;
        int colonIndex = 0;
        String starterTok = null;

        try {
            for (String line : kmtfData) {
                lineIndex = line.indexOf(LINE_TERMINATOR);
                colonIndex = line.indexOf(":");

                if (line.equals(TAG_BODY)) {
                    detected = true;
                    continue;
                } else if (line.equals(TAG_CLOSE)) {
                    break;
                } else if (line.startsWith(HEADER_OPT)) {
                    tag = line.substring(colonIndex + 1, colonIndex + N2);
                } else if (line.startsWith(HEADER_MAN)) {
                    contents = line.substring(0, lineIndex).split(TOKEN);
                    ntpDate = contents[contents.length - 1];
                }

                if (detected) {
                    if (line.endsWith(LINE_TERMINATOR)) {
                        modLine = line.substring(0, lineIndex);
                        contents = modLine.split(TOKEN);

                        // starter(첫 토큰)가 AMD0090이면 하트비트로 인정
                        starterTok = (contents.length > 0) ? contents[0] : null;

                        if (HB_STARTER.equalsIgnoreCase(starterTok)) {
                            // 만약에 시뮬이면 AMD0090/S/EDX1//
//                            if (contents.length > 1 &&
//                                    SIMUL_HB.equalsIgnoreCase(contents[1])) {
//                                log.debug("Simul Heartbeat skip");
//                                continue;
//                            }

                            setHeartBeat(true);
                            log.debug("Heartbeat (starter=) raw={}", modLine);
                            continue;
                        }

                        if (contents.length == CONTENT_COUNT) {
                            log.debug("KMTF CONTENT_COUNT= {}",contents.length);
                            segment = new KmtfSegment();
                            segment.decode(contents, tag);
                            segmentList.add(segment);
                        }

                    }
                } else {
                    continue;
                }
            }
        } catch (RuntimeException e) {
            log.warn("Exception during KMTF decode: {}", e.getMessage(), e);
            throw e;
        }
    }

    public ArrayList<byte[]> encode() {
        ArrayList<byte[]> bean = new ArrayList<>();

        for (KmtfSegment seg : segmentList) {
            log.info("Cudm : {}", seg.getCudm());
            if ("D".equalsIgnoreCase(seg.getCudm())) {
                log.info("KMTF Delete");
                // TODO : KMTF 삭제 요청 처리 부분 요구사항에 따라 아래 기능 추가/삭제 결정
                bean.add(seg.encodeKmtfDelete());
            } else {
                bean.add(seg.encode());
            }
        }

        log.debug("Total KMTF segments encoded: {}", bean.size());
        return bean;
    }

    public String getNtpDate() {
        return ntpDate;
    }

    public void setNtpDate(String ntpServerDate) {
        this.ntpDate = ntpServerDate;
    }

    public boolean isHeartBeat() {
        return heartBeat;
    }

    public void setHeartBeat(boolean hBeat) {
        this.heartBeat = hBeat;
    }
}
