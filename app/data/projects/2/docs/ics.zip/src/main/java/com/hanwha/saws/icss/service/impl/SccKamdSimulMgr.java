/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.kiss.MissleTrackSduBean;
import com.hanwha.saws.icss.endpoint.KissListener;
import com.hanwha.saws.icss.persistence.dao.local.SimulDao;
import com.hanwha.saws.icss.persistence.model.KamdSimulModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccKamdSimulMgr {

    private static final int BFF = 0xFF;
    private static final int N2 = 2;
    private static final byte KAMD_TRAIN_END = 0x07;
    private static final String ICSS_A_DIR = "ICSS_A";

    private List<String> simulList = null;
    private ArrayList<KamdSimulModel> tSendSimList = null;
    private KamdSimulModel qData = null;
    private List<KamdSimulModel> kamdList = null;

    @Value("${ics.group-byte-length}")
    int groupByteLength;
    @Value("${scc.send-port}")
    int sccPort;

    @Autowired
    KissListener kissListener;

    @Autowired
    private SccServiceImpl sccService;

    @Autowired
    @Qualifier("kamdSimulMap")
    private ConcurrentHashMap<String, Integer> kamdSimulMap;

    @Autowired
    SimulDao simulDao;

    @Autowired
    PropConfig prop;

    @Scheduled(fixedDelayString = "4000", initialDelayString = "3000")
    public void monitor() {

        int mSTmp = 0;

        simulList = new ArrayList<String>(kamdSimulMap.keySet());

        tSendSimList = new ArrayList<>();

        for (String key : simulList) {

            qData = new KamdSimulModel();
            qData.setSimulNo(Integer.parseInt(key));
            qData.setKamdRoute(kamdSimulMap.get(key));
            kamdList = simulDao.selectKamdSimulList(qData);

            if (kamdList.size() == 0) {
                kamdSimulMap.remove(key);
                log.debug("KAMD SIMUL SEND FINISH");
                simulEndAlarm(Integer.parseInt(key));
            } else {
                mSTmp = (kamdSimulMap.get(key) + 1);
                kamdSimulMap.put(key, mSTmp);
                tSendSimList.addAll(kamdList);
            }
        }
        makeKamdQueue(tSendSimList);
    }

    private void makeKamdQueue(ArrayList<KamdSimulModel> tSendList) {
        MissleTrackSduBean mstBean = new MissleTrackSduBean();
        ArrayList<byte[]> smList = null;
        String mIp = sccService.getSimulSenderIp();

        if (tSendList.size() > 0) {
            smList = mstBean.getSimulEncode(tSendList);

            for (byte[] bs : smList) {
                kissListener.putQueue(new RecvMsgQueueBean(bs, mIp));
            }
        }
    }

    private void simulEndAlarm(int simulNo) {
        ByteBuffer bBufTmp = ByteBuffer.allocate(groupByteLength);
        HashMap<Integer, NodeModel> nHList = prop.getNodeInfoHash();
        ByteBuffer bBuf = null;
        byte[] gB = null;
        byte[] rMsgB = null;

        for (int i = 0; i < groupByteLength; i++) {
            bBufTmp.put((byte) BFF);
        }

        gB = bBufTmp.array();
        bBuf = ByteBuffer.allocate((N2 + gB.length + N2));
        bBuf.put(STypeRepo.getCtlCmd().getCode());
        bBuf.put((byte) (gB.length + N2));
        bBuf.put(gB);
        bBuf.put(KAMD_TRAIN_END);
        bBuf.put((byte) simulNo);
        rMsgB = bBuf.array();

        sendUdp(nHList.get(NodeRepo.getSccA().getCode()), sccPort, rMsgB);
        sendUdp(nHList.get(NodeRepo.getSccB().getCode()), sccPort, rMsgB);
    }

    private boolean sendUdp(NodeModel info, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket packet = null;

            packet = new DatagramPacket(data, data.length, mcastaddr, port);
            
            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccService sendUdpData()" + e.toString());
            return false;
        }

        return true;
    }

}
