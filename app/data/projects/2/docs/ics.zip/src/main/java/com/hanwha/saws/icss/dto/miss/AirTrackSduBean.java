/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.miss;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hanwha.saws.icss.dto.CommonHeaderSduBean;
import com.hanwha.saws.icss.dto.kiss.MissleTrackVOBean;
import com.hanwha.saws.icss.persistence.model.McrcSimulModel;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class AirTrackSduBean {

    private static final int N0 = 0;
    private static final int N2 = 2;
    private static final int N4 = 4;
    private static final int N500 = 500;
    private static final int B00 = 0x00;
    private static final int B0F = 0x0F;
    private static final int BFF = 0xFF;
    
    private static final long SERIALVERSIONUID = 4709012600880909642L;

    private static final int MO_SIZE = 11;
    private static final int MO_MAX_CNT = 5;

    private static final int SIM_MO_SIZE = 28;
    private static final int SIM_MO_MAX_CNT = 2;

    private static final byte MSG_TYPE = 0x05;

    private static final int SEGMENT_SIZE = 11;
    private static final int SEGMENT_MAX_CNT = 5;

    private static final int SIM_SEGMENT_SIZE = 28;
    private static final int SIM_SEGMENT_MAX_CNT = 2;

    private static final int SIMULATION_CODE = 2;

    private CommonHeaderSduBean header;
    private byte[] originFilterByte;

    private int moCnt;
    boolean isSimulData = false;

    private List<AirTrackMOBean> mos = null;
    private Timestamp recvTime;

    public AirTrackSduBean(byte[] pdu) throws IOException, RuntimeException {
        try {
            decode(ByteBuffer.wrap(pdu));
        } catch (IOException | RuntimeException e) {
            log.warn("Air track data decoded InValid. skip");
            throw e;
        }
    }

    public AirTrackSduBean() {}

    private void decode(ByteBuffer dBuf) throws IOException {
        
        try {
            AirTrackMOBean vo = null;
            int length = 0;

            header = new CommonHeaderSduBean(dBuf.get(), dBuf.get());

            length = header.getPayloadLengthInt();

            if ((length > 0) && (length % SIM_MO_SIZE == 0)) {
                isSimulData = true;
            }

            moCnt = length / (isSimulData ? SIM_MO_SIZE : MO_SIZE);

            mos = new ArrayList<>();

            for (int i = 0; i < moCnt; i++) {
                vo = new AirTrackMOBean();
                vo.decode(dBuf, isSimulData);
                mos.add(vo);
            }

            originFilterByte = encode();

        } catch (IOException e) {
            log.warn(e.toString(),e);
            throw e;
        }

    }

    public void setFilterMoList(List<AirTrackMOBean> moList) {
        mos = (moList == null) ? null : List.copyOf(moList);
        try {
            moCnt = moList.size();
            originFilterByte = encode();
        } catch (IOException e) {
            log.warn(e.toString(), e);
        }

    }

    private byte[] encode() throws IOException {

        int bLen = (isSimulData ? (moCnt * SIM_MO_SIZE) : (moCnt * MO_SIZE));
        byte hLen = ((mos == null) ? B00 : (byte) bLen);
        ByteBuffer b = null;
        
        header = new CommonHeaderSduBean(MSG_TYPE, hLen);

        b = ByteBuffer.allocate(header.getHeader().length + bLen);
        b.put(header.getType());
        b.put(header.getPayloadLength());

        if (mos != null) {
            for (int i = 0; i < moCnt; i++) {
                b.put(mos.get(i).encode());
            }
        }

        return b.array();
    }

    public ArrayList<byte[]> getSimulEncode(List<McrcSimulModel> l, int refP) {

        ArrayList<byte[]> encodeByteList = new ArrayList<>();
        ArrayList<byte[]> mcrcPacketList = new ArrayList<>();
        ArrayList<byte[]> tmp = new ArrayList<>();

        byte ref = (byte) refP;
        ByteBuffer sBuf = null;

        int id = 0;
        int flightSize = 0;
        byte packed = 0;
        double xPosition = 0;
        double yPosition = 0;
        short speed = 0;
        short direction = Short.parseShort("1");
        int bLen = 0;
        int pLen = 0;
        ByteBuffer buffer = null;
        int dvInt = 0;
        int scaled = 0;
        
        for (McrcSimulModel m : l) {
            sBuf = ByteBuffer.allocate(SIM_SEGMENT_SIZE);
            id = Integer.parseInt(m.getMcrcType()) & B0F;
            flightSize = (Integer.parseInt(m.getMcrcCount()) & B0F);
            packed = (byte) ((id << N4) | flightSize);
            xPosition = Double.parseDouble(m.getMcrcLocationX());
            yPosition = Double.parseDouble(m.getMcrcLocationY());
            speed = Short.parseShort(m.getMcrcKnot());
            direction = Short.parseShort(m.getMcrcDirection());
            
            sBuf.put((byte) (((SIMULATION_CODE << N4) | (ref & BFF)) & BFF));
            sBuf.put(m.getMcrcCode().getBytes());
            sBuf.put(packed); // 1byte
            sBuf.putDouble(xPosition);
            sBuf.putDouble(yPosition);
            sBuf.putShort(speed);
            sBuf.putShort(direction);
            
            dvInt = Integer.parseInt(m.getMcrcFeet());
            scaled = dvInt / N500;
            sBuf.put((byte) (scaled & BFF));

            encodeByteList.add(sBuf.array());
        }

        for (byte[] bs : encodeByteList) {

            tmp.add(bs);

            if (tmp.size() == N2) {

                bLen = SIM_MO_SIZE * SIM_MO_MAX_CNT;
                header = new CommonHeaderSduBean(MSG_TYPE, (byte) bLen);
                pLen = header.getHeader().length + bLen;
                buffer = ByteBuffer.allocate(pLen);
                buffer.put(header.getType());
                buffer.put(header.getPayloadLength());

                for (byte[] eb : tmp) {
                    buffer.put(eb);
                }

                mcrcPacketList.add(buffer.array());
                tmp.clear();
            }
        }

        if (!tmp.isEmpty()) {

            bLen = SIM_MO_SIZE;
            header = new CommonHeaderSduBean(MSG_TYPE, (byte) bLen);

            pLen = header.getHeader().length + bLen;
            buffer = ByteBuffer.allocate(pLen);
            buffer.put(header.getType());
            buffer.put(header.getPayloadLength());

            for (byte[] b2 : tmp) {
                buffer.put(b2);
            }

            mcrcPacketList.add(buffer.array());
            tmp.clear();
        }

        return mcrcPacketList;
    }
    
//    public String getDecodeDataResult() {
//        
//        StringBuilder sb = new StringBuilder();
//        
//        // byteString 바꾸고 싶으면 HexByteUtil.getHexStringToByte
//        sb.append("SIMUL DATA : ").append(isSimulData).append("\n");
//        sb.append("Header");
//        sb.append("\n       type : " + (int) header.getTypeInt()); 
//        sb.append("\n       length : " + header.getPayloadLengthInt());
//        
//        for (int i = 0; i < mos.size(); i++) {
//            AirTrackMOBean  bean = mos.get(i);
//            sb.append("\n       Message Object " + i);
//            sb.append("\n           Ref Position: " + bean.getRefPosition());
//            sb.append(
//                    "\n          Simul Live State : " + bean.getSimLiveState()
//            );
//            sb.append("\n         Track Number: " + bean.getTrackNumberStr());
//            sb.append(
//                    "\n          Flight Size(0:known, 1: 1, 2:2~7, 3: >8 : " +
//                            bean.getFlightSize()
//            );
//            sb.append("\n           Identity : " + bean.getIdentityStr());
//            
//            if (bean.getSimLiveState() != N2) {
//                int xPosition = ((bean.getXPosition() & 0x800) != 0)
//                                ?(bean.getXPosition() | 0xFFFFF000) 
//                                : bean.getXPosition();
//                int yPosition = ((bean.getYPosition() & 0x800) != 0)
//                                ? (bean.getYPosition() | 0xFFFFF000) 
//                                : bean.getYPosition();
//                sb.append("\n           X Position : " + xPosition);
//                sb.append("\n           Y Position : " + yPosition);
//                sb.append(
//                        "\n           X Velocity : " + bean.getXVelocityInt()
//                );
//                sb.append(
//                        "\n           Y Velocity : " + bean.getYVelocityInt()
//                );
//            } else {
//                sb.append("\n           X Position : " + bean.getLongitude());
//                sb.append("\n           Y Position : " + bean.getLatitude());
//                sb.append("\n           Speed : " + bean.getSpeed());
//                sb.append("\n           Direction : " + bean.getCourse());
//            }
//            sb.append("\n           Atitude : " + bean.getAltitudeInt());
//        }
//
//        sb.append("     length : " + header.getPayloadLengthInt());
//        return sb.toString();
//        
//    }

}
