/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;

import lombok.Data;

@Data
public class SmtStatusHistRes {

    private Long idx;
    private Long seq;
    @JsonProperty("node_id") private Integer nodeId;
    @JsonProperty("node_name") private String nodeName;
    @JsonProperty("ip") private String ipAddr;
    @JsonProperty("type_1") private String type1;
    @JsonProperty("type_2") private String type2;
    @JsonProperty("type_3") private String type3;
    @JsonProperty("type_4") private String type4;
    @JsonProperty("type_5") private String type5;
    @JsonProperty("insert_time") private String insertTime;

    @JsonIgnore
    public void setData(StatusHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

        idx = data.getIdx();
        seq = data.getSeqNo();
        nodeId = data.getNodeId();
        nodeName = data.getNodeName();

        seq = data.getIdx();
        nodeId = data.getNodeId();
        nodeName = data.getNodeName();
        ipAddr = data.getIpAddr();
        type1 = data.getType1();
        type2 = data.getType2();
        type3 = data.getType3();
        type4 = data.getType4();
        type5 = data.getType5();
        insertTime = sdf.format(data.getInsertTime());

    }
}
