/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.common.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hanhwa.saws.mediator.common.service.MediatorService;
import com.hanhwa.saws.mediator.config.MediatorConfig;
import com.hanhwa.saws.mediator.dto.code.ResponseCode;
import com.hanhwa.saws.mediator.dto.request.AlarmVo;
import com.hanhwa.saws.mediator.dto.request.BaseResponse;
import com.hanhwa.saws.mediator.dto.request.DianosisResponseVo;
import com.hanhwa.saws.mediator.util.StatusUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MediatorServiceImpl implements MediatorService {

    private static final int N1000 = 1000;

    @Autowired private MediatorConfig mediatorConfig;
    @Value("${server.local-ip}") private String localIp;

    @Override
    @Async
    public void resetSystem() {

        String sPath = "";
        ProcessBuilder processBuilder = null;

        try {
            log.info("Preparing to restart system...");
//            Thread.sleep(N1000);
            LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(N1000));

            sPath = mediatorConfig.getRestartScript();
            log.debug("Using restart script path: {}", sPath);

            processBuilder = new ProcessBuilder("bash", "-c", sPath + " &");

            processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
            processBuilder.redirectError(ProcessBuilder.Redirect.INHERIT);

            processBuilder.start();

            log.debug("Restart script launched in background.");
        } catch (RuntimeException e) {
            log.warn("Failed to execute restart script: {}", e.getMessage(), e);
//            Thread.currentThread().interrupt();
        } catch (IOException e) {
            log.warn("Failed to execute I/O script: {}", e.getMessage(), e);
        }
    }

    @Override
    public DianosisResponseVo getDiagnosis() {
        DianosisResponseVo response = new DianosisResponseVo();

        response.setCpu(StatusUtil.getCpuUsage());
        response.setHdd(StatusUtil.getDiskUsage());
        response.setMem(StatusUtil.getMemUsage());
        response.setAlarmList(getActiveAlarms());

        log.debug("Dianosis Response " + response);
        return response;
    }

    @Override
    public BaseResponse pingCheck(String ip) {
        
        boolean routerAlive = isPingAlive(ip);

        if (routerAlive) {
            return new BaseResponse(ResponseCode.C200);
        } else {
            return new BaseResponse(
                    ResponseCode.C400,
                    "Router connect fail"
                );

        }

    }

    private boolean isPingAlive(String ip) {
        try {
            
            String[] command = null;
            Process process = null;
            int result = 0;
            //int exitCode = 0;
            
            /*
             * StringBuilder sb = new StringBuilder(); 
             * sb.append("ping");
             * sb.append(" -I ").append(localIp);
             * sb.append(" -c 1");
             * sb.append(" -W 1");
             * sb.append(" ").append(ip);
             * command = sb.toString().split(" ");
             * process = new ProcessBuilder(command).start();
             */
            ProcessBuilder pb = new ProcessBuilder(List.of(
                    "ping", "-I", localIp, "-c","1","-W","1",ip
            ));
            process = pb.start();
            process.toHandle().onExit().join();
            result = process.exitValue();
//            result = process.waitFor();
            log.debug("Ping from {} to {} exitCode: {}", localIp, ip, result);

            return result == 0;
        } catch (IOException e) {
            log.warn("Ping failed (from {} to {}): {}",
                    localIp,
                    ip,
                    e.getMessage()
                    );
            return false;
        } 
    }

    private List<AlarmVo> getActiveAlarms() {

        return AlarmVo.getList();
    }

}
