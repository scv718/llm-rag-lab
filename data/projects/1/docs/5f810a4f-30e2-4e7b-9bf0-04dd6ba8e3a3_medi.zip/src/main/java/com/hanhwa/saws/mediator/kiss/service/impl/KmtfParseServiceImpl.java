/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */

package com.hanhwa.saws.mediator.kiss.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hanhwa.saws.mediator.common.service.AlarmService;
import com.hanhwa.saws.mediator.dto.kiss.KmtfBean;
import com.hanhwa.saws.mediator.kiss.service.KamdNtpService;
import com.hanhwa.saws.mediator.kiss.service.KamdService;
import com.hanhwa.saws.mediator.kiss.service.KmtfParseService;
import lombok.extern.slf4j.Slf4j;

@Service("KmtfParseService")
@Slf4j
public class KmtfParseServiceImpl implements KmtfParseService {

    private static final String TOKEN = "/";
    private static final String LINE_TERMINATOR = "//";
    private static final String SPACE = "-";
    private static final String ESCAPE = "\\";
    private static final String TAG_INTRO = "INTRO//";
    private static final String TAG_BODY = "BODY//";
    private static final String TAG_CLOSE = "CLOSE//";
    private static final String HEADER_MAN = "KMTF";
    private static final String HEADER_OPT = "EDX";
    private static final String MODE_OPER = "OPER";
    private static final String MODE_EXER = "EXER";
    private static final int HEARTBEAT_CONTENT_COUNT = 3;
    private static final String DATE_FORMAT = "yyyyMMddhhmmss";
    private static final int CONTENT_COUNT = 26;

    private boolean isCorrupted = false;

    @Autowired KamdService kamdService;

    @Autowired KamdNtpService kamdNtpService;

    @Autowired AlarmService alarmService;

    @Override
    public void processCompleteKmtfData(String completeData) {
        try {
            List<String> kmtfData = new ArrayList<>();
            KmtfBean kmtfBean = new KmtfBean();
            ArrayList<byte[]> encList = null;

            log.debug("Complete KMTF data: {}", completeData);

            for (String line : completeData.split(LINE_TERMINATOR)) {
                line = line.trim();

                if (!line.isEmpty()) {
                    kmtfData.add(line + LINE_TERMINATOR);
                }
            }

            log.debug("Split KMTF data into lines: {}", kmtfData);

            kmtfBean.decode(kmtfData);

            if (kmtfBean.isHeartBeat()) {
                log.debug("KAMD HEARTBEAT RECV");
                kamdNtpService.setNtp(kmtfBean.getNtpDate());
                return;
            }

            encList = kmtfBean.encode();

            if (encList != null) {
                log.debug("KAMD RECV SIZE : " + encList.size());
            }


            kamdService.putKamd(encList);

            if (isCorrupted) {
                alarmService.setDataCorruptionAlarm("true");
                log.info("DATA CORRUPTION ALARM CLEAR (KAMD)");
                isCorrupted = false;
            }

        } catch (Exception e) {
            log.warn("Invalid RASD KMTF data skip: {}", e.getMessage(), e);

            if (!isCorrupted) {
                alarmService.setDataCorruptionAlarm("false");
                log.info("DATA CORRUPTION ALARM MINOR (KAMD)");
                isCorrupted = true;
            }

        }
    }
}
