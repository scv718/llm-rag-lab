/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.HashMap;
import java.util.Map;

public class EmsTypeRepo {
    private static final Map<String, EmsTypeRepo> CODE_MAP = new HashMap<>();
    
    public static final EmsTypeRepo START = new EmsTypeRepo("START");
    public static final EmsTypeRepo STOP = new EmsTypeRepo("STOP");
    public static final EmsTypeRepo SUCCESS = new EmsTypeRepo("SUCCESS");
    public static final EmsTypeRepo FAIL = new EmsTypeRepo("FAIL");
    
    private final String code;

    private EmsTypeRepo(String cd) {
        this.code = cd;
    }
    
    static {
        CODE_MAP.put(START.getCode(), START);
        CODE_MAP.put(STOP.getCode(), STOP);
        CODE_MAP.put(SUCCESS.getCode(), SUCCESS);
        CODE_MAP.put(FAIL.getCode(), FAIL);
    }

    public static EmsTypeRepo getStart() {
        return START;
    }

    public static EmsTypeRepo getStop() {
        return STOP;
    }

    public static EmsTypeRepo getSuccess() {
        return SUCCESS;
    }

    public static EmsTypeRepo getFail() {
        return FAIL;
    }
    
    public String getCode() {
        return code;
    }


}
