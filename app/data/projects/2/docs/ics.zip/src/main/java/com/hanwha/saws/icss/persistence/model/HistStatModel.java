/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class HistStatModel {
    private String trackNumber;
    private long cnt;
    
    private String trackNumberEnc;
    private byte[] trackNumberHash;
    
    private String identityEnc;
    private byte[] identityHash;    
}
