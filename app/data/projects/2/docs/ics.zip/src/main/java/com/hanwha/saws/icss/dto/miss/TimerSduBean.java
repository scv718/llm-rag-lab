/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.miss;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

import com.hanwha.saws.icss.dto.CommonHeaderSduBean;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class TimerSduBean {

    private static final long SERIALVERSIONUID = -3842866157809330732L;

    private static final byte MSG_TYPE = 0x08;

    private static final int SEGMENT_SIZE = 14;

    private CommonHeaderSduBean header;
    private byte[] originFilterByte;
    private byte[] dateTime = new byte[SEGMENT_SIZE];

    String dF = "yyyyMMddHHmmss";
    DateTimeFormatter formatter = null;

    public TimerSduBean(byte[] pdu) throws IOException, RuntimeException {

        try {

            decode(ByteBuffer.wrap(pdu));

        } catch (IOException | RuntimeException e) {
            log.warn("site location data decoded InValid. skip");
            throw e;
        }

    }

//    public TimerSduBean(String dateTimeString) {
//        byte[] dTTmp = dateTimeString.getBytes();
//        this.dateTime = Arrays.copyOf(dTTmp, dTTmp.length);
//
//        encode();
//    }

    public TimerSduBean() {

        formatter = DateTimeFormatter.ofPattern(dF);

        this.dateTime = LocalDateTime.now().format(formatter).getBytes();

        encode();
    }

    private void encode() {
        int length = 0;
        int pLen = 0;
        ByteBuffer buffer = null;

        header = new CommonHeaderSduBean(MSG_TYPE, (byte) dateTime.length);

        length = header.getPayloadLengthInt();
        pLen = header.getHeader().length + length;

        buffer = ByteBuffer.allocate(pLen);

        buffer.put(header.getHeader());
        buffer.put(dateTime);

        originFilterByte = buffer.array();
    }

    private void decode(ByteBuffer buffer) throws IOException {

        int length = 0;
        int pLen = 0;

        header = new CommonHeaderSduBean(buffer.get(), buffer.get());

        length = header.getPayloadLengthInt();

        if (length > 0) {
            buffer.get(dateTime, 0, length);
        }

        pLen = header.getHeader().length + dateTime.length;

        originFilterByte = new byte[pLen];

        System.arraycopy(buffer.array(), 0, originFilterByte, 0, pLen);

    }

}
