/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import com.hanwha.saws.icss.dto.code.AlarmRepo;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class ServerAlarmStatModel {
    private static final int N10 = 10;
    private static final int N99999 = 99999;

    private Long seqNo;
    private String nodeName;
    private String nodeIp;
    private String statType;
    private Integer icsAlarm = 0;
    private Integer icsRestart = 0;
    private Integer icsSwitch = 0;
    private Integer cpu = 0;
    private Integer mem = 0;
    private Integer disk = 0;
    private Integer process = 0;
    private Integer misAlarm = 0;
    private Integer misRestart = 0;
    private Integer kisAlarm = 0;
    private Integer kisRestart = 0;
    private Integer idx;

    private Integer smsStatusEvent = 0;
    private Integer smsControlAlarm = 0;
    private Integer smsControlRestart = 0;
    private Integer smsModemAlarm = 0;
    private Integer smsModemBerAlarm = 0;
    private Integer smsConvAlarm = 0;
    private Integer smsClockEvent = 0;
    private Integer smsSModuleEquipAlarm = 0;
    private Integer smsHeartbeart = 0;
    private Integer smsSModuleAlarm = 0;
    private Integer smsPowerAlarm = 0;
    private Integer smsTrafficJamAlarm = 0;

    private Integer switchAlarm = 0;
    private Integer routerAlarm = 0;

    private Date updateTime;

    private String st;
    private String ed;

    private int rowCount;
    private int startIdx;
    
    public void setPage(Integer page, Integer listCount) {
     
        if (page == null || page == 0) {
            page = 1;
        }

        if (listCount == null || listCount == 0) {
            listCount = N10;
        }

        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }
    
//    public void setOverCount() {
//        if (icsAlarm > N99999) {
//            icsAlarm = N99999;
//        }
//        if (icsRestart > N99999) {
//            icsRestart = N99999;
//        }
//        if (cpu > N99999) {
//            cpu = N99999;
//        }
//        if (mem > N99999) {
//            mem = N99999;
//        }
//        if (disk > N99999) {
//            disk = N99999;
//        }
//        if (process > N99999) {
//            process = N99999;
//        }
//        if (misAlarm > N99999) {
//            misAlarm = N99999;
//        }
//        if (misRestart > N99999) {
//            misRestart = N99999;
//        }
//        if (kisAlarm > N99999) {
//            kisAlarm = N99999;
//        }
//        if (kisRestart > N99999) {
//            kisRestart = N99999;
//        }
//        if (smsStatusEvent > N99999) {
//            smsStatusEvent = N99999;
//        }
//        if (smsControlAlarm > N99999) {
//            smsControlAlarm = N99999;
//        }
//        if (smsControlRestart > N99999) {
//            smsControlRestart = N99999;
//        }
//        if (smsModemAlarm > N99999) {
//            smsModemAlarm = N99999;
//        }
//        if (smsModemBerAlarm > N99999) {
//            smsModemBerAlarm = N99999;
//        }
//        if (smsConvAlarm > N99999) {
//            smsConvAlarm = N99999;
//        }
//        if (smsClockEvent > N99999) {
//            smsClockEvent = N99999;
//        }
//        if (smsSModuleEquipAlarm > N99999) {
//            smsSModuleEquipAlarm = N99999;
//        }
//        if (smsHeartbeart > N99999) {
//            smsHeartbeart = N99999;
//        }
//        if (smsSModuleAlarm > N99999) {
//            smsSModuleAlarm = N99999;
//        }
//        if (smsPowerAlarm > N99999) {
//            smsPowerAlarm = N99999;
//        }
//        if (smsTrafficJamAlarm > N99999) {
//            smsTrafficJamAlarm = N99999;
//        }
//     
//    }

    public void setData(AlarmHistStatModel param) {
        AlarmRepo code = AlarmRepo.fromCode(param.getAlarmId());

        if (isCodeMatch(code, AlarmRepo.getAlmSystem())) {
            icsAlarm += param.getAlarmCount();
            process += param.getAlarmCount();
            smsHeartbeart += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmNodata())) {
            icsAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmDataCorrupt())) {
            icsAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmCpu())) {
            cpu += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmHdd())) {
            disk += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmMem())) {
            mem += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmDb())) {
            icsAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmFailover())) {
            icsSwitch += param.getAlarmCount();
            smsStatusEvent += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmReset())) {
            icsRestart += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsClockChange())) {
            smsClockEvent += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsControl())) {
            smsControlAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsModem())) {
            smsModemAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsConv())) {
            smsConvAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsPwr())) {
            smsPowerAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsCrypto())) {
            smsSModuleAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsTraffic())) {
            smsTrafficJamAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsControlRestart())) {
            smsControlRestart += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsModemBerFault())) {
            smsModemBerAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsCryptoOff())) {
            smsSModuleEquipAlarm += param.getAlarmCount();
        } else if (isCodeMatch(code, AlarmRepo.getAlmSmsCryptoDelete())) {
            smsSModuleEquipAlarm += param.getAlarmCount(); // 소거는 탈장과 동일 취급
        } else {
            log.debug("ServerAlarmStatModel code {} problem", code.getCode());
        }       
    }
    
    private boolean isCodeMatch(AlarmRepo origin, AlarmRepo target) {
        
        return origin.getCode().equals(target.getCode());
        
    }
}
