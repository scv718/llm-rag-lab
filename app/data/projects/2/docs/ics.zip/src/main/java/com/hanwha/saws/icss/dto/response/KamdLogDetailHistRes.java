/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;

import lombok.Data;

@Data 
public class KamdLogDetailHistRes {

    private static final int N3 = 3;
    
    @JsonProperty("insert_time")
    private String insertTime;
    @JsonProperty("seq")
    private int seq;
    @JsonProperty("track_number")
    private String trackNumber;
    
    private String speed;
    private String direction;
    private String altitude;
    
    @JsonProperty("latitude")
    private String latitude;
    
    @JsonProperty("longitude")
    private String longitude;
    
    @JsonIgnore
    public void setDefaultData(KamdHistDetailModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        seq = data.getIdx();
        speed = data.getSpeed().setScale(1, RoundingMode.HALF_UP)
                .toPlainString();
        direction = data.getDirection().toPlainString();
        altitude = BigDecimal.valueOf((double) data.getAltitude())
                .setScale(N3, RoundingMode.HALF_UP)
                .toPlainString();
        insertTime = sdf.format(data.getInsertTime());        

    }
}
