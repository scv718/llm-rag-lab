/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.ServerAlarmStatModel;

import lombok.Data;

@Data
public class SmtStatRes {

    @JsonInclude(Include.NON_NULL) private int idx;

    @JsonProperty("node_name") private String name;

    @JsonProperty("node_ip") private String nodeIp;

    @JsonProperty("stat_type") private String statType;

    @JsonProperty("ics_alarm") private Integer icsAlarm;

    @JsonProperty("ics_restart") private Integer icsRestart;

    @JsonProperty("ics_switch") private Integer icsSwitch;

    @JsonProperty("mis_alarm") private Integer misAlarm;

    @JsonProperty("mis_restart") private Integer misRestart;

    @JsonProperty("kis_alarm") private Integer kisAlarm;

    @JsonProperty("kis_restart") private Integer kisRestart;

    @JsonInclude(Include.NON_NULL) private Integer cpu;
    @JsonInclude(Include.NON_NULL) private Integer mem;
    @JsonInclude(Include.NON_NULL) private Integer disk;
    @JsonInclude(Include.NON_NULL) private Integer process;

    @JsonProperty("status_event") private Integer statusEvent;

    @JsonProperty("control_alarm") private Integer controlAlarm;

    @JsonProperty("control_restart") private Integer controlRestart;

    @JsonProperty("modem_alarm") private Integer modemAlarm;

    @JsonProperty("modem_ber_alarm") private Integer modemBerAlarm;

    @JsonProperty("conv_alarm") private Integer convAlarm;

    @JsonProperty("conv_clock_alarm") private Integer convClockAlarm;

    @JsonProperty("smodule_clear_Alarm") private Integer smoduleClearAlarm;

    @JsonProperty("smodule_alarm") private Integer smoduleAlarm;

    @JsonProperty("power_alarm") private Integer powerAlarm;

    @JsonProperty("traffic_jam_alarm") private Integer trafficJamAlarm;

    @JsonProperty("heart_beat") private Integer heartBeat;

    @JsonProperty("switch_alarm") private Integer switchAlarm;
    @JsonProperty("router_alarm") private Integer routerAlarm;

    @JsonProperty("update_time") private String updateTime;

    @JsonIgnore
    public void setData(ServerAlarmStatModel data, NodeRepo node) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        idx = data.getIdx();
        nodeIp = data.getNodeIp();
        name = data.getNodeName();

        if (node.getCode() == NodeRepo.getIcssA().getCode()) {
            icsAlarm = data.getIcsAlarm();
            icsRestart = data.getIcsRestart();
            icsSwitch = data.getIcsSwitch();
            cpu = data.getCpu();
            mem = data.getMem();
            disk = data.getDisk();
            process = data.getProcess();

        } else if (node.getCode() == NodeRepo.getMissA().getCode()) {
            misAlarm = data.getMisAlarm();
            misRestart = data.getMisRestart();
            cpu = data.getCpu();
            mem = data.getMem();
            disk = data.getDisk();
            process = data.getProcess();

        } else if (node.getCode() == NodeRepo.getKissA().getCode()) {
            kisAlarm = data.getKisAlarm();
            kisRestart = data.getKisRestart();
            cpu = data.getCpu();
            mem = data.getMem();
            disk = data.getDisk();
            process = data.getProcess();

        } else if (node.getCode() == NodeRepo.getSmsA().getCode()) {
            statusEvent = data.getSmsStatusEvent();
            controlAlarm = data.getSmsControlAlarm();
            controlRestart = data.getSmsControlRestart();
            modemAlarm = data.getSmsModemAlarm();
            modemBerAlarm = data.getSmsModemBerAlarm();
            convAlarm = data.getSmsConvAlarm();
            convClockAlarm = data.getSmsClockEvent();
            smoduleClearAlarm = data.getSmsSModuleEquipAlarm();
            heartBeat = data.getSmsHeartbeart();
            smoduleAlarm = data.getSmsSModuleAlarm();
            powerAlarm = data.getSmsPowerAlarm();
            trafficJamAlarm = data.getSmsTrafficJamAlarm();

        } else if (node.getCode() == NodeRepo.getSwitchA().getCode()) {
            switchAlarm = data.getSwitchAlarm();

        } else if (node.getCode() == NodeRepo.getRouterA().getCode()) {
            routerAlarm = data.getRouterAlarm();

        }

        updateTime = sdf.format(data.getUpdateTime());
    }
}
