/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.request.MedAlarmReq;
import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.persistence.model.NodeModel;

public interface MedService {

    public void heartbeatRequest(NodeModel nodeInfo);

    void medStatusReport(MedStatusReq req, String senderIp);

    void medAlarmReport(MedAlarmReq req, String senderIp);

    boolean getMedRouterPing(String senderIp, String targetIp);
}
