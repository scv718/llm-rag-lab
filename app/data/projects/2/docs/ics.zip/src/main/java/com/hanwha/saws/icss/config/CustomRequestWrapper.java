/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import org.springframework.util.StreamUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

public class CustomRequestWrapper extends HttpServletRequestWrapper {

    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping()
            .create();

    private byte[] body = null;

    private final String clientIp;
    private String ip = null;
    
    public CustomRequestWrapper(HttpServletRequest req) throws IOException {
        super(req);
        
        if ((req.getContentType() != null)) {
			if (req.getContentType().toLowerCase().startsWith("multipart")) {
				this.body = GSON.toJson(req.getParameterMap()).getBytes();
			} else {
                this.body = StreamUtils.copyToByteArray(req.getInputStream());
            }
        } else {
            this.body = StreamUtils.copyToByteArray(req.getInputStream());
        }

        ip = req.getHeader("X-Forwarded-For");
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = req.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = req.getRemoteAddr();
        }
        
        this.clientIp = ip;
    }
    
    @Override
    public String getRemoteAddr() {
        return this.clientIp;
    }
    
    public byte[] getBody() {
        
        return Arrays.copyOf(body, body.length);
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        
        final ByteArrayInputStream bis = new ByteArrayInputStream(body);
        
        return new ServletImpl(bis);

    }

//    public byte[] getContentAsByteArray() {
//        return Arrays.copyOf(body, body.length);
//    }

    
    class ServletImpl extends ServletInputStream {
        
        private InputStream is;

        
        public ServletImpl(InputStream bis) {

            is = bis;

        }

        @Override
        public int read() throws IOException {

            return is.read();

        }

        @Override
        public int read(byte[] b) throws IOException {

            return is.read(b);

        }

        @Override
        public boolean isFinished() {
            return false;
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setReadListener(ReadListener listener) {}

    }
}
