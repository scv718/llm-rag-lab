/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.EmerHistModel;

public interface EmerHistDao {

    public void insertEmerHist(EmerHistModel param);

    public int selectEmerHistTotalCount(EmerHistModel param);

    public List<EmerHistModel> selectEmerHistList(EmerHistModel param);

}
