/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.Data;

@Data
public class MedAlarmReq {

    private static final Gson LOG_GSON = createLogGson();

    private static final long SERIALVERSIONUID = 1L;

    @JsonProperty("alarm_type") private String alarmType;
    
    @JsonProperty("sev") private String severity;
    @JsonProperty("time") private String time;

    private static Gson createLogGson() {
        GsonBuilder b = new GsonBuilder();
        
        b.disableHtmlEscaping();
        b.setPrettyPrinting();
        return b.create();
    }

//    public String toJsonString() {
//        return LOG_GSON.toJson(this);
//    }
}
