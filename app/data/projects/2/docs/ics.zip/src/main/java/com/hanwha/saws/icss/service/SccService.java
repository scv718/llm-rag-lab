/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.io.IOException;
import java.util.HashMap;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.request.KamdSimulReq;
import com.hanwha.saws.icss.dto.request.McrcSimulReq;
import com.hanwha.saws.icss.dto.request.SccStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;

public interface SccService {

    public BaseResponse sccLoginOut(SccStatusReq req, String senderIp);

    public void handleEvent(RecvMsgQueueBean param);
    
    /*
    public BaseResponse sccLogHist(SccStatusReq body, String remoteAddr);

    public BaseResponse sccLogHistNL(SccStatusReq body, String remoteAddr);
    */
    
    public BaseResponse sccDetailLogHist(SccStatusReq body, String remoteAddr);
    
    public BaseResponse sccDetailStatHist(SccStatusReq body, String remoteAddr);
    
    public BaseResponse sccVoiceStatus(String remoteAddr);

    BaseResponse getMsgHistList(HashMap body) throws IOException;

    BaseResponse getEmHistList(HashMap body) throws IOException;

    BaseResponse getAirDefWarnHistList(HashMap body) throws IOException;

    public BaseResponse getAirDefWarnAirRaidHistList(HashMap body)
            throws IOException;

    public BaseResponse sccMcrcSimulList(HashMap body, String remoteAddr);

    public BaseResponse sccKamdSimulList(HashMap body, String remoteAddr);

    public BaseResponse sccMcrcSimulAdd(McrcSimulReq body, String remoteAddr);

    public BaseResponse sccKamdSimulAdd(KamdSimulReq body, String remoteAddr);

    public BaseResponse sccMcrcSimulDel(McrcSimulReq body, String remoteAddr);

    public BaseResponse sccKamdSimulDel(KamdSimulReq body, String remoteAddr);

    public BaseResponse sccDevStatus(String remoteAddr);

    void handleEventV(RecvMsgQueueBean param);

    String getSimulSenderIp();
}
