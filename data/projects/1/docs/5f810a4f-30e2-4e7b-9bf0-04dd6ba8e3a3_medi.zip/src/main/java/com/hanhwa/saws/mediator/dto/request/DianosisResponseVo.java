/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.request;

import lombok.Data;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@Data
public class DianosisResponseVo {

    @JsonProperty("cpu") private int cpu;

    @JsonProperty("hdd") private int hdd;

    @JsonProperty("mem") private int mem;

    @JsonProperty("alarm_list") private List<AlarmVo> alarmList;
}
