/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.persistence.dao.local.AirDefWarnHistDao;
import com.hanwha.saws.icss.persistence.dao.local.AirRaidHistDao;
import com.hanwha.saws.icss.persistence.dao.local.AlarmDao;
import com.hanwha.saws.icss.persistence.dao.local.EmerHistDao;
import com.hanwha.saws.icss.persistence.dao.local.MessageHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusHistDao;
import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Service("SyncHistInsertService")
@Slf4j
public class SyncHistInsertServiceImpl implements SyncHistInsertService {

    @Autowired PropConfig prop;

    @Autowired IcsSyncService syncService;

    @Value("${prop.host-name}") String hostName;

    @Value("${ics.failover-dir.alarm-hist}") String alarmHistDir;

    @Value("${ics.failover-dir.msg-hist}") String msgHistDir;

    @Value("${ics.failover-dir.air-hist}") String airHistDir;

    @Value("${ics.failover-dir.emer-hist}") String emerHisDir;

    @Value("${ics.failover-dir.airdefwarn-hist}") String airDefWarnDir;

    @Value("${ics.failover-dir.status-hist}") String statusHistDir;

    @Autowired AlarmDao alarmDao;

    @Autowired MessageHistDao msgHistDao;

    @Autowired EmerHistDao emerHistDao;

    @Autowired AirDefWarnHistDao airDefWarnHistDao;

    @Autowired AirRaidHistDao airHistDao;

    @Autowired StatusHistDao statusHistDao;

    @Override
    public void insertFailoverAlarmHist(AlarmHistModel bean, String mode) {

        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nHash);
        String sum = nodeInfo.getName() + " ";

        sum += AlarmRepo.getAlmFailover().getMsg() + " mode " + mode;
        bean.setTime();
        bean.setCurrUuid(UUID.randomUUID().toString().replace("-", ""));
        bean.setNodeId(nodeInfo.getNodeId());
        bean.setNodeName(nodeInfo.getName());
        bean.setAddrIp(nodeInfo.getAddrIp());
        bean.setAlarmId(AlarmRepo.getAlmFailover().getCode());
        bean.setAlarmName(AlarmRepo.getAlmFailover().getMsg());
        bean.setServerity(AlarmRepo.getSvrInfo().getCode());
        bean.setLocation(nodeInfo.getAddrIp());
        bean.setSummary(sum);
        bean.setRecoverReason(null);
        bean.setRecoverTime(null);
        bean.setTally(1);
        bean.setFirstOccurrence(new Date());
        bean.setLastOccurrence(new Date());

        try {
            alarmDao.insertAlarmHistInsert(bean);
        } catch (RuntimeException e) {
            log.warn("insertFailoverAlarmHist() alarmDao " + e.toString());
            return;
        }

        try {
            syncService.insertAlarmHistInsert(bean);
        } catch (RuntimeException e2) {
            log.warn("insertFailoverAlarmHist() syncService " + e2.toString());

            makeSyncAlarmHistFile(bean);
        }
    }

    @Override
    public void insertAlarmHist(AlarmHistModel bean) {

        try {
            alarmDao.insertAlarmHistInsert(bean);
        } catch (RuntimeException e) {
            log.warn("insertAlarmHist() alarmDao " + e.toString());
            return;
        }

        try {
            syncService.insertAlarmHistInsert(bean);
        } catch (RuntimeException e2) {
            log.warn("insertAlarmHist() syncService " + e2.toString());

            makeSyncAlarmHistFile(bean);
        }
    }

    private void makeSyncAlarmHistFile(AlarmHistModel bean) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String lmPrefix = "makeSyncAlarmHistFile() ";
        String fOPath = (alarmHistDir + "/" + dStr + "/" + UUID.randomUUID());

        try {
            if (!Files.exists(Paths.get(alarmHistDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(alarmHistDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lmPrefix + " create file/dir " + e.toString());
        }
        
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(fOPath))) {
            oos.writeObject(bean);
        } catch (IOException | RuntimeException e2) {
            log.warn(lmPrefix + " writeObject " + e2.toString());
        }

    }

    @Override
    public void insertMessageHist(MessageHistModel param) {
        param.setTime();
        param.setDataType(STypeRepo.getAdcCmd().getCode() + "");
        param.setDataTypeName(STypeRepo.getAdcCmd().getMsg());
        param.setSysId(hostName);
        param.setDataName(System.currentTimeMillis() + "");
        param.setRecvGroup(hostName);

        try {
            msgHistDao.insertMessageHist(param);
        } catch (RuntimeException e) {
            log.warn("insertMessageHist() msgHistDao " + e.toString());
            return;
        }

        try {
            syncService.insertMessageHist(param);
        } catch (RuntimeException e2) {
            log.warn("insertMessageHist() syncService " + e2.toString());
            makeSyncMessageHistFile(param);
        }

    }

    @Override
    public void insertEmHist(EmerHistModel param) {
        param.setTime();
        param.setDataType(STypeRepo.getEmCmd().getCode() + "");
        param.setDataTypeName(STypeRepo.getEmCmd().getMsg());
        param.setSysId(hostName);
        param.setDataName(System.currentTimeMillis() + "");
        param.setRecvGroup(hostName);

        try {
            emerHistDao.insertEmerHist(param);
        } catch (RuntimeException e) {
            log.warn("insertEmHist() emerHistDao " + e.toString());
            return;
        }

        try {
            syncService.insertEmerHist(param);
        } catch (RuntimeException e2) {
            log.warn("insertEmHist() syncService " + e2.toString());
            makeSyncEmerHistFile(param);
        }
    }

    @Override
    public void insertAirDefWarnHist(AirDefWarnHistModel param) {
        String lmPrefix = "insertAirDefWarnHist()";

        param.setTime();
        param.setDataType(STypeRepo.getAdwCmd().getCode() + "");
        param.setDataTypeName(STypeRepo.getAdwCmd().getMsg());
        param.setSysId(hostName);
        param.setDataName(System.currentTimeMillis() + "");
        param.setRecvGroup(hostName);

        try {
            airDefWarnHistDao.insertAirDefWarnHist(param);
        } catch (RuntimeException e) {
            log.warn(lmPrefix + " airDefWarnHistDao " + e.toString());
            return;
        }

        try {
            syncService.insertAirDefWarnHist(param);
        } catch (RuntimeException e2) {
            log.warn(lmPrefix + " syncService " + e2.toString());

            makeSyncAirDefWarnHistFile(param);
        }

    }

    private void makeSyncMessageHistFile(MessageHistModel bean) {
        String lmPrefix = "makeSyncMessageHistFile()";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String fOPath = (msgHistDir + "/" + dStr + "/" + UUID.randomUUID());
        ObjectOutputStream os = null;

        try {
            if (!Files.exists(Paths.get(msgHistDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(msgHistDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lmPrefix + " create file/dir " + e.toString());
        }

        if (os == null) {

            try {
                os = new ObjectOutputStream(new FileOutputStream(fOPath));
                os.writeObject(bean);
            } catch (IOException | RuntimeException e2) {
                log.warn(lmPrefix + " writeObject " + e2.toString());
            }

            if (os != null) {

                try {
                    os.close();
                } catch (IOException ee) {
                    log.warn(ee.toString());
                }
            }
        }

    }

    @Override
    public void insertAirRaidHist(AirRaidHistModel param) {
        String lmPrefix = "insertAirRaidHist()";

        param.setTime();
        param.setDataType(STypeRepo.getArCmd().getCode() + "");
        param.setDataTypeName(STypeRepo.getArCmd().getMsg());
        param.setSysId(hostName);
        param.setDataName(System.currentTimeMillis() + "");
        param.setRecvGroup(hostName);

        try {
            airHistDao.insertAirHist(param);
        } catch (RuntimeException e) {
            log.warn(lmPrefix + " airHistDao " + e.toString());
            return;
        }

        try {
            syncService.insertAirHist(param);
        } catch (RuntimeException e2) {
            log.warn(lmPrefix + " syncService " + e2.toString());
            makeSyncAirRaidHistFile(param);
        }

    }

    @Override
    public void insertAirDefWarnAirRaidHist(AirRaidHistModel param) {
        param.setTime();
        param.setDataType(STypeRepo.getAdwArCmd().getCode() + "");
        param.setDataTypeName(STypeRepo.getAdwArCmd().getMsg());
        param.setSysId(hostName);
        param.setDataName(System.currentTimeMillis() + "");
        param.setRecvGroup(hostName);

        try {
            airHistDao.insertAirHist(param);
        } catch (RuntimeException e) {
            log.warn("insertAirDefWarnAirRaidHist() " + e.toString());
            return;
        }

        try {
            syncService.insertAirHist(param);
        } catch (RuntimeException e2) {
            log.warn("insertAirDefWarnAirRaidHist() sync " + e2.toString());

            makeSyncAirRaidHistFile(param);
        }

    }

    private void makeSyncAirRaidHistFile(AirRaidHistModel bean) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String lmPrefix = "makeSyncAirRaidHistFile()";
        ObjectOutputStream os = null;
        String fOPath = (airHistDir + "/" + dStr + "/" + UUID.randomUUID());

        try {
            if (!Files.exists(Paths.get(airHistDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(airHistDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lmPrefix + " create file/dir " + e.toString());
        }

        try {
            os = new ObjectOutputStream(new FileOutputStream(fOPath));
            os.writeObject(bean);
        } catch (IOException | RuntimeException e2) {
            log.warn(lmPrefix + " writeObject " + e2.toString());
        }

        if (os != null) {

            try {
                os.close();
            } catch (IOException ee) {
                log.warn(ee.toString());
            }
        }

    }

    private void makeSyncEmerHistFile(EmerHistModel bean) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String lmPrefix = "makeSyncEmerHistFile()";
        ObjectOutputStream os = null;
        String fOPath = (emerHisDir + "/" + dStr + "/" + UUID.randomUUID());

        try {
            if (!Files.exists(Paths.get(emerHisDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(emerHisDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lmPrefix + " create file/dir " + e.toString());
        }

        try {
            os = new ObjectOutputStream(new FileOutputStream(fOPath));
            os.writeObject(bean);
        } catch (IOException | RuntimeException e2) {
            log.warn(lmPrefix + " writeObject " + e2.toString());
        } 

        if (os != null) {

            try {
                os.close();
            } catch (IOException ee) {
                log.warn(ee.toString());
            }
            }

    }

    private void makeSyncAirDefWarnHistFile(AirDefWarnHistModel bean) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String lMPrefix = "makeSyncAirDefWarnHistFile()";
        ObjectOutputStream os = null;
        String fOPath = (airDefWarnDir + "/" + dStr + "/" + UUID.randomUUID());

        try {
            if (!Files.exists(Paths.get(airDefWarnDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(airDefWarnDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lMPrefix + " create file/dir " + e.toString());
        }

        try {
            os = new ObjectOutputStream(new FileOutputStream(fOPath));
            os.writeObject(bean);
        } catch (IOException | RuntimeException e2) {
            log.warn(lMPrefix + " writeObject " + e2.toString());
        } 

        if (os != null) {

            try {
                os.close();
            } catch (IOException ee) {
                log.warn(ee.toString());
            }
        }

    }

    @Override
    public void insertStatusHist(StatusHistModel bean) {
        try {
            statusHistDao.insertStatusHist(bean);
        } catch (RuntimeException e) {
            log.warn("insertStatusHist() statusHistDao " + e.toString());
            return;
        }

        try {
            syncService.insertStatusHist(bean);
        } catch (RuntimeException e2) {
            log.warn("syncService insertStatusHist() sync " + e2.toString());

            makeSyncStatusHistFile(bean);
        }

    }

    private void makeSyncStatusHistFile(StatusHistModel bean) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = formatter.format(LocalDateTime.now());
        String lMPrefix = "makeSyncStatusHistFile()";
        ObjectOutputStream os = null;
        String fOPath = (statusHistDir + "/" + dStr + "/" + UUID.randomUUID());

        try {
            if (!Files.exists(Paths.get(statusHistDir + "/" + dStr))) {
                Files.createDirectories(Paths.get(statusHistDir + "/" + dStr));
            }
        } catch (IOException | RuntimeException e) {
            log.warn(lMPrefix + " create file/dir " + e.toString());
        }

        try {
            os = new ObjectOutputStream(new FileOutputStream(fOPath));
            os.writeObject(bean);
        } catch (IOException | RuntimeException e2) {
            log.warn(lMPrefix + " writeObject " + e2.toString());
        } 

        if (os != null) {

            try {
                os.close();
            } catch (IOException ee) {
                log.warn(ee.toString());
            }
        }

    }

}
