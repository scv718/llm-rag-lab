/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.controller;

import java.net.InetAddress;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hanhwa.saws.mediator.common.service.MediatorService;
import com.hanhwa.saws.mediator.dto.code.ResponseCode;
import com.hanhwa.saws.mediator.dto.request.BaseResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class RequestController {

    @Autowired private MediatorService mediatorService;

    @RequestMapping(value = { "/v1/request" }, method = RequestMethod.POST)

    public Object handleRequest(@RequestBody Map<String, String> request) {
        String opCode = request.get("op_code");
        Object res = null;

        log.debug("Received icss request: {}", request);
        switch (opCode) {
            case "diagnosis":
                res = mediatorService.getDiagnosis();
                break;
            case "heartbeat":
                res = new BaseResponse(ResponseCode.C200);
                break;
            case "reset":
                mediatorService.resetSystem();
                res = new BaseResponse(ResponseCode.C200);
                break;
            case "router":
                String ip = request.get("ip");
                res = mediatorService.pingCheck(ip);
                break;
            default:
                res = new BaseResponse(ResponseCode.C400);
                break;
            }

        return res;

    }




}

