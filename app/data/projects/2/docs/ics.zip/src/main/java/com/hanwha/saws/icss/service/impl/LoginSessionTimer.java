/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.LoginSessionBean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LoginSessionTimer {
    @Autowired
    @Qualifier("sessionMap")
    private ConcurrentHashMap<String, LoginSessionBean> sessionMap;

    List<String> keys = null;
    Long extm = 0L;
    boolean isExNull = false;

    @Scheduled(fixedDelayString = "180000", initialDelayString = "3000")
    public void monitor() {
        isExNull = false;

        if (sessionMap.size() != 0) {
            keys = new ArrayList(sessionMap.keySet());
            for (String eKey : keys) {
                if (sessionMap.get(eKey) == null) {
                    continue;
                }

                extm = sessionMap.get(eKey).getExpireTime();

                if (extm == null) {
                    isExNull = true;
                }

                if (isExNull || (extm < System.currentTimeMillis())) {
                    sessionMap.remove(eKey);
                }

            }
        }

    }
}
