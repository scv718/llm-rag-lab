/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.io.IOException;
import java.nio.ByteBuffer;

import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.SmsRepo;
import com.hanwha.saws.icss.dto.modem.CBit;
import com.hanwha.saws.icss.dto.modem.IBit;
import com.hanwha.saws.icss.dto.modem.PBit;
import com.hanwha.saws.icss.dto.modem.SBit;
import com.hanwha.saws.icss.dto.modem.TBit;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SmsTcpEventBean {
    private static final int DATE_BYTE_LENGTH = 12;
    private static final byte EVENT_MAJOR = 0x20;
    private static final byte EVENT_CLEAR = 0x00;
    private static final byte EVENT_MINOR = 0x10;
    private static final int B_MAX = 0xFF;
    
    private static final int BIT7 = 7;
    private static final int BIT6 = 6;
    private static final int BIT5 = 5;
    private static final int BIT4 = 4;
    private static final int BIT3 = 3;
    private static final int BIT2 = 2;
    private static final int BIT1 = 1;
    private static final int BIT0 = 0;
    
    private static final int N1 = 1;
    private static final int N2 = 2;
    
    private NodeRepo code;

    private short msgType;
    private short opCode;
    private int sid;
    private int length;
    private String date;
    private byte option;
    private boolean isActive;
    private boolean isWarn;
    private String internalMsg;
    private byte serverity = 0x00;
    private CBit cBit;
    private TBit tBit;
    private long berCount = 0; // unsigned int
    private IBit iBit;
    private SBit sBit;
    private PBit pBit;
    
    public AlarmRepo getServerityCode() {

        AlarmRepo cd = null;

        switch (serverity) {
            case EVENT_CLEAR: {
                cd = AlarmRepo.getSvrCle();
                break;
            }
            case EVENT_MAJOR: {
                cd = AlarmRepo.getSvrMaj();
                break;
            }
            case EVENT_MINOR: {
                cd = AlarmRepo.getSvrMin();
                break;
            }
            default: {
                cd = AlarmRepo.getSvrMin();
                break;
            }
        }
        
        return cd;
    }

    public void headerDecode(ByteBuffer buffer) {
        msgType = buffer.getShort();
        opCode = buffer.getShort();
        sid = buffer.getInt();
        length = buffer.getInt();
    }

    public void decode(byte[] array) throws IOException, RuntimeException {
        long uIntMask = 0xFFFFFFFFFFFFFFFFL;
        byte tmp = 0x00;
        ByteBuffer deBuf = ByteBuffer.wrap(array);
        String ctl = null;
        String conv = null;
        String modem = null;
        String sModule = null;
        String power = null;

        CBit c = null;
        IBit i = null;
        PBit p = null;
        TBit t = null;
        SBit s = null;

        short sK = 0;
        boolean isSOff = false;
        boolean isSDel = false;

        headerDecode(deBuf);

        sK = SmsRepo.from(opCode).getCode();
        isSOff = (sK == SmsRepo.getEventFaultSmoduleOff().getCode());
        isSDel = (sK == SmsRepo.getEventFaultSmoduleDelete().getCode());

        if (sK == SmsRepo.getEventModemStatus().getCode()) {
            date = getTime(deBuf);
            date = "";
            option = deBuf.get();

            tmp = deBuf.get();

            if (tmp == N1) {
                isActive = true;
            } else {
                if (tmp == N2) {
                    isWarn = false;    
                }else {
                    isWarn = true;
                }                
            }
            
            

        } else if (sK == SmsRepo.getEventConvClockChange().getCode()) {
            tmp = deBuf.get();
            date = "";
            
            if (tmp == 1) {
                internalMsg = "Internal Clock -> External Clock Change";
            } else {
                internalMsg = "External Clock -> Internal Clock Change";
            }
        } else if (sK == SmsRepo.getEventFaultControl().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            if (deBuf.hasRemaining()) { // 3바이트가 안올수도 있다는 가정하에
                c = new CBit();

                ctl = HexByteUtil.getBinStr(deBuf.get());

                c.setBinaryString(ctl);
                c.setMem(getBit(ctl, BIT7));
                c.setVocoder(getBit(ctl, BIT6));
                c.setIfUnit(getBit(ctl, BIT5));
                c.setCrypto(getBit(ctl, BIT4));
                c.setEthernet1(getBit(ctl, BIT3));
                c.setEthernet2(getBit(ctl, BIT2));
                c.setFlash(getBit(ctl, BIT1));

                this.cBit = c;
            }
        } else if (sK == SmsRepo.getEventRestartControl().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }
        } else if (sK == SmsRepo.getEventFaultModem().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            if (deBuf.hasRemaining()) { // 3바이트가 안올수도 있다는 가정하에
                t = new TBit();

                tmp = deBuf.get();
                modem = HexByteUtil.getBinStr(tmp);

                t.setBinaryString(modem);

                if ((tmp & B_MAX) == B_MAX) {
                    t.setNoCard(1);
                } else {
                    t.setFpga(getBit(modem, BIT7));
                    t.setDac(getBit(modem, BIT6));
                    t.setClk(getBit(modem, BIT5));
                    t.setPwr(getBit(modem, BIT4));   
                    t.setModemSync(getBit(modem, BIT3));            
                    t.setNoCard(0);                    
                }

                this.tBit = t;
            }
        } else if (sK == SmsRepo.getEventFaultBerThresModem().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            if (deBuf.hasRemaining()) {
                berCount = deBuf.getLong();
            }

        } else if (sK == SmsRepo.getEventFaultConv().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            // 프로토콜 변경에 따른 bean 구조 변경
            if (deBuf.hasRemaining()) {
                i = new IBit();

                tmp = deBuf.get();

                conv = HexByteUtil.getBinStr(tmp);
                i.setBinaryString(conv);

                if ((tmp & B_MAX) == B_MAX) {
                    i.setNoCard(1);
                } else {
                    i.setExtInt(0); // 여기서 또 안쓴다 <-- 문서에 없음 0325 ICD에 없음
                    i.setUpc(getBit(conv, BIT6));
                    i.setDnc(getBit(conv, BIT5));
                    i.setUpcPll(getBit(conv, BIT4));
                    i.setDncPll(getBit(conv, BIT3));
                    i.setFixPll(getBit(conv, BIT2));
                    i.setNoCard(0);
                }

                this.iBit = i;
            }
        } else if (isSOff || isSDel) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

        } else if (sK == SmsRepo.getEventFaultSmodule().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            if (deBuf.hasRemaining()) {
                tmp = deBuf.get();

                sModule = HexByteUtil.getBinStr(tmp);

                s = new SBit();

                s.setNoCard((((tmp & B_MAX) == B_MAX) ? 1 : 0));
                s.setIsConnect(getBit(sModule, BIT7));

                this.sBit = s;
            }
        } else if (sK == SmsRepo.getEventFaultPower().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }

            if (deBuf.hasRemaining()) {
                tmp = deBuf.get();

                power = HexByteUtil.getBinStr(tmp);

                p = new PBit();

                p.setV5One(getBit(power, BIT7));
                p.setV5Two(getBit(power, BIT6));
                p.setVTwelve(getBit(power, BIT5));

                this.pBit = p;

            }
        } else if (sK == SmsRepo.getEventFaultTraffic().getCode()) {
            date = getTime(deBuf);
            date = "";
            tmp = deBuf.get();

            if (tmp != 0) {
                serverity = tmp; // Major 0x20;
            }
        } else {
            log.debug("알 수 없는 코드");
        }

    }

    private String getTime(ByteBuffer buffer) {

        byte[] strDate = new byte[DATE_BYTE_LENGTH];
        
        buffer.get(strDate);
        
        return new String(strDate);
    }

    private int getBit(String binary, int index) {
        return ((binary.charAt(index) == '0') ? 0 : 1);
    }

}
