/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.SmsTcpEventBean;

public interface SmsEService {    
    public void eventHandle(SmsTcpEventBean event);
        
}
