/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.KamdSimulModel;

import lombok.Data;

@Data
public class KamdSimulRes {
    @JsonProperty("simul_no") private String simulNo;
    @JsonProperty("code") private String kamdCode;
    @JsonProperty("type") private String kamdType;
    @JsonProperty("route") private Integer kamdRoute;

    @JsonProperty("location_x_start") private String kamdLocationXStart;
    @JsonProperty("location_y_start") private String kamdLocationYStart;
    @JsonProperty("location_x") private String kamdLocationX;
    @JsonProperty("location_y") private String kamdLocationY;
    @JsonProperty("location_x_end") private String kamdLocationXEnd;
    @JsonProperty("location_y_end") private String kamdLocationYEnd;
    @JsonProperty("knot") private Integer kamdKnot;
    @JsonProperty("feet") private Integer kamdFeet;
    @JsonProperty("direction") private Integer kamdDirection;
    @JsonProperty("create_time") private String createSys;

    @JsonIgnore
    public void setBeanData(KamdSimulModel bean) {
        simulNo = bean.getSimulNo() + "";
        kamdCode = bean.getKamdCode();
        kamdType = bean.getKamdType();
        kamdRoute = bean.getKamdRoute();
        kamdLocationXStart = bean.getKamdLocationXStart();
        kamdLocationYStart = bean.getKamdLocationYStart();
        kamdLocationX = bean.getKamdLocationX();
        kamdLocationY = bean.getKamdLocationY();
        kamdLocationXEnd = bean.getKamdLocationXEnd();
        kamdLocationYEnd = bean.getKamdLocationYEnd();

        if (bean.getKamdKnot() != null) {
            kamdKnot = Integer.parseInt(bean.getKamdKnot());
        }
        
        if (bean.getKamdFeet() != null) {
            kamdFeet = Integer.parseInt(bean.getKamdFeet());
        }
        
        if (bean.getKamdDirection() != null) {
            kamdDirection = Integer.parseInt(bean.getKamdDirection());
        }
        
        createSys = bean.getCreateSys();
    }
}
