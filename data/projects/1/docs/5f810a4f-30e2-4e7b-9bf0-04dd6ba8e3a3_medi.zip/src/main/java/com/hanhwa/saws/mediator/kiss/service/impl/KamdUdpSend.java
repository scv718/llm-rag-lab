/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.kiss.service.impl;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hanhwa.saws.mediator.util.ByteUtil;
import com.hanhwa.saws.mediator.util.MulticastSenderUtil;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KamdUdpSend implements Runnable {

    private static final int N2 = 2;
    private static final int N10 = 10;
    private static final int B_FF = 0xFF;
    private static final byte MSG_TYPE = 0x00;

    @Autowired @Qualifier("kamdSendQueue")
    private ConcurrentLinkedQueue<ArrayList<byte[]>> kamdSendQueue;

    @Value("${sendserver.icss-host}") private String icssHost;

    @Value("${sendserver.kamd-udp-port}") private int kamdUdpPort;

    @Value("${sendserver.local-ip}") private String localIp;

    @Value("${mediator.mode}") private String mode;

    private volatile MulticastSenderUtil senderService;

    @PostConstruct
    public void setupSender() {

        if (!"kamd".equalsIgnoreCase(mode)) {
            return;
        }

        try {
            this.senderService = new MulticastSenderUtil(icssHost, kamdUdpPort,
                    localIp);
            log.debug("KAMD sender initialized: host={}, port={}, localIp={}",
                    icssHost, kamdUdpPort, localIp);
        } catch (Exception e) {
            log.warn("Failed to initialize MulticastSenderService: {}",
                    e.getMessage(), e);
        }
    }

    @Override
    public void run() {
        ArrayList<byte[]> encodedDatas = null;

        while (true) {
            try {
                encodedDatas = kamdSendQueue.poll();

                if (encodedDatas == null) {
                    CompletableFuture<Void> delay = new CompletableFuture<>();
                    delay.completeOnTimeout(null, N10, TimeUnit.MILLISECONDS)
                            .join();
                    continue;
                }

                for (byte[] data : encodedDatas) {
                    sendByte(data);
                }

            } catch (RuntimeException e2) {
                log.warn("KAMD UDP send fail: {}", e2.getMessage(), e2);
            }
        }
    }

    public void sendByte(byte[] payload) {

        try {
            int len = payload.length;
            byte[] packetData = null;
            ByteBuffer sBuf = ByteBuffer.allocate(N2 + len);
            String msg = "KAMD UDP send success: Type={}, Size={}";

            sBuf.put(MSG_TYPE);
            sBuf.put((byte) (payload.length & B_FF));
            sBuf.put(payload);

            packetData = sBuf.array();

            log.debug("kamd send data : {}", ByteUtil.bytesToHex(packetData));

            senderService.send(packetData);

            log.info(msg, MSG_TYPE, len);
        } catch (Exception e) {
            log.warn("KAMD UDP send failed: {}", e.getMessage(), e);
        }
    }
}
