/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.SccStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.DetailHistStatRes;
import com.hanwha.saws.icss.persistence.dao.local.StatDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistStatModel;
import com.hanwha.saws.icss.persistence.model.HistStatModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.ServerAlarmStatModel;
import com.hanwha.saws.icss.persistence.model.ServerHistStatModel;
import com.hanwha.saws.icss.service.StatService;
import com.hanwha.saws.icss.util.DataCrypt;

import lombok.extern.slf4j.Slf4j;

@Service("StatService")
@Slf4j
public class StatServiceImpl implements StatService {

    private static final int N7 = 7;
    private static final int N6 = 6;
    private static final int N1 = 1;
    private static final int N100 = 100;
    
    @Autowired StatDao statDao;
    @Autowired PropConfig prop;
    @Value("${ics.user-key}") String uK;
    @Value("${ics.file-key}") String fileKey;
    
    private DataCrypt crypt = new DataCrypt();
    
    @Override
    public void makeIcsAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getIcssA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getIcssB().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getIcssA());

    }

    @Override
    public void makeMissAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getMissA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getMissB().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getMissA());

    }

    @Override
    public void makeKissAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getKissA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getKissB().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getKissA());

    }

    @Override
    public void makeSmsAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getSmsA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getSmsB().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getSmsA());

    }

    @Override
    public void makeSwitchAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getSwitchA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getSwitchB().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getSwitchA());

    }

    @Override
    public void makeRouterAlarmStat() {
        ArrayList<NodeModel> targetNodes = new ArrayList<>();
        NodeModel nInfo = null;

        nInfo = prop.getNodeInfoHash().get(NodeRepo.getRouterA().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getRouterB().getCode());
        targetNodes.add(nInfo);
        nInfo = prop.getNodeInfoHash().get(NodeRepo.getRouterM().getCode());
        targetNodes.add(nInfo);
        makeTypeCodeSearch(targetNodes, NodeRepo.getRouterA());
    }
    
    @Override
    public void makeMissHistStat() {
        ServerHistStatModel info = statDao.selectMcrcLastHistStat();
        LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
        LocalDateTime st = null;
        LocalDateTime ed = null;
        LocalDateTime prevDate = null;
        Instant instant = null;
        ZoneId zoneId = null;
        ServerHistStatModel param = null;
        List<ServerHistStatModel> list = null;
        Date tmpD = null;
        boolean isEnd = false;
        
        if (info != null) {
            if (info.getUpdateTime() instanceof java.sql.Date ts) {
                prevDate = ts.toLocalDate().atStartOfDay();
            }
        }
        
        while (!isEnd) {
            if (prevDate == null) {
                st = today.minusDays(N7);
                ed = today.minusDays(N6);
                prevDate = st;
            } else {
                st = prevDate.plusDays(N1);
                ed = st.plusDays(N1);
                prevDate = st;
            }
            
            if (st.isAfter(today) || st.isEqual(today)) {
                isEnd = true; // 종료
                continue;
            }
            param = new ServerHistStatModel();
            param.parseStartTime(st);
            param.parseEndTime(ed);
            
            list = statDao.selectMcrcHistCount(param);

            for (ServerHistStatModel serverHistStatModel : list) {
                tmpD = Date.from(st.atZone(ZoneId.systemDefault()).toInstant());
                serverHistStatModel.setUpdateTime(tmpD);
            }
            if (list.size() > 0) {
                statDao.insertMcrcHistStat(list);
            }
            
        }        
    }
    
    @Override
    public void makeKissHistStat() {
        ServerHistStatModel info = statDao.selectKamdLastHistStat();
        LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
        LocalDateTime st = null;
        LocalDateTime ed = null;
        LocalDateTime prevDate = null;
        Instant instant = null;
        ZoneId zoneId = null;
        ServerHistStatModel param = null;
        List<ServerHistStatModel> list = null;
        Date tmpD = null;
        
        boolean isEnd = false;

        if (info != null) {
            if (info.getUpdateTime() instanceof java.sql.Date ts) {
                prevDate = ts.toLocalDate().atStartOfDay();
            }
        }
        
        while (!isEnd) {
            if (prevDate == null) {
                st = today.minusDays(N7);
                ed = today.minusDays(N6);
                prevDate = st;
            } else {
                st = prevDate.plusDays(N1);
                ed = st.plusDays(N1);
                prevDate = st;
            }
            
            if (st.isAfter(today) || st.isEqual(today)) {
                isEnd = true; // 종료
                continue;
            }
            param = new ServerHistStatModel();
            param.parseStartTime(st);
            param.parseEndTime(ed);
            
            list = statDao.selectKamdHistCount(param);

            for (ServerHistStatModel serverHistStatModel : list) {
                tmpD = Date.from(st.atZone(ZoneId.systemDefault()).toInstant());
                serverHistStatModel.setUpdateTime(tmpD);
            }
            if (list.size() > 0) {
                statDao.insertKamdHistStat(list);
            }
            
        }
        
    }

    @Override
    public BaseResponse getMissHistStat(SccStatusReq body) {
        
        ServerHistStatModel param = new ServerHistStatModel();
        List<HistStatModel> list = null;
        long tCnt = 0;
        long tPage = 0;
        
        try {
            
            param.setDetailMcrcParam(body, uK);
            list = statDao.selectMcrcHistStat(param);            
            
            if (list == null || list.size() == 0) {
                return new BaseResponse(ResRepo.getC204());
            }
            return new BaseResponse(ResRepo.getC200(), parseHistStat(list));

        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.warn("getMissHistStat() " + e.toString());
        } catch (DataAccessException e) {
            log.warn("getMissHistStat db " + e.toString());
        } catch (GeneralSecurityException e) {
            log.warn("getMissHistStat decrypt " + e.toString());
        }
        
        return new BaseResponse(ResRepo.getC999());
        
    }

    @Override
    public BaseResponse getKissHistStat(SccStatusReq body) {
       
        ServerHistStatModel param = new ServerHistStatModel();
        List<HistStatModel> list = null;
        
        try {
            
            param.setDetailParam(body, uK);
            list = statDao.selectKamdHistStat(param);
            
            if (list == null || list.size() == 0) {
                return new BaseResponse(ResRepo.getC204());
            }
            return new BaseResponse(ResRepo.getC200(),parseHistStat(list));

        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.warn("getKissHistStat() " + e.toString());
        } catch (DataAccessException e) {
            log.warn("getKissHistStat db " + e.toString());
        } catch (GeneralSecurityException e) {
            log.warn("getKissHistStat decrypt " + e.toString());
        }
        
        return new BaseResponse(ResRepo.getC999());
        
    }

    private List<DetailHistStatRes> parseHistStat(List<HistStatModel> rList)
            throws RuntimeException, GeneralSecurityException {
        List<DetailHistStatRes> list = new ArrayList<>();
        DetailHistStatRes bean = null;

        for (HistStatModel r : rList) {
            bean = new DetailHistStatRes();
            bean.setCount(r.getCnt() + "");
//            암호화 정보 해석 
            if (r.getTrackNumberEnc() != null) {
                bean.setTrackNumber(new String(
                        crypt.decrypt(r.getTrackNumberEnc(), fileKey)));
            }
            
            if (r.getIdentityEnc() != null) {
                bean.setIdentity(
                        new String(crypt.decrypt(r.getIdentityEnc(), fileKey)));
            }
            
            list.add(bean);
        }
        return list;

    }
    
    private void makeTypeCodeSearch(ArrayList<NodeModel> targetNodes,
            NodeRepo code) {
        List<ServerAlarmStatModel> list = null;
        ServerAlarmStatModel lastModel = null;
        LocalDateTime lastDate = null;
        Instant instant = null;
        ZoneId zoneId = null;

        if (code.getCode() == NodeRepo.getIcssA().getCode()) {
            list = statDao.selectIcssLastAlarmStat();
        } else if (code.getCode() == NodeRepo.getMissA().getCode()) {
            list = statDao.selectMissLastAlarmStat();
        } else if (code.getCode() == NodeRepo.getKissA().getCode()) {
            list = statDao.selectKissLastAlarmStat();
        } else if (code.getCode() == NodeRepo.getSmsA().getCode()) {
            list = statDao.selectSmsLastAlarmStat();
        } else if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
            list = statDao.selectSwitchLastAlarmStat();
        } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
            list = statDao.selectRouterLastAlarmStat();
        } else {
            log.warn("AlarmStat CODE TYPE {} ", code);
            return;
        }

        for (NodeModel node : targetNodes) {

            for (ServerAlarmStatModel lastStat : list) {
                if (lastStat.getNodeName().equals(node.getName())) {
                    lastModel = lastStat;
                }
            }

            if (lastModel != null) {
                if (lastModel.getUpdateTime() instanceof java.sql.Date ts) {
                    lastDate = ts.toLocalDate().atStartOfDay();
                }
            }

            makeAlarmStatInfo(lastDate, node, code);
        }

    }

    private void makeAlarmStatInfo(LocalDateTime prevDate, NodeModel nodeInfo,
            NodeRepo code) {

        LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
        LocalDateTime st = null;
        LocalDateTime ed = null;
        AlarmHistStatModel param = null;
        List<AlarmHistStatModel> list = null;
        ServerAlarmStatModel aBean = null;
        boolean isEnd = false;
        ArrayList<ServerAlarmStatModel> statList = new ArrayList<>();
        Date tmpD = null;

        while (!isEnd) {
            if (prevDate == null) {
                st = today.minusDays(N7);
                ed = today.minusDays(N6);
                prevDate = st;
            } else {
                st = prevDate.plusDays(N1);
                ed = st.plusDays(N1);
                prevDate = st;
            }

            if (st.isAfter(today) || st.isEqual(today)) {
                isEnd = true; // 종료
                continue;
            }

            param = new AlarmHistStatModel();
            param.parseStartTime(st);
            param.parseEndTime(ed);
            param.setNodeId(nodeInfo.getNodeId());

            list = statDao.selectAlarmHistCount(param);

            aBean = new ServerAlarmStatModel();

            aBean.setNodeName(nodeInfo.getName());
            aBean.setNodeIp(nodeInfo.getAddrIp());
            aBean.setStatType("3");
            tmpD = Date.from(st.atZone(ZoneId.systemDefault()).toInstant());
            aBean.setUpdateTime(tmpD);

            for (AlarmHistStatModel m : list) {
                aBean.setData(m);
            }

//            aBean.setOverCount();

            statList.add(aBean);
        }

        if (statList.size() == 0) {
            log.trace("stat log 0");
            return;
        }

        if (code.getCode() == NodeRepo.getIcssA().getCode()) {
            statDao.insertIcssAlarmStat(statList);
        } else if (code.getCode() == NodeRepo.getMissA().getCode()) {
            statDao.insertMissAlarmStat(statList);
        } else if (code.getCode() == NodeRepo.getKissA().getCode()) {
            statDao.insertKissAlarmStat(statList);
        } else if (code.getCode() == NodeRepo.getSmsA().getCode()) {
            statDao.insertSmsAlarmStat(statList);
        } else if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
            statDao.insertSwitchAlarmStat(statList);
        } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
            statDao.insertRouterAlarmStat(statList);
        } else {
            log.warn("AlarmStat CODE TYPE {} ", code);
            return;
        }
    }

}
