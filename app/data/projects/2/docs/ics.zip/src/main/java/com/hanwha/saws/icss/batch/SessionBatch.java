/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.service.LoginSessionService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SessionBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    private static final int ACTIVE = 1;
    
    @Autowired PropConfig prop;
    @Autowired RestClientService restClient;
    @Autowired LoginSessionService loginSessionService;
    
    @Scheduled(
            fixedDelayString = "${cron.login-session}000",
            initialDelayString = "${cron.init-delay}000")
    public void sessionSync() throws IOException {

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("stand by");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        statusLog.debug("LOGIN SESSION SYNC BATCH START");

        try {
            eventHandle();
        } catch (NoClassDefFoundError e) {
            log.warn("sessionSync() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("sessionSync batch " + e.toString());
        }

        statusLog.debug("LOGIN SESSION SYNC BATCH END");

    }

    private void eventHandle() {
        
        String rIp = prop.getRIcsIp();
        
        restClient.icsSyncSession(rIp, loginSessionService.getSessionAll());

    }
    
}
