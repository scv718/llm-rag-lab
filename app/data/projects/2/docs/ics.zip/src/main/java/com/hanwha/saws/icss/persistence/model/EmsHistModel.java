/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class EmsHistModel {
    private static final int N10 = 10;
    
    private int idx;
    private long seqNo;
    private String operationType;
    private String operationResult;
    private Date insertTime;

    private String st;
    private String ed;

    private int rowCount;
    private int startIdx;

    public void setPage(Integer page, Integer listCount) {
      
        if (page == null || page == 0) {
            page = 1;
        }
        
        if (listCount == null || listCount == 0) {
            listCount = N10;
        }
        
        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }
}
