/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.io.Serializable;
import java.util.Arrays;

public class CommonHeaderSduBean implements Serializable {

    private static final int BFF = 0xFF;
    private static final int H_LEN = 2;
    private static final int T_LOC = 0;
    private static final int LEN_LOC = 1;
    private byte[] header = new byte[H_LEN];
    
    public CommonHeaderSduBean(byte type, byte length) {
        this.header[T_LOC] = type;
        this.header[LEN_LOC] = length;
    }

    public byte getType() {
        return header[T_LOC];
    }

    public int getTypeInt() {
        return header[T_LOC] & BFF;
    }

    public byte getPayloadLength() {
        return header[LEN_LOC];
    }

    public int getPayloadLengthInt() {
        return header[LEN_LOC] & BFF;
    }

    public byte[] getHeader() {
        return header.clone();
    }

    public void setHeader(byte[] h) {
        this.header = ((h == null) ? null : Arrays.copyOf(h, h.length));
    }
}
