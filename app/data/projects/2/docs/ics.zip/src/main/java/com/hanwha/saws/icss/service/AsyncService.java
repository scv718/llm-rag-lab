/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

public interface AsyncService {

    public void resetIcs();

    public void diagnosis();
}
