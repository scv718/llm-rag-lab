/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import com.hanwha.saws.icss.dto.request.KamdSimulArrReq;

import lombok.Data;

@Data
public class KamdSimulModel {

    private int simulNo;
    private String kamdCode;
    private String kamdType;
    private Integer kamdRoute;

    private String kamdLocationXStart;
    private String kamdLocationYStart;
    private String kamdLocationX;
    private String kamdLocationY;
    private String kamdLocationXEnd;
    private String kamdLocationYEnd;

    private String kamdKnot;
    private String kamdFeet;
    private String kamdDirection;
    private String kamdCount;
    private String sysId;
    private String createSys;

    public void setData(KamdSimulArrReq data) {
        simulNo = Integer.parseInt(data.getSimulNo());
        kamdCode = data.getKamdCode();
        kamdType = data.getKamdType();
        kamdRoute = data.getKamdRoute();
        kamdLocationXStart = data.getKamdLocationXStart();
        kamdLocationYStart = data.getKamdLocationYStart();
        kamdLocationX = data.getKamdLocationX();
        kamdLocationY = data.getKamdLocationY();
        kamdLocationXEnd = data.getKamdLocationXEnd();
        kamdLocationYEnd = data.getKamdLocationYEnd();

        if (data.getKamdKnot() != null) {
            kamdKnot = data.getKamdKnot() + "";
        }

        if (data.getKamdFeet() != null) {
            kamdFeet = data.getKamdFeet() + "";
        }

        if (data.getKamdDirection() != null) {
            kamdDirection = data.getKamdDirection() + "";
        }

        sysId = data.getSysId();
        createSys = data.getCreateSys();
    }
}
