/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.io.IOException;
import java.util.HashMap;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.request.SmtThresholdSetReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;

public interface SmtService {

    public BaseResponse failover(LoginSessionBean session);

    public BaseResponse reset(LoginSessionBean session, int nodeId);

    public BaseResponse remoteIcsReset(LoginSessionBean bean);

    public BaseResponse diagnosis(LoginSessionBean session, int nodeId);

    public BaseResponse sawStatusList(LoginSessionBean data, String remoteAddr,
            String operation);

    BaseResponse resourceHistList(LoginSessionBean session, HashMap body,
            String remoteAddr, String operation);

    public BaseResponse thresholdInfo(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);

    public BaseResponse thresholdUpdate(LoginSessionBean data,
            SmtThresholdSetReq body, String remoteAddr, String requestURI);

    public BaseResponse changeMode(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);

    public BaseResponse operationHistList(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);

    public BaseResponse smtOperationCmdList(LoginSessionBean data,
            String remoteAddr);

    public BaseResponse emsStartHistList(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);

    public BaseResponse sendRecvCodeList(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);

    public BaseResponse sendRecvDataHistList(LoginSessionBean data,
            HashMap body, String remoteAddr, String requestURI);

    public BaseResponse icsAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    public BaseResponse misAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    public BaseResponse kisAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    public BaseResponse modemAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    public BaseResponse switchAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    public BaseResponse routerAlarmStat(LoginSessionBean data, HashMap body,
            String remoteAddr);

    boolean isFailingOver();

}
