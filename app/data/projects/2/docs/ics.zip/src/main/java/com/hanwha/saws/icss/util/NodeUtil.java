/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.util.HashMap;

import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;

public class NodeUtil {

	private static final int MODE_LOCAL = 0;

    private NodeUtil() {}
    
    public static String getNodeRemoteIcsIP(String hostName,
            HashMap<Integer, NodeModel> nodeInfoHash) {

        String ip = "";
        
        if (hostName.equals("ICSS_A")) {
            ip = nodeInfoHash.get(NodeRepo.getIcssB().getCode()).getAddrIp();
        } else {
            ip = nodeInfoHash.get(NodeRepo.getIcssA().getCode()).getAddrIp();
        }

        return ip;
    }

    public static NodeModel getNodeRemoteIcs(String hostName,
            HashMap<Integer, NodeModel> nodeInfoHash) {

        NodeModel model = null;

        if (hostName.equals("ICSS_A")) {
            model = nodeInfoHash.get(NodeRepo.getIcssB().getCode());
        } else {
            model = nodeInfoHash.get(NodeRepo.getIcssA().getCode());
        }

        return model;
    }

    public static String getNodeIP(NodeRepo code,
            HashMap<Integer, NodeModel> nIHP) {

        return nIHP.get(code.getCode()).getAddrIp();
    }

    public static NodeModel getNodeInfoP(String hostName,
            HashMap<Integer, NodeModel> nodeInfoHash) {

        NodeModel model = null;

        if (hostName.equals("ICSS_A")) {
            model = nodeInfoHash.get(NodeRepo.getIcssA().getCode());
        } else {
            model = nodeInfoHash.get(NodeRepo.getIcssB().getCode());
        }

        return model;
    }

    public static int getIcsStatus(String hostName, StatusModel statusModel,
            int mode) {

        int rt = 0;

        if (mode == MODE_LOCAL) {
            if (hostName.equals("ICSS_A")) {
                rt = statusModel.getIcssA();
            } else {
                rt = statusModel.getIcssB();
            }
        } else {
            if (hostName.equals("ICSS_A")) {
                rt = statusModel.getIcssB();
            } else {
                rt = statusModel.getIcssA();
            }
        }

        return rt;
    }

    public static void setIcsStatusMode(String hostName,
            StatusModel statusModel, StatusRepo code, int mode) {

        if (mode == MODE_LOCAL) {

            if (hostName.equals("ICSS_A")) {
                statusModel.setIcssA(code.getCode());
            } else {
                statusModel.setIcssB(code.getCode());
            }

        } else {

            if (hostName.equals("ICSS_A")) {
                statusModel.setIcssB(code.getCode());
            } else {
                statusModel.setIcssA(code.getCode());
            }

        }

    }

    public static NodeModel getNdAltScc(HashMap<Integer, NodeModel> nHash,
            String rIp) {

        NodeModel sccA = nHash.get(NodeRepo.getSccA().getCode());
        NodeModel sccB = nHash.get(NodeRepo.getSccB().getCode());
        NodeModel model = null;

        if (sccA.getAddrIp().equals(rIp)) {
            model = sccB;
        } else {
            model = sccA;
        }

        return model;
    }

}