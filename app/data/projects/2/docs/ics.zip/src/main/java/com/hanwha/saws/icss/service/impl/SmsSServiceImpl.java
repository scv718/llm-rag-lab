/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.CompletionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.SmsTcpMsgBean;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.SmsSModuleRes;
import com.hanwha.saws.icss.endpoint.SmsClient;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.SmsSService;
import com.hanwha.saws.icss.service.SyncHistInsertService;

import lombok.extern.slf4j.Slf4j;

@Service("SmsSService")
@Slf4j
public class SmsSServiceImpl implements SmsSService {

    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N5 = 5;
    private static final int N8 = 8;
    private static final int N17 = 17;
    private static final int N20 = 20;
    private static final int N900 = 900;
    private static final int N1000 = 1000;
    private static final short B0001 = 0x0001;
    private static final short B01 = 0x01;

    private static final int SMS_SMODULE_INFO = 14;
    private static final int SMS_SMODULE_DIAGNOSIS = 15;
    private static final int SMS_SMODULE_LOGIN = 16;
    private static final int SMS_SMODULE_PIN_CHANGE = 17;
    private static final int SMS_SMODULE_LOGOUT = 18;
    private static final int SMS_SMODULE_CRYPTO_SET = 19;
    private static final int SMS_SMODULE_CRYPTO_STATUS = 20;
    private static final int SMS_SMODULE_BOARD_STATUS = 21;
    private static final int SMS_SMODULE_INSERT_KEY_CODE = 22;

    @Autowired PropConfig prop;

    @Autowired StatusConfigDao stConfDao;
    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired NonSyncHistDao nonSyncHistDao;

    @Autowired RdbSyncRtService rtSync;

    @Autowired AlarmService alarmService;

    @Value("${prop.host-name}") String hostName;

    private final SmsClient smsClientMgr; // 인터페이스만 의존

    @Autowired
    public SmsSServiceImpl(SmsClient smsClient) {
        this.smsClientMgr = smsClient;
    }

    @Override
    public BaseResponse sModuleInfo(int nodeId, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleInfo();
        NodeRepo nCd = NodeRepo.getSmsA();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        String tMsg = null;
        String tLog = null;

        try {
            stmB.setReqInfo(SMS_SMODULE_INFO, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {

                if ((sTOB.getData().length) == N17) {
                    resData.setModemStatusData(sTOB);
                    tMsg = OpHistRltRepo.getResultSuccess().getName();
                    tLog = nCd.getName() + " smodule info success";
                    insertOperationHist(oHBean, tMsg, tLog);
                    res.setData(resData);

                    return res;
                } else {
                    tMsg = OpHistRltRepo.getResultFailed().getName();
                    tLog = nCd.getName() + " smodule info failed";
                    insertOperationHist(oHBean, tMsg, tLog);

                    return new BaseResponse(ResRepo.getC512());
                }

            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " smodule info failed";
            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "sModuleInfo() smodule info {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }

    }

    @Override
    public BaseResponse sModuleDiagnosis(int nodeId, LoginSessionBean bean) {

        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleDignosis();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_DIAGNOSIS, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resData.setModemDiagnosisData(sTOB);

                parseSModuleDiagnosisAlarm(resData, nInfo, bean); // 알람진단

                tLog = nCd.getName() + " smodule diagnosis success";
                if (resData.getStatus() != 0) {
                    tLog = nCd.getName() + " smodule diagnosis failed";
                }

                tMsg = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(oHBean, tMsg, tLog);
                res.setData(resData);

                return res;

            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " smodule diagnosis failed";
            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "sModuleDiagnosis() smodule diagnosis {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleLogin(int nodeId, String pin,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleLogin();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        int resetCdRes = -1;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_LOGIN, new Object[] { pin });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
                resData.setStatus(resetCdRes);
                res.setData(resData);

                tLog = nCd.getName() + " smodule login success";
                tMsg = OpHistRltRepo.getResultSuccess().getName();

                if (resetCdRes != 0) {
                    tLog = nCd.getName() + " smodule login failed";
                }

                insertOperationHist(oHBean, tMsg, tLog);

                return res;
            }

            tLog = nCd.getName() + " smodule login failed";
            tMsg = OpHistRltRepo.getResultFailed().getName();

            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "sModuleLogin() smodule login {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModulePinChange(int nodeId, String oldPin, String pin,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmodulePinChange();

        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        int resetCdRes = -1;
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_PIN_CHANGE,
                    new Object[] { oldPin, pin });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
                resData.setStatus(resetCdRes);
                res.setData(resData);

                tLog = nCd.getName() + " smodule pin change success";
                if (resetCdRes != 0) {
                    tLog = nCd.getName() + " smodule pin change failed";
                }

                tMsg = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(oHBean, tMsg, tLog);
                return res;
            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " smodule  pin change failed";
            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "sModulePinChange() smodule  pin change {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleLogout(int nodeId, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleLogout();

        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        int resetCdRes = -1;
        String lLog = null;
        String lMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_LOGOUT, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
                resData.setStatus(resetCdRes);
                res.setData(resData);

                lLog = nCd.getName() + " smodule logout success";
                if (resetCdRes != 0) {
                    lLog = nCd.getName() + " smodule logout failed";
                }

                lMsg = OpHistRltRepo.getResultSuccess().getName();

                insertOperationHist(oHBean, lMsg, lLog);

                return res;
            }

            lLog = nCd.getName() + " smodule logout failed";
            lMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, lMsg, lLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            lLog = "sModuleLogout() smodule logout {} {}";
            lMsg = OpHistRltRepo.getResultFailed().getName();
            log.warn(lLog, nInfo.getName(), e.toString());

            insertOperationHist(oHBean, lMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleCryptoModeUpdate(int nodeId, int key,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleCryptoSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        int resetCdRes = -1;
        String lLog = null;
        String lMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_CRYPTO_SET, new Object[] { key });
            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
                resData.setStatus(resetCdRes);
                res.setData(resData);

                lLog = nCd.getName() + " smodule crypto mode change success";

                if (resData.getStatus() != 0) {
                    lLog = nCd.getName() + " smodule crypto mode change failed";
                }

                lMsg = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(oHBean, lMsg, lLog);

                return res;
            }

            lMsg = OpHistRltRepo.getResultFailed().getName();
            lLog = nCd.getName() + " smodule crypto mode change failed";
            insertOperationHist(oHBean, lMsg, lLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            lLog = "sModuleCryptoModeUpdate() smodule crypto mode change {} {}";
            log.warn(lLog, nInfo.getName(), e.toString());
            lMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, lMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleCryptoModeStatus(int nodeId,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleCryptoStatus();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        ByteBuffer sBuf = null;
        int result = 0;
        String lLog = null;
        String lMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_CRYPTO_STATUS, null);
            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                sBuf = ByteBuffer.wrap(sTOB.getData());
                result = (int) sBuf.get();

                resData.setStatus(result);

                if (sBuf.hasRemaining()) {
                    if (sBuf.getShort() == B0001) {
                        resData.setKey(N1);
                    } else {
                        resData.setKey(0);
                    }
                }

                res.setData(resData);

                lLog = nCd.getName() + " smodule crypto mode status success";

                if (resData.getStatus() != 0) {
                    lLog = nCd.getName() + " smodule crypto mode status failed";
                }

                lMsg = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(oHBean, lMsg, lLog);
                return res;
            }

            lMsg = OpHistRltRepo.getResultFailed().getName();
            lLog = nCd.getName() + " smodule crypto mode status failed";
            insertOperationHist(oHBean, lMsg, lLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            lLog = "sModuleCryptoModeStatus() smodule crypto mode status {} {}";
            log.warn(lLog, nInfo.getName(), e.toString());
            lMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, lMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleCryptoBoardStatus(int nodeId,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleBoardStatus();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        ByteBuffer sBuf = null;
        int result = 0;
        short status = 0;
        String lLog = null;
        String lMsg = null;

        try {

            stmB.setReqInfo(SMS_SMODULE_BOARD_STATUS, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                sBuf = ByteBuffer.wrap(sTOB.getData());
                result = (int) sBuf.get();

                resData.setStatus(result);

                if (sBuf.hasRemaining()) {
                    status = sBuf.getShort();
                    resData.setCpu(getBit(status, 0));
                    resData.setFpga(getBit(status, N1));
                    resData.setEquipped(getBit(status, N2));
                }

                res.setData(resData);

                lLog = nCd.getName() + " smodule crypto mode status success";

                if (resData.getStatus() != 0) {
                    lLog = nCd.getName() + " smodule crypto mode status failed";
                }

                lMsg = OpHistRltRepo.getResultSuccess().getName();

                insertOperationHist(oHBean, lMsg, lLog);

                return res;
            }

            lMsg = OpHistRltRepo.getResultFailed().getName();
            lLog = nCd.getName() + " smodule crypto mode status failed";
            insertOperationHist(oHBean, lMsg, lLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            lLog = "sModuleCryptoBoardStatus() smodule crypt mode status {} {}";
            lMsg = OpHistRltRepo.getResultFailed().getName();
            log.warn(lLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, lMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse sModuleInsertKeyCode(int nodeId, String mode,
            String mmc, String keyNum, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsSmoduleInsertKeyCode();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        String groupId = "";
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        LocalDate today = LocalDate.now();
        String month = null;
        boolean isTxtLenFix = false;
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmsSModuleRes resData = new SmsSModuleRes();
        int resetCdRes = -1;
        String lLog = null;
        String lMsg = null;

        try {

            if (mode.equals("0")) {

                month = today.format(DateTimeFormatter.ofPattern("MM"));
                groupId = (Integer.parseInt(month) + N8) + "";
            } else {
                groupId = mmc;
            }

            isTxtLenFix = Set.of("0", "5", "6", "7", "8").contains(groupId);

            if ((isTxtLenFix) && (keyNum.length() != N20)) {
                log.trace("keynum not match");
                return new BaseResponse(ResRepo.getC514());
            }

            stmB.setReqInfo(SMS_SMODULE_INSERT_KEY_CODE,
                    new Object[] { groupId, keyNum });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
                resData.setStatus(resetCdRes);
                res.setData(resData);

                lLog = nCd.getName() + " smodule key insert success";

                if (resData.getStatus() != 0) {
                    lLog = nCd.getName() + " smodule key insert failed";
                }

                lMsg = OpHistRltRepo.getResultSuccess().getName();

                insertOperationHist(oHBean, lMsg, lLog);

                return res;
            }

            lMsg = OpHistRltRepo.getResultFailed().getName();
            lLog = nCd.getName() + " smodule key insert failed";
            insertOperationHist(oHBean, lMsg, lLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            lMsg = OpHistRltRepo.getResultFailed().getName();
            lLog = "sModuleInsertKeyCode() smodule key insert {} {}";
            log.warn(lLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, lMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    private int getBit(short value, int position) {
        
        int retBit = (value >>> position) & B01;
        
        return retBit;
    }

    private void parseSModuleDiagnosisAlarm(SmsSModuleRes resData,
            NodeModel nodeInfo, LoginSessionBean bean) {
        boolean isAlarmClear = false;
        AlarmRepo ac = null;
        AlarmRepo lv = null;
        String flag = null;

        if (resData.getStatus() != null) {
            isAlarmClear = ((resData.getStatus() == 0) ? true : false);
            ac = AlarmRepo.getAlmSmsCrypto();
            lv = AlarmRepo.getSvrMaj();
            flag = resData.getFlag();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, flag);
        }
    }

    private OperationHistModel getOpHistBean(LoginSessionBean bean,
            OpCmdRepo code, NodeModel nm) {
        OperationHistModel model = new OperationHistModel();
        String addInfo = hostName + " " + nm.getName() + " " + nm.getAddrIp();
        String tMsg = OpHistRltRepo.getResultSuccess().getCode();

        model.setStartTime(new Date());
        model.setUserId(bean.getUserId());
        model.setUserName(bean.getName());
        model.setUserIp(bean.getIp());
        model.setOperation(code.getMsg());
        model.setAdditionalInfo(addInfo);
        model.setOperationResult(tMsg);
        model.setEndTime(new Date());

        return model;
    }

    // LM_OPERATION_HIST 관리단말 명령 이력 저장
    private void insertOperationHist(OperationHistModel bean, String resultCode,
            String oHMsg) {
        try {

            bean.setOperationResult(resultCode);

            if (oHMsg.length() > N1000) {
                oHMsg = oHMsg.substring(0, N900);
            }

            bean.setAdditionalInfo(oHMsg);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);
        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString(), e);
        }
    }

}
