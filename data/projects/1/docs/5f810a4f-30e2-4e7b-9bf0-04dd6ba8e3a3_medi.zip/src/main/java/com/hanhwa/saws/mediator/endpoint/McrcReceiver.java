/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class McrcReceiver implements Runnable {

    private static final int N40000 = 40000;

    private MulticastSocket mSocket;

    private volatile boolean keepListening = true;
    private boolean timeoutCheckStarted = false;
    @Value("${server.udp-port}") private int udpPort;
    @Value("${server.udp-ip}") private String udpIp;
    @Value("${mediator.mode}") private String mode;
    @Value("${server.local-ip}") private String localIp;
    @Autowired
    private McrcTimeoutCheck mcrcTmoutCheck;

    @Autowired @Qualifier("mcrcRecvQueue")
    private ConcurrentLinkedQueue<byte[]> mcrcRecvQueue;

    @Autowired @Qualifier("McrcListenerExecutor")
    private TaskExecutor mcrcListenerExecutor;

    @Override
    public void run() {
        try {
            InetAddress maddr = InetAddress.getByName(udpIp);
            InetAddress addr = InetAddress.getByName(localIp);
            NetworkInterface nIf = NetworkInterface.getByInetAddress(addr);

            if (nIf == null) {
                throw new SocketException("No nif for IP: " + localIp);
            }

            mSocket = new MulticastSocket(udpPort);
            mSocket.joinGroup(new InetSocketAddress(maddr, 0), nIf);

            log.info("UDP Listener started on PORT: {}", udpPort);

            listenAndProcess();

        } catch (SocketException e) {
            log.warn("Failed to open UDP socket: {}", e.getMessage(), e);
        } catch (IOException e) {
            log.warn("Error: {}", e.getMessage(), e);
        }
    }

    private void listenAndProcess() {
        byte[] buffer = new byte[N40000];
        int length = 0;
        byte[] data = null;

        DatagramPacket dPacket = new DatagramPacket(buffer, buffer.length);

        String packetErrMsg = "MCRC RECEIVED DATA ({} bytes)";

        while (keepListening) {
            try {
                mSocket.receive(dPacket);

                length = dPacket.getLength();
                data = new byte[length];
                System.arraycopy(buffer, 0, data, 0, length);

                log.debug(packetErrMsg, length);

                mcrcRecvQueue.offer(data);

                mcrcTmoutCheck.setLastReceivedTime(System.currentTimeMillis());


                if (!timeoutCheckStarted) {
                    timeoutCheckStarted = true;
                    startTimeoutCheck();
                }

            } catch (IOException e) {
                log.warn("Error receiving UDP packet: {}", e.getMessage(), e);
            }
        }
    }

    public void startTimeoutCheck() {
        mcrcListenerExecutor.execute(mcrcTmoutCheck);
    }

}
