/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SmsSockListener {
    private static final int N1 = 1;
    private static final int N6 = 6;
    private static final int N5000 = 5000;
    
    private final TcpClientManager client;
    private final Executor smsListenerExecutor;
    private int unknownCount = 0;
    
    public SmsSockListener(
            TcpClientManager client, Executor smsListenerExecutor) {
        this.client = client;
        this.smsListenerExecutor = smsListenerExecutor;
    }

    public void addUnknownCount() {
        unknownCount += N1;
    }
    
    public void setUnknownInit() {
        unknownCount = 0;
    }

    public void tryConnect() {
        
        Socket socket = null;
        boolean isSN = false;
        boolean isSC = false;
        boolean isSConn = true;
        
        socket = client.getSocket();
        
        if (unknownCount > N6) {
            log.debug("SMS UNKNOWN COUNT {} RECONNECT", unknownCount);
            client.closeSocket();
            unknownCount = 0;
        }
        
        isSN = (socket == null);
        isSC = isSN || socket.isClosed();
        isSConn = !isSN && socket.isConnected();
        
        if (isSN || isSC || !isSConn) {

            try {

                log.info("SMS Trying to connect {}:{}", client.getHost(),
                        client.getPort());

                socket = new Socket();
                socket.setReuseAddress(true);
                socket.connect(new InetSocketAddress(client.getHost(),
                        client.getPort()), N5000);
                socket.setSoTimeout(0);

                client.setSocket(socket);

                log.info("SMS Connected to server {}:{}", client.getHost(),
                        client.getPort());

                if (client.startReceiver(smsListenerExecutor)) {
                    log.info("Receiver started for {}:{}", client.getHost(),
                            client.getPort());
                } else {
                    log.warn("Receiver already running, skip start");
                }

            } catch (Exception e) {
                log.warn("Connection failed to {}:{}, retry", client.getHost(),
                        client.getPort());
                       
            }

        }
       
    }

}
