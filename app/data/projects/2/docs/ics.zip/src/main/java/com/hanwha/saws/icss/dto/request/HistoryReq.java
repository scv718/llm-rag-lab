/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HistoryReq {
    private static final int N10 = 10;
    private String id;
    @JsonProperty("start_time") private String startTime;
    @JsonProperty("end_time") private String endTime;
    private String type;
    private int page = 1;
    @JsonProperty("list_size") private int listSize = N10;

    public void setLastMonth() {

        String fStr = "yyyyMMddHHmmss";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(fStr);
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime oneMonthAgo = null;
        LocalDateTime start = null;
        LocalDateTime end = null;

        if ((startTime == null) && (endTime == null)) {

            oneMonthAgo = now.minusMonths(1);
            this.startTime = oneMonthAgo.format(formatter);
            this.endTime = now.format(formatter);

        } else if ((startTime != null) && (endTime == null)) {

            start = LocalDateTime.parse(startTime, formatter);
            endTime = start.plusMonths(1).format(formatter);

        } else if ((startTime == null) && (endTime != null)) {

            end = LocalDateTime.parse(endTime, formatter);
            startTime = end.minusMonths(1).format(formatter);

        }
    }

}
