/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.EmsHistModel;
import com.hanwha.saws.icss.persistence.model.LoginHistModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;

public interface NonSyncHistDao {

    public void insertEmsHistInfo(EmsHistModel model);

    public void insertOperationHistInfo(OperationHistModel model);

    public List<OperationHistModel> selectOperationHistList(
            OperationHistModel param);

    public int selectOperationHistTotalCount(OperationHistModel param);

    public List<EmsHistModel> selectEmsHistList(EmsHistModel model);

    public int selectEmsHisTotalCount(EmsHistModel model);

    public void insertLoginHist(LoginHistModel model);

    public List<LoginHistModel> selectLoginHistList(LoginHistModel param);

    public int selectLoginHistListTotalCount(LoginHistModel param);

}