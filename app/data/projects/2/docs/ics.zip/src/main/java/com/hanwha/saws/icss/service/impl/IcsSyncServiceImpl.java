/*
 * ICSS
 * Version 1.0.0
 * by NBware
 * @Autowired 제거 방식이 공식문서에 추가 
 * 2022년부터 lombok 생성사 주입 방식 권장 (@RequiredArgsConstructor +final)
 * Since Spring 4.3, if a class defines only one constructor
 * Spring can automatically use that constructor for dependency injection,
 * even without the @Autowired annotation
 * (Spring Framework Reference, Section 5.2.7 — Injection with constructors)
 * Spring Boot 3.3.0 Reference Documentation 이후에도 빼라고 권장 (2022년)
 * Spring Boot favors constructor injection over field injection.
 * It allows your beans to be immutable and easier to test
 */
package com.hanwha.saws.icss.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hanwha.saws.icss.config.RemoteDbHealthMonitor;
import com.hanwha.saws.icss.persistence.dao.remote.SyncDao;
import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.persistence.model.UserModel;
import com.hanwha.saws.icss.service.IcsSyncService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service("IcsSyncService")
@RequiredArgsConstructor
@Slf4j
public class IcsSyncServiceImpl implements IcsSyncService {

    private final SyncDao syncDao;
    private final RemoteDbHealthMonitor remoteDbHealthMonitor;

    public List<StatusModel> getRemoteStatusList() {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            try {
                return syncDao.selectStatusList();
            } catch (RuntimeException e) {
                log.warn("getRemoteStatusList() " + e.toString());
            }
        } else {
            log.warn("getRemoteStatusList() remote db not alived");
        }
        return null;
    }

    public void setRemoteStatus(StatusModel model) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            try {
                syncDao.updateStatus(model);
            } catch (RuntimeException e) {
                log.warn("setRemoteStatus() " + e.toString());
            }
        } else {
            log.warn("setRemoteStatus() remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteStatus(List<StatusModel> param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.deleteStatusAll();
            if (param.size() > 0) {
                syncDao.syncStatusInfo(param);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteNode(List<NodeModel> param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.deleteNodeAll();
            if (param.size() > 0) {
                syncDao.syncNodeInfo(param);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteUserGroup(List<UserModel> param,
            List<GroupModel> gParam) {

        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.truncateUserAll(); // 속도문제로 빠른 삭제
            
            if (param.size() > 0) {
                syncDao.syncUserInfo(param);
            }
            
            syncDao.truncateGroupAll(); // 속도문제로 빠른 삭제

            if (gParam.size() > 0) {
                syncDao.syncGroupInfo(gParam);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteThreshold(List<ThresholdModel> param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.deleteThresholdAll();
            if (param.size() > 0) {
                syncDao.syncThresholdInfo(param);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteCurrAlarm(List<CurrAlarmModel> param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
//  DELETE가 느려서 초기 DEADLOCK이 발생 따라서 remote에 하는것이기 때문에 TRUNCATE로 처리
            syncDao.truncateCurrAlarmAll();
            if (param.size() > 0) {
                syncDao.syncCurrAlarmInfo(param);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteDefaultCode(List<DefaultCodeModel> param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.deleteDefaultCodeAll();
            if (param.size() > 0) {
                syncDao.syncDefaultCode(param);
            }

        } else {
            throw new IllegalStateException("remote db not alived");
        }

    }

    @Override
    public void syncMcrcHistBulkInsert(List<McrcHistModel> list) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertMcrcHistBulkInsert(list);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }
    
    @Override
    public void syncMcrcDetailHistBulkInsert(List<McrcHistDetailModel> list) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertMcrcHistDetailBulkInsert(list);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
        
    }

    @Override
    public void syncKamdHistBulkInsert(List<KamdHistModel> list) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertKamdHistBulkInsert(list);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }
    
    @Override
    public void syncKamdDetailHistBulkInsert(List<KamdHistDetailModel> list) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertKamdHistDetailBulkInsert(list);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
        
    }

    @Transactional(
            value = "remoteTransactionManager",
            rollbackFor = { SQLException.class, RuntimeException.class })
    @Override
    public void syncRemoteSawInfo(List<SawInfoModel> list) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.deleteSawInfoAll();
            if (list.size() > 0) {
                syncDao.syncSawInfo(list);
            }
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Override
    public void insertAlarmHistInsert(AlarmHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertAlarmHistInsert(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Override
    public void insertMessageHist(MessageHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertMessageHist(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Override
    public void insertAirHist(AirRaidHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertAirHist(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }        
    }

    @Override
    public void insertEmerHist(EmerHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertEmerHist(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Override
    public void insertAirDefWarnHist(AirDefWarnHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertAirDefWarnHist(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

    @Override
    public void insertStatusHist(StatusHistModel param) {
        if (remoteDbHealthMonitor.isRemoteAlive()) {
            syncDao.insertStatusHist(param);
        } else {
            throw new IllegalStateException("remote db not alived");
        }
    }

}
