/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.kiss.MissleTrackSduBean;
import com.hanwha.saws.icss.dto.kiss.MissleTrackVOBean;
import com.hanwha.saws.icss.persistence.dao.local.KamdHistDetailDao;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.util.DataCrypt;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class DBBulkKissDetailInsertMgr {
    private static final int N50 = 50;

    @Qualifier("kissDecQueue")
    private final ConcurrentLinkedQueue<MissleTrackSduBean> kissDecQueue;
    
    private final KamdHistDetailDao kamdRealHistDao;

    public final IcsSyncService syncService;

    @Value("${ics.user-key}")
    String uK;

    @Value("${ics.file-key}")
    String fK;
    
    @Value("${ics.failover-dir.kamd-detail}")
    String kamdSyncFailDir;
    
    private DataCrypt crypt = new DataCrypt();
    
    ArrayList<KamdHistDetailModel> bulkList = new ArrayList<>();
    
    @Scheduled(fixedDelayString = "100", initialDelayString = "3000")
    public void monitor() {
        
        KamdHistDetailModel bean = null;
        int bSize = 0;
        int qSize = 0;
        
        try {
            
            while (kissDecQueue.size() != 0) {            
                try {
                    bean = parseModel(kissDecQueue.poll());
                    if (bean != null) {
                        bulkList.add(bean);
                    }
                    
                } catch (GeneralSecurityException e) {
                    log.warn("KissDecService parse " + e.toString());
                    continue;
                }
                
                bSize = bulkList.size();
                qSize = kissDecQueue.size();

                if ((bSize > N50) || (qSize == 0)) {
                    kamdRealHistDao.insertKamdHistDetailBulkInsert(bulkList);
                    syncKissHist(bulkList);
                    bulkList.clear();
                }
            }

        } catch (RuntimeException e) {
            log.warn("KissDecServiceThread " + e.toString());
            bulkList.clear();
        }
    }
    
    private void syncKissHist(ArrayList<KamdHistDetailModel> bulkList) {
        try {
            syncService.syncKamdDetailHistBulkInsert(bulkList);
        } catch (RuntimeException e) {
            log.warn("syncKissHist() " + e.toString() + ": filesave");
            makeSyncKissFile(bulkList);
        }
    }
    
    private void makeSyncKissFile(ArrayList<KamdHistDetailModel> bulkList) {

        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = fmter.format(LocalDateTime.now());
        String dirPath = kamdSyncFailDir + "/" + dStr;

        try {

            if (!Files.exists(Paths.get(dirPath))) {
                Files.createDirectories(Paths.get(dirPath));
            }

        } catch (IOException | RuntimeException e) {
            log.warn("makeSyncKissDetailFile() createFile/Dir " + e.toString());
        }

        try (ObjectOutputStream os = new ObjectOutputStream(
                new FileOutputStream(dirPath + "/" + UUID.randomUUID()))) {

            os.writeObject(bulkList);

        } catch (IOException | RuntimeException e2) {
            log.warn("makeSyncKissDetailFile write " + e2.toString());
        }
    }
    
    private KamdHistDetailModel parseModel(MissleTrackSduBean model)
            throws GeneralSecurityException {
        KamdHistDetailModel krM = new KamdHistDetailModel();
//        log.debug("###"+model.getDecodeDataResult());
        List<MissleTrackVOBean> vos = model.getVos();
        MissleTrackVOBean bean = null;

        if (vos != null && vos.size() > 0) {
            bean = vos.get(0);
        }
        
        krM.setInsertTime(model.getRecvTime());
        krM.setSpeedStrConvert(bean.getVelocitySpeedStr());
        krM.setDirectionStr(bean.getVelocityCourseStr());
        krM.setAltitudeConvert(bean.getMissileAltitude());
        krM.setTrackNumberHash(hmacSha256(bean.getTrackNumberString(), uK));
        krM.setLatitudeHash(hmacSha256(bean.getMissileLocLatitudeStr(), uK));
        krM.setLongitudeHash(hmacSha256(bean.getMissileLocLongitudeStr(), uK));
        krM.setTrackNumberEnc(
                crypt.encrypt(bean.getTrackNumberString().getBytes(), fK));
        krM.setLatitudeEnc(
                crypt.encrypt(bean.getMissileLocLatitudeStr().getBytes(), fK));
        krM.setLongitudeEnc(
                crypt.encrypt(bean.getMissileLocLongitudeStr().getBytes(), fK));
        
        return krM;
    }
    
    private byte[] hmacSha256(String data, String key)
            throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] rawHmac = null;

        mac.init(new SecretKeySpec(key.getBytes(), "HmacSHA256"));
        rawHmac = mac.doFinal(data.getBytes());

        return rawHmac;
    }
   
}
