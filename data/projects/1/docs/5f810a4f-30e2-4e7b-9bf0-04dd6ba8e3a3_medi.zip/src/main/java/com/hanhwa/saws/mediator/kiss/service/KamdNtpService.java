/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.kiss.service;

public interface KamdNtpService {

    void setNtp(String time);
}
