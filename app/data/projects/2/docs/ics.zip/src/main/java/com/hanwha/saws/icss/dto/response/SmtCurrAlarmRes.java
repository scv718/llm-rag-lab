/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;

import lombok.Data;

@Data
public class SmtCurrAlarmRes {

    private Integer seq;
    @JsonProperty("node_id") private Integer nodeId;
    @JsonProperty("node_name") private String nodeName;
    @JsonProperty("ip") private String addrIp;
    @JsonProperty("alarm_id") private String alarmId;
    @JsonProperty("alarm_name") private String alarmName;
    private String serverity;
    private String summary;
    @JsonProperty("first_occur") private String firstOccurrence;
    @JsonProperty("last_occur") private String lastOccurrence;
    private int tally;

    @JsonIgnore
    public void setData(CurrAlarmModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        seq = data.getSeq();
        nodeId = data.getNodeId();
        nodeName = data.getNodeName();
        addrIp = data.getAddrIp();
        alarmId = data.getAlarmId();
        alarmName = data.getAlarmName();
        serverity = data.getServerity();
        summary = data.getSummary();
        firstOccurrence = sdf.format(data.getFirstOccurrence());
        lastOccurrence = sdf.format(data.getLastOccurrence());
        tally = data.getTally();

    }
}
