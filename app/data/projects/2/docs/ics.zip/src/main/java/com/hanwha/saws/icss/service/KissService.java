/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.io.IOException;
import java.util.HashMap;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.response.BaseResponse;

public interface KissService {

    public void handleEvent(RecvMsgQueueBean param);

    BaseResponse getKamdHistList(HashMap body)
            throws IOException;
}
