/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class NodeModel {

    private Integer nodeId;
    private String sysId;
    private String name;
    private String addrIp;
    private String osVersion;
    private String modelName;
    private String hddSize;
    private String memorySize;
    private String venderName;
    private String portNumber;
    private Date updateTime;
    private Integer alarmFlag;
    private Integer activeMode;
    
    public NodeModel() {}
    
    public NodeModel(NodeModel src) {
        this.nodeId = src.nodeId;
        this.sysId = src.sysId;
        this.name = src.name;
        this.addrIp = src.addrIp;
        this.osVersion = src.osVersion;
        this.modelName = src.modelName;
        this.hddSize = src.hddSize;
        this.memorySize = src.memorySize;
        this.venderName = src.venderName;
        this.portNumber = src.portNumber;

        this.updateTime = ((src.updateTime != null) 
                           ? new Date(src.updateTime.getTime()) 
                           : null);

        this.alarmFlag = src.alarmFlag;
        this.activeMode = src.activeMode;
    }
}
