/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SmsSockReceiver implements Runnable {

    private static final int N1024 = 1024;

    private final TcpClientManager client;

    public SmsSockReceiver(TcpClientManager client) {
        this.client = client;
    }
    
    @Override
    public void run() {
        
        byte[] buf = new byte[N1024];
        int len = 0;
        
        try (InputStream in = client.getSocket().getInputStream()) {
            
            while ((len = in.read(buf)) != -1) {
                byte[] data = Arrays.copyOf(buf, len);
                client.onReceive(data); // 기존 로직 그대로
            }
        } catch (IOException e) {
            log.debug("Disconnected from server {}:{}", client.getHost(),
                    client.getPort());            
        }finally {
            client.closeSocket();
            client.receiverFinished(); // Receiver 종료 플래그 해제
        }
    }
}
