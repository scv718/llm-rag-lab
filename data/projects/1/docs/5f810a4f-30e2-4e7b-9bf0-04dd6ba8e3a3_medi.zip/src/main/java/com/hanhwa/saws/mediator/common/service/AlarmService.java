/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.common.service;

public interface AlarmService {

    void setNoDataAlarm(String result);

    void setDataCorruptionAlarm(String result);

}
