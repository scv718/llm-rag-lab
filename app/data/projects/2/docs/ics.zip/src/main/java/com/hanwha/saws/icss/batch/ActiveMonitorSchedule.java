/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.request.ActiveStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.service.SmtService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ActiveMonitorSchedule {

    private static Logger statusLog = null;

    private static final int M_LOCAL = 0;
    private static final int M_REMO = 1;
    private static final int INIT_WAIT = 0;
    private static final int ACTIVE = 1;
    private static final int STANDBY = 0;
    private static final int UNKNOWN = 0;

    @Autowired PropConfig prop;
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired RestClientService restClient;
    @Autowired SmtService smtService;
    @Autowired IcsSyncService syncService;
    @Autowired RdbSyncRtService rtSync;
    @Autowired AlarmService alarmService;
    @Value("${prop.host-name}") String hostName;
    @Value("${server.hostIp}") private String localIp;
    
    @Scheduled(
            fixedDelayString = "${cron.active-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void activeMonitor() throws IOException {

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());
        statusLog.debug("ACTIVE MONITOR BATCH START");

        try {

            if (!smtService.isFailingOver()) {
                eventHandle();
            } else {
                log.debug("NOW FAILOVER");
            }

        } catch (NoClassDefFoundError e) {
            log.warn("activeMonitor() NoClassDefFound");
        } catch (RuntimeException e) {
            log.warn("activeMonitor batch " + e.toString());
        }

        statusLog.debug("ACTIVE MONITOR BATCH END");
    }

    private void eventHandle() {

        BaseResponse res = null;
        boolean localActiveDown = false;
        boolean localActive = false;

        List<StatusModel> statusList = null;
        List<StatusModel> remoteStatusList = null;

        String typeBin = "0";
        final int RADIX = 2;
        final int LOCALDOWN = 2;
        final int TWOLDOWN = 3;
        int downType = 0;
        int localDbMode = -1;
        boolean remoteDown = false;
        StatusModel param = null;
        ActiveStatusReq body = null;
        StatusRepo stCode = null;
        
        try {
            prop.readNodeSawStatus(); // nodeinfo, sawinfo read

            statusList = statusConfigDao.selectStatusList(); // 내 DB에서 상태 조회
            if ((statusList == null) || (statusList.isEmpty())) {
                localActiveDown = true;
            } else {
                localDbMode = -1;
                for (StatusModel sm : statusList) {

                    // 줄바꿈은 최상위 식에서만 연결된다
                    localDbMode = NodeUtil.getIcsStatus(hostName, sm, M_LOCAL);
                }

                if (localDbMode == StatusRepo.getACTIVE().getCode()) {
                    localActive = true;
                }
            }
        } catch (RuntimeException e) {
            log.warn("eventHandle() " + e.toString());
            localActiveDown = true;
        }

        res = restClient.getHeartBeat(prop.getRIcsIp());
        remoteStatusList = syncService.getRemoteStatusList();

        if (res == null) { // 상대 REST DOWN시
            remoteDown = true;
        }

        if (remoteStatusList == null) { // 상대 DB 다운시
            remoteDown = true;
        }

        typeBin = ((localActiveDown) ? "1" : "0") + (remoteDown ? "1" : "0");

        downType = Integer.parseInt(typeBin, RADIX);

        if (!isLocalNetProblem()) { // 로컬 네트워크 다운상태
            param = new StatusModel();
            
            prop.setActiveMode(STANDBY);
            stCode = StatusRepo.getSTANDBY();           
            NodeUtil.setIcsStatusMode(hostName, param, stCode, M_LOCAL);
            
            stCode = StatusRepo.getACTIVE();        
            NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
            body = new ActiveStatusReq(null, stCode.getCode());
            restClient.setMode(body, prop.getRIcsIp());
           
            statusConfigDao.updateStatus(param);
            rtSync.insertQueue(param, "UPDATE");
            return;
        }
        
        switch (downType) {
            case LOCALDOWN, TWOLDOWN : {
                prop.setActiveMode(UNKNOWN);
                break;
            }
            case 0 : {
                statusSync(localActive, statusList, remoteStatusList);
                break;
            }
            case 1 : {
                remoteDownStatus(localActive, statusList, remoteStatusList);
                break;
            }
            default : {
                log.warn("local/remote not match type {}", downType);
                break;
            }
        }
    }

    private void statusSync(boolean localActive, List<StatusModel> statusList,
            List<StatusModel> remoteStatusList) {

        int remoteDbMode = -1;
        boolean remoteActive = false;
        final int RADIX = 2;
        int activeType = 0;

        String typeBin = null;

        final int twoStandby = 0;
        final int twolActive = 3;
        final int localAct = 2;

        int localRemoteDbMode = -1;

        StatusModel param = null;

        StatusRepo stCode = null;

        AlarmRepo ac = null;
        AlarmRepo rep = null;
        NodeModel rN = null;
        String summary = null;

        for (StatusModel sm : remoteStatusList) {
            remoteDbMode = NodeUtil.getIcsStatus(hostName, sm, M_REMO);
        }

        if (remoteDbMode == StatusRepo.getACTIVE().getCode()) {
            remoteActive = true;
        }

        typeBin = ((localActive) ? "1" : "0") + (remoteActive ? "1" : "0");

        activeType = Integer.parseInt(typeBin, RADIX);

        switch (activeType) {
            case twoStandby, twolActive: { // 둘다 standby 또는 둘다 active
                doTypeSync(localActive);
                break;
            }
            case 1: { // remote active
                prop.setActiveMode(STANDBY);
                break;
            }
            case localAct: { // local active
                prop.setActiveMode(ACTIVE);
    
                for (StatusModel st : statusList) {
                    localRemoteDbMode = NodeUtil.getIcsStatus(hostName, st,
                            M_REMO);
                }
                if (localRemoteDbMode != StatusRepo.getSTANDBY().getCode()) {
                    param = new StatusModel();
                    stCode = StatusRepo.getSTANDBY();
                    NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
                    statusConfigDao.updateStatus(param);
                    rtSync.insertQueue(param, "UPDATE");
                }
    
                ac = AlarmRepo.getAlmSystem();
                rep = AlarmRepo.getSvrCle();
                rN = NodeUtil.getNodeRemoteIcs(hostName, 
                        prop.getNodeInfoHash());
                summary = (rN.getName() + " connection problem");
                alarmService.alarmUpdate(true, ac, rN, rep, summary);
                break;
            }

            default: {
                log.warn("local/remote mode is normal {}", activeType);
                break;
            }
        }
    }

    private void doTypeSync(boolean localActive) {

        ActiveStatusReq body = null;
        StatusModel param = null;
        StatusRepo stCode = null;

        if (hostName.equals("ICSS_A")) {

            param = new StatusModel();
            stCode = StatusRepo.getSTANDBY();
            NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
            statusConfigDao.updateStatus(param);

            if (localActive) { // 둘다 active 상태

                stCode = StatusRepo.getSTANDBY();
                param = new StatusModel();
                NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
                syncService.setRemoteStatus(param);
                body = new ActiveStatusReq(null, stCode.getCode());
                restClient.setMode(body, prop.getRIcsIp());
                prop.setActiveMode(ACTIVE);

            } else { // 둘다 standby 상태

                param = new StatusModel();
                stCode = StatusRepo.getACTIVE();
                NodeUtil.setIcsStatusMode(hostName, param, stCode, M_LOCAL);
                statusConfigDao.updateStatus(param);
                syncService.setRemoteStatus(param);
                prop.setActiveMode(ACTIVE);

            }
        } else { // 내가 ICSS_A가 아니고 둘다 살아있으면 standby설정 어차피
            prop.setActiveMode(STANDBY);
            if (localActive) { // 둘다 살아있는데 내가 STANDBY가 안되어있으면 우선 DB처리
                stCode = StatusRepo.getSTANDBY();
                param = new StatusModel();
                NodeUtil.setIcsStatusMode(hostName, param, stCode, M_LOCAL);
                statusConfigDao.updateStatus(param);
                syncService.setRemoteStatus(param);
            }
        }
    }

    private void remoteDownStatus(boolean localActive,
            List<StatusModel> statusList,
            List<StatusModel> remoteStatusList) {

        int remoteDbMode = -1;
        StatusModel param = null;
        StatusRepo stCode = null;
        AlarmRepo ac = null;
        AlarmRepo rep = null;
        NodeModel rN = null;
        String summary = null;

        for (StatusModel sm : statusList) {
            remoteDbMode = NodeUtil.getIcsStatus(hostName, sm, M_REMO);
        }

        prop.setActiveMode(ACTIVE);

        if (localActive) {

            if (remoteDbMode != StatusRepo.getUNKNOWN().getCode()) {
                stCode = StatusRepo.getUNKNOWN();
                param = new StatusModel();
                NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
                statusConfigDao.updateStatus(param);

                if (remoteStatusList != null) {
                    rtSync.insertQueue(param, "UPDATE");
                }
            }

            ac = AlarmRepo.getAlmSystem();
            rep = AlarmRepo.getSvrMin();
            rN = NodeUtil.getNodeRemoteIcs(hostName, prop.getNodeInfoHash());

            summary = (rN.getName() + " connection problem");
            alarmService.alarmUpdate(false, ac, rN, rep, summary);
            
        } else {

            param = new StatusModel();
            stCode = StatusRepo.getACTIVE();
            NodeUtil.setIcsStatusMode(hostName, param, stCode, M_LOCAL);
            if (remoteDbMode != StatusRepo.getUNKNOWN().getCode()) {
                stCode = StatusRepo.getUNKNOWN();
                NodeUtil.setIcsStatusMode(hostName, param, stCode, M_REMO);
            }

            statusConfigDao.updateStatus(param);

            if (remoteStatusList != null) {
                rtSync.insertQueue(param, "UPDATE");
            }

        }
    }
    
    private boolean isLocalNetProblem() {

        if (isKeepalivedRunning()) {
            if (isCommOkByIp(localIp)) {
                return true;
            }
        }

        return false;
    }
    
    private boolean isCommOkByIp(String ipStr) {

        if (ipStr == null || ipStr.isBlank()) {
            return false;
        }

        try {
            InetAddress ip = InetAddress.getByName(ipStr);

            NetworkInterface nif = findInterfaceByIp(ip);
            if (nif == null) {
                return false; // IP가 안잡힘
            } else if (!nif.isUp()) {
                return false; // state DOWN
            } else if (!hasCarrier(nif.getName())) {
                return false; // NO-CARRIER
            }

            return true; // 그 외 통신 가능으로 간주
        } catch (IOException e) {
            return false;
        }
    }

    private boolean hasCarrier(String ifName) {
        Path carrierPath = Path.of("/sys/class/net", ifName, "carrier");
        
        try {
            String v = Files.readString(carrierPath, StandardCharsets.US_ASCII)
                    .trim();
            return "1".equals(v);
        } catch (IOException e) {
            return false;
        }
    }

    private NetworkInterface findInterfaceByIp(InetAddress ip)
            throws IOException {
        Enumeration<NetworkInterface> ifs = NetworkInterface
                .getNetworkInterfaces();
        
        while (ifs.hasMoreElements()) {
            NetworkInterface nif = ifs.nextElement();
            Enumeration<InetAddress> addrs = null;
            if (nif == null) {
                continue;
            }
            if (nif.isLoopback() || nif.isVirtual()) {
                continue;
            }

            addrs = nif.getInetAddresses();
            while (addrs.hasMoreElements()) {
                if (ip.equals(addrs.nextElement())) {
                    return nif;
                }
            }
        }
        return null;
    }

    private boolean isKeepalivedRunning() {
        
        Path comm = null;
        
        try (DirectoryStream<Path> ds = Files
                .newDirectoryStream(Path.of("/proc"))) {
            for (Path p : ds) {
                String v = null;
                String name = p.getFileName().toString();
                if (!isDigits(name)) {
                    continue;
                }

                comm = p.resolve("comm");
                if (!Files.isReadable(comm)) {
                    continue;
                }

                v = Files.readString(comm, StandardCharsets.US_ASCII).trim();
                if ("keepalived".equals(v)) {
                    return true;
                }
            }
        } catch (IOException ignored) {
            log.trace("isKeepalivedRunning error");
        }
        return false;
    }

    private boolean isDigits(String s) {
        if (s == null || s.isEmpty()) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

}
