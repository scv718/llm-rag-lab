/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;

public interface SyncHistInsertService {

    void insertFailoverAlarmHist(AlarmHistModel param, String mode);

    void insertMessageHist(MessageHistModel param);

    void insertAirRaidHist(AirRaidHistModel param);

    void insertAirDefWarnAirRaidHist(AirRaidHistModel param);

    void insertEmHist(EmerHistModel param);

    void insertAirDefWarnHist(AirDefWarnHistModel param);

    void insertAlarmHist(AlarmHistModel bean);

    void insertStatusHist(StatusHistModel bean);
}
