/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.kiss.service.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.hanhwa.saws.mediator.kiss.service.KamdNtpService;
import lombok.extern.slf4j.Slf4j;

@Service("KamdNtpService")
@Slf4j
public class KamdNtpServiceImpl implements KamdNtpService {

    @Value("${ntp.script-path}") private String ntpPath;

    @Value("${ntp.mode}") private String ntpMode;

    @Override
    public void setNtp(String dateStr) {

        try {

            String finalDateStr;
            Date utcDate = null;
            Date kstDate = null;
            SimpleDateFormat kstFormat = null;
            SimpleDateFormat utcFormat = null;
            ProcessBuilder processBuilder;
            Process process;
            int exitCode;   
            
            StringBuilder sb = new StringBuilder();

            // 기본은 UTC 로 인식함
            if (!"KST".equalsIgnoreCase(ntpMode)) {

                utcFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                utcFormat.setTimeZone(TimeZone.getTimeZone("UTC")); 
                utcDate = utcFormat.parse(dateStr);

                kstFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                kstFormat.setTimeZone(TimeZone.getTimeZone("Asia/Seoul"));
                finalDateStr = kstFormat.format(utcDate);

                log.info("System time changed to KST: {}", finalDateStr);
            } else {
//                // KST 모드라면 변환 없이 입력값 그대로 사용하려했으나 정적검사로 인해 변경
                kstFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                kstFormat.setTimeZone(TimeZone.getTimeZone("Asia/Seoul"));
                kstDate = kstFormat.parse(dateStr);
                
                finalDateStr = kstFormat.format(kstDate);
                     
                // dateStr이 KST임을 명시적으로 로깅만
                //finalDateStr = dateStr;
                log.info("System time changed to KST: {}", finalDateStr);
            }


            processBuilder = new ProcessBuilder();
            /*
             * sb.append("bash"); 
             * sb.append(" ").append(ntpPath);
             * sb.append(" ").append(finalDateStr);
             * processBuilder.command(sb.toString().split(" "));
             */
            
            processBuilder.command("bash", ntpPath, finalDateStr);
            processBuilder.inheritIO();

            log.info("Executing: bash {} {}", ntpPath, finalDateStr);

            process = processBuilder.start();
            process.toHandle().onExit().join();
            exitCode = process.exitValue();

            if (exitCode == 0) {
                log.info("Time sync successfully.");
            } else {
                log.warn("Time sync script failed: {}", exitCode);
            }

        } catch (RuntimeException e) {
            log.warn("Time sync error: {}", e.toString(), e);
        } catch (IOException e) {
            log.warn("Time sync I/O error: {}", e.toString(), e);
        } catch (ParseException e) {
            log.warn("Time Date Parse error: {}", e.toString(), e);
        }
    }

}
