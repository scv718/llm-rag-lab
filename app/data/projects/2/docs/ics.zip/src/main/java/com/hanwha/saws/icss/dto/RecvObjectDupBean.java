/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import lombok.Data;

@Data
public class RecvObjectDupBean {
	
	private long recvTime;
	private String senderIp;
	private Long knot;
	
	public RecvObjectDupBean copy() {
	    RecvObjectDupBean c = new RecvObjectDupBean();
	    
	    c.setRecvTime(this.recvTime);
	    c.setSenderIp(this.senderIp);
	    c.setKnot(this.knot);
	    return c;
	}
}
