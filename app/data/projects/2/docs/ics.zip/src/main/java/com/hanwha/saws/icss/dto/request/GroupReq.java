/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import lombok.Data;

@Data
public class GroupReq {

    private String id;
    private String name;
    private String desc;

}
