/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "mediator")
public class MediatorConfig {

    private String restartScript;

    public String getRestartScript() {
        return restartScript;
    }

    public void setRestartScript(String rScript) {
        this.restartScript = rScript;
    }
}
