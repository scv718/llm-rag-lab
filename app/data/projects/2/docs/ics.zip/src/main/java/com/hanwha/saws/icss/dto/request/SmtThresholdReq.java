/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import lombok.Data;

@Data
public class SmtThresholdReq {

    private Integer type;
    private Integer level;
    private Integer data;

}
