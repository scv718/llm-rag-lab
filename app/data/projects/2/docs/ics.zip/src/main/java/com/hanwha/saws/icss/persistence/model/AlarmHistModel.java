/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class AlarmHistModel implements Serializable {
    private static final int N10 = 10;
    private static final int N1000 = 1000;
    
    private long seqNo;
    private String currUuid;
    private Integer nodeId;
    private String nodeName;
    private String addrIp;
    private String alarmId;
    private String alarmName;
    private String serverity;
    private String prevSev;
    private String location;
    private String summary;
    private Date firstOccurrence;
    private Date lastOccurrence;
    private String recoverReason;
    private Date recoverTime;
    private int tally;
    private int totalCount;
    private Timestamp insertTime;

    private long idx;
    private String startTime;
    private String endTime;
    private int rowCount;
    private int startIdx;

    public void setPage(Integer page, Integer listCount) {
      
        if (page == null || page == 0) {
            page = 1;
        }
        
        if (listCount == null || listCount == 0) {
            listCount = N10;
        }
        
        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }

    public void setTime() {
        LocalDateTime now = LocalDateTime.now();

        now = now.plusNanos(System.nanoTime() % N1000); // 미세한 차이 추가
        insertTime = Timestamp.valueOf(now);
        lastOccurrence = insertTime;
    }

    public void parseCurrentBean(CurrAlarmModel bean) {
        currUuid = bean.getUuid();
        nodeId = bean.getNodeId();
        nodeName = bean.getNodeName();
        addrIp = bean.getAddrIp();
        alarmId = bean.getAlarmId();
        alarmName = bean.getAlarmName();
        serverity = bean.getServerity();
        prevSev = bean.getServerity(); 
        location = bean.getLocation();
        summary = bean.getSummary();
        firstOccurrence = bean.getFirstOccurrence();
        lastOccurrence = bean.getLastOccurrence();
        tally = bean.getTally();
        insertTime = bean.getInsertTime();

    }
}
