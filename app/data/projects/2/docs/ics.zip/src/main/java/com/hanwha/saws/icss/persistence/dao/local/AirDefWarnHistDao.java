/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;

public interface AirDefWarnHistDao {

    public void insertAirDefWarnHist(AirDefWarnHistModel param);

    public int selectAirDefWarnHistTotalCount(AirDefWarnHistModel param);

    public List<AirDefWarnHistModel> selectAirDefWarnHistList(
            AirDefWarnHistModel param);

}
