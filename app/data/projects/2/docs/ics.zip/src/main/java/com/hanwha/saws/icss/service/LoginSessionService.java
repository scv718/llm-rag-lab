/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ConcurrentHashMap;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.model.UserModel;

public interface LoginSessionService {

    public BaseResponse getSession(String bearer, String ip);

    boolean getCheckSession(String userId);

    public LoginSessionBean genSession(UserModel bean, String senderIp)
            throws InvalidKeyException, NoSuchAlgorithmException;

    void syncSession(ConcurrentHashMap<String, LoginSessionBean> bean);

    ConcurrentHashMap<String, LoginSessionBean> getSessionAll();

    void deleteSession(String bearer);

    LoginSessionBean getUserSession(String userId);

    void pSess(String ip);

}
