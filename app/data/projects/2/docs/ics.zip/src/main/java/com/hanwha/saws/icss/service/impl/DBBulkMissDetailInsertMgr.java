/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvObjectDupBean;
import com.hanwha.saws.icss.dto.miss.AirTrackMOBean;
import com.hanwha.saws.icss.dto.miss.AirTrackSduBean;
import com.hanwha.saws.icss.persistence.dao.local.McrcHistDetailDao;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.util.DataCrypt;
import com.hanwha.saws.icss.util.HexByteUtil;
import com.hanwha.saws.icss.util.McrcLatLonParser;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class DBBulkMissDetailInsertMgr {

    private static final double EPS = 1e-12;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N5 = 5;
    private static final int N50 = 50;
    private static final int N256 = 256;
    private static final int N500 = 500;
    private static final int N127500 = 127500;
    
    private static final int N1 = 1;
    private static final int N10 = 10;
    private static final int N20 = 20;
    private static final int N250 = 250;
    private static final int N7 = 7;
    private static final int N12 = 12;
    private static final int N90 = 90;
    private static final int N270 = 270;
    private static final int N360 = 360;
    private static final int N128 = 128;
    private static final int N255 = 255;
    private static final int N60 = 60;
    private static final double D025 = 0.25;
    private static final double D5 = 5.0;
    private static final double D128 = 128;
    private static final double D3600 = 3600;
    private static final double DM_TO_NM = (1 / 1.012685914);
    private static final int BFF = 0xFF;
    
    @Qualifier("MissDecQueue")
    private final ConcurrentLinkedQueue<AirTrackSduBean> missDecQueue;
    
    @Autowired
    @Qualifier("missPrevKnotMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> missPrevKnotMap;
    
    private final McrcHistDetailDao mcrcRealHistDao;

    public final IcsSyncService syncService;
    
    @Value("${ics.user-key}")
    String uK;

    @Value("${ics.file-key}")
    String fK;
    
    @Value("${ics.failover-dir.mcrc-detail}")
    String mcrcSyncFailDir;
    
    private DataCrypt crypt = new DataCrypt();
    private McrcLatLonParser xyParser = new McrcLatLonParser(); 
    ArrayList<McrcHistDetailModel> bulkList = new ArrayList<>();
    
    @Scheduled(fixedDelayString = "100", initialDelayString = "3000")
    public void monitor() {
        
        List<McrcHistDetailModel> mList = null;
        int bSize = 0;
        int qSize = 0;
        
        try {
            
            while (missDecQueue.size() != 0) {            
                try {
                    mList = parseModel(missDecQueue.poll());
                    if (mList != null && !mList.isEmpty()) {
                        bulkList.addAll(mList);
                    }

                } catch (GeneralSecurityException e) {
                    log.warn("MissDecService parse " + e.toString());
                    continue;
                }

                bSize = bulkList.size();
                qSize = missDecQueue.size();

                if ((bSize > N50) || (qSize == 0)) {
                    mcrcRealHistDao.insertMcrcHistDetailBulkInsert(bulkList);
                    syncMissHist(bulkList);
                    bulkList.clear();
                }
            }

        } catch (RuntimeException e) {
            log.warn("MissDecServiceThread " + e.toString(),e);
            bulkList.clear();
        }
    }
    
    private void syncMissHist(ArrayList<McrcHistDetailModel> bulkList) {
        try {
            syncService.syncMcrcDetailHistBulkInsert(bulkList);
        } catch (RuntimeException e) {
            log.warn("syncMissHist() " + e.toString() + ": filesave");
            makeSyncMissFile(bulkList);
        }
    }
    
    private void makeSyncMissFile(ArrayList<McrcHistDetailModel> bulkList) {

        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = fmter.format(LocalDateTime.now());
        String dirPath = mcrcSyncFailDir + "/" + dStr;

        try {

            if (!Files.exists(Paths.get(dirPath))) {
                Files.createDirectories(Paths.get(dirPath));
            }

        } catch (IOException | RuntimeException e) {
            log.warn("makeSyncMissFile() createFile/Dir " + e.toString());
        }

        try (ObjectOutputStream os = new ObjectOutputStream(
                new FileOutputStream(dirPath + "/" + UUID.randomUUID()))) {

            os.writeObject(bulkList);

        } catch (IOException | RuntimeException e2) {
            log.warn("makeSyncMissFile write " + e2.toString());
        }
    }
    
    private List<McrcHistDetailModel> parseModel(AirTrackSduBean model)
            throws GeneralSecurityException {
        
        List<McrcHistDetailModel> mList = new ArrayList<>();
        McrcHistDetailModel mrM = null;
        List<AirTrackMOBean> mos = model.getMos();
        String idenStr = "";
        String flStr = "";
        String latStr = "";
        String longStr = "";
        double[] outDeg = null;
        float xPos = 0;
        float yPos = 0;
        int tmpAlt = 0;
        Timestamp base = model.getRecvTime();
        
        int altitude = (tmpAlt == N127500) ? 0 : tmpAlt;
        
        if (mos == null || mos.isEmpty()) {
            return null;
        }
        
        for (int i = 0; i < mos.size(); i++) {
            AirTrackMOBean mo = mos.get(i);

            mrM = new McrcHistDetailModel();
            mrM.setInsertTime(Timestamp.from(base.toInstant().plusNanos(i)));
            mrM.setSimulMode(mo.getSimLiveState());
            
            idenStr = mo.getIdentity() + "";
            
            if (mo.getIdentity() == 0 || mo.getIdentity() > N12) {
                idenStr = "0";
            }
            
            flStr = mo.getFlightSize() + "";
            
            tmpAlt = mo.getAltitudeInt() * N500;
            mrM.setAltitude((tmpAlt == N127500) ? 0 : tmpAlt);
            
            mrM.setIdentityHash(hmacSha256(idenStr, uK));
            mrM.setIdentityEnc(crypt.encrypt(idenStr.getBytes(), fK));
            mrM.setFlightSizeHash(hmacSha256(flStr, uK));
            
            mrM.setTrackNumberHash(hmacSha256(mo.getTrackNumberStr(), uK));
            mrM.setTrackNumberEnc(
                    crypt.encrypt(mo.getTrackNumberStr().getBytes(), fK));
            mrM.setFlightSizeEnc(crypt.encrypt(flStr.getBytes(), fK));
         
            if (mrM.getSimulMode() != N2) {
//              방향, 위도, 경도는 우리 임의 로직 
                int dir = getDirection(mo.getXVelocity(), mo.getYVelocity());
                long speed = getKnots(mo.getXVelocity(), mo.getYVelocity());
                
//              여기서 보정 추가
                long round = getCalcedKnot(mo,speed);              
              
                if (mo.getRefPosition() == 0) {
                    xyParser.initOsan();                    
                } else {
                    xyParser.initDaegu();
                }                
                
                outDeg = new double[N2];

                xPos = xyParser.systemAirCoordinate((float) mo.getXPosition());
                yPos = xyParser.systemAirCoordinate((float) mo.getYPosition());

                xyParser.xyToDegLatLon(xPos, yPos, outDeg);
                
                mrM.setDirectionStr(dir + "");
                mrM.setSpeedStr(round + "");
                latStr = Double.toString(outDeg[0]);
                longStr = Double.toString(outDeg[N1]);
                
                mrM.setLatitudeHash(hmacSha256(latStr, uK));
                mrM.setLongitudeHash(hmacSha256(longStr, uK));
                mrM.setLatitudeEnc(crypt.encrypt(latStr.getBytes(), fK));
                mrM.setLongitudeEnc(crypt.encrypt(longStr.getBytes(), fK));
               
            } else {
                latStr = mo.getLatitude() + "";
                longStr = mo.getLongitude() + "";
                
                mrM.setLatitudeHash(hmacSha256(latStr, uK));
                mrM.setLongitudeHash(hmacSha256(longStr, uK));
                mrM.setLatitudeEnc(crypt.encrypt(latStr.getBytes(), fK));
                mrM.setLongitudeEnc(crypt.encrypt(longStr.getBytes(), fK));
                
                mrM.setSpeedStr(mo.getSpeed() + "");
                mrM.setDirectionStr(mo.getCourse() + "");
            }
      
            mList.add(mrM);
        }  
        return mList;
    }
    
    /** 
     * 이전 데이터를 가지고 0.25%내외로 이동하는 보정 속도를 처리하고
     * 10단위로 데이터를 출력하되 반올림을 하는 2차 보정 수행    
     */
    private long getCalcedKnot(AirTrackMOBean mo,Long speed) {
        
        String trackNum = HexByteUtil
                .getByteArrayToHexString(mo.getTrackNumber());
        String key = mo.getSimLiveState() + "_" + trackNum;
        Long prevKnot = null;
        long round = 0;
        long deltaSpeed = 0;
        long threshold = 0;        
        
        if (missPrevKnotMap.containsKey(key)) {
            prevKnot = missPrevKnotMap.get(key).getKnot();
        }

        if (prevKnot == null) {
            round = ((speed + N5) / N10) * N10;
            missPrevKnotMap.get(key).setKnot(round);
            return round;
        }
        
        //smoothing 처리
        deltaSpeed = speed - prevKnot;
        threshold = (speed < N250) ? N10 : N20;
        
        //음수를 양수로 바꾸면서 절대값 범위 측정 
        if (Math.abs(deltaSpeed) > threshold) {
            prevKnot += (long) (deltaSpeed * D025);
        } else {
            prevKnot = speed;
        }
        
        round = ( (prevKnot + N5) / N10 ) * N10;
        missPrevKnotMap.get(key).setKnot(round);        
        
        return round;
    }
            
    /**
     * 단위는 1/128 dm/s 이며 이를 NM(해리)로 변환하고  
     * 이를 knot 의 단위인 NM/h으로 변환해서 추출한다
     * xy의 값의 범위는 +- 127/128 dm/sec 단위로 움직이며 
     * TM좌표계(Tangent Mercator)기준으로 
     * x  + (동) -(서) 으로 구분된다 
     * y  + (북) -(남) 으로 구분된다
     * 값의 범위는 0~127 128~255로 정확히 절반으로 구분된다 unsigned랑 헷갈리지 말것
     * 이전 속도와의 보정하는 smoothed_speed는 통제 UI에서 할 것
     */    
    private long getKnots(byte x, byte y) {
        
        int uX = x & BFF;
        int uY = y & BFF;
//      문서에 나온대로 1/128 dm/s 기준        
        double dmPerSecPerLsb = 1 / D128; // 주의 소숫점을 뽑으려면 double로 나눠야함
      
        /*
         * 1시간 dm/h 로 변경 사유는 소숫점이 너무 깊어져서 부동소숫점 연산에 문제가 생긴다 
         * 시간단위로 숫자를 올린다음 나중에
         * 초로 변경하기 위함 float scale_factor = 28.125f; 이게 원본의 값
         */       
        double dmPerHourPerLsb = dmPerSecPerLsb * D3600;
               
        /*
         * DM_TO_NM = 1/1.012685914 시스템 내부 좌표계 보정용 스케일 팩터
         * 원래라면 dm은 데시미터라 10센치,
         * 해리는 1852 미터이기 때문에 dmToNm = (0.1 / 1852.0) 여야 하는데 
         * UI 표기, GPS/ADS-B,
         * 합의된 기준등의 이유로 1/1.012685914 이렇게 되었고 
         * DM_TO_NM' = k · (0.1/1852.0) 이 중에
         * k값으로 추정 k는 우리도 모르기때문에 고정상수로 사용 dm을 NM으로 변환
         */
        double nmPerHourPerLsb = dmPerHourPerLsb * DM_TO_NM;
        double knot = 0;
        
        float xVel;
        float yVel;
//      동북, 서남을 구분하기 위해 정확히 절반 255로 빼서 음수 양수 구분        
        
        if (uX >= N128) {
            xVel = (float) (((uX - N255) * nmPerHourPerLsb));

        } else {
            xVel = (float) ((uX * nmPerHourPerLsb));

        }
        
        if (uY >= N128) {
            yVel = (float) (((uY - N255) * nmPerHourPerLsb));
        } else {
            yVel = (float) (((uY) * nmPerHourPerLsb));
        }

        /*
         * ============원래 로직============= 
         * 3600으로 나누고 다시 60씩 곱하면서 피타고라스정리후 다시 60을
         * 곱함 소숫점 문제로 dm / hour를 nm으로 바꾸고 원래대로 dm / second로 변경 
         * xNmPerSec =(float) ((xSigned * nmPerHourPerLsb) / D3600); 
         * yNmPerSec = (float)((ySigned * nmPerHourPerLsb) / D3600);
         * NM 계산을 위해 이미 시간단위인 데이터를 초단위로 바꿨기 때문에 분단위로 변경 숫자가 
         * 너무 작아서 분단위로 올림
         * xNmPMin = xNmPerSec * N60; yNmPMin = yNmPerSec * N60; knotPerMin =
         * Math.sqrt(Math.pow(xNmPMin, N2) + Math.pow(yNmPMin, N2)); 
         * 시간으로 변환
         * knot = (long)(knotPerMin * N60); 
         * ============원래 로직 끝=============
         * 피타고라스 정리로 인해 밑변과 높이를 곱연산하면 빗변이 나오는데, 
         * 이게 속도 (v*v)=(vx*vx)​+(vy*vy​) v= √(vx*vx)​+(vy*vy​) 루트 정리 
         * Math.sqrt((xNmPerMin * xNmPerMin) + (yNmPerMin * yNmPerMin)); 
         * 실제 이거와 동일
         */
        knot = Math.sqrt(Math.pow(xVel, N2) + Math.pow(yVel, N2));
        
        return (long) knot;
    }
    
    public int getDirection(byte x, byte y) {

        int uX = x & BFF;
        int uY = y & BFF;
        double dmPerSecPerLsb = 1 / D128; // 주의 소숫점을 뽑으려면 double로 나눠야함
        double dmPerHourPerLsb = dmPerSecPerLsb * D3600;
        double nmPerHourPerLsb = dmPerHourPerLsb * DM_TO_NM;

        float xVel;
        float yVel;
        
        /*
         * 군용,지상항법은 자북을 기준으로 하고 항공/GPS는 진북을 기준으로 하기 때문에 7도 보정한다 
         * 매년 자기 정보가 바뀌므로 이건 나중에 고려를 해야 할 것임 
         * 2025년 NOAA(미국 해양대기청)기준 WMM-2025에 따르면 
         * 2025-11-12 8.98° W ± 0.32° changing by 0.04° W per year 
         * 편차가 서 편차 8.98 거의 9도에 가깝다
         * 매년 0.04 서쪽이동중이라고 한다
         */
        
        int scale_factor = N7; // 자기편차 보정
        double degree = 0;
        double radian = 0; // 삼각함수 각도 계산
        double scale_degree = 0;
        
        int cal = 0;
        int cal2 = 0;
        
        if (uX >= N128) {
            xVel = (float) (((uX - N255) * nmPerHourPerLsb));
        } else {
            xVel = (float) (((uX) * nmPerHourPerLsb));
        }

        if (uY >= N128) {
            yVel = (float) (((uY - N255) * nmPerHourPerLsb));
        } else {
            yVel = (float) (((uY) * nmPerHourPerLsb));
        }

        radian = Math.atan2(xVel, yVel); // 삼각함수 각도 계산

        /*
         * 남/북 방향이 0일때는 동 서 방향만 사용 동/서도 0이면 그냥 0 x가 0이면 남/북밖에 없다 
         * y가 0이면 동/서밖에 없다
         */
        if (yVel == 0.0) {
            if (xVel > 0) {
                degree = (N90 + scale_factor); // 자기편차 보정
            } else if (xVel < 0) {
                degree = (N270 + scale_factor);
            }
        } else {
            scale_degree = scale_factor;

            if (radian <= 0) {
                scale_degree += N360; // 아래 5도 보정을 위한 추가 360
            }
            degree = Math.toDegrees(radian) + scale_degree;

        }

        /*
         * 5도 보정 군용장비는 방위 해상도를 조정함 
         * 다수의 전술 디스플레이(레이더, 항법기, 관제기)는 방위각을 5도 단위로만 표시
         * degree = Math.round(degree / D5) * D5; // 5도 반올림
         */
        cal = ((int) degree % N5);
        cal2 = ((int) degree);
        if (cal < N3) {
            cal2 = cal2 - cal;
        } else {
            cal2 = cal2 + (N5 - cal);
        }
        cal2 = ((cal2 % N360) == 0) ? N360 : (cal2 % N360);
//        1~360사이만 나오게 보정작업 
        degree = ((degree % N360) == 0) ? N360 : (degree % N360);
        return (int) cal2;
    }

//    private int toUnsignedByte(int val) {
//        return (val < 0) ? (val + N256) : val;
//    }
    
    private byte[] hmacSha256(String data, String key)
            throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] rawHmac = null;

        mac.init(new SecretKeySpec(key.getBytes(), "HmacSHA256"));
        rawHmac = mac.doFinal(data.getBytes());

        return rawHmac;
    }
   
}
