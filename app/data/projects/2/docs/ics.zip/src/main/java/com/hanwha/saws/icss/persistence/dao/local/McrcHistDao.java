/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.McrcHistModel;

public interface McrcHistDao {

    public List<McrcHistModel> selectMcrcHistList(McrcHistModel model);

    public List<McrcHistModel> selectMcrcHistSccSearch(McrcHistModel model);

    public long selectMcrcHistTotalCount(McrcHistModel model);

    public void insertMessageHistDao(McrcHistModel model);

    public void insertMcrcHistBulkInsert(List<McrcHistModel> list);

}
