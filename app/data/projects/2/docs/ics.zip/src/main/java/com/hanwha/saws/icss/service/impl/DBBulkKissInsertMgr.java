/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.persistence.dao.local.KamdHistDao;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.service.IcsSyncService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class DBBulkKissInsertMgr {

    private static final int N50 = 50;

    @Value("${ics.failover-dir.kamd}")
    String kamdSyncFailDir;

    @Qualifier("kissBulkQueue")
    private final ConcurrentLinkedQueue<KamdHistModel> kissBulkQueue;

    @Qualifier("kissFileQueue")
    private final ConcurrentLinkedQueue<KamdHistModel> kissFileQueue;

    private final KamdHistDao kamdHistDao;
    private final IcsSyncService syncService;

    private ArrayList<KamdHistModel> bulkList = new ArrayList<>();

    @Scheduled(fixedDelayString = "300", initialDelayString = "3000")
    public void monitor() {

        KamdHistModel model = null;
        int bSize = 0;
        int qSize = 0;

        bulkList.clear();

        try {
            while (kissBulkQueue.size() != 0) {            
                
                model = kissBulkQueue.poll();
                MDC.put("LOG_KEY", model.getLogKInfo());
                
                log.debug("Missle File Queue Insert");
                kissFileQueue.offer(model);
                bulkList.add(model);

                bSize = bulkList.size();
                qSize = kissBulkQueue.size();

                if ((bSize > N50) || (qSize == 0)) {
                    kamdHistDao.insertKamdHistBulkInsert(bulkList);

                    syncKissHist(bulkList);
                    bulkList.clear();
                }
            }

        } catch (RuntimeException e) {
            log.warn("kissBulkInsertThread " + e.toString());
            bulkList.clear();
        }
    }

    private void syncKissHist(ArrayList<KamdHistModel> bulkList) {
        try {
            syncService.syncKamdHistBulkInsert(bulkList);
        } catch (RuntimeException e) {
            log.warn("syncKissHist() " + e.toString() + ": filesave");
            makeSyncKissFile(bulkList);
        }
    }

    private void makeSyncKissFile(ArrayList<KamdHistModel> bulkList) {

        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = fmter.format(LocalDateTime.now());
        String dirPath = kamdSyncFailDir + "/" + dStr;

        try {

            if (!Files.exists(Paths.get(dirPath))) {
                Files.createDirectories(Paths.get(dirPath));
            }

        } catch (IOException | RuntimeException e) {
            log.warn("makeSyncKissFile() createFile/Dir " + e.toString());
        }

        try (ObjectOutputStream os = new ObjectOutputStream(
                new FileOutputStream(dirPath + "/" + UUID.randomUUID()))) {

            os.writeObject(bulkList);

        } catch (IOException | RuntimeException e2) {
            log.warn("makeSyncKamdFile write " + e2.toString());
        }
    }

}
