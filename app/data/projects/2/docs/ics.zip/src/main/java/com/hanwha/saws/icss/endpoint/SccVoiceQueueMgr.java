/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.service.MissService;
import com.hanwha.saws.icss.service.SccService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccVoiceQueueMgr {
    private static final int N30 = 30;
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");

    private final SccService sccService;
    @Autowired
    @Qualifier("voiceQueue") 
    private ConcurrentLinkedQueue<RecvMsgQueueBean> voiceQueue;

    @Autowired
    public SccVoiceQueueMgr(SccService sccService) {
        this.sccService = sccService;
    }

    @Scheduled(fixedDelayString = "30", initialDelayString = "3000")
    public void monitor() {
        final String lFormat = "[SCC VOICE] Queue took : 1 , remain {}";

        RecvMsgQueueBean msg = null;

        while ((msg = voiceQueue.poll()) != null) {
            sccService.handleEventV(msg);
            qLog.debug(lFormat, voiceQueue.size());
        }

    }
}
