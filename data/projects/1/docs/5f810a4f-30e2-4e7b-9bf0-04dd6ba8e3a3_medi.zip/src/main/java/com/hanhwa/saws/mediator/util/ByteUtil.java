/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */

package com.hanhwa.saws.mediator.util;

import com.hanhwa.saws.mediator.endpoint.KamdReceiver;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ByteUtil {

    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N7 = 7;
    private static final int N8 = 8;
    private static final int N16 = 16;
    private static final int N24 = 24;
    private static final int B_FF = 0xFF;
    private static final int B00 = 0x00;
    private static final int B01 = 0x01;
    private static final int B07 = 0x07;
    private static final int B08 = 0x08;
    private static final int B09 = 0x09;
    private static final int B10 = 0x10;
    private static final int B11 = 0x11;
    private static final int B12 = 0x12;
    private static final int B13 = 0x13;
    private static final int B14 = 0x14;
    private static final int B15 = 0x15;
    private static final int B16 = 0x16;
    private static final int B17 = 0x17;
    private static final int B18 = 0x18;
    private static final int B19 = 0x19;
    private static final int B_0A = 0x0a;
    private static final int B_0B = 0x0b;
    private static final int B_0C = 0x0c;
    private static final int B_0D = 0x0d;
    private static final int B_0E = 0x0e;
    private static final int B_0F = 0x0f;
    private static final int B_1A = 0x1a;
    private static final int B_1B = 0x1b;
    private static final int B_1C = 0x1c;
    private static final int B_1D = 0x1d;
    private static final int B_1E = 0x1e;
    private static final int B_1F = 0x1f;

    private static final String SWAP_2BYTE_MSG =
            "swap2Bytes requires a 2-byte array";
    private static final String BT_TO_INT2_MSG =
            "byteArrayToInt requires a 2-byte array.";
    private static final String BT_TO_INT4_MSG =
            "byteArrayToInt requires a 2-byte array.";

    private ByteUtil() {}

    public static byte[] swap2Byte(byte[] array) {
        if ((array == null) || (array.length != N2)) {
            throw new IllegalArgumentException(SWAP_2BYTE_MSG);
        }

        return new byte[] { array[1], array[0] };
    }

    public static int byteArrayToInt(byte[] bytes) {
        int a0 = 0;
        int a1 = 0;
        int rt = 0;

        if ((bytes == null) || (bytes.length != N2)) {
            throw new IllegalArgumentException(BT_TO_INT2_MSG);
        }

        a0 = ((bytes[0] & B_FF) << N8);
        a1 = (bytes[1] & B_FF);
        rt = (a0 | a1);

        return rt;
    }

//    public static int byteArrayToInt4(byte[] bytes) {
//        int a0 = 0;
//        int a1 = 0;
//        int a2 = 0;
//        int a3 = 0;
//        int rt = 0;
//
//        if ((bytes == null) || (bytes.length != N4)) {
//            throw new IllegalArgumentException(BT_TO_INT4_MSG);
//        }
//
//        a0 = ((bytes[0] & B_FF) << N24);
//        a1 = ((bytes[1] & B_FF) << N16);
//        a2 = ((bytes[N2] & B_FF) << N8);
//        a3 = (bytes[N3] & B_FF);
//        rt = (a0 | a1 | a2 | a3);
//
//        return rt;
//    }

    public static byte[] intToByteArray2(int value) {
        byte a0 = (byte) ((value >> N8) & B_FF);
        byte a1 = (byte) (value & B_FF);
        byte[] rt = new byte[] { a0, a1 };

        return rt;
    }

//    public static byte[] intToByteArray4(int value) {
//        byte a0 = (byte) ((value >> N24) & B_FF);
//        byte a1 = (byte) ((value >> N16) & B_FF);
//        byte a2 = (byte) ((value >> N8) & B_FF);
//        byte a3 = (byte) (value & B_FF);
//        byte[] rt = new byte[] { a0, a1, a2, a3 };
//
//        return rt;
//    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();

        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }

        return sb.toString().trim();
    }

    public static byte[] swap2Bytes(byte[] array) {
        byte[] swapped = new byte[array.length];

        for (int i = 0; i < array.length; i += N2) {
            swapped[i] = array[i + 1];
            swapped[i + 1] = array[i];
        }

        return swapped;
    }

    public static byte[] bitSwap(byte[] array) {
        byte[] swapped = new byte[array.length];
        int rev = 0;

        for (int i = 0; i < array.length; i++) {
            rev = Integer.reverse(array[i] & B_FF);
            swapped[i] = (byte) ((rev >>> N24) & B_FF);
        }

        return swapped;
    }

//    public static byte extractBits(byte[] bitData, int startBit, int endBit) {
//        int bitLength = endBit - startBit + 1;
//        int byteValue = 0;
//        int bitPos = 0;
//        int byteIndex = 0;
//        int bitIndex = 0;
//        int bit = 0;
//
//        for (int i = 0; i < bitLength; i++) {
//            bitPos = startBit + i;
//            byteIndex = bitPos / N8;
//            bitIndex = bitPos % N8;
//            bit = (bitData[byteIndex] >> (N7 - bitIndex)) & 1;
//
//            byteValue = (byteValue << 1) | bit;
//        }
//
//        return (byte) byteValue;
//    }

    public static String getByteArrayToBynaryString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        String binStr = null;

        for (byte b : bytes) {
            binStr = Integer.toBinaryString(B_FF & b);
            sb.append(String.format("%8s", binStr).replace(' ', '0'));
        }

        return sb.toString();
    }

    public static int getReverseValue(String data, int start, int end) {
        String token = data.substring(start, end + 1);
        StringBuilder sb = new StringBuilder(token);
        String val = sb.reverse().toString();

        return Integer.parseInt(val, N2);
    }

    public static String getAlphanumeric(int number) {
        String result = null;

        if ((number >= B00) && (number <= B07)) {
            result = Integer.toString(number);
        } else if ((number > B07) && (number <= B_1F)) {

            switch (number) {
                case B08: {
                    result = "A";
                    break;
                }
                case B09: {
                    result = "B";
                    break;
                }
                case B_0A: {
                    result = "C";
                    break;
                }
                case B_0B: {
                    result = "D";
                    break;
                }
                case B_0C: {
                    result = "E";
                    break;
                }
                case B_0D: {
                    result = "F";
                    break;
                }
                case B_0E: {
                    result = "G";
                    break;
                }
                case B_0F: {
                    result = "H";
                    break;
                }
                case B10: {
                    result = "J";
                    break;
                }
                case B11: {
                    result = "K";
                    break;
                }
                case B12: {
                    result = "L";
                    break;
                }
                case B13: {
                    result = "M";
                    break;
                }
                case B14: {
                    result = "N";
                    break;
                }
                case B15: {
                    result = "P";
                    break;
                }
                case B16: {
                    result = "Q";
                    break;
                }
                case B17: {
                    result = "R";
                    break;
                }
                case B18: {
                    result = "S";
                    break;
                }
                case B19: {
                    result = "T";
                    break;
                }
                case B_1A: {
                    result = "U";
                    break;
                }
                case B_1B: {
                    result = "V";
                    break;
                }
                case B_1C: {
                    result = "W";
                    break;
                }
                case B_1D: {
                    result = "X";
                    break;
                }
                case B_1E: {
                    result = "Y";
                    break;
                }
                case B_1F: {
                    result = "Z";
                    break;
                }
                default: {
                    break;
                }
            }
        }

        return result;
    }

}
