/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.persistence.model.NodeModel;

public interface IcsEtcService {

    void icsStatusReport(MedStatusReq req, String senderIp);

    void icsNodeUpdate(NodeModel bean);

}
