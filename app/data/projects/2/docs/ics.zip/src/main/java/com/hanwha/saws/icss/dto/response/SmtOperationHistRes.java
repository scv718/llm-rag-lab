/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;

import lombok.Data;

@Data
public class SmtOperationHistRes {

    private int idx;
    private String id;
    private String name;
    @JsonProperty("ip") private String ipAddr;
    private String operation;
    private String result;
    @JsonProperty("start_time") private String startTime;
    @JsonProperty("end_time") private String endTime;
    @JsonProperty("insert_time") private String insertTime;
    @JsonProperty("add_info") private String additionalInfo;

    @JsonIgnore
    public void setData(OperationHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        idx = data.getIdx();
        id = data.getUserId();
        name = data.getUserName();
        ipAddr = data.getUserIp();
        operation = data.getOperation();
        result = data.getOperationResult();
        
        insertTime = sdf.format(data.getInsertTime());
        startTime = sdf.format(data.getStartTime());
        endTime = sdf.format(data.getEndTime());
        additionalInfo = data.getAdditionalInfo();

    }
}
