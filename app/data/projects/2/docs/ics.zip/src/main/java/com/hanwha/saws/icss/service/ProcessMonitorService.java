/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

public interface ProcessMonitorService {

    void markReceivedNow();

    boolean isRecentWithin9Seconds();

    void markReceivedErrNow();

    boolean isRecentErrWithin9Seconds();

}
