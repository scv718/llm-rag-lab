/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.common.service;


import com.hanhwa.saws.mediator.dto.request.BaseResponse;
import com.hanhwa.saws.mediator.dto.request.DianosisResponseVo;

public interface MediatorService {

    void resetSystem();

    DianosisResponseVo getDiagnosis();

    BaseResponse pingCheck(String ip);

}
