/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class ThresholdModel {

    private int nodeId;
    private int type;
    private int level;
    private int data;
    private Date updateTime;

}