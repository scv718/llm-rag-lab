/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.code.ThCodeBean;
import com.hanwha.saws.icss.dto.code.ThCodeRepo;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;

import lombok.Data;

@Data
public class ThresholdRes {

    private int type;
    @JsonProperty("type_name") private String typeName;
    private int level;
    @JsonProperty("level_name") private String levelName;
    private int data;

    @JsonIgnore
    public void setBean(ThresholdModel tm) {
        
        ThCodeBean levelCode = null;
        ThCodeBean typeCode = null;

        type = tm.getType();
        level = tm.getLevel();
        data = tm.getData();

        levelCode = ThCodeRepo.getLevelCode(this.level);
        if (levelCode != null) {
            levelName = levelCode.getMsg();
        }

        typeCode = ThCodeRepo.getTypeCode(this.type);
        if (typeCode != null) {
            typeName = typeCode.getMsg();
        }
        
    }
}
