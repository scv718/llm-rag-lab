/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.scc.SccCommandBean;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.ProcessMonitorService;
import com.hanwha.saws.icss.service.impl.SccVoiceTimer;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccVoiceReceiver {

    private static final int INIT_WAIT = 0;
    private static final int N2000 = 2000;
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");
    private static final int ACTIVE = 1;
    private final PropConfig propConfig;

    @Value("${listener.bond-ip}") String bondIp;
    @Value("${listener.scc-voice.ip}") String ip;
    @Value("${listener.scc-voice.port}") int port;
    @Value("${ics.group-byte-length}") int groupByteLength;


    @Value("${sms.send-port}") int smsPort;
    @Value("${scc-voice.send-port}") int sccVPort;
    @Autowired
    @Qualifier("voiceQueue") 
    private ConcurrentLinkedQueue<RecvMsgQueueBean> voiceQueue;

    @Autowired PropConfig prop;
    @Autowired SccVoiceTimer voiceTimer;
    
    @Autowired
    public SccVoiceReceiver(PropConfig propConfig) {
        this.propConfig = propConfig;
    }

    public void putQueue(RecvMsgQueueBean bean) {

        String logTmp = "[SCC VOICE] Queue put : 1 , remain {}";
        
        HashMap<Integer, NodeModel> nH = null;
        NodeModel rSccNode = null;
        
        if (prop.getActiveMode() != ACTIVE) {
            log.debug("TYPE: SCC Voice - its standby");
            return;
        }
        
        nH = prop.getNodeInfoHash();
        rSccNode = NodeUtil.getNdAltScc(nH, bean.getSenderIp());
        
        relayVoice(bean.getData(),rSccNode,bean.getSenderIp());

        log.debug("Scc Voice Queue Insert ip : " + bean.getSenderIp());
        voiceQueue.offer(bean);
        qLog.debug(logTmp, voiceQueue.size());
    }
    
    private void relayVoice(byte[] data, NodeModel remoteSccNode,
            String senderIp) throws RuntimeException {
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel tmpNode = null;

        String msg = "";

        if (!voiceTimer.checkVoicePriority(senderIp)) { // 통과시 데이터 수신 갱신
            msg = "Voice Priority failed status code: {} status ip:{} myip: {}";
            log.info(msg, voiceTimer.getVoiceAuthStatus(),
                    voiceTimer.getVoiceAuthIp(), senderIp);
            return;
        }

        log.debug("SCC SEND VOICE TO ALT SCC");
        sendUdp(remoteSccNode, sccVPort, data);

        if (prop.isModemSendMode()) { // 작전모드일때만 저장
            log.debug("SCC OPERATION MODE, SEND TO MODEM");
            tmpNode = nH.get(NodeRepo.getSmsA().getCode());
            sendUdp(tmpNode, smsPort, data);

            tmpNode = nH.get(NodeRepo.getSmsB().getCode());
            sendUdp(tmpNode, smsPort, data);
        } else {
            log.debug("SCC STANDBY MODE, DO NOT SEND TO MODEM");
        }

    }
    
    private boolean sendUdp(NodeModel info, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket packet = null;

            packet = new DatagramPacket(data, data.length, mcastaddr, port);
            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccVoiceReceiver sendUdpData()" + e.toString());
            return false;
        }

        return true;
    }

    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {
        final byte[] mBuf = new byte[N2000];

        MulticastSocket socket = null;
        NetworkInterface netIf = null;
        InetSocketAddress group = null;
        InetAddress mcastAddr = null;
        InetAddress localAddr = null;
        DatagramPacket packet = null;

        byte[] copy = null;
        int pLen = 0;
        String recvIp = null;

        String logSMsg = "Scc voice service setting ip: {} port:{}";
        String logIMsg = "Scc voice Listener inner error: {}";
        String logOMsg = "Scc voice Listener outer error: {}";
        String logFMsg = "Scc voice Listener leaveGroup failed: {}";
        String logFSsg = "Scc voice Listener leaveGroup";
        String[] ipList = ip.trim().split(",");
        boolean isClose = false;
        
        while (true) {

            if (socket == null || socket.isClosed()) {
                
                try {
                    
                    localAddr = InetAddress.getByName(bondIp);
                    netIf = NetworkInterface.getByInetAddress(localAddr);
                    socket = new MulticastSocket(port);

                    for (String mIp : ipList) {
                        mcastAddr = InetAddress.getByName(mIp.trim());
                        group = new InetSocketAddress(mcastAddr, port);
                        socket.joinGroup(group, netIf);
                        log.info("Scc voice service joinGroup: {}:{}",
                                mIp.trim(), port);
                    }

                    while (true) {
                        try {

                            packet = new DatagramPacket(mBuf, mBuf.length);

                            socket.receive(packet);

                            if (propConfig.getInitFlag() == INIT_WAIT) {
                                continue;
                            }

                            pLen = packet.getLength();
                            copy = Arrays.copyOf(packet.getData(), pLen);
                            recvIp = packet.getAddress().getHostAddress();

                            log.debug("Scc Voice Queue Insert");
                            putQueue(new RecvMsgQueueBean(copy, recvIp));

                        } catch (IOException | RuntimeException e2) {
                            log.warn(logIMsg, e2.toString());
                        }
                    }

                } catch (IOException | RuntimeException e) {
                    log.error(logOMsg, e.toString());

                }
                
                if (socket == null || netIf == null) {
                    isClose = true;
                } else {
                    isClose = false;
                }

                if (!isClose) {
                    for (String mIp : ipList) {

                        if (!mIp.isEmpty()) {
                            try {
                                mcastAddr = InetAddress.getByName(mIp);
                                group = new InetSocketAddress(mcastAddr, port);
                                socket.leaveGroup(group, netIf);
                                log.debug("{} complete: {}:{}", logSMsg, mIp,
                                        port);
                            } catch (IOException e3) {
                                log.warn("{} failed for {}:{} - {}", logSMsg,
                                        mIp, port, e3.toString());
                            }
                        }
                    }
                    socket.close();
                    log.info("Scc voice socket closed");
                }                
            }

        }
    }

}
