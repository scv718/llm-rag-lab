/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.response.AlarmCodeRes;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.SmtAlarmHistListRes;
import com.hanwha.saws.icss.dto.response.SmtAlarmHistRes;
import com.hanwha.saws.icss.dto.response.SmtCurrAlarmRes;
import com.hanwha.saws.icss.persistence.dao.local.AlarmDao;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Service("AlarmService")
@Slf4j
public class AlarmServiceImpl implements AlarmService {
    
    private static final int N100 = 100;
    private static final int N900 = 900;
    private static final int N1000 = 1000;
    
    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired AlarmDao alarmDao;

    @Autowired NonSyncHistDao nonSyncHistDao;

    @Value("${prop.host-name}") String hostName;

    @Autowired PropConfig prop;

    @Autowired RdbSyncRtService rtSync;

    @Override
    public List<CurrAlarmModel> getCurrentAlarmDeviceInfo(Integer nodeId) {
        CurrAlarmModel param = new CurrAlarmModel();

        try {
            param.setNodeId(nodeId);

            return alarmDao.selectCurrentAlarmDeviceInfo(param);

        } catch (RuntimeException e) {
            log.warn("getCurrentAlarmDeviceInfo() " + e.toString());
        }

        return null;
    }

    @Override
    public BaseResponse currAlarmList(LoginSessionBean session, Integer nodeId,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel mNode = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cACode = OpCmdRepo.getSawCurrAlarmHist();
        OperationHistModel histBean = getOpHistBean(session, cACode, mNode);

        CurrAlarmModel p = new CurrAlarmModel();
        SmtCurrAlarmRes cAlarmRes = null;

        String rc = "";
        String histAdditionalInfo = "";
        HashMap<String, List<SmtCurrAlarmRes>> resHash = new HashMap<>();
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        List<CurrAlarmModel> list = null;
        List<SmtCurrAlarmRes> resData = new ArrayList<>();

        try {

            if (nodeId != null) {
                p.setNodeId(nodeId);
            }

            list = alarmDao.selectCurrentAlarmSearch(p);

            for (CurrAlarmModel m : list) {
                cAlarmRes = new SmtCurrAlarmRes();

                cAlarmRes.setData(m);
                resData.add(cAlarmRes);
            }

            resHash.put("list", resData);

            res.setData(resHash);

            rc = OpHistRltRepo.getResultSuccess().getName();

            histAdditionalInfo = "current alarm list";

            return res;
        } catch (RuntimeException e) {
            log.warn("currAlarmList() " + e.toString());

            rc = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();

        } finally {
            insertOperationHist(histBean, rc, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    private void insertOperationHist(OperationHistModel bean, String resultCode,
            String msg) {

        try {

            bean.setOperationResult(resultCode);

//            if (msg.length() > N1000) {
//                msg = msg.substring(0, N900);
//            }

            bean.setAdditionalInfo(msg);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);

        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString());
        }

    }

    private OperationHistModel getOpHistBean(LoginSessionBean bean,
            OpCmdRepo code, NodeModel nm) {

        OperationHistModel model = new OperationHistModel();
        String addStr = hostName + " " + nm.getName() + " " + nm.getAddrIp();
        String sCode = OpHistRltRepo.getResultSuccess().getCode();

        model.setStartTime(new Date());
        model.setUserId(bean.getUserId());
        model.setUserName(bean.getName());
        model.setUserIp(bean.getIp());
        model.setOperation(code.getMsg());
        model.setAdditionalInfo(addStr);
        model.setOperationResult(sCode);
        model.setEndTime(new Date());

        return model;
    }

    @Override
    public void alarmUpdate(boolean status, AlarmRepo code, NodeModel nodeInfo,
            AlarmRepo levelCode, String summary) {

        try {
            CurrAlarmModel curParam = new CurrAlarmModel();
            List<CurrAlarmModel> cAL = null;
            CurrAlarmModel info = null;

            curParam.setNodeId(nodeInfo.getNodeId());
            curParam.setAlarmId(code.getCode());            
            cAL = alarmDao.selectCurrentAlarmInfo(curParam);

            if (cAL != null && cAL.size() == 1) {
                info = cAL.get(0);
            } else if (cAL != null && cAL.size() > 1) { // 중복입력 1개 삭제
                cAL.sort(Comparator.comparing(CurrAlarmModel::getInsertTime));

                for (int i = 0; i < cAL.size() - 1; i++) {
                    alarmDao.deleteCurrentAlarm(cAL.get(i));
                }
                info = cAL.get(cAL.size() - 1);
            }

            if (info != null) {

                if (status) {
                    recoverAlarm(info);
                } else {

                    info.setTally(info.getTally() + 1);
                    info.setSummary(summary);
                    info.setLastOccurrence(new Date());
                    alarmDao.updateCurrentAlarmTally(info);
                    alarmDao.updateAlarmHistTally(info);
                    rtSync.insertQueue(info, "UPDATE");
                }

            } else {

                if (!status) { // 정상에 정상은 바꿀필요없음. 신규 이상상태

                    insertNewAlarm(nodeInfo, code, levelCode, summary);

                }
            }
        } catch (RuntimeException e) {
            log.warn("alarmUpdate() " + e.toString());
        }
    }

    /**
     * 알람 업데이트시 레벨이 다르면 CLEAR 진행
     */
    @Override
    public void alarmLevelUpdate(boolean status, AlarmRepo code,
            NodeModel nodeInfo, AlarmRepo levelCode, String summary) {

        try {
            CurrAlarmModel curParam = new CurrAlarmModel();
            CurrAlarmModel info = null;
            List<CurrAlarmModel> cAL = null;

            curParam.setNodeId(nodeInfo.getNodeId());
            curParam.setAlarmId(code.getCode());

            cAL = alarmDao.selectCurrentAlarmInfo(curParam);

            if (cAL != null && cAL.size() == 1) {
                info = cAL.get(0);
            } else if (cAL != null && cAL.size() > 1) { // 중복입력 1개 삭제
                cAL.sort(Comparator.comparing(CurrAlarmModel::getInsertTime));

                for (int i = 0; i < cAL.size() - 1; i++) {
                    alarmDao.deleteCurrentAlarm(cAL.get(i));
                }

                info = cAL.get(cAL.size() - 1);
            }

            if (info != null) {

                if (status) {
                    recoverAlarm(info);

                    return;

                }

                if (info.getServerity().equals(levelCode.getCode())) {
                    info.setTally(info.getTally() + 1);
                    info.setSummary(summary);
                    info.setLastOccurrence(new Date());
                    alarmDao.updateCurrentAlarmTally(info);
                    alarmDao.updateAlarmHistTally(info);
                    rtSync.insertQueue(info, "UPDATE");
                    return;

                } else { // 정리후 신규 레벨 입력
                    recoverAlarm(info);
                    insertNewAlarm(nodeInfo, code, levelCode, summary);

                    return;

                }

            }

            if (!status) { // 기존알람 없고 신규 알람시 입력
                insertNewAlarm(nodeInfo, code, levelCode, summary);
            }

        } catch (RuntimeException e) {
            log.warn("alarmUpdate() " + e.toString());
        }
    }

    private void insertNewAlarm(NodeModel nodeInfo, AlarmRepo code,
            AlarmRepo levelCode, String summary) {

        CurrAlarmModel nBean = new CurrAlarmModel();
        AlarmHistModel model = new AlarmHistModel();

        nBean.setTime();
        nBean.setUuid((UUID.randomUUID().toString().replace("-", "")));
        nBean.setNodeId(nodeInfo.getNodeId());
        nBean.setNodeName(nodeInfo.getName());
        nBean.setAddrIp(nodeInfo.getAddrIp());
        nBean.setAlarmId(code.getCode());
        nBean.setAlarmName(code.getMsg());
        nBean.setServerity(levelCode.getCode());
        nBean.setLocation(nodeInfo.getAddrIp());
        nBean.setSummary(summary);
        nBean.setTally(1);
        nBean.setFirstOccurrence(new Date());

        alarmDao.insertCurrentAlarm(nBean);
        rtSync.insertQueue(nBean, "INSERT");
        model.parseCurrentBean(nBean);

        syncHistInsertService.insertAlarmHist(model);
    }

    private void recoverAlarm(CurrAlarmModel info) {

        AlarmHistModel model = new AlarmHistModel();
        
        alarmDao.deleteCurrentAlarm(info);
        rtSync.insertQueue(info, "DELETE");

        model.parseCurrentBean(info);
        model.setTime();
        model.setServerity(AlarmRepo.getSvrCle().getCode());
        model.setRecoverReason(AlarmRepo.getSvrCle().getMsg());
        model.setRecoverTime(new Date());

        syncHistInsertService.insertAlarmHist(model);
    }

    @Override
    public BaseResponse alarmHistSearch(LoginSessionBean session, HashMap body,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawAlarmHist();
        NodeModel mNode = NodeUtil.getNodeInfoP(hostName, nList);

        AlarmHistModel param = new AlarmHistModel();
        SmtAlarmHistListRes resData = new SmtAlarmHistListRes();
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        OperationHistModel histBean = getOpHistBean(session, cd, mNode);

        List<AlarmHistModel> list = null;
        String rt = "";
        String histAdditionalInfo = "";
        Integer page = 0;
        Integer pSize = 0;
        int tCnt = 0;
        int tPages = 0;
        int tmp = 0;
        SmtAlarmHistRes rData = null;

        try {

            param.setStartTime((String) body.get("start_time"));
            param.setEndTime((String) body.get("end_time"));

            if (body.get("node_id") != null) {
                param.setNodeId((Integer) body.get("node_id"));
            }

            if (body.get("alarm_id") != null) {
                param.setAlarmId((String) body.get("alarm_id"));
            }

            page = (Integer) body.get("page");
            pSize = (Integer) body.get("list_size");

            param.setPage(page, pSize);

            list = alarmDao.selectAlarmHistSearch(param);

            if ((list != null) && (list.size() > 0)) {
                tCnt = alarmDao.selectAlarmHistSearchTotalCount(param);

                resData.setTotalCount(tCnt);

                tmp = param.getRowCount();
                tPages = (tCnt + (param.getRowCount() - 1)) / tmp;

                resData.setTotalPage(tPages);
            }

            for (AlarmHistModel alarmHistModel : list) {
                rData = new SmtAlarmHistRes();

                rData.setData(alarmHistModel);

                resData.getList().add(rData);
            }

            res.setData(resData);

            rt = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "alarm history list";

            return res;
        } catch (RuntimeException e) {
            log.warn("alarmHistSearch() " + e.toString());

            rt = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();

        } finally {

            insertOperationHist(histBean, rt, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse msgAlarmList(LoginSessionBean session, HashMap body,
            String remoteAddr, String requestURI) {
        
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawAlarmHist();
        NodeModel mNode = NodeUtil.getNodeInfoP(hostName, nList);

        AlarmHistModel param = new AlarmHistModel();
        CurrAlarmModel p = new CurrAlarmModel();
        SmtAlarmHistListRes resData = new SmtAlarmHistListRes();
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        OperationHistModel histBean = getOpHistBean(session, cd, mNode);

        List<AlarmHistModel> list = null;
        List<CurrAlarmModel> cList = null;
        String rt = "";
        String histAdditionalInfo = "";
        
        Integer pSize = N100;
        SmtAlarmHistRes rData = null;

        try {

            param.setStartTime((String) body.get("start_time"));
            param.setEndTime((String) body.get("end_time"));

            param.setPage(null, pSize);

            list = alarmDao.selectAlarmHistSearch(param); //일단 조회           
            p.setStartTime((String) body.get("start_time"));
            p.setEndTime((String) body.get("end_time"));
            cList = alarmDao.selectCurrentAlarmSearchDate(p);

            list.addAll(parseCurrToHist(list,cList));
            sortHist(list);
            
            for (AlarmHistModel alarmHistModel : list) {
                rData = new SmtAlarmHistRes();

                rData.setData(alarmHistModel);

                resData.getList().add(rData);
            }
            resData.setTotalCount(list.size());
            res.setData(resData);

            rt = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "alarm msg list";

            return res;
        } catch (RuntimeException e) {
            log.warn("msgAlarmList() " + e.toString());

            rt = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();

        } finally {

            insertOperationHist(histBean, rt, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }
    
    private List<AlarmHistModel> parseCurrToHist(List<AlarmHistModel> histList,
            List<CurrAlarmModel> cList) {
        
        List<AlarmHistModel> list = new ArrayList<>();
        HashMap<String, String> uuidTmp = new HashMap<>();
        AlarmHistModel bean = null;
        
        for (AlarmHistModel m : histList) {
            uuidTmp.put(m.getCurrUuid(),"");
        }
        
        for (CurrAlarmModel curr : cList) {
            if (uuidTmp.containsKey(curr.getUuid())) {
                continue;
            }

            bean = new AlarmHistModel();
            bean.parseCurrentBean(curr);
            list.add(bean);
        }
        return list;
    }

    private void sortHist(List<AlarmHistModel> list) {
        
        Map<String, AlarmHistModel> m = new HashMap<>();
        
        for (AlarmHistModel v : list) {
                      
            String key = v.getCurrUuid();
            AlarmHistModel old = m.get(key);

            if (old == null) {
                m.put(key, v);
                continue;
            }
            
//           if (v.getLastOccurrence().compareTo(old.getLastOccurrence()) > 0) {
//                m.put(key, v);
//            }

        }
        
        list.clear();
        list.addAll(m.values());

        Collections.sort(list, new Comparator<AlarmHistModel>() {
            @Override
            public int compare(AlarmHistModel o1, AlarmHistModel o2) {
                return o2.getLastOccurrence().compareTo(o1.getLastOccurrence());
            }
        });

        for (int i = 0; i < list.size(); i++) {
            list.get(i).setIdx(i + 1L);        
        }
    }
        
    @Override
    public BaseResponse alarmIdList(LoginSessionBean session, String remoteAddr,
            String operation) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel mNode = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cd = OpCmdRepo.getSawAlarmIdList();

        OperationHistModel histBean = getOpHistBean(session, cd, mNode);

        BaseResponse res = new BaseResponse(ResRepo.getC200());
        ArrayList<AlarmCodeRes> resList = new ArrayList<>();
        HashMap<String, List<AlarmCodeRes>> resData = new HashMap<>();

        AlarmCodeRes rData = null;
        String rt = "";
        String histAdditionalInfo = "";
        List<AlarmRepo> list = null;

        try {

            list = AlarmRepo.getAlarmOnlyCodes();

            for (AlarmRepo alarmCode : list) {

                rData = new AlarmCodeRes(alarmCode);

                resList.add(rData);
            }

            resData.put("list", resList);

            res.setData(resData);

            rt = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "alarm id list";

            return res;
        } catch (RuntimeException e) {

            log.warn("alarmIdList() " + e.toString());

            rt = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();

        } finally {
            insertOperationHist(histBean, rt, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public List<CurrAlarmModel> getCurrAlarmSearch(Integer nodeId) {
        CurrAlarmModel p = new CurrAlarmModel();

        try {
            p.setNodeId(nodeId);

            return alarmDao.selectCurrentAlarmSearch(p);
        } catch (RuntimeException e) {
            log.warn("currAlarmList() " + e.toString());

        }
        return null;
    }

}
