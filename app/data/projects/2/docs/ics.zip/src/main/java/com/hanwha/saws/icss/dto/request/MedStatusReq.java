/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import lombok.Data;

@Data
public class MedStatusReq {

    private int cpu = 0;
    private int hdd = 0;
    private int mem = 0;
    private String app;
}
