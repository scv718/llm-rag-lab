/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.nio.ByteBuffer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;

import lombok.Data;

@Data
public class SmsSModuleRes {
    private static final int BFFFF = 0xFFFF;
    private static final int BFF = 0xFF;
    
    private static final int P0000 = 0x0000;
    private static final int P0001 = 0x0001;
    private static final int P0010 = 0x0010;
    private static final int P0100 = 0x0100;
    private static final int P1000 = 0x1000;
    
    @JsonIgnore final static String[] ERROR_0541 = {
            "SRAM Error",
            "Data Flash Error",
            "Interface FPGA Error",
            "Algorithm FPGA Data Error",
            "Algorithm FPGA Error",
            "Battery Error",
            "RTC Error",
            "Key Data Error",
            "Key Validation Error",
            "PIN Data Error",
            "LOG Data Error",
            "ID Data Error",
            "Serial Number Data Error",
            "CIS Error"
    };
    
    @JsonInclude(Include.NON_NULL) private String type;
    @JsonInclude(Include.NON_NULL) private String serial;
    @JsonInclude(Include.NON_NULL) private String lock; 
    @JsonInclude(Include.NON_NULL) private Integer login; 
    @JsonProperty("module_valid") private Integer moduleValid;
    
    @JsonInclude(Include.NON_NULL) private Integer battery; 
    @JsonProperty("vaild_time") private String validTime;
    
    @JsonInclude(Include.NON_NULL) private String id;
    @JsonInclude(Include.NON_NULL) private Integer fpga;

    @JsonInclude(Include.NON_NULL) private Integer status;
    @JsonInclude(Include.NON_NULL) private String flag;

    @JsonInclude(Include.NON_NULL) private Integer key;

    @JsonInclude(Include.NON_NULL) private Integer cpu;
    @JsonInclude(Include.NON_NULL) private Integer equipped;

    @JsonIgnore
    public void setModemStatusData(SmsTcpObjectBean bean) {

        int pType = 0;
        int pSerial = 0;
        int pLock = 0;
        int pLogin = 0;
        int pValid = 0;
        int pBattery = 0;
        int pDays = 0;
        int pHours = 0;
        int pMins = 0;
        int pModuleId = 0;
        int pFpga = 0;
        
        ByteBuffer buffer = ByteBuffer.wrap(bean.getData());
        
        buffer.get(); // result (0x00이면 정상, 이건 생략하거나 따로 체크)
        
        pType = buffer.getShort() & BFFFF;
        pSerial = buffer.getShort() & BFFFF;
        pLock = buffer.get() & BFF;
        pLogin = buffer.get() & BFF;
        pValid = buffer.get() & BFF;
        pBattery = buffer.get() & BFF;
        pDays = buffer.getShort() & BFFFF;
        pHours = buffer.get() & BFF;
        pMins = buffer.get() & BFF;
        pModuleId = buffer.getShort() & BFFFF;
        pFpga = buffer.getShort() & BFFFF;

        switch (pType) {
            case P0001:
                type = "제어기용";
                break;
            case P0010:
                type = "일반용";
                break;
            case P0100:
                type = "특수용";
                break;
            case P1000:
                type = "시험용 모듈";
                break;
            default:
                type = "알 수 없음";
                break;
        }

        serial = String.format("%04X", pSerial);

        lock = (pLock == 1) ? "lock" : "unlock";
        login = pLogin;
        moduleValid = pValid;
        battery = pBattery;
        validTime = (pDays + "일 " + pHours + "시간 " + pMins + "분");
        id = String.format("%04X", pModuleId);
        fpga = ((pFpga == P0000) ? 0 : 1);
    }

    @JsonIgnore
    public void setModemDiagnosisData(SmsTcpObjectBean bean) {

        ByteBuffer buffer = ByteBuffer.wrap(bean.getData());
        
        status = buffer.get() & BFF;

        if (status > 0) {
            flag = ERROR_0541[(buffer.getShort() & BFFFF)];
        }
    }
    


}
