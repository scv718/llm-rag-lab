/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OpCmdRepo {

    private static final Map<String, OpCmdRepo> CODE_MAP = new HashMap<>();

    private static final String M1 = "통합제어서버 절체";
    private static final String M2 = "송수신 모뎀 절체";
    private static final String M3 = "연동서버 리셋";
    private static final String M4 = "통합제어서버 리셋";
    private static final String M5 = "송수신 모뎀 리셋";
    private static final String M6 = "연동서버 진단";
    private static final String M7 = "통합제어서버 진단";
    private static final String M8 = "송수신 모뎀 진단";
    private static final String M9 = "장비 종합 상태 조회";
    private static final String M10 = "장비 상태 조회";
    private static final String M11 = "장비 임계치 조회";
    private static final String M12 = "장비 임계치 업데이트";
    private static final String M13 = "작전대기모드 변경";
    private static final String M14 = "사용자 잠금 해제";
    private static final String M15 = "비밀번호 변경";
    private static final String M16 = "사용자 조회";
    private static final String M17 = "사용자 추가";
    private static final String M18 = "사용자 수정";
    private static final String M19 = "사용자 삭제";
    private static final String M20 = "그룹 조회";
    private static final String M21 = "그룹 추가";
    private static final String M22 = "그룹 수정";
    private static final String M23 = "그룹 삭제";
    private static final String M24 = "접속중인 사용자 조회";
    private static final String M25 = "접속중인 사용자 강제 로그아웃";
    private static final String M26 = "로그인 이력 조회";
    private static final String M27 = "현재 알람 조회";
    private static final String M28 = "알람 이력 조회";
    private static final String M29 = "알람 ID 조회";
    private static final String M30 = "제어반 설정 요청";
    private static final String M31 = "변복조반 BER 임계치 조회";
    private static final String M32 = "변복조반 BER 임계치 설정";
    private static final String M33 = "변복조반 상태 조회";
    private static final String M34 = "제어반 상태 조회";
    private static final String M35 = "중간주파수 처리반 UPC 설정";
    private static final String M36 = "중간주파수 처리반 DNC 설정";
    private static final String M37 = "중간주파수 신호 경로 설정";
    private static final String M38 = "중간주파수 처리반 BIT LEVEL 설정";
    private static final String M39 = "중간주파수 처리반 상태 조회";
    private static final String M40 = "암호모듈 정보 요청";
    private static final String M41 = "암호모듈 진단 요청";
    private static final String M42 = "암호모듈 로그인 요청";
    private static final String M43 = "암호모듈 PIN 변경 요청";
    private static final String M44 = "암호모듈 로그아웃 요청";
    private static final String M45 = "암호모듈 비문평문 설정 요청";
    private static final String M46 = "암호모듈 비문평문 상태 조회";
    private static final String M47 = "암호장비 구동반 보드 상태 조회";
    private static final String M48 = "암호모듈 수동 키 코드 입력";
    private static final String M49 = "중간주파수 처리반 DNC 설정";
    private static final String M50 = "중간주파수 처리반 UPC 설정";
    private static final String M51 = "명령어 이력 ID 조회";
    private static final String M52 = "명령어 이력 조회";
    private static final String M53 = "통합제어서버 기동 이력 조회";
    private static final String M54 = "데이터 송수신 타입 조회";
    private static final String M55 = "데이터 송수신 조회";
    private static final String M56 = "통합제어서버 장애 통계 조회";
    private static final String M57 = "통합제어서버 장애 통계 EXCEL 조회";
    private static final String M58 = "MCRC 연동서버 장애 통계 조회";
    private static final String M59 = "KAMD 연동서버 장애 통계 조회";
    private static final String M60 = "송수신모뎀 장애 통계 조회";
    private static final String M61 = "스위치 장애 통계 조회";
    private static final String M62 = "라우터 장애 통계 조회";
    
    private static final OpCmdRepo FO = new OpCmdRepo("1", M1);
    private static final OpCmdRepo FOM = new OpCmdRepo("2", M2);
    private static final OpCmdRepo RSM = new OpCmdRepo("3", M3);
    private static final OpCmdRepo RSI = new OpCmdRepo("4", M4);
    private static final OpCmdRepo RMM = new OpCmdRepo("5", M5);
    private static final OpCmdRepo DM = new OpCmdRepo("6", M6);
    private static final OpCmdRepo DI = new OpCmdRepo("7", M7);
    private static final OpCmdRepo DM2 = new OpCmdRepo("8", M8);
    private static final OpCmdRepo SLS = new OpCmdRepo("9", M9);
    private static final OpCmdRepo SRS = new OpCmdRepo("10", M10);
    private static final OpCmdRepo STL = new OpCmdRepo("11", M11);
    private static final OpCmdRepo STU = new OpCmdRepo("12", M12);
    private static final OpCmdRepo SCM = new OpCmdRepo("13", M13);
    private static final OpCmdRepo UU = new OpCmdRepo("14", M14);
    private static final OpCmdRepo UCP = new OpCmdRepo("15", M15);
    private static final OpCmdRepo UL = new OpCmdRepo("16", M16);
    private static final OpCmdRepo UA = new OpCmdRepo("17", M17);
    private static final OpCmdRepo UM = new OpCmdRepo("18", M18);
    private static final OpCmdRepo UD = new OpCmdRepo("19", M19);
    private static final OpCmdRepo GL = new OpCmdRepo("20", M20);
    private static final OpCmdRepo GA = new OpCmdRepo("21", M21);
    private static final OpCmdRepo GM = new OpCmdRepo("22", M22);
    private static final OpCmdRepo GD = new OpCmdRepo("23", M23);
    private static final OpCmdRepo SL = new OpCmdRepo("24", M24);
    private static final OpCmdRepo FL = new OpCmdRepo("25", M25);
    private static final OpCmdRepo LH = new OpCmdRepo("26", M26);
    private static final OpCmdRepo CAL = new OpCmdRepo("27", M27);
    private static final OpCmdRepo ALH = new OpCmdRepo("28", M28);
    private static final OpCmdRepo AIL = new OpCmdRepo("29", M29);
    private static final OpCmdRepo CU = new OpCmdRepo("30", M30);
    private static final OpCmdRepo BS = new OpCmdRepo("31", M31);
    private static final OpCmdRepo BS2 = new OpCmdRepo("32", M32);
    private static final OpCmdRepo MS = new OpCmdRepo("33", M33);
    private static final OpCmdRepo CUS = new OpCmdRepo("34", M34);
    private static final OpCmdRepo UPS = new OpCmdRepo("35", M35);
    private static final OpCmdRepo DNS = new OpCmdRepo("36", M36);
    private static final OpCmdRepo LPS = new OpCmdRepo("37", M37);
    private static final OpCmdRepo BLS = new OpCmdRepo("38", M38);
    private static final OpCmdRepo CVS = new OpCmdRepo("39", M39);
    private static final OpCmdRepo CI = new OpCmdRepo("40", M40);
    private static final OpCmdRepo CD = new OpCmdRepo("41", M41);
    private static final OpCmdRepo CL = new OpCmdRepo("42", M42);
    private static final OpCmdRepo CP = new OpCmdRepo("43", M43);
    private static final OpCmdRepo CLO = new OpCmdRepo("44", M44);
    private static final OpCmdRepo CS = new OpCmdRepo("45", M45);
    private static final OpCmdRepo CST = new OpCmdRepo("46", M46);
    private static final OpCmdRepo CB = new OpCmdRepo("47", M47);
    private static final OpCmdRepo CK = new OpCmdRepo("48", M48);
    private static final OpCmdRepo DDS = new OpCmdRepo("49", M49);
    private static final OpCmdRepo DUS = new OpCmdRepo("50", M50);
    private static final OpCmdRepo OIL = new OpCmdRepo("51", M51);
    private static final OpCmdRepo OHL = new OpCmdRepo("52", M52);
    private static final OpCmdRepo EHL = new OpCmdRepo("53", M53);
    private static final OpCmdRepo DSCL = new OpCmdRepo("54", M54);
    private static final OpCmdRepo DSL = new OpCmdRepo("55", M55);
    private static final OpCmdRepo ISL = new OpCmdRepo("56", M56);
    private static final OpCmdRepo ISX = new OpCmdRepo("57", M57);
    private static final OpCmdRepo MSL = new OpCmdRepo("58", M58);
    private static final OpCmdRepo KSL = new OpCmdRepo("59", M59);
    private static final OpCmdRepo MOS = new OpCmdRepo("60", M60);
    private static final OpCmdRepo SWL = new OpCmdRepo("61", M61);
    private static final OpCmdRepo RTL = new OpCmdRepo("62", M62);
    
    private String code;
    private String msg;

    static {
        CODE_MAP.put(FO.getCode(), FO);
        CODE_MAP.put(FOM.getCode(), FOM);
        CODE_MAP.put(RSM.getCode(), RSM);
        CODE_MAP.put(RSI.getCode(), RSI);
        CODE_MAP.put(RMM.getCode(), RMM);
        CODE_MAP.put(DM.getCode(), DM);
        CODE_MAP.put(DI.getCode(), DI);
        CODE_MAP.put(DM2.getCode(), DM2);
        CODE_MAP.put(SLS.getCode(), SLS);
        CODE_MAP.put(SRS.getCode(), SRS);
        CODE_MAP.put(STL.getCode(), STL);
        CODE_MAP.put(STU.getCode(), STU);
        CODE_MAP.put(SCM.getCode(), SCM);
        CODE_MAP.put(UU.getCode(), UU);
        CODE_MAP.put(UCP.getCode(), UCP);
        CODE_MAP.put(UL.getCode(), UL);
        CODE_MAP.put(UA.getCode(), UA);
        CODE_MAP.put(UM.getCode(), UM);
        CODE_MAP.put(UD.getCode(), UD);
        CODE_MAP.put(GL.getCode(), GL);
        CODE_MAP.put(GA.getCode(), GA);
        CODE_MAP.put(GM.getCode(), GM);
        CODE_MAP.put(GD.getCode(), GD);
        CODE_MAP.put(SL.getCode(), SL);
        CODE_MAP.put(FL.getCode(), FL);
        CODE_MAP.put(LH.getCode(), LH);
        CODE_MAP.put(CAL.getCode(), CAL);
        CODE_MAP.put(ALH.getCode(), ALH);
        CODE_MAP.put(AIL.getCode(), AIL);
        CODE_MAP.put(CU.getCode(), CU);
        CODE_MAP.put(BS.getCode(), BS);
        CODE_MAP.put(BS2.getCode(), BS2);
        CODE_MAP.put(MS.getCode(), MS);
        CODE_MAP.put(CUS.getCode(), CUS);
        CODE_MAP.put(UPS.getCode(), UPS);
        CODE_MAP.put(DNS.getCode(), DNS);
        CODE_MAP.put(LPS.getCode(), LPS);
        CODE_MAP.put(BLS.getCode(), BLS);
        CODE_MAP.put(CVS.getCode(), CVS);
        CODE_MAP.put(CI.getCode(), CI);
        CODE_MAP.put(CD.getCode(), CD);
        CODE_MAP.put(CL.getCode(), CL);
        CODE_MAP.put(CP.getCode(), CP);
        CODE_MAP.put(CLO.getCode(), CLO);
        CODE_MAP.put(CS.getCode(), CS);
        CODE_MAP.put(CST.getCode(), CST);
        CODE_MAP.put(CB.getCode(), CB);
        CODE_MAP.put(CK.getCode(), CK);
        CODE_MAP.put(DDS.getCode(), DDS);
        CODE_MAP.put(DUS.getCode(), DUS);
        CODE_MAP.put(OIL.getCode(), OIL);
        CODE_MAP.put(OHL.getCode(), OHL);
        CODE_MAP.put(EHL.getCode(), EHL);
        CODE_MAP.put(DSCL.getCode(), DSCL);
        CODE_MAP.put(DSL.getCode(), DSL);
        CODE_MAP.put(ISL.getCode(), ISL);
        CODE_MAP.put(ISX.getCode(), ISX);
        CODE_MAP.put(MSL.getCode(), MSL);
        CODE_MAP.put(KSL.getCode(), KSL);
        CODE_MAP.put(MOS.getCode(), MOS);
        CODE_MAP.put(SWL.getCode(), SWL);
        CODE_MAP.put(RTL.getCode(), RTL);
        
    }

    OpCmdRepo(String c, String hMsg) {
        this.code = c;
        this.msg = hMsg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static OpCmdRepo getFailover() {
        return FO;
    }

    public static OpCmdRepo getFailoverModem() {
        return FOM;
    }

    public static OpCmdRepo getResetMed() {
        return RSM;
    }

    public static OpCmdRepo getResetIcs() {
        return RSI;
    }

    public static OpCmdRepo getResetModem() {
        return RMM;
    }

    public static OpCmdRepo getDiagnosisMed() {
        return DM;
    }

    public static OpCmdRepo getDiagnosisIcs() {
        return DI;
    }

    public static OpCmdRepo getDiagnosisModem() {
        return DM2;
    }

    public static OpCmdRepo getSawStatusList() {
        return SLS;
    }

    public static OpCmdRepo getSawResourceList() {
        return SRS;
    }

    public static OpCmdRepo getSawThresholdList() {
        return STL;
    }

    public static OpCmdRepo getSawThresholdUpdate() {
        return STU;
    }

    public static OpCmdRepo getSawChangeMode() {
        return SCM;
    }

    public static OpCmdRepo getSawUserUnlock() {
        return UU;
    }

    public static OpCmdRepo getSawUserChangePw() {
        return UCP;
    }

    public static OpCmdRepo getSawUserList() {
        return UL;
    }

    public static OpCmdRepo getSawUserAdd() {
        return UA;
    }

    public static OpCmdRepo getSawUserModify() {
        return UM;
    }

    public static OpCmdRepo getSawUserDelete() {
        return UD;
    }

    public static OpCmdRepo getSawGroupList() {
        return GL;
    }

    public static OpCmdRepo getSawGroupAdd() {
        return GA;
    }

    public static OpCmdRepo getSawGroupModify() {
        return GM;
    }

    public static OpCmdRepo getSawGroupDelete() {
        return GD;
    }

    public static OpCmdRepo getSawSessionList() {
        return SL;
    }

    public static OpCmdRepo getSawForceLogout() {
        return FL;
    }

    public static OpCmdRepo getSawLoginHist() {
        return LH;
    }

    public static OpCmdRepo getSawCurrAlarmHist() {
        return CAL;
    }

    public static OpCmdRepo getSawAlarmHist() {
        return ALH;
    }

    public static OpCmdRepo getSawAlarmIdList() {
        return AIL;
    }

    public static OpCmdRepo getSmsControlUnitSet() {
        return CU;
    }

    public static OpCmdRepo getSmsModemBerThresStatus() {
        return BS;
    }

    public static OpCmdRepo getSmsModemBerThresSet() {
        return BS2;
    }

    public static OpCmdRepo getSmsModemStatus() {
        return MS;
    }

//    public static OpCmdRepo getSmsControlUnitStatus() {
//        return CUS;
//    }

    public static OpCmdRepo getSmsConvUpcSet() {
        return UPS;
    }

    public static OpCmdRepo getSmsConvDncSet() {
        return DNS;
    }

    public static OpCmdRepo getSmsConvLoopbackSet() {
        return LPS;
    }

    public static OpCmdRepo getSmsConvBitlevelSet() {
        return BLS;
    }

    public static OpCmdRepo getSmsConvStatus() {
        return CVS;
    }

    public static OpCmdRepo getSmsSmoduleInfo() {
        return CI;
    }

    public static OpCmdRepo getSmsSmoduleDignosis() {
        return CD;
    }

    public static OpCmdRepo getSmsSmoduleLogin() {
        return CL;
    }

    public static OpCmdRepo getSmsSmodulePinChange() {
        return CP;
    }

    public static OpCmdRepo getSmsSmoduleLogout() {
        return CLO;
    }

    public static OpCmdRepo getSmsSmoduleCryptoSet() {
        return CS;
    }

    public static OpCmdRepo getSmsSmoduleCryptoStatus() {
        return CST;
    }

    public static OpCmdRepo getSmsSmoduleBoardStatus() {
        return CB;
    }

    public static OpCmdRepo getSmsSmoduleInsertKeyCode() {
        return CK;
    }

    public static OpCmdRepo getSmsConvDefaultDncSet() {
        return DDS;
    }

    public static OpCmdRepo getSmsConvDefaultUpcSet() {
        return DUS;
    }

    public static OpCmdRepo getSawOperationIdList() {
        return OIL;
    }

    public static OpCmdRepo getSawOperationHistList() {
        return OHL;
    }

    public static OpCmdRepo getSawEmsHistList() {
        return EHL;
    }

    public static OpCmdRepo getDataSRCmdList() {
        return DSCL;
    }

    public static OpCmdRepo getDataSRList() {
        return DSL;
    }

    public static OpCmdRepo getIcsStatList() {
        return ISL;
    }

    public static OpCmdRepo getIcsStatListExcel() {
        return ISX;
    }

    public static OpCmdRepo getMisStatList() {
        return MSL;
    }

    public static OpCmdRepo getKisStatList() {
        return KSL;
    }

    public static OpCmdRepo getModemStatList() {
        return MOS;
    }

    public static OpCmdRepo getSwitchStatList() {
        return SWL;
    }

    public static OpCmdRepo getRouterStatList() {
        return RTL;
    }
    
    public static OpCmdRepo fromCode(String code) {
        OpCmdRepo result = CODE_MAP.get(code);

        if (result == null) {
            throw new IllegalArgumentException("Unknown code: " + code);
        }

        return result;
    }

    public static List<OpCmdRepo> getOpOnlyCodes() {
        List<OpCmdRepo> list = new ArrayList<>();

        for (OpCmdRepo item : CODE_MAP.values()) {
            list.add(item);

        }

        list.sort(Comparator.comparingInt(a -> Integer.parseInt(a.getCode())));

        return list;
    }

}
