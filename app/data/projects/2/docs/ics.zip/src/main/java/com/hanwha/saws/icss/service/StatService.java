/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.request.SccStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;

public interface StatService {

    public void makeIcsAlarmStat();

    public void makeMissAlarmStat();

    void makeKissAlarmStat();

    void makeSmsAlarmStat();

    void makeSwitchAlarmStat();

    void makeRouterAlarmStat();

    void makeMissHistStat();

    void makeKissHistStat();

    BaseResponse getKissHistStat(SccStatusReq body);
    
    BaseResponse getMissHistStat(SccStatusReq body);
}
