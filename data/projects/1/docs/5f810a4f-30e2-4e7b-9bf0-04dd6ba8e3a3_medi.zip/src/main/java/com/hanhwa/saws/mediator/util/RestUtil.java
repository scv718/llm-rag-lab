/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.util;

import java.net.URI;
import java.net.URISyntaxException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hanhwa.saws.mediator.common.service.impl.AlarmServiceImpl;
import com.hanhwa.saws.mediator.dto.request.BaseResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RestUtil {

    @Autowired private RestTemplate restTemplate;

    private HttpHeaders getHeader() {
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);

        return headers;
    }

    public BaseResponse sendData(Object paramMap, String url)
            throws URISyntaxException {
        HttpEntity<Object> entity = new HttpEntity<>(paramMap, getHeader());
        URI uri = new URI(url);
        HttpMethod post = HttpMethod.POST;
        ResponseEntity<BaseResponse> response = null;

        response = restTemplate.exchange(uri, post, entity, BaseResponse.class);
        log.info("Send Data Success: {}",response.getBody());
        return response.getBody();
    }
}
