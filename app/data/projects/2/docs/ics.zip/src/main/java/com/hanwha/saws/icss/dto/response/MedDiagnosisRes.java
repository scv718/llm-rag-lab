/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MedDiagnosisRes {

    private int cpu = 0;
    private int hdd = 0;
    private int mem = 0;

    @JsonProperty("alarm_list") private List<MedAlarmInfo> alarmList;

}
