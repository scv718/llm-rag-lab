/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hanhwa.saws.mediator.common.service.AlarmService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KamdTimeoutCheck implements Runnable {

    private static final long T_DURA = TimeUnit.SECONDS.toMillis(12);
    private static final int INTERVAL = 1;
    private volatile boolean previousState = true;
    private AtomicLong lastReceivedTime = new AtomicLong(0);
    @Autowired private AlarmService alarmService;

    public void setLastReceivedTime(long time) {
        lastReceivedTime.set(time);
    }

    @Override
    public void run() {
        while (true) {
            try {
                long cTime = System.currentTimeMillis();
                boolean cState = (cTime - lastReceivedTime.get() <= T_DURA);
                CompletableFuture<Void> delay = new CompletableFuture<>();

                if (cState != previousState) {

                    if (cState) {
                        alarmService.setNoDataAlarm("true");
                    } else {
                        alarmService.setNoDataAlarm("false");
                    }

                    previousState = cState;
                }

                delay.completeOnTimeout(null, INTERVAL, TimeUnit.SECONDS)
                        .join();
            } catch (RuntimeException e3) {
                log.warn("KamdTimeoutCheck error: {}", e3.getMessage(), e3);
            }
        }
    }
}
