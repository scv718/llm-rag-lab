/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class McrcSimulReq {

    @JsonProperty("simul_no") private String simulNo;
    @JsonProperty("code") private String mcrcCode;
    @JsonProperty("type")private String mcrcType;
    @JsonProperty("route") private Integer mcrcRoute;
    @JsonProperty("location_x")private String mcrcLocationX;
    @JsonProperty("location_y") private String mcrcLocationY;

    @JsonProperty("knot") private Integer mcrcKnot;
    @JsonProperty("feet") private Integer mcrcFeet;
    @JsonProperty("direction") private Integer mcrcDirection;
    @JsonProperty("count") private Integer mcrcCount;
    @JsonProperty("create_time") private String createSys;
    
    @JsonProperty("track") private McrcSimulTrackReq track;
    @JsonProperty("routes") private List<McrcSimulRouteReq> routes;
    
    
    private String sysId;

}
