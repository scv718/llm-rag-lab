/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class GroupModel {
	
	private String groupId;
	private String sysId;
	private String groupName;
	private String desc64;
	private Date updateTime;

}
