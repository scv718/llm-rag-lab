/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;

import lombok.Data;

@Data
public class SmtDeviceStatusRes {

    @JsonProperty("node_id") private int nodeId;
    @JsonProperty("node_name") private String name;
    @JsonProperty("ip_addr") private String addrIp;
    @JsonProperty("model_name") private String modelName;
    @JsonProperty("os_version") private String osVersion;
    private String mode;
    @JsonProperty("alarm") private int alarmFlag;
    private String status;
    @JsonProperty("ref") private String ref;

    @JsonIgnore
    public void setData(StatusModel sm, NodeModel nm, String opMode, int rp) {
        NodeRepo code = NodeRepo.from(nm.getNodeId());

        mode = opMode;
        nodeId = nm.getNodeId();
        name = nm.getName();
        addrIp = nm.getAddrIp();
        modelName = nm.getModelName();
        osVersion = nm.getOsVersion();
        alarmFlag = nm.getAlarmFlag();
        
        if (rp == 0) {
            ref = "0";
        } else {
            ref = "1";
        }
        
        if (code.getCode() == NodeRepo.getIcssA().getCode()) {
            status = sm.getIcssA() + "";
        } else if (code.getCode() == NodeRepo.getIcssB().getCode()) {
            status = sm.getIcssB() + "";
        } else if (code.getCode() == NodeRepo.getMissA().getCode()) {
            status = sm.getMissA() + "";
        } else if (code.getCode() == NodeRepo.getMissB().getCode()) {
            status = sm.getMissB() + "";
        } else if (code.getCode() == NodeRepo.getKissA().getCode()) {
            status = sm.getKissA() + "";
        } else if (code.getCode() == NodeRepo.getKissB().getCode()) {
            status = sm.getKissB() + "";
        } else if (code.getCode() == NodeRepo.getSccA().getCode()) {
            status = sm.getSccA() + "";
        } else if (code.getCode() == NodeRepo.getSccB().getCode()) {
            status = sm.getSccB() + "";
        } else if (code.getCode() == NodeRepo.getSmtA().getCode()) {
            status = "0";
        } else if (code.getCode() == NodeRepo.getSmtB().getCode()) {
            status = "0";
        } else if (code.getCode() == NodeRepo.getSmsA().getCode()) {
            status = sm.getSmsA() + "";
        } else if (code.getCode() == NodeRepo.getSmsB().getCode()) {
            status = sm.getSmsB() + "";
        } else if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
            status = sm.getSwitchA() + "";
        } else if (code.getCode() == NodeRepo.getSwitchB().getCode()) {
            status = sm.getSwitchB() + "";
        } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
            status = sm.getRouterA() + "";
        } else if (code.getCode() == NodeRepo.getRouterB().getCode()) {
            status = sm.getRouterB() + "";
        } else if (code.getCode() == NodeRepo.getRouterM().getCode()) {
            status = sm.getRouterM() + "";
        } else {
            status = sm.getIcssA() + "";
        }

    }

}
