/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.persistence.dao.local.AlarmDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.dao.local.UserGroupDao;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.persistence.model.UserModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.SmtService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DBSyncMonitorSchedule {
    private static Logger statusLog = null;
    private static final int M_LOCAL = 0;
    private static final int INIT_WAIT = 0;
    
    @Autowired PropConfig prop;
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired UserGroupDao userGroupDao;
    @Autowired AlarmDao alarmDao;
    @Autowired IcsSyncService syncService;
    @Autowired SmtService smtService;
    @Value("${prop.host-name}") String hostName;
    
    @Scheduled(
            fixedDelayString = "${cron.sync-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void dbSyncMonitor() throws IOException {
       
        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }
        
        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }
        
        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());
        statusLog.debug("DB SYNC MONITOR BATCH START");

        try {
            if (!smtService.isFailingOver()) {
                eventHandle();
            } else {
                log.debug("NOW FAILOVER");
            }
        } catch (NoClassDefFoundError e) {
            log.warn("dbSyncMonitor() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("dbSyncMonitor batch " + e.toString());
        }
        
        statusLog.debug("DB SYNC MONITOR BATCH END");

    }

    private void eventHandle() {
        
        int localDbMode = -1;
        boolean localActive = false;
        List<StatusModel> statusList = null;
        
        try {
            
            statusList = statusConfigDao.selectStatusList();
            
            for (StatusModel sm : statusList) {
                
                localDbMode = NodeUtil.getIcsStatus(hostName, sm, M_LOCAL);
            }

            if (localDbMode == StatusRepo.getACTIVE().getCode()) {
                localActive = true;
            }

        } catch (RuntimeException e) {
            log.warn(e.toString(), e);
        }

        if (localActive) {  
            syncStatusInfo();
            syncNodeInfo();
            syncUserGroupInfo();
            syncThresholdInfo();
            syncCurrentAlarmInfo();
            syncSawInfo();
            syncDefaultCodeInfo();   
        }

    }

    private void syncDefaultCodeInfo() {
        
        List<DefaultCodeModel> codeList = null;
        
        try {
            
            codeList = statusConfigDao.selectDefaultCodeAll(); 
            
            syncService.syncRemoteDefaultCode(codeList);
            
        } catch (RuntimeException e) {
            log.warn("syncDefaultCodeInfo() " + e.toString());
        }
    }

    private void syncStatusInfo() {
        
        try {
            List<StatusModel> sStatusList = statusConfigDao.selectStatusList();

            syncService.syncRemoteStatus(sStatusList);
            
        } catch (RuntimeException e) {
            log.warn("syncStatusInfo() " + e.toString());
        }

    }

    private void syncNodeInfo() {
        
        try {
            List<NodeModel> nodeInfoList = statusConfigDao.selectNodeInfoList();
            
            syncService.syncRemoteNode(nodeInfoList);
            
        } catch (RuntimeException e) {
            log.warn("syncNodeInfo() " + e.toString());
        }
    }

    private void syncUserGroupInfo() {
        
        try {
            List<UserModel> userList = userGroupDao.selectUserList();
            List<GroupModel> groupList = userGroupDao.selectGroupList();
            
            syncService.syncRemoteUserGroup(userList, groupList);

        } catch (RuntimeException e) {
            log.warn("syncUserGroupInfo() " + e.toString());
        }
    }

    private void syncThresholdInfo() {
        
        List<ThresholdModel> thresholdList = null; 
        
        try {
            
            thresholdList = statusConfigDao.selectThresholdList();
            
            syncService.syncRemoteThreshold(thresholdList);
            
        } catch (RuntimeException e) {
            log.warn("syncThresholdInfo() " + e.toString());
        }
    }

    private void syncCurrentAlarmInfo() {

        List<CurrAlarmModel> currAlarmList = null;
        
        try {
           
            currAlarmList = alarmDao.selectCurrentAlarmList();

            syncService.syncRemoteCurrAlarm(currAlarmList);
            
        } catch (RuntimeException e) {
            log.warn("syncCurrentAlarmInfo() " + e.toString());
        }
    }

    private void syncSawInfo() {
        
        List<SawInfoModel> sawList = null;
                
        try {
            
            sawList = statusConfigDao.selectSawList();
            
            syncService.syncRemoteSawInfo(sawList);
            
        } catch (RuntimeException e) {
            log.warn("syncSawInfo() " + e.toString());
        }
    }

}