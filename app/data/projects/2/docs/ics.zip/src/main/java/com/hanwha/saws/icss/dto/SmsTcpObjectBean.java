/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.io.IOException;
import java.nio.ByteBuffer;
import com.hanwha.saws.icss.util.HexByteUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SmsTcpObjectBean {

    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N8 = 8;
    private static final int N9 = 9;
    private static final int N10 = 10;
    
    
    private static final int HEADER_SIZE = 12;
    private short msgType = 0;
    private short opCode = 0;
    private int sid = 0;
    private int length = 0;
    private byte[] data = null;

    private String ctlBit = null;
    private String modemBit = null;
    private String convBit = null;
    private String powerBit = null;
    private String sModuleBit = null;

    private byte ctlByte = 0;
    private byte modemByte = 0;
    private byte convByte = 0;
    private byte powerByte = 0;
    private byte sModuleByte = 0;

//    public boolean parseControlUnitStatus() {
//        int dataLenMax = N10;
//        int ctlBitLen = N8;
//        int pwrBitLen = N9;
//
//        if ((data == null) || (data.length != dataLenMax)) {
//            log.trace("parseControlUnitStatus data failed");
//            return false;
//        }
//
//        ctlBit = HexByteUtil.getBinStr(data[ctlBitLen]);
//        ctlByte = data[ctlBitLen];
//        powerBit = HexByteUtil.getBinStr(data[pwrBitLen]);
//        powerByte = data[pwrBitLen];
//
//        return true;
//    }

    public boolean parseModemUnitStatus() {

        if ((data == null) || (data.length != 1)) {
            log.trace("parseModemUnitStatus data failed");
            return false;
        }

        modemBit = HexByteUtil.getBinStr(data[0]);
        modemByte = data[0];
        return true;
    }

    public boolean parseDiagnosis() {

        int dataLenMax = N5;
        int ctlBitLen = 0;
        int modemBitLen = 1;
        int convBitLen = N2;
        int pwrBitLen = N3;
        int sBitLen = N4;

        if ((data == null) || (data.length != dataLenMax)) {
            log.trace("parseDiagnosis data failed");
            return false;
        }

        ctlBit = HexByteUtil.getBinStr(data[ctlBitLen]);
        ctlByte = data[ctlBitLen];
        modemBit = HexByteUtil.getBinStr(data[modemBitLen]);
        modemByte = data[modemBitLen];
        convBit = HexByteUtil.getBinStr(data[convBitLen]);
        convByte = data[convBitLen];
        powerBit = HexByteUtil.getBinStr(data[pwrBitLen]);
        powerByte = data[pwrBitLen];
        sModuleBit = HexByteUtil.getBinStr(data[sBitLen]);
        sModuleByte = data[sBitLen];

        return true;
    }

    public void setHeader(short type, short hOp, int hId, int hLen) {
        this.msgType = type;
        this.opCode = hOp;
        this.sid = hId;
        this.length = hLen;
    }

    public void headerDecode(byte[] array) {
        byte[] header = new byte[HEADER_SIZE];
        ByteBuffer buffer = null;
        
        System.arraycopy(array, 0, header, 0, header.length);
        
        buffer = ByteBuffer.wrap(header);
        
        msgType = buffer.getShort();
        opCode = buffer.getShort();
        sid = buffer.getInt();
        length = buffer.getInt();
    }

    public void decode(byte[] array) {
        
        headerDecode(array);
        
        data = new byte[length];
        
        System.arraycopy(array, HEADER_SIZE, data, 0, data.length);
    }

    public byte[] headerEncode() throws IOException {
        
        ByteBuffer buffer = ByteBuffer.allocate(HEADER_SIZE);
        
        buffer.putShort(msgType);
        buffer.putShort(opCode);
        buffer.putInt(sid);
        buffer.putInt(length);
        
        return buffer.array();
    }

    public byte[] encode() throws IOException {
        int dataLen = ((data == null) ? 0 : data.length);
        byte[] pdu = new byte[HEADER_SIZE + dataLen];

        System.arraycopy(headerEncode(), 0, pdu, 0, HEADER_SIZE);
        
        if (data != null) {
            System.arraycopy(data, 0, pdu, HEADER_SIZE, data.length);
        }
        
        return pdu;
    }

}
