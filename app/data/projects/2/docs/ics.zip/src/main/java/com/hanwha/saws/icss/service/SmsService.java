/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.util.List;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;

public interface SmsService {

    public void heartbeat(NodeRepo code);

    BaseResponse reset(OperationHistModel histBean, NodeModel nodeInfo,
            LoginSessionBean bean);

    BaseResponse diagnosis(OperationHistModel histBean, NodeModel nodeInfo,
            LoginSessionBean bean);

    void monitorDiagnosis(NodeRepo nc);

    BaseResponse failover(LoginSessionBean bean);

    boolean smsModeChangeAuto(Integer mode, Integer noId);
    
    BaseResponse modeChange(LoginSessionBean bean, Integer mode,
            Integer nodeId);

//    BaseResponse setControlUnit(int nodeId, String targetIp, String remoteIp,
//            LoginSessionBean bean);

//    BaseResponse controlUnitStatus(int nodeId, LoginSessionBean bean);

    BaseResponse getModemBerInfo(int nodeId, LoginSessionBean bean);

    BaseResponse setModemBerInfo(int nodeId, long threshold,
            LoginSessionBean bean);

    BaseResponse getModemStatus(int nodeId, LoginSessionBean bean);

    BaseResponse convUpcUpdate(int nodeId, Double upc, int upcAtt,
            LoginSessionBean bean);

    BaseResponse convDncUpdate(int nodeId, Double dnc, int dncAtt,
            LoginSessionBean bean);

    BaseResponse convStatus(int nodeId, int type, LoginSessionBean bean);

    BaseResponse convLoopbackUpdate(int nodeId, int loopback,
            LoginSessionBean bean);

    BaseResponse convBitLevelUpdate(int nodeId, int uul, int ull, int dul,
            int dll, LoginSessionBean data);

    public BaseResponse convDncDefaultUpdate(int nodeId, Number dncMain,
            Integer dncSub, LoginSessionBean data);

    public BaseResponse convUpcDefaultUpdate(int nodeId, Number dncMain,
            Integer dncSub, LoginSessionBean data);

    void changeOpMode();

}
