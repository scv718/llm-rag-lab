/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.hanwha.saws.icss.dto.SmsTcpMsgBean;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;

public interface SmsClient {
    SmsTcpObjectBean sendRequestMsg(SmsTcpMsgBean bean, NodeRepo code)
            throws IOException, CompletionException;

    SmsTcpObjectBean sendRequestMsg(SmsTcpMsgBean bean, NodeRepo code,
            int timeout) throws IOException, CompletionException;

    String smsIsAllConnect();

    void addUnknownCount(NodeRepo code);

    void setUnknownInit(NodeRepo code);
}