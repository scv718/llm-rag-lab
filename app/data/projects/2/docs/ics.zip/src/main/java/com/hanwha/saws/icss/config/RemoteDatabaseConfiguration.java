/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@MapperScan(
        value = "com.hanwha.saws.icss.persistence.dao.remote",
        sqlSessionFactoryRef = "remoSSF")
@EnableTransactionManagement(proxyTargetClass = true)
public class RemoteDatabaseConfiguration {

    @Bean(name = "remoDS")
    @ConfigurationProperties(prefix = "spring.remote.datasource")
    public DataSource remoDS() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "remoSSF")
    public SqlSessionFactory remoSSF(@Qualifier("remoDS") DataSource remoDS,
            ApplicationContext ctx) throws Exception {

        String xmlPath = "classpath:mappers/remote/*.xml";
        String configPath = "classpath:mybatis-config.xml";

        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();

        factoryBean.setDataSource(remoDS);
        factoryBean.setMapperLocations(ctx.getResources(xmlPath));
        factoryBean.setConfigLocation(ctx.getResource(configPath));

        return factoryBean.getObject();
    }

    @Bean(name = "remoSST")
    public SqlSessionTemplate remoSST(SqlSessionFactory remoSSF) {

        return new SqlSessionTemplate(remoSSF);
    }

    @Bean(name = "remoteTransactionManager")
    public PlatformTransactionManager remoteTxManager()
            throws URISyntaxException, ParseException, IOException {
        return new DataSourceTransactionManager(remoDS());
    }

}
