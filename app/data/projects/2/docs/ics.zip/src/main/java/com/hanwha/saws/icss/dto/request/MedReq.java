/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MedReq {

    private static final String HEART_BEAT = "heartbeat";
    private static final String RESET = "reset";
    private static final String DIAGNOSIS = "diagnosis";

    @JsonProperty("op_code") private String opCode;
    
    @JsonInclude(Include.NON_NULL) private String ip;


}
