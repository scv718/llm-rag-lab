/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.kiss.service;

import java.util.ArrayList;

public interface KamdService {

    void putKamd(ArrayList<byte[]> kmtfBean);

}
