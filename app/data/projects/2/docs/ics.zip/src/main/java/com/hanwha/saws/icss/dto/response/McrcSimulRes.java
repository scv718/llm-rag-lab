/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.McrcSimulModel;

import lombok.Data;

@Data
public class McrcSimulRes {
    @JsonProperty("simul_no") private String simulNo;
    @JsonProperty("code") private String mcrcCode;
    @JsonProperty("type") private String mcrcType;
    @JsonProperty("route") private Integer mcrcRoute;
    @JsonProperty("location_x") private String mcrcLocationX;
    @JsonProperty("location_y") private String mcrcLocationY;
    @JsonProperty("knot") private Integer mcrcKnot;
    @JsonProperty("feet") private Integer mcrcFeet;
    @JsonProperty("direction") private Integer mcrcDirection;
    @JsonProperty("count") private Integer mcrcCount;
    @JsonProperty("create_time") private String createSys;

    @JsonIgnore
    public void setBeanData(McrcSimulModel bean) {
        simulNo = bean.getSimulNo() + "";
        mcrcCode = bean.getMcrcCode();
        mcrcType = bean.getMcrcType();
        mcrcRoute = bean.getMcrcRoute();
        mcrcLocationX = bean.getMcrcLocationX();
        mcrcLocationY = bean.getMcrcLocationY();
        
        if (bean.getMcrcKnot() != null) {
            mcrcKnot = Integer.parseInt(bean.getMcrcKnot());
        }
        
        if (bean.getMcrcFeet() != null) {
            mcrcFeet = Integer.parseInt(bean.getMcrcFeet());
        }
        
        if (bean.getMcrcDirection() != null) {
            mcrcDirection = Integer.parseInt(bean.getMcrcDirection());
        }
        
        if (bean.getMcrcCount() != null) {
            mcrcCount = Integer.parseInt(bean.getMcrcCount());
        }
        
        createSys = bean.getCreateSys();
    }
}
