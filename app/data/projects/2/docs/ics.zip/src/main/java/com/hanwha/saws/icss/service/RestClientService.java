/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.util.concurrent.ConcurrentHashMap;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.request.ActiveStatusReq;
import com.hanwha.saws.icss.dto.request.MedReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.MedDiagnosisRes;

public interface RestClientService {

    public Integer getIcsStatus(String ip);

    public BaseResponse getHeartBeat(String ip);

    public Integer setMode(ActiveStatusReq param, String ip);

    BaseResponse setActiveMode(String ip);

    BaseResponse getMedCommonReq(String ip, MedReq bean);

    BaseResponse setIcsResetReq(String ip, LoginSessionBean bean);

    MedDiagnosisRes getMedDiagnosisReq(String ip, MedReq bean);

    BaseResponse getIcsDiagnosisReq(String ip, MedReq bean);

    BaseResponse icsSyncSession(String ip,
            ConcurrentHashMap<String, LoginSessionBean> b);
}
