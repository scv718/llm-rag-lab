/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.msg;

import lombok.Data;

@Data
public class McrcSeqBean {

    SequenceHeader seqHeader;
    byte[] body;
}
