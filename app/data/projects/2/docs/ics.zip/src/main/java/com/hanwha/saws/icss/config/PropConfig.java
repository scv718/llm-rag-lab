/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.code.EmsTypeRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.SawInfoRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.request.ActiveStatusReq;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.EmsHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.util.NodeUtil;

import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Component
@Data
@Slf4j
public class PropConfig {

    private static final int M_LO = 0;
    private static final int M_REMO = 1;
    private static final int INIT_RUN = 1;

    private int initFlag = 0;
    private int localActiveMode = 0;
    private String rIcsIp = "";
    private boolean modemSendMode = false;

    @Autowired
    StatusConfigDao stConfDao;
    @Autowired
    NonSyncHistDao nonSyncHistDao;

    @Value("${prop.host-name}")
    String hostName;

    @Autowired
    RestClientService restClient;
    @Autowired
    IcsSyncService syncService;

    HashMap<Integer, NodeModel> nodeInfoHash = new HashMap<>();

    @Value("${ics.log.block-api}")
    String[] innerLogBlockApis;
    @Value("${ics.remote-url-only}")
    String[] remoteUrlOnly;

    public int getActiveMode() {
        return localActiveMode;
    }

    public void setActiveMode(int mode) {
        String tmpStr = "ACTIVE";

        if (this.localActiveMode != mode) {
            this.localActiveMode = mode;

            if ((localActiveMode == 0)) {
                tmpStr = "STANDBY";
            }

            log.info(hostName + " MODE CHANGE : " + tmpStr);
        }

    }

    public void readNodeSawStatus() {

        String sawActive = "0";

        for (NodeModel nodeInfoModel : stConfDao.selectNodeInfoList()) {
            nodeInfoHash.put(nodeInfoModel.getNodeId(), nodeInfoModel);
        }

        sawActive = stConfDao.selectSawList().get(0).getOperation();

        if (sawActive.equals(SawInfoRepo.getOperationActive().getCode())) {
            modemSendMode = true;
        } else {
            modemSendMode = false;
        }
    }

    public boolean isBlockMatch(String api) {

        boolean matched = false;

        for (String blockApi : innerLogBlockApis) {
            matched = api.matches(".*" + blockApi + ".*");

            if (matched) {

                break;
            }

        }

        return matched;
    }

    public boolean isRemoteOnlyMatch(String api, String ip) {

        boolean matched = true;

        for (String blockApi : remoteUrlOnly) {
            if (api.matches(".*" + blockApi + ".*")) {
                matched = ((ip.equals("127.0.0.1")) || (rIcsIp.equals(ip)));
                break;
            }
        }

        return matched;
    }

    @PostConstruct
    public void coldStart() {

        int remoteDbMode = -1;
        int remoteActiveMode = -1;
        int remoteStatus = -1;
        StatusModel stM = null;
        List<StatusModel> rStList = null;
        final int defStd = 3;
        final int defAct = 2;
        boolean isRstListNull = false;
        
        List<StatusModel> statusList = null;
        String icsActive = null;
        ActiveStatusReq body  = null;
        
        try {

            statusList = stConfDao.selectStatusList();
            icsActive = stConfDao.selectSawList().get(0).getOperation();

            for (NodeModel mInfo : stConfDao.selectNodeInfoList()) {

                nodeInfoHash.put(mInfo.getNodeId(), mInfo);

            }

            rIcsIp = NodeUtil.getNodeRemoteIcsIP(hostName, nodeInfoHash);

            if (icsActive.equals(SawInfoRepo.getOperationActive().getCode())) {
                modemSendMode = true;
            } else {
                modemSendMode = false;
            }

            for (StatusModel sm : statusList) {
                remoteDbMode = NodeUtil.getIcsStatus(hostName, sm, M_REMO);
            }

            if (remoteDbMode == -1) {
                throw new IllegalStateException("CM_STATUS_INFO no data");
            }

            remoteActiveMode = restClient.getIcsStatus(rIcsIp);

            rStList = syncService.getRemoteStatusList();

            printRemoteStatus(remoteActiveMode, rStList);

            isRstListNull = ((rStList == null) || (rStList.isEmpty()));

            if ((remoteActiveMode == -1) || isRstListNull) {

                setLocalActive();

                if (remoteActiveMode > -1) {

                    body = new ActiveStatusReq(null, defStd);

                    restClient.setMode(body, rIcsIp);

                } else if ((rStList != null) && (rStList.isEmpty())) {

                    statusList = stConfDao.selectStatusList();
                    syncService.setRemoteStatus(statusList.get(0));
                }

            } else {

                stM = rStList.get(0);
                remoteStatus = NodeUtil.getIcsStatus(hostName, stM, M_REMO);

                if ((remoteStatus != defAct) && (remoteActiveMode == 1)) {

                    setLocalActive();
                    statusList = stConfDao.selectStatusList();
                    syncService.setRemoteStatus(statusList.get(0));

                } else if (remoteStatus == defAct) {

                    setLocalStandby();

                    remoteReCheck();
                }

            }

            initFlag = INIT_RUN;

        } catch (DataAccessException | CompletionException e) {
            log.error("ColdStart failed", e);
            bootInsert(EmsTypeRepo.getFail().getCode());
            throw e;
        } catch (IllegalStateException e) {
            log.error("ColdStart failed", e);
            bootInsert(EmsTypeRepo.getFail().getCode());
            throw e;
        }

        bootInsert(EmsTypeRepo.getSuccess().getCode());
    }

    private void printRemoteStatus(int remoteActiveMode,
            List<StatusModel> list) {
        final int n2 = 2;

        String dbLogMsg = "";
        int status = -1;
        String restLogMsg = "DOWN";
        String logMsg = "[{}] REMOTE DB STATAUS :{},REMOTE  REST STATUS: {}";

        if ((list == null) || (list.size() == 0)) {

            dbLogMsg = "DOWN";

        } else {

            status = NodeUtil.getIcsStatus(hostName, list.get(0), M_REMO);

            if (status == 1) {
                dbLogMsg = "UNKNOWN";
            } else if (status == n2) {
                dbLogMsg = "ACTIVE";
            } else {
                dbLogMsg = "STANDBY";
            }
        }

        if (remoteActiveMode == 0) {
            restLogMsg = "STANDBY";
        } else if (remoteActiveMode == 1) {
            restLogMsg = "ACTIVE";
        }

        log.info(logMsg, hostName, dbLogMsg, restLogMsg);
    }

    private void remoteReCheck() {

        int reActiveMode = -1;
        List<StatusModel> remoteStatusList = null;
        int remoteStatus = -1;
        StatusModel sm = null;
        final int sStd = 3;
        final int sAct = 2;
        ActiveStatusReq body = null;
        CompletableFuture<Void> delay = new CompletableFuture<>();
        
        log.info("[{}] REMOTE Recheck", hostName);
        
        try {
            delay.completeOnTimeout(null, sStd, TimeUnit.SECONDS).join();
        } catch (CompletionException e) {
            log.warn("Delay failed", e.getCause());
            throw e;
        }

        reActiveMode = restClient.getIcsStatus(rIcsIp);

        remoteStatusList = syncService.getRemoteStatusList();

        if ((remoteStatusList != null) && (remoteStatusList.size() > 0)) {

            sm = remoteStatusList.get(0);

            remoteStatus = NodeUtil.getIcsStatus(hostName, sm, M_REMO);
        }

        printRemoteStatus(reActiveMode, remoteStatusList);

        if (remoteStatus != sAct) {

            setLocalActive();

            body = new ActiveStatusReq(null, sStd);

            restClient.setMode(body, rIcsIp);
        }

    }

    private void setLocalActive() {

        StatusModel param = new StatusModel();
        StatusRepo sr = StatusRepo.getACTIVE();

        log.info("[{}] SET LOCAL ACTIVE SERVICE", hostName);

        NodeUtil.setIcsStatusMode(hostName, param, sr, M_LO);
        sr = StatusRepo.getSTANDBY();
        NodeUtil.setIcsStatusMode(hostName, param, sr, M_REMO);

        stConfDao.updateStatus(param);

        localActiveMode = 1;
    }

    private void setLocalStandby() {

        StatusModel param = new StatusModel();
        StatusRepo sr = StatusRepo.getSTANDBY();

        log.info("[{}] SET LOCAL STANDBY SERVICE", hostName);

        NodeUtil.setIcsStatusMode(hostName, param, sr, M_LO);

        stConfDao.updateStatus(param);

        localActiveMode = 0;
    }

    private void bootInsert(String result) {

        try {

            EmsHistModel em = new EmsHistModel();

            em.setOperationType(EmsTypeRepo.getStart().getCode());
            em.setOperationResult(result);
            em.setInsertTime(new Date());

            nonSyncHistDao.insertEmsHistInfo(em);

        } catch (RuntimeException e) {
            log.warn(e.toString(), e);
        }
    }

}
