/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;

import lombok.Data;

@Data 
public class McrcLogDetailHistRes {

    @JsonProperty("insert_time")
    private String insertTime;
    @JsonProperty("seq")
    private int seq;
    @JsonProperty("track_number")
    private String trackNumber;
    
    @JsonProperty("identity")
    private String identity;
    
    @JsonProperty("flight_size")
    private String flSize;
    
    private String speed;
    private String direction;
    private String altitude;
    
    @JsonProperty("latitude")
    private String latitude;
    
    @JsonProperty("longitude")
    private String longitude;
    
    @JsonIgnore
    public void setDefaultData(McrcHistDetailModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");       
        
        seq = data.getIdx();
        speed = data.getSpeed().toPlainString();
        direction = data.getDirection().toPlainString();
        altitude = String.format("%.0f", data.getAltitude());
        insertTime = sdf.format(data.getInsertTime());        

    }
}
