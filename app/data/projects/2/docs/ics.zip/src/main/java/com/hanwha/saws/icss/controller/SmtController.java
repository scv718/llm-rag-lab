/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.GroupReq;
import com.hanwha.saws.icss.dto.request.HistoryReq;
import com.hanwha.saws.icss.dto.request.SmtThresholdSetReq;
import com.hanwha.saws.icss.dto.request.UserReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.LoginSessionService;
import com.hanwha.saws.icss.service.SmsService;
import com.hanwha.saws.icss.service.SmsSService;
import com.hanwha.saws.icss.service.SmtService;
import com.hanwha.saws.icss.service.UserGroupService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@RestController
@Slf4j
public class SmtController {

    @Autowired SmtService smtService;
    @Autowired SmsService smsService;
    @Autowired SmsSService smssService;
    @Autowired LoginSessionService loginSessionService;
    @Autowired UserGroupService userGroupService;
    @Autowired AlarmService alarmService;

    /*
     * 긍정 if 조건문 통과되는지 실험용
     */
    @PostMapping("/v1/smtFailover")
    public BaseResponse failover(HttpServletRequest request,
            @RequestBody HashMap body) {

        BaseResponse res = authCheck(request);

        if ((res.getResCd()) == (ResRepo.getC200().getCode())) {
            log.trace("smt failover");

            return smtService.failover((LoginSessionBean) res.getData());
        }

        return res;
    }

    @PostMapping("/v1/smtFailoverModem")
    public BaseResponse failoverModem(HttpServletRequest request,
            @RequestBody HashMap body) {

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("smtFailoverModem " + res.getResCd());
            return res;
        }

        return smsService.failover((LoginSessionBean) res.getData());
    }

    @PostMapping("/v1/smtModemChangeMode")
    public BaseResponse modemChangeMode(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer activeMode = (Integer) body.get("mode");
        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean lS = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("modemChangeMode " + res.getResCd());
            return res;
        }

        if (activeMode == null || nodeId == null) {
            log.trace("modemChangeMode param null");
            return new BaseResponse(ResRepo.getC403());
        }

        lS = (LoginSessionBean) res.getData();

        return smsService.modeChange(lS, activeMode, nodeId);
    }

    @PostMapping("/v1/reset")
    public BaseResponse reset(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("reset " + res.getResCd());

            return res;
        }

        if (nodeId == null) {
            log.trace("reset param null");

            return new BaseResponse(ResRepo.getC403());
        }

        return smtService.reset((LoginSessionBean) res.getData(), nodeId);

    }

    @PostMapping("/v1/diagnosis")
    public BaseResponse diagnosis(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("diagnosis " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("diagnosis param null");
            return new BaseResponse(ResRepo.getC403());
        }

        return smtService.diagnosis((LoginSessionBean) res.getData(), nodeId);
    }

    @PostMapping("/v1/smtModemBerThreshold")
    public BaseResponse modemBerThreshold(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("modemBerThreshold " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("modemBerThreshold param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.getModemBerInfo(nodeId, sb);

    }

    @PostMapping("/v1/smtModemBerThresholdUpdate")
    public BaseResponse modemBerThresholdUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        String ts = body.get("threshold").toString();
        LoginSessionBean sb = null;
        Long threshold = Long.parseLong(ts);

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("smtModemBerThresholdUpdate " + res.getResCd());
            return res;
        }

        if ((nodeId == null) || (threshold == null)) {
            log.trace("modemBerThresholdUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.setModemBerInfo(nodeId, threshold, sb);

    }

    @PostMapping("/v1/smtModemInfo")
    public BaseResponse modemInfo(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("modemInfo " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("modemInfo param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.getModemStatus(nodeId, sb);
    }

    @PostMapping("/v1/smtModemUpcUpdate")
    public BaseResponse convUpcUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Number upcVal = (Number) body.get("upc");
        Integer upcAtt = (Integer) body.get("upc_att");
        Double upc = upcVal.doubleValue();
        
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convUpcUpdate " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convUpcUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        upc = ((upc == null) ? -1 : upc);
        upcAtt = ((upcAtt == null) ? -1 : upcAtt);
        sb = (LoginSessionBean) res.getData();

        return smsService.convUpcUpdate(nodeId, upc, upcAtt, sb);

    }

    @PostMapping("/v1/smtModemUpcInfo")
    public BaseResponse convUpcStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        int bitType = 1;
        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convUpcStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convUpcStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convStatus(nodeId, bitType, sb);

    }

    @PostMapping("/v1/smtModemDncUpdate")
    public BaseResponse convDncUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {
        
        Integer nodeId = (Integer) body.get("node_id");
        Number dncVal = (Number) body.get("dnc");
        Integer dncAtt = (Integer) body.get("dnc_att");
        Double dnc = dncVal.doubleValue();
        LoginSessionBean sb = null;
        
        
        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convDncUpdate " + res.getResCd());

            return res;
        }

        if (body.get("node_id") == null) {
            log.trace("convDncUpdate param null");

            return new BaseResponse(ResRepo.getC403());
        }

        dnc = ((dnc == null) ? -1 : dnc);
        dncAtt = ((dncAtt == null) ? -1 : dncAtt);
        sb = (LoginSessionBean) res.getData();
        return smsService.convDncUpdate(nodeId, dnc, dncAtt, sb);

    }

    @PostMapping("/v1/smtModemDncDefaultUpdate")
    public BaseResponse convDncDefaultUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Number main = (Number) body.get("dnc_main");
        Integer sub = (Integer) body.get("dnc_sub");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convDncDefaultUpdate " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convDncDefaultUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convDncDefaultUpdate(nodeId, main, sub, sb);

    }

    @PostMapping("/v1/smtModemUpcDefaultUpdate")
    public BaseResponse convUpcDefaultUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Number main = (Number) body.get("upc_main");
        Integer sub = (Integer) body.get("upc_sub");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convUpcDefaultUpdate " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convUpcDefaultUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convUpcDefaultUpdate(nodeId, main, sub, sb);

    }

    @PostMapping("/v1/smtModemDncInfo")
    public BaseResponse convDncStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        final int bitType = 2;
        LoginSessionBean sb = null;
        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convDncStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convDncStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convStatus(nodeId, bitType, sb);

    }

    @PostMapping("/v1/smtModemLoopbackUpdate")
    public BaseResponse convLoopbackUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Integer loopback = (Integer) body.get("loopback");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convLoopbackUpdate " + res.getResCd());
            return res;
        }

        if ((nodeId == null) || (loopback == null)) {
            log.trace("convLoopbackUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convLoopbackUpdate(nodeId, loopback, sb);

    }

    @PostMapping("/v1/smtModemLoopbackInfo")
    public BaseResponse convLoopbackStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        final int bitType = 3;
        LoginSessionBean sb = null;
        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convLoopbackStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convLoopbackStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convStatus(nodeId, bitType, sb);

    }

    @PostMapping("/v1/smtModemBitlevelInfo")
    public BaseResponse convBitLevelStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        final int bitType = 4;
        LoginSessionBean sb = null;
        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convBitLevelStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convBitLevelStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convStatus(nodeId, bitType, sb);

    }

    @PostMapping("/v1/smtModemBitlevelUpdate")
    public BaseResponse convBitLevelUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Integer uul = (Integer) body.get("upc_upper_level");
        Integer ull = (Integer) body.get("upc_lower_level");
        Integer dul = (Integer) body.get("dnc_upper_level");
        Integer dll = (Integer) body.get("dnc_lower_level");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convBitLevelUpdate " + res.getResCd());

            return res;
        }

        if (nodeId == null) {
            log.trace("convBitLevelUpdate param null");

            return new BaseResponse(ResRepo.getC403());
        }

        uul = ((uul == null) ? -1 : uul);
        ull = ((ull == null) ? -1 : ull);
        dul = ((dul == null) ? -1 : dul);
        dll = ((dll == null) ? -1 : dll);

        sb = (LoginSessionBean) res.getData();

        return smsService.convBitLevelUpdate(nodeId, uul, ull, dul, dll, sb);

    }

    @PostMapping("/v1/smtModemConvDiagnosis")
    public BaseResponse convDiagnosis(HttpServletRequest request,
            @RequestBody HashMap body) {

        final int bitType = 5;
        LoginSessionBean sb = null;
        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("convDiagnosis " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("convDiagnosis param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smsService.convStatus(nodeId, bitType, sb);

    }

    @PostMapping("/v1/smtModemSModule")
    public BaseResponse sModuleInfo(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleInfo " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("sModuleInfo param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleInfo(nodeId, sb);
    }

    @PostMapping("/v1/smtModemSModuleDiagnosis")
    public BaseResponse sModuleDiagnosis(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleDiagnosis " + res.getResCd());

            return res;
        }

        if (nodeId == null) {
            log.trace("sModuleDiagnosis param null");

            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleDiagnosis(nodeId, sb);

    }

    @PostMapping("/v1/smtModemSModuleLogin")
    public BaseResponse sModuleLogin(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        String pin = (String) body.get("pin");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleLogin " + res.getResCd());

            return res;
        }

        if ((nodeId == null) || (pin == null)) {
            log.trace("sModuleLogin param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleLogin(nodeId, pin, sb);

    }

    @PostMapping("/v1/smtModemSModuleLogout")
    public BaseResponse sModuleLogout(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleLogout " + res.getResCd());

            return res;
        }

        if (nodeId == null) {
            log.trace("sModuleLogout param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleLogout(nodeId, sb);
    }

    @PostMapping("/v1/smtModemSModuleCryptoModeUpdate")
    public BaseResponse sModuleCryptoModeUpdate(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        Integer key = (Integer) body.get("key");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleCryptoModeUpdate " + res.getResCd());
            return res;
        }

        if ((nodeId == null) || (key == null)) {
            log.trace("sModuleCryptoModeUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleCryptoModeUpdate(nodeId, key, sb);

    }

    @PostMapping("/v1/smtModemSModuleCryptoMode")
    public BaseResponse sModuleCryptoModeStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleCryptoModeStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("sModuleCryptoModeStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleCryptoModeStatus(nodeId, sb);
    }

    @PostMapping("/v1/smtModemSModuleBoardInfo")
    public BaseResponse sModuleCryptoBoardStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleCryptoBoardStatus " + res.getResCd());
            return res;
        }

        if (nodeId == null) {
            log.trace("sModuleCryptoBoardStatus param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModuleCryptoBoardStatus(nodeId, sb);
    }

    @PostMapping("/v1/smtModemSModuleInsertKeyCode")
    public BaseResponse sModuleInsertKeyCode(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        String mode = (String) body.get("mode");
        String mCode = (String) body.get("manual_mode_code");
        String keyNum = (String) body.get("key_num");
        LoginSessionBean sb = null;
        boolean pANull = false;
        boolean pBNull = false;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModuleInsertKeyCode " + res.getResCd());
            return res;
        }

        pANull = ((nodeId == null) || (mode == null) || (keyNum == null));
        pBNull = ((mode.equals("1") && mCode == null));

        if (pANull || pBNull) {
            log.trace("sModuleInsertKeyCode param null");

            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService
                .sModuleInsertKeyCode(nodeId, mode, mCode, keyNum, sb);

    }

    @PostMapping("/v1/smtModemSModulePinChange")
    public BaseResponse sModulePinChange(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        String pin = (String) body.get("pin");
        String oldPin = (String) body.get("old_pin");
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sModulePinChange " + res.getResCd());
            return res;
        }

        if ((nodeId == null) || (pin == null) || (oldPin == null)) {
            log.trace("sModulePinChange param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smssService.sModulePinChange(nodeId, oldPin, pin, sb);

    }

    private BaseResponse authCheck(HttpServletRequest request) {

        String auth = request.getHeader("Authorization");
        BaseResponse res = null;
        boolean isPass = true;

        if ((auth == null) || (!auth.startsWith("Bearer "))) {
            isPass = false;
            res = new BaseResponse(ResRepo.getC402());
        }

        if (isPass) {
            auth = auth.substring("Bearer ".length());
            res = loginSessionService.getSession(auth, request.getRemoteAddr());
        }

        return res;

    }

    @PostMapping("/v1/smtLogin")
    public BaseResponse login(HttpServletRequest request,
            @RequestBody UserReq req) {

        return userGroupService.login(req, request.getRemoteAddr());
    }

    @PostMapping("/v1/smtLogout")
    public BaseResponse logout(HttpServletRequest request,
            @RequestBody UserReq req) {

        String ip = request.getRemoteAddr();
        LoginSessionBean sb = null;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("logout " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.logout(sb, ip);

    }
    
    @PostMapping("/v1/smtPwChange")
    public BaseResponse pwChange(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        String auth = request.getHeader("Authorization");
        BaseResponse res = null;

        if (auth != null) {
            res = authCheck(request);

            if (res.getResCd() != ResRepo.getC200().getCode()) {
                log.trace("pwChange " + res.getResCd());

                return res;
            }

            sb = (LoginSessionBean) res.getData();
        } else {
            if ((req.getId() == null) || (req.getOldPw() == null)) {
                log.trace("pwChange id none");

                return new BaseResponse(ResRepo.getC403());
            }
        }

        return userGroupService.userPwChange(sb, req, ip, uri);
    }

    @PostMapping("/v1/smtUserList")
    public BaseResponse getUserList(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("getUserList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.getUserList(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtUserAdd")
    public BaseResponse userAdd(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("userAdd " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.userAdd(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtUserModify")
    public BaseResponse userModify(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("userModify " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.userModify(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtUserDelete")
    public BaseResponse userDelete(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("userDelete " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.userDelete(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtGroupList")
    public BaseResponse getGroupList(HttpServletRequest request,
            @RequestBody GroupReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("smtGroupList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.getGroupList(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtGroupAdd")
    public BaseResponse groupAdd(HttpServletRequest request,
            @RequestBody GroupReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("groupAdd " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.groupAdd(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtGroupModify")
    public BaseResponse groupModify(HttpServletRequest request,
            @RequestBody GroupReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("groupModify " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.groupModify(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtGroupDelete")
    public BaseResponse groupDelete(HttpServletRequest request,
            @RequestBody GroupReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("groupModify " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.groupDelete(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtSessionList")
    public BaseResponse getSessionList(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("getSessionList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.getSessionList(sb, req, ip, uri);

    }

    @PostMapping("/v1/forceLogout")
    public BaseResponse forceLogout(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("forceLogout " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.forceLogout(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtLoginHistoryList")
    public BaseResponse getLoginHistoryList(HttpServletRequest request,
            @RequestBody HistoryReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("getLoginHistoryList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return userGroupService.getLoginHistoryList(sb, req, ip, uri);

    }

    @PostMapping("/v1/smtSawDeviceStatusList")
    public BaseResponse sawStatusList(HttpServletRequest request,
            @RequestBody UserReq req) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("sawStatusList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.sawStatusList(sb, ip, uri);

    }

    @PostMapping("/v1/smtCurrentAlarmList")
    public BaseResponse currAlarmList(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        Integer nodeId = (Integer) body.get("node_id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("currAlarmList " + res.getResCd());
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return alarmService.currAlarmList(sb, nodeId, ip, uri);

    }

    @PostMapping("/v1/smtAlarmHistList")
    public BaseResponse alarmHistSearch(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        boolean isNonVal = true;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("alarmHistSearch");
            return res;
        }

        isNonVal = (st == null) || (ed == null);

        if (isNonVal) {
            log.trace("alarmHistSearch time null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return alarmService.alarmHistSearch(sb, body, ip, uri);

    }
    
    @PostMapping("/v1/smtAlarmMsgList")
    public BaseResponse msgAlarmList(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        boolean isNonVal = true;

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {            
            return res;
        }
        
        isNonVal = (st == null) || (ed == null);
        
        if (isNonVal) {
            return new BaseResponse(ResRepo.getC403());
        }
        
        sb = (LoginSessionBean) res.getData();
        
        return alarmService.msgAlarmList(sb, body, ip, uri);
    }

    @PostMapping("/v1/smtAlarmIdList")
    public BaseResponse alarmIdList(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("alarmIdList");

            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return alarmService.alarmIdList(sb, ip, uri);

    }

    @PostMapping("/v1/smtSawResourceHistList")
    public BaseResponse resourceHistList(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        Integer nId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("resourceHistList");
            return res;
        }

        if ((st == null) || (ed == null) || (nId == null)) {
            log.trace("resourceHistList param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.resourceHistList(sb, body, ip, uri);

    }

    @PostMapping("/v1/smtThresholdInfo")
    public BaseResponse thresholdInfo(HttpServletRequest request,
            @RequestBody HashMap body) {

        Integer nodeId = (Integer) body.get("node_id");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("thresholdInfo");
            return res;
        }

        if (nodeId == null) {
            log.trace("thresholdInfo param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.thresholdInfo(sb, body, ip, uri);
    }

    @PostMapping("/v1/smtThresholdUpdate")
    public BaseResponse thresholtUpdate(HttpServletRequest request,
            @RequestBody SmtThresholdSetReq body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("thresholtUpdate");
            return res;
        }

        if (body.getNodeId() == null) {
            log.trace("thresholtUpdate param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.thresholdUpdate(sb, body, ip, uri);

    }

    @PostMapping("/v1/smtChangeMode")
    public BaseResponse changeMode(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        String mode = (String) body.get("mode");

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("changeMode");
            return res;
        }

        if (mode == null) {
            log.trace("changeMode param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.changeMode(sb, body, ip, uri);

    }

    @PostMapping("/v1/smtOperationCmdList")
    public BaseResponse smtOperationCmdList(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("smtOperationCmdList");
            return res;
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.smtOperationCmdList(sb, ip);
    }

    @PostMapping("/v1/smtOperationHistList")
    public BaseResponse operationHistList(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("operationHistList");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("operationHistList param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.operationHistList(sb, body, ip, uri);

    }

    @PostMapping("/v1/smtEmsStartHistList")
    public BaseResponse emsStartHistList(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");

        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("emsStartHistList");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("emsStartHistList param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.emsStartHistList(sb, body, ip, uri);

    }

    /*
     * 리턴값 실험 저 라인대로 찍으면 굳이 구형방식 안써도 됨
     */
    @PostMapping("/v1/smtSendRecvCodeList")
    public BaseResponse sendRecvCodeList(HttpServletRequest request,
            @RequestBody HashMap body) {

        BaseResponse res = authCheck(request);
        String lIp = request.getRemoteAddr();
        String lUrl = request.getRequestURI();
        LoginSessionBean recvData = null;

        if (res.getResCd() == ResRepo.getC200().getCode()) {
            recvData = (LoginSessionBean) res.getData();

            return smtService.sendRecvCodeList(recvData, body, lIp, lUrl);
        }

        return res;
    }

    @PostMapping("/v1/smtSendRecvDataHistList")
    public BaseResponse sendRecvDataHistList(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();
        String uri = request.getRequestURI();
        String id = (String) body.get("id");

        BaseResponse res = authCheck(request);

        if (res.getResCd() == ResRepo.getC200().getCode()) {

            if ((st == null) || (ed == null) || (id == null)) {
                log.trace("smt send recv datahist list param null");

                return new BaseResponse(ResRepo.getC403());
            }

            sb = (LoginSessionBean) res.getData();
            return smtService.sendRecvDataHistList(sb, body, ip, uri);
        }

        return res;
    }

    @PostMapping("/v1/smtIcsAlarmStat")
    public BaseResponse icsAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("icsAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("icsAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.icsAlarmStat(sb, body, ip);

    }

    @PostMapping("/v1/smtMisAlarmStat")
    public BaseResponse misAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("misAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("misAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.misAlarmStat(sb, body, ip);
    }

    @PostMapping("/v1/smtKisAlarmStat")
    public BaseResponse kisAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("kisAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("kisAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.kisAlarmStat(sb, body, ip);
    }

    @PostMapping("/v1/smtModemAlarmStat")
    public BaseResponse modemAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("modemAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("modemAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.modemAlarmStat(sb, body, ip);
    }

    @PostMapping("/v1/smtSwitchAlarmStat")
    public BaseResponse switchAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("switchAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("switchAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.switchAlarmStat(sb, body, ip);
    }

    @PostMapping("/v1/smtRouterAlarmStat")
    public BaseResponse routerAlarmStat(HttpServletRequest request,
            @RequestBody HashMap body) {

        String st = (String) body.get("start_time");
        String ed = (String) body.get("end_time");
        LoginSessionBean sb = null;
        String ip = request.getRemoteAddr();

        BaseResponse res = authCheck(request);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            log.trace("routerAlarmStat");
            return res;
        }

        if ((st == null) || (ed == null)) {
            log.trace("routerAlarmStat param null");
            return new BaseResponse(ResRepo.getC403());
        }

        sb = (LoginSessionBean) res.getData();

        return smtService.routerAlarmStat(sb, body, ip);

    }
}
