/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Map;
import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.AbstractRequestLoggingFilter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonReader;
import com.hanhwa.saws.mediator.dto.request.BaseResponse;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RequestLoggingFilter extends AbstractRequestLoggingFilter {

    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping()
            .create();

    private static final int N200 = 200;
    private static final int N51200 = 51200;
    private static volatile boolean isSet = false;

    private void setConf() {
        int sizeLim = N51200;

        if (isSet) {
            log.trace("is set false");
            return;

        } else {
            setIncludeQueryString(true);
            setIncludeClientInfo(true);
            setIncludePayload(true);
            setMaxPayloadLength(sizeLim);
            isSet = true;
        }

    }

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {

        long timeMil = Calendar.getInstance().getTimeInMillis();
        JsonReader reader = null;
        RequestInfo info = null;
        String ip = "";
        String param = "";

        try {
            reader = new JsonReader(new StringReader(message));

            request.setAttribute("API_TIME", timeMil);
            info = GSON.fromJson(reader, RequestInfo.class);

            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            info.setRemoteAddr(ip);
            request.setAttribute("remoteaddr", ip);

            if ("POST".equals(info.getMethod())) {
                param = GSON.toJson(info.getPayload());
            }

        } catch (RuntimeException e) {
            log.warn(e.getMessage());
        }
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {

        JsonReader reader = null;
        RequestInfo info = null;
        String ip = "";

        try {
            reader = new JsonReader(new StringReader(message));

            info = GSON.fromJson(reader, RequestInfo.class);

            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            info.setRemoteAddr(ip);

            request.removeAttribute("API_TIME");
            request.removeAttribute("LOG_KEY");
        } catch (RuntimeException e) {
            log.warn(e.getMessage());
        }

    }

    @Override
    public void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        CustomResponseWrapper wrapper = null;
        HttpServletResponse responseToUse = null;
        String ip = "";
        boolean isPayload = false;
        String res = "";
        BaseResponse br = null;
        String lMsgType = "[{}][{}][{}] [RES] type :{}";
        String lResType = "[{}][{}][{}] [RES_PAYLOAD] {}";
        String uri = request.getRequestURI();
        String conType = response.getContentType();
        String reqMethod = request.getMethod();
        RequestInfo info = new RequestInfo();
        String payloadData = "";
        String resMsg = "";
        String transactionId = (String) request.getHeader("TransactionId");
        String cType = null;
        CustomRequestWrapper requestToUse = null;

        if (transactionId == null || transactionId.equals("")) {
            transactionId = UUID.randomUUID().toString();
        }

        MDC.put("TransactionId", transactionId);
        MDC.put("LOG_KEY", transactionId);

        try {
            requestToUse = new CustomRequestWrapper(request);
        } catch (IOException e) {
            log.warn("doFilterInternal " + e.toString());
            throw e;
        }

        beforeRequest(requestToUse, createMessage(requestToUse, "", ""));

        try {
            responseToUse = new CustomResponseWrapper(response);
            filterChain.doFilter(requestToUse, responseToUse);
            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            if (responseToUse instanceof CustomResponseWrapper) {
                isPayload = false;
                wrapper = (CustomResponseWrapper) responseToUse;

                res = wrapper.getDataStreamToString();
                try {

                    cType = response.getContentType();
                    if (cType != null && cType.matches("(.*)json(.*)")) {

                        isPayload = true;

                        log.debug(lResType, uri, ip, reqMethod, res);

                        br = GSON.fromJson(res, BaseResponse.class);
                    }

                } catch (Exception e2) {
                    log.debug("[{}][{}][{}] [RES] {}", uri, ip, reqMethod, res);
                }

                info.setRemoteAddr(ip);
                info.setUrl(uri);

                if (isPayload) {
                    payloadData = res;
                }

                if (br != null) {
                    resMsg = br.getResMsg();
                }

                if (responseToUse.getStatus() != N200) {
                    resMsg = res;
                }

            }
        } finally {
            afterRequest(requestToUse, createMessage(requestToUse, "", ""));
            MDC.remove("LOG_KEY");
            MDC.remove("TransactionId");
        }
    }

    @Override
    @SneakyThrows
    protected String createMessage(HttpServletRequest request, String prefix,
            String suffix) {

        RequestInfo requestInfo = new RequestInfo();
        String method = request.getMethod();
        String ipAddress = request.getHeader("X-FORWARDED-FOR");
        String url = request.getRequestURI();
        String queryString = request.getQueryString();
        HttpSession session = null;
        String user = request.getRemoteUser();
        CustomRequestWrapper wrapper = (CustomRequestWrapper) request;
        String cEncoding = wrapper.getCharacterEncoding();
        byte[] buf = null;
        int length = 0;
        String payload = "";
        StringBuilder msg = new StringBuilder();
        Map<String, String[]> paramMap = null;

        requestInfo.setMethod(method);
        requestInfo.setContentType(request.getContentType());
        requestInfo.setAccept(request.getHeader("Accept"));
        requestInfo.setRemoteAddr(request.getRemoteAddr());

        if (ipAddress == null) {
            ipAddress = request.getRemoteAddr();
        }

        requestInfo.setRemoteAddr(ipAddress);

        if (isIncludeQueryString()) {

            if (queryString != null && "GET".equals(method)) {
                requestInfo.setGetParam(queryString);
            }

            if ("POST".equals(method)) {

                paramMap = request.getParameterMap();

                if (paramMap != null && !paramMap.isEmpty()) {
                    requestInfo.setPostParam(paramMap);
                }
            }

        }

        requestInfo.setUrl(url);
        if (isIncludeClientInfo()) {
            session = request.getSession(false);
            if (session != null) {
                requestInfo.setSession(session.getId());
            }

            if (user != null) {
                requestInfo.setUser(user);
            }
        }

        setConf();

        buf = wrapper.getBody();
        length = Math.min(buf.length, getMaxPayloadLength());

        try {
            payload = new String(buf, 0, length, cEncoding);
            requestInfo.setPayload(GSON.fromJson(payload, LinkedTreeMap.class));
        } catch (UnsupportedEncodingException e) {
            payload = "[unknown]";
        }

        msg.append(GSON.toJson(requestInfo));

        return msg.toString();
    }


    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class RequestInfo {//297 line

        @JsonProperty("Method") private String method;

        @JsonProperty("Content-Type") private String contentType;

        @JsonProperty("Accept") private String accept;

        @JsonProperty("RemoteAddr") private String remoteAddr;

        @JsonProperty("URL") private String url;

        @JsonProperty("session") private String session;

        @JsonProperty("User") private String user;

        @JsonProperty("GET-Parameter") private String getParam;

        @JsonProperty("POST-Parameter") private Map<String, String[]> postParam;

        @JsonProperty("Payload") private LinkedTreeMap<String, Object> payload;

    }

}
