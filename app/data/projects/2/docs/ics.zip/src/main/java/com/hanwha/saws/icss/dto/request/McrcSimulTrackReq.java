/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class McrcSimulTrackReq {


    @JsonProperty("code") private String mcrcCode;
    @JsonProperty("identity") private String mcrcType;
    @JsonProperty("direction") private Integer mcrcDirection;
    @JsonProperty("count") private Integer mcrcCount;    
}
