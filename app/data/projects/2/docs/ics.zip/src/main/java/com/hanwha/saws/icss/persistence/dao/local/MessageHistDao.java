/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.MessageHistModel;

public interface MessageHistDao {

    public void insertMessageHist(MessageHistModel param);

    public int selectMessageHistTotalCount(MessageHistModel param);

    public List<MessageHistModel> selectMessageHistList(MessageHistModel param);

}
