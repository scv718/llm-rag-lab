/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hanwha.saws.icss.dto.RSyncB;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.SmsQueueBean;
import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.kiss.MissleTrackSduBean;
import com.hanwha.saws.icss.dto.miss.AirTrackSduBean;
import com.hanwha.saws.icss.dto.scc.SccCommandBean;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;

@Configuration
public class QueueConfig {

    @Bean(name = "kissRecvBulkQueue")
    public ConcurrentLinkedQueue<RecvMsgQueueBean> kissRecvBulkQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "missRecvBulkQueue")
    public ConcurrentLinkedQueue<RecvMsgQueueBean> missRecvBulkQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "sccQueue")
    public ConcurrentLinkedQueue<RecvMsgQueueBean> sccQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "voiceQueue")
    public ConcurrentLinkedQueue<RecvMsgQueueBean> voiceQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    
    @Bean(name = "smsEventQueue")
    public ConcurrentLinkedQueue<SmsTcpEventBean> smsEventQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    
    @Bean(name = "missFileQueue")
    public ConcurrentLinkedQueue<McrcHistModel> missFileQueue() {
        return new ConcurrentLinkedQueue<>();
    }   
    
    @Bean(name = "kissFileQueue")
    public ConcurrentLinkedQueue<KamdHistModel> kissFileQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    
    @Bean(name = "missBulkQueue")
    public ConcurrentLinkedQueue<McrcHistModel> missBulkQueue() {
        return new ConcurrentLinkedQueue<>();
    }   
    
    @Bean(name = "kissBulkQueue")
    public ConcurrentLinkedQueue<KamdHistModel> kissBulkQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    
    @Bean(name = "rSyncQueue")
    public ConcurrentLinkedQueue<RSyncB> rSyncQueue() {
        return new ConcurrentLinkedQueue<>();
    }    
    
    @Bean(name = "voiceFileQueue")
    public ConcurrentLinkedQueue<SccCommandBean> voiceFileQueue() {
        return new ConcurrentLinkedQueue<>();
    }        
    
    @Bean(name = "airTrackSmsAQueue")
    public ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsAQueue() {
        return new ConcurrentLinkedQueue<>();
    }    
    
    @Bean(name = "airTrackSmsBQueue")
    public ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsBQueue() {
        return new ConcurrentLinkedQueue<>();
    }    
    
    @Bean(name = "kissDecQueue")
    public ConcurrentLinkedQueue<MissleTrackSduBean> kissDecQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    
    @Bean(name = "missDecQueue")
    public ConcurrentLinkedQueue<AirTrackSduBean> missDecQueue() {
        return new ConcurrentLinkedQueue<>();
    }
    

}