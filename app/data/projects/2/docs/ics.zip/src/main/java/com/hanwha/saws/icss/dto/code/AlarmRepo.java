/*
 * ICSS
 *
 * Version 1.0.0
 * sparrow에서 일반적인 enum을 쓰면 검사오류 발생 때문에 강제로 repo로 변경되었다가 
 * 납품 2달 지난후 static으로 변경되어 지금 원래대로 enum을 돌릴 시간이 없어 이런 기괴한 구조가 됨 
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AlarmRepo {
    
    private static final Map<String, AlarmRepo> CODE_MAP = new HashMap<>();
    private static final Map<String, AlarmRepo> A_CODE_MAP = new HashMap<>();
    
    private static final String M_CRI = "CRITICAL";
    private static final String M_MAJ = "MAJOR";
    private static final String M_MIN = "MINOR";
    private static final String M_CLE = "CLEAR";
    private static final String M_INF = "INFO";

    private static final String M_SYS = "SYSTEM_FAIL";
    private static final String M_NOD = "NO DATA";
    private static final String M_COR = "DATA CORRUPT";
    private static final String M_CPU = "CPU THRESHOLD OVERFLOW";
    private static final String M_HDD = "HDD THRESHOLD OVERFLOW";
    private static final String M_MEM = "MEM THRESHOLD OVERFLOW";
    private static final String M_DB = "DB THRESHOLD OVERFLOW";
    private static final String M_FO = "FAILOVER";
    private static final String M_RST = "RESET";
    private static final String M_CLK = "SMS CLOCK CHANGE";
    private static final String M_CTRL = "SMS CONTROL UNIT FAULT";
    private static final String M_MOD = "SMS MODULATION UNIT FAULT";
    private static final String M_CONV = "SMS IF CONVERTER UNIT FAULT";
    private static final String M_PWR = "SMS POWER UNIT FAULT";
    private static final String M_CRY = "SMS CRYPTO UNIT FAULT";
    private static final String M_TRF = "SMS SEND TRAFFIC FAULT";
    private static final String M_RST_CTRL = "SMS CONTROL RESTART";
    private static final String M_BER = "SMS MODULATION BER FAULT";
    private static final String M_CRY_OFF = "SMS CRYPTO UNIT OFF FAULT";
    private static final String M_CRY_DEL = "SMS CRYPTO UNIT DELETE";

    private static final AlarmRepo C_CRI = new AlarmRepo("CRI", M_CRI);
    private static final AlarmRepo C_MAJ = new AlarmRepo("MAJ", M_MAJ);
    private static final AlarmRepo C_MIN = new AlarmRepo("MIN", M_MIN);
    private static final AlarmRepo C_CLE = new AlarmRepo("CLE", M_CLE);
    private static final AlarmRepo C_INF = new AlarmRepo("INF", M_INF);

    private static final AlarmRepo SYS = new AlarmRepo("1", M_SYS);
    private static final AlarmRepo NOD = new AlarmRepo("2", M_NOD);
    private static final AlarmRepo COR = new AlarmRepo("3", M_COR);
    private static final AlarmRepo CPU = new AlarmRepo("4", M_CPU);
    private static final AlarmRepo HDD = new AlarmRepo("5", M_HDD);
    private static final AlarmRepo MEM = new AlarmRepo("6", M_MEM);
    private static final AlarmRepo DB = new AlarmRepo("7", M_DB);
    private static final AlarmRepo FO = new AlarmRepo("8", M_FO);
    private static final AlarmRepo RST = new AlarmRepo("9", M_RST);
    private static final AlarmRepo CLK = new AlarmRepo("10", M_CLK);
    private static final AlarmRepo CTRL = new AlarmRepo("11", M_CTRL);
    private static final AlarmRepo MOD = new AlarmRepo("12", M_MOD);
    private static final AlarmRepo CONV = new AlarmRepo("13", M_CONV);
    private static final AlarmRepo PWR = new AlarmRepo("14", M_PWR);
    private static final AlarmRepo CRY = new AlarmRepo("15", M_CRY);
    private static final AlarmRepo TRF = new AlarmRepo("16", M_TRF);
    private static final AlarmRepo RST_CTRL = new AlarmRepo("17", M_RST_CTRL);
    private static final AlarmRepo BER = new AlarmRepo("18", M_BER);
    private static final AlarmRepo CRY_OFF = new AlarmRepo("19", M_CRY_OFF);
    private static final AlarmRepo CRY_DEL = new AlarmRepo("20", M_CRY_DEL);

    private String code;
    private String msg;

    AlarmRepo(String cd, String m) {
        this.code = cd;
        this.msg = m;
    }

    static {
        CODE_MAP.put("CRI", C_CRI);
        CODE_MAP.put("MAJ", C_MAJ);
        CODE_MAP.put("MIN", C_MIN);
        CODE_MAP.put("CLE", C_CLE);
        CODE_MAP.put("INF", C_INF);

        CODE_MAP.put("1", SYS);
        CODE_MAP.put("2", NOD);
        CODE_MAP.put("3", COR);
        CODE_MAP.put("4", CPU);
        CODE_MAP.put("5", HDD);
        CODE_MAP.put("6", MEM);
        CODE_MAP.put("7", DB);
        CODE_MAP.put("8", FO);
        CODE_MAP.put("9", RST);
        CODE_MAP.put("10", CLK);
        CODE_MAP.put("11", CTRL);
        CODE_MAP.put("12", MOD);
        CODE_MAP.put("13", CONV);
        CODE_MAP.put("14", PWR);
        CODE_MAP.put("15", CRY);
        CODE_MAP.put("16", TRF);
        CODE_MAP.put("17", RST_CTRL);
        CODE_MAP.put("18", BER);
        CODE_MAP.put("19", CRY_OFF);
        CODE_MAP.put("20", CRY_DEL);

        A_CODE_MAP.put("1", SYS);
        A_CODE_MAP.put("2", NOD);
        A_CODE_MAP.put("3", COR);
        A_CODE_MAP.put("4", CPU);
        A_CODE_MAP.put("5", HDD);
        A_CODE_MAP.put("6", MEM);
        A_CODE_MAP.put("7", DB);
        A_CODE_MAP.put("8", FO);
        A_CODE_MAP.put("9", RST);
        A_CODE_MAP.put("10", CLK);
        A_CODE_MAP.put("11", CTRL);
        A_CODE_MAP.put("12", MOD);
        A_CODE_MAP.put("13", CONV);
        A_CODE_MAP.put("14", PWR);
        A_CODE_MAP.put("15", CRY);
        A_CODE_MAP.put("16", TRF);
        A_CODE_MAP.put("17", RST_CTRL);
        A_CODE_MAP.put("18", BER);
        A_CODE_MAP.put("19", CRY_OFF);
        A_CODE_MAP.put("20", CRY_DEL);

    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static AlarmRepo getSvrCri() {
        return C_CRI;
    }

    public static AlarmRepo getSvrMaj() {
        return C_MAJ;
    }

    public static AlarmRepo getSvrMin() {
        return C_MIN;
    }

    public static AlarmRepo getSvrCle() {
        return C_CLE;
    }

    public static AlarmRepo getSvrInfo() {
        return C_INF;
    }

    public static AlarmRepo getAlmSystem() {
        return SYS;
    }

    public static AlarmRepo getAlmNodata() {
        return NOD;
    }

    public static AlarmRepo getAlmDataCorrupt() {
        return COR;
    }

    public static AlarmRepo getAlmCpu() {
        return CPU;
    }

    public static AlarmRepo getAlmHdd() {
        return HDD;
    }

    public static AlarmRepo getAlmMem() {
        return MEM;
    }

    public static AlarmRepo getAlmDb() {
        return DB;
    }

    public static AlarmRepo getAlmFailover() {
        return FO;
    }

    public static AlarmRepo getAlmReset() {
        return RST;
    }

    public static AlarmRepo getAlmSmsClockChange() {
        return CLK;
    }

    public static AlarmRepo getAlmSmsControl() {
        return CTRL;
    }

    public static AlarmRepo getAlmSmsModem() {
        return MOD;
    }

    public static AlarmRepo getAlmSmsConv() {
        return CONV;
    }

    public static AlarmRepo getAlmSmsPwr() {
        return PWR;
    }

    public static AlarmRepo getAlmSmsCrypto() {
        return CRY;
    }

    public static AlarmRepo getAlmSmsTraffic() {
        return TRF;
    }

    public static AlarmRepo getAlmSmsControlRestart() {
        return RST_CTRL;
    }

    public static AlarmRepo getAlmSmsModemBerFault() {
        return BER;
    }

    public static AlarmRepo getAlmSmsCryptoOff() {
        return CRY_OFF;
    }

    public static AlarmRepo getAlmSmsCryptoDelete() {
        return CRY_DEL;
    }

    public static AlarmRepo fromCode(String cd) {
        AlarmRepo result = CODE_MAP.get(cd);
        
        if (result == null) {
            throw new IllegalArgumentException("Unknown code: " + cd);
        }
        return result;
    }

    public static List<AlarmRepo> getAlarmOnlyCodes() {
        List<AlarmRepo> list = new ArrayList<>();
        
        for (AlarmRepo item : A_CODE_MAP.values()) {
            list.add(item);
        }
        Collections.sort(list, getAlarmCodeComparator());
        return list;
    }
    
    private static Comparator<AlarmRepo> getAlarmCodeComparator() {
        return Comparator.comparingInt(acd -> Integer.parseInt(acd.getCode()));
    }
  
}
