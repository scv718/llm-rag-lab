/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.kiss;

import java.nio.ByteBuffer;
import com.hanhwa.saws.mediator.util.SduUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class KmtfSegment {
    

    private static final int SEGMENT_SIZE = 53;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N6 = 6;
    private static final int N7 = 7;
    private static final int N8 = 8;
    private static final int N9 = 9;
    private static final int N10 = 10;
    private static final int N11 = 11;
    private static final int N12 = 12;
    private static final int N13 = 13;
    private static final int N14 = 14;
    private static final int N15 = 15;
    private static final int N16 = 16;
    private static final int N17 = 17;
    private static final int N18 = 18;
    private static final int N19 = 19;
    private static final int N20 = 20;
    private static final int N21 = 21;
    private static final int N22 = 22;
    private static final int N23 = 23;
    private static final int N24 = 24;
    private static final int N25 = 25;
    private static final int N127 = 127;
    private static final int BFE = 0xFE;

    private boolean heartbeat = false;
    
    String starter;
    String trackNumber;
    String impactTime;
    String impactLocLatitude;
    String impactLocLongitude;
    String impactLocAltitude;
    String impactLocUncMajor;
    String impactLocUncMinor;
    String impactLocUncBearing;
    String launchTime;
    String launchLocLatitude;
    String launchLocLongitude;
    String launchLocAltitude;
    String launchLocUncMajor;
    String launchLocUncMinor;
    String launchLocUncBearing;
    String missileLocLatitude;
    String missileLocLongitude;
    String missileLocAltitude;
    String missileLocUncertainty;
    String missileLocTime;
    String velocityCourse;
    String velocitySpeed;
    String type;
    String amplication;
    String simulation;
    String cudm;

    String trimVeloCource = "";
    String trimVeloSpeed = "";

    public void decode(String[] contents, String tag) {

        starter = contents[0];
        trackNumber = contents[1];
        impactTime = contents[N2];
        impactLocLatitude = contents[N3];
        impactLocLongitude = contents[N4];
        impactLocAltitude = contents[N5];
        impactLocUncMajor = contents[N6];
        impactLocUncMinor = contents[N7];
        impactLocUncBearing = contents[N8];
        launchTime = contents[N9];
        launchLocLatitude = contents[N10];
        launchLocLongitude = contents[N11];
        launchLocAltitude = contents[N12];
        launchLocUncMajor = contents[N13];
        launchLocUncMinor = contents[N14];
        launchLocUncBearing = contents[N15];
        missileLocLatitude = contents[N16];
        missileLocLongitude = contents[N17];
        missileLocAltitude = contents[N18];
        missileLocUncertainty = contents[N19];
        missileLocTime = contents[N20];
        velocityCourse = contents[N21];
        velocitySpeed = contents[N22];
        type = contents[N23];
        amplication = contents[N24];
        simulation = contents[N25];
        cudm = (tag == null) ? "M" : tag;

    }

    public byte[] encode() {
        byte[] trackNumberB = new byte[N5];
        byte[] impactTimeB = new byte[N4];
        byte[] impactLocLatitudeB = new byte[N3];
        byte[] impactLocLongitudeB = new byte[N3];
        float impactAltitudeB = 0L;
        byte[] launchTimeB = new byte[N4];
        byte[] launchLocLongitudeB = new byte[N3];
        byte[] launchLocLatitudeB = new byte[N3];
        float launchAltitudeB = 0L;
        byte[] missileLocLatitudeB = new byte[N3];
        byte[] missileLocLongitudeB = new byte[N3];
        float missileAltitudeB = 0L;
        byte[] velocityCourseB = new byte[N3];
        byte[] velocitySpeedB = new byte[N3];
        int typeB = 0;
        int amplicationB = 0;
        int simulationB = 0;
        byte mix1 = 0x00;
        byte cudmB = 0x00;
        ByteBuffer buffer = null;
        byte[] bArr = null;

        trimVeloCource = velocityCourse.replace("\\", "").trim();
        trimVeloSpeed = velocitySpeed.replace("\\", "").trim();

        buffer = ByteBuffer.allocate(SEGMENT_SIZE);

        bArr = trackNumber.getBytes();

        for (int i = 0; i < trackNumberB.length; i++) {
            trackNumberB[i] = (i < bArr.length) ? bArr[i] : 0;
        }

        impactTimeB = SduUtil.encodeTime(impactTime);
        impactLocLatitudeB = SduUtil.encodeLatLng(impactLocLatitude);
        impactLocLongitudeB = SduUtil.encodeLatLng(impactLocLongitude);
        impactAltitudeB = parseFloatSafe(impactLocAltitude);
        launchTimeB = SduUtil.encodeTime(launchTime);
        launchLocLatitudeB = SduUtil.encodeLatLng(launchLocLatitude);
        launchLocLongitudeB = SduUtil.encodeLatLng(launchLocLongitude);
        launchAltitudeB = parseFloatSafe(launchLocAltitude);
        missileLocLatitudeB = SduUtil.encodeLatLng(missileLocLatitude);
        missileLocLongitudeB = SduUtil.encodeLatLng(missileLocLongitude);
        missileAltitudeB = parseFloatSafe(missileLocAltitude);
        velocityCourseB = SduUtil.encodeVelocity(trimVeloCource);
        velocitySpeedB = SduUtil.encodeVelocity(trimVeloSpeed);
        typeB = parseIntSafe(type);

        amplicationB = parseIntSafe(amplication);
        simulationB = parseIntSafe(simulation);
        cudmB = (byte) ("D".equalsIgnoreCase(cudm) ? 1 : 0);

        if ((amplicationB < 0) || (amplicationB > N127)) {
            throw new IllegalArgumentException(
                    "Amplication must be between 0 and 127.");
        }

        mix1 = (byte) ((mix1 & BFE) | (amplicationB << 1));

        simulationB = parseIntSafe(simulation);

        if ((simulationB != 0) && (simulationB != 1)) {
            throw new IllegalArgumentException("Simulation must be 0 or 1.");
        }

        mix1 = (byte) ((mix1 & BFE) | simulationB);

        buffer.put(trackNumberB);
        buffer.put(impactTimeB);
        buffer.put(impactLocLatitudeB);
        buffer.put(impactLocLongitudeB);
        buffer.putFloat(impactAltitudeB);
        buffer.put(launchTimeB);
        buffer.put(launchLocLatitudeB);
        buffer.put(launchLocLongitudeB);
        buffer.putFloat(launchAltitudeB);
        buffer.put(missileLocLatitudeB);
        buffer.put(missileLocLongitudeB);
        buffer.putFloat(missileAltitudeB);
        buffer.put(velocityCourseB);
        buffer.put(velocitySpeedB);
        buffer.putShort((short) typeB);
        buffer.put(mix1);
        buffer.put(cudmB);

        return buffer.array();
    }

    private int parseIntSafe(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private float parseFloatSafe(String value) {
        try {

            return Float.parseFloat(value.replaceAll("\\\\", ""));
        } catch (NumberFormatException e) {
            return 0.0f;
        }
    }

    public byte[] encodeKmtfDelete() {
        ByteBuffer buffer = ByteBuffer.allocate(SEGMENT_SIZE);

        // 1) trackNumber 앞 5바이트(부족시 0패딩) — 기존 로직 그대로
        byte[] trackNumberB = new byte[N5];
        byte[] bArr = (trackNumber == null) ? new byte[0] :
                trackNumber.getBytes();
        byte simulationB = 0;
        byte cudmB = 0;
        
        for (int i = 0; i < trackNumberB.length; i++) {
            trackNumberB[i] = (i < bArr.length) ? bArr[i] : 0;
        }
        buffer.put(trackNumberB);

        // 2) 중간은 0으로 패딩 (마지막 2바이트 남겨둠)
        buffer.put(new byte[SEGMENT_SIZE - N5 - N2]);

        // 3) 끝-1 바이트: simulation (문자열 "0"/"1" 혹은 0으로)
        simulationB = (byte) ((parseIntSafe(simulation) == 1) ? 1 : 0);
        buffer.put(simulationB);

        // 4) 끝 바이트: cudm (D -> 1, 그 외 -> 0)
        cudmB = (byte) ("D".equalsIgnoreCase(cudm) ? 1 : 0);
        buffer.put(cudmB);

        return buffer.array();
    }



}
