/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

public class LogParamUtil {
    private static final float N1000 = 1000.0f;

    private LogParamUtil() {}

    public static String getCheckTime(long startTime) {

        long endTime = System.currentTimeMillis();

        return "" + ((endTime - startTime) / N1000);

    }

}
