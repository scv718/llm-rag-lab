/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ThCodeRepo {

    private static final List<ThCodeBean> ALL = new ArrayList<ThCodeBean>();

    private static final int L_CRI = 0; // Critical
    private static final int L_MAJ = 1; // Major
    private static final int L_MIN = 2; // Minor
    private static final int L_WARN = 3; // Warning

    private static final int T_CPU = 0;
    private static final int T_MEM = 1;
    private static final int T_HDD = 2;

    static {
        ALL.add(new ThCodeBean(L_CRI, "CRI", "LEVEL"));
        ALL.add(new ThCodeBean(L_MAJ, "MAJ", "LEVEL"));
        ALL.add(new ThCodeBean(L_MIN, "MIN", "LEVEL"));
        ALL.add(new ThCodeBean(L_WARN, "WARN", "LEVEL"));

        ALL.add(new ThCodeBean(T_CPU, "CPU", "TYPE"));
        ALL.add(new ThCodeBean(T_MEM, "MEM", "TYPE"));
        ALL.add(new ThCodeBean(T_HDD, "HDD", "TYPE"));
    }

    private ThCodeRepo() {}
    
//    public static List<ThCodeBean> getLevelList() {
//        List<ThCodeBean> result = new ArrayList<ThCodeBean>();
//        ThCodeBean tc = null;
//
//        for (int i = 0; i < ALL.size(); i++) {
//            tc = (ThCodeBean) ALL.get(i);
//
//            if ("LEVEL".equals(tc.getGroup())) {
//                result.add(tc);
//            }
//        }
//
//        Collections.sort(result, getCodeComparator());
//
//        return result;
//    }
//
//    public static List<ThCodeBean> getTypeList() {
//        List<ThCodeBean> result = new ArrayList<ThCodeBean>();
//        ThCodeBean tc = null;
//        
//        for (int i = 0; i < ALL.size(); i++) {
//            tc = (ThCodeBean) ALL.get(i);
//
//            if ("TYPE".equals(tc.getGroup())) {
//                result.add(tc);
//            }
//        }
//  
//        Collections.sort(result, getCodeComparator());
//
//        return result;
//    }

    public static ThCodeBean getLevelCode(int code) {
        ThCodeBean tc = null;

        for (int i = 0; i < ALL.size(); i++) {
            tc = ALL.get(i);

            if (("LEVEL".equals(tc.getGroup())) && (tc.getCode() == code)) {
                return tc;
            }
        }
        return null;
    }

    public static ThCodeBean getTypeCode(int code) {
        ThCodeBean tc = null;

        for (int i = 0; i < ALL.size(); i++) {
            tc = ALL.get(i);

            if (("TYPE".equals(tc.getGroup())) && (tc.getCode() == code)) {
                return tc;
            }
        }
        return null;
    }

//    private static Comparator<ThCodeBean> getCodeComparator() {
//
//        return (a, b) -> Integer.compare(a.getCode(), b.getCode());
//    }

}