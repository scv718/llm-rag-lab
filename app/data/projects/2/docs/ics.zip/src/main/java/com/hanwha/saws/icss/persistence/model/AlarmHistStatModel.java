/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class AlarmHistStatModel implements Serializable {
    
    private int nodeId;
    private String alarmId;
    private int alarmCount;
    private Timestamp startTime;
    private Timestamp endTime;

    public void parseStartTime(LocalDateTime st) {
        startTime = Timestamp.valueOf(st);
    }

    public void parseEndTime(LocalDateTime ed) {
        endTime = Timestamp.valueOf(ed);
    }
}