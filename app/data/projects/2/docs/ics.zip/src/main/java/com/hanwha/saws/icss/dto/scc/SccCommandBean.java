/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.scc;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.hanwha.saws.icss.dto.CommonHeaderSduBean;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SccCommandBean {

    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N7 = 7;
    private static final int N160 = 160;
    
    private static final int BFF = 0xFF;

    private CommonHeaderSduBean header;
    private byte[] originFilterByte;

    private byte typeCmd;
    private int groupByteLen;
    private byte[] voiceBody;
    byte[] voiceGroupByte;
    byte[] cmdGroupByte;
    private byte cmdFrameId;
    private byte cmdFrame;

    private int fileSaveType = 0;
    
    private String logKInfo;

    byte type = 0;
    STypeRepo code = null;

    public SccCommandBean() {}
    
    public SccCommandBean(byte[] packet, int groupLen)
            throws IOException {

        try {            
            boolean d1 = false;
            boolean d2 = false;
            boolean d3 = false;
            boolean d4 = false;
            boolean d5 = false;
            boolean d6 = false;
            boolean d7 = false;
            byte cv = 0;
            
            setCommonCmd(ByteBuffer.wrap(packet));

            typeCmd = packet[0];
            groupByteLen = groupLen;
            type = packet[0];
            code = STypeRepo.fromCode(type);
            cv = code.getCode();

            d1 = (cv == STypeRepo.getArCmd().getCode());
            d2 = (cv == STypeRepo.getAdcCmd().getCode());
            d3 = (cv == STypeRepo.getEmCmd().getCode());
            d4 = (cv == STypeRepo.getAdwCmd().getCode());
            d5 = (cv == STypeRepo.getAdwArCmd().getCode());

            d6 = (cv == STypeRepo.getCtlCmd().getCode());
            d7 = (cv == STypeRepo.getEtcCmd().getCode());

            if (cv == STypeRepo.getVoCmd().getCode()) {
                setVoiceCmd(ByteBuffer.wrap(packet));
            } else if (d1 || d2 || d3 || d4 || d5) {
                setCommonCmd(ByteBuffer.wrap(packet));
            } else if (d6 || d7) {
                setCommandCmd(ByteBuffer.wrap(packet));
            } else {
                log.debug("NON CODE " + code);
            }
        } catch (IOException | RuntimeException e) {
            log.warn("Command data decoded InValid. skip");
            throw e;
        }
    }
    
    public void setLogKInfo(String logK) {
        logKInfo = logK;
    }
    
    public String getLogKInfo() {
        return logKInfo;
    }

    public void setFileSaveType(int isTrue) {
        fileSaveType = isTrue;
    }

    public int getFileSaveType() {
        return fileSaveType;
    }

    public byte getType() {
        return typeCmd;
    }

    public byte getFrameId() {
        return cmdFrameId;
    }

    public int getFrame() {
        return cmdFrame & BFF; // unsigned
    }
    
    public String getCmdGroupId() {
        return HexByteUtil.getByteArrayToHexString(cmdGroupByte);
    }
    
    public byte[] getOriginFilterByte() {
        if (originFilterByte == null) {
            return null;
        }
        return Arrays.copyOf(originFilterByte, originFilterByte.length);
    }

    private void setCommandCmd(ByteBuffer cBuf) throws IOException {
        int length = 0;
        byte[] body = null;
        ByteBuffer bodyBuf = null;

        header = new CommonHeaderSduBean(cBuf.get(), cBuf.get());
        length = header.getPayloadLengthInt();
        body = new byte[length];
        cBuf.get(body);

        cmdGroupByte = new byte[groupByteLen];
        
        if (length > 0) {
            bodyBuf = ByteBuffer.wrap(body);
            bodyBuf.get(cmdGroupByte);
            cmdFrameId = bodyBuf.get();
            cmdFrame = bodyBuf.get(); // 타입이 1이면 음성권한 타입이 4~6이면 훈련넘버
        }

        originFilterByte = encode(body);
    }

    private void setCommonCmd(ByteBuffer cBuf) throws IOException {
        int length = 0;
        byte[] body = null;

        header = new CommonHeaderSduBean(cBuf.get(), cBuf.get());
        length = header.getPayloadLengthInt();
        body = new byte[length];
        cBuf.get(body);

        originFilterByte = encode(body);
    }

    private byte[] encode(byte[] body) throws IOException {
        int pLen = (header.getHeader().length + body.length);

        ByteBuffer eBuf = ByteBuffer.allocate(pLen);
        
        eBuf.put(header.getType());
        eBuf.put(header.getPayloadLength());
        eBuf.put(body);
        
        return eBuf.array();
    }

    private void setVoiceCmd(ByteBuffer vBuf) throws IOException {
        int vLen = 0;
        int voiceMaxLen = N160;
        
        header = new CommonHeaderSduBean(vBuf.get(), vBuf.get());
        voiceGroupByte = new byte[groupByteLen];
        
        vBuf.get(voiceGroupByte);
        vLen = header.getPayloadLengthInt() - groupByteLen;

        if (vBuf.remaining() != voiceMaxLen) {
            log.debug("Voice Length Not Match " + vBuf.remaining());
            throw new IOException("body length not match");
        }
        
        voiceBody = new byte[vLen];
        vBuf.get(voiceBody);
        originFilterByte = voiceEncode(voiceGroupByte, voiceBody);

    }

    public byte[] getVoiceToSave() {
        byte[] tmp = new byte[N160];

        System.arraycopy(voiceBody, 0, tmp, 0, tmp.length);

        return tmp;
    }

    private byte[] voiceEncode(byte[] groupByte, byte[] body)
            throws IOException {

        int pLen = N2 + voiceGroupByte.length + body.length;
        ByteBuffer vBuff = ByteBuffer.allocate(pLen);

        vBuff.put(header.getType());
        vBuff.put(header.getPayloadLength());
        vBuff.put(groupByte);
        vBuff.put(body);

        return vBuff.array();
    }

//    public List<byte[]> getVoiceList() {
//
//        ArrayList<byte[]> list = new ArrayList<>();
//        int start = 0;
//        int end = 0;
//        byte[] chunk = null;
//        byte[] sendP = null;
//        int tChunks = voiceBody.length / N160;
//
//        for (int i = 0; i < tChunks; i++) {
//            start = i * N160;
//            end = start + N160;
//            chunk = Arrays.copyOfRange(voiceBody, start, end);
//
//            sendP = new byte[N2 + groupByteLen + N160];
//
//            sendP[N0] = STypeRepo.getVoCmd().getCode();
//            sendP[N1] = (byte) (BFF & (chunk.length + groupByteLen));
//
//            System.arraycopy(voiceGroupByte, 0, sendP, N2, groupByteLen);
//            System.arraycopy(chunk, 0, sendP, N7, chunk.length);
//
//            list.add(sendP);
//        }
//
//        return list;
//    }
}
