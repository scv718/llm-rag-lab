/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;

import lombok.Data;

@Data
public class VoiceStatusRes {
    
    @JsonProperty("voice_active_yn") private String activeYn = "N";
    @JsonProperty("voice_priority") private String prioritry;
    private String name;
    private String ip;
    
}
