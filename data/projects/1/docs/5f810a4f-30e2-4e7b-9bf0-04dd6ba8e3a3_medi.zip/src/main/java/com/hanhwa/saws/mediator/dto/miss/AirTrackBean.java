/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.miss;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import com.hanhwa.saws.mediator.miss.service.EncodeIF;
import com.hanhwa.saws.mediator.util.ByteUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AirTrackBean implements EncodeIF {

    private static final byte MESSAGE_TYPE = 0x05;
    private static final int SDU_UNIT_SIZE = 11;
    private static final int M_SIZE = 6;

    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N6 = 6;
    private static final int N7 = 7;
    private static final int N8 = 8;
    private static final int N9 = 9;
    private static final int N14 = 14;
    private static final int N16 = 16;
    private static final int N19 = 19;
    private static final int N23 = 23;
    private static final int N24 = 24;
    private static final int N26 = 26;
    private static final int N27 = 27;
    private static final int N29 = 29;
    private static final int N30 = 30;
    private static final int N31 = 31;
    private static final int N32 = 32;
    private static final int N33 = 33;
    private static final int N35 = 35;
    private static final int N36 = 36;
    private static final int N37 = 37;
    private static final int N38 = 38;
    private static final int N39 = 39;
    private static final int N41 = 41;
    private static final int N42 = 42;
    private static final int N43 = 43;
    private static final int N47 = 47;
    private static final int B0F = 0x0f;
    private static final int BFF = 0xff;

    private int refP = 0;
    private int simulLiveState;
    private int flightSize;
    private int identity;
    private int xPosition;
    private int yPosition;
    private int xVelocity;
    private int yVelocity;
    private int altitude;
    byte[] positionByte;
    byte[] trackNumber;
    String trackNumberStr;


    private List<byte[]> msgFormatArray = new ArrayList<>();

    public AirTrackBean(byte[] rawMessageData, int refPosition) {
        parseMessages(rawMessageData);
        refP = refPosition;
    }

    private void parseMessages(byte[] rawMessageData) {

        int totalMessages = rawMessageData.length / M_SIZE;
        int startIdx = 0;
        byte[] message = null;

        try {
            for (int i = 0; i < totalMessages; i++) {
                startIdx = i * M_SIZE;
                message = new byte[M_SIZE];

                System.arraycopy(rawMessageData, startIdx, message, 0, M_SIZE);
                msgFormatArray.add(message);
            }

            for (byte[] messageFor : msgFormatArray) {
                decode(messageFor);
            }

        } catch (RuntimeException e) {
            log.warn("Error while parsing Airtrack messages", e.toString());
        }
    }

    public void decode(byte[] rawData) {
        byte[] swappedMessage = ByteUtil.swap2Bytes(rawData);
        byte[] bitSwappedMessage = ByteUtil.bitSwap(swappedMessage);
        String bStr = "";
        int label = 0;
        int subLabel = 0;
        int sw = 0;
        int tr0 = 0;
        int tr1 = 0;
        int tr2 = 0;
        int tr3 = 0;
        int tr4 = 0;
        String sTr0 = null;
        String sTr1 = null;
        String sTr2 = null;
        String sTr3 = null;
        String sTr4 = null;

        bStr = ByteUtil.getByteArrayToBynaryString(bitSwappedMessage);
        label = ByteUtil.getReverseValue(bStr, 0, N3);

        switch (label) {
            case N9: {
                subLabel = ByteUtil.getReverseValue(bStr, N4, N7);
                if (subLabel == 0) {
                    simulLiveState = ByteUtil.getReverseValue(bStr, N23, N23);
                } else if (subLabel == N4) {
                    tr0 = ByteUtil.getReverseValue(bStr, N24, N26);
                    tr1 = ByteUtil.getReverseValue(bStr, N27, N29);
                    tr2 = ByteUtil.getReverseValue(bStr, N30, N32);
                    tr3 = ByteUtil.getReverseValue(bStr, N33, N37);
                    tr4 = ByteUtil.getReverseValue(bStr, N38, N42);

                    trackNumber = getTrackNumArray(tr0, tr1, tr2, tr3, tr4);
                    sTr0 = ByteUtil.getAlphanumeric(tr0);
                    sTr1 = ByteUtil.getAlphanumeric(tr1);
                    sTr2 = ByteUtil.getAlphanumeric(tr2);
                    sTr3 = ByteUtil.getAlphanumeric(tr3);
                    sTr4 = ByteUtil.getAlphanumeric(tr4);

                    trackNumberStr = sTr4 + sTr3 + sTr2 + sTr1 + sTr0;
                }
                break;
            }
            case N2: {
                identity  = ByteUtil.getReverseValue(bStr, N16, N19);
                xPosition = ByteUtil.getReverseValue(bStr, N24, N35);
                yPosition = ByteUtil.getReverseValue(bStr, N36, N47);
                break;
            }
            case N8: {
                sw = ByteUtil.getReverseValue(bStr, N41, N41);
                if (sw == 0) {
                    xVelocity = ByteUtil.getReverseValue(bStr, N24, N31);
                    yVelocity = ByteUtil.getReverseValue(bStr, N32, N39);
                    altitude  = ByteUtil.getReverseValue(bStr, N16, N23);
                    flightSize = ByteUtil.getReverseValue(bStr, N42, N43);
                }
                break;
            }
            default: {
                log.warn("Unsupported Label: {}", label);
                break;
            }
        }
    }

    @Override
    public byte[] encode() {
        ByteBuffer buffer = ByteBuffer.allocate(SDU_UNIT_SIZE);
        byte[] bf = null;

        buffer.put((byte) ((simulLiveState << N4) | refP));
        buffer.put(trackNumber);
        buffer.put((byte) ((identity << N4) | flightSize));
        buffer.put((byte) ((yPosition) >> N4));
        buffer.put((byte) (((yPosition & B0F) << N4) | (xPosition >> N8)));
        buffer.put((byte) ((xPosition) & BFF));
        buffer.put((byte) xVelocity);
        buffer.put((byte) yVelocity);
        buffer.put((byte) altitude);

        bf = buffer.array();

        log.debug("AirTrack byte encode success: {}", ByteUtil.bytesToHex(bf));

        return bf;
    }

    byte[] getTrackNumArray(int tr1, int tr2, int tr3, int tr4, int tr5) {
        byte[] dest = new byte[N3];
        int i = (tr1) | (tr2 << N3) | (tr3 << N6) | (tr4 << N9) | (tr5 << N14);
        byte[] src = integer2Bytes(i);

        System.arraycopy(src, 1, dest, 0, dest.length);

        return dest;
    }

    private byte[] integer2Bytes(int intValue) {
        byte bytes[] = new byte[N4];
        int bFF = 0xFF;

        bytes[N3] = (byte) (intValue & bFF);
        bytes[N2] = (byte) ((intValue >>> N8) & bFF);
        bytes[1] = (byte) ((intValue >>> N16) & bFF);
        bytes[0] = (byte) ((intValue >>> N24) & bFF);
        return bytes;
    }

    @Override
    public byte getType() {
        return MESSAGE_TYPE;
    }

    public static String getByteArrayToBynaryString(byte[] bytes) {
        //StringBuffer sb = new StringBuffer();
        StringBuilder sb = new StringBuilder();
        String bStr = null;

        for (byte b : bytes) {
            bStr = Integer.toBinaryString(BFF & b);

            sb.append(String.format("%8s", bStr).replace(' ', '0'));
        }
        return sb.toString();
    }

}
