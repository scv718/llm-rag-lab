/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.controller;

import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.KamdSimulReq;
import com.hanwha.saws.icss.dto.request.McrcSimulReq;
import com.hanwha.saws.icss.dto.request.McrcSimulRouteReq;
import com.hanwha.saws.icss.dto.request.McrcSimulTrackReq;
import com.hanwha.saws.icss.dto.request.SccStatusReq;
import com.hanwha.saws.icss.dto.request.UserReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.service.LoginSessionService;
import com.hanwha.saws.icss.service.SccService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * 현재 sessionValid 외에는 전부 세션 잠금 해제 상태 
 * 필요시 BaseResponse res = authCheck(request) 으로 잠글 예정 20250901  
 */
@CrossOrigin
@RestController
@Slf4j
public class SccController {

    @Autowired SccService sccService;
    @Autowired LoginSessionService loginSessionService;

    @PostMapping("/v1/sccStatus")
    public BaseResponse sccLoginOut(HttpServletRequest request,
            @RequestBody SccStatusReq body) {
        return sccService.sccLoginOut(body, request.getRemoteAddr());
    }
    
    /*
    @PostMapping("/v1/sccLogHist")
    public BaseResponse sccLogHist(HttpServletRequest request,
            @RequestBody SccStatusReq body) {

        if ((body.getStartTime() == null) || (body.getEndTime() == null)) {
            log.trace("body is null");
            return new BaseResponse(ResRepo.getC403());
        }
        
        아래 impl에 중요정보가 있다하여 지웠습니다
        return sccService.sccLogHist(body, request.getRemoteAddr());
    }
    */
    
    @PostMapping("/v1/sccDetailLogHist")
    public BaseResponse sccDetailLogHist(HttpServletRequest request,
            @RequestBody SccStatusReq body) {
        
        /*
         * 범위 : 속도, 고도, 방향, 시간
         * 고정 : tracknumber, identity(식별부호) 
         * 필수 : 시간 1페이지
         * 100개
         */
        
        if ((body.getStartTime() == null) || (body.getEndTime() == null)) {
            log.trace("body is null");
            return new BaseResponse(ResRepo.getC403());
        }

        return sccService.sccDetailLogHist(body, request.getRemoteAddr());
    }

    @PostMapping("/v1/sccDetailStatHist")
    public BaseResponse sccDetailStatHist(HttpServletRequest request,
            @RequestBody SccStatusReq body) {
        
        /*
         * 범위 : 시간 
         * 고정 : tracknumber 또는 identity 
         * 필수 : 시간 1페이지 100개
         */
        
        if ((body.getStartTime() == null) || (body.getEndTime() == null)) {
            log.trace("body is null");
            return new BaseResponse(ResRepo.getC403());
        }

        return sccService.sccDetailStatHist(body, request.getRemoteAddr());
    }
        
   /*
    @PostMapping("/v1/sccLogHistNoLimit")
    public BaseResponse sccLogHistNL(HttpServletRequest request,
            @RequestBody SccStatusReq body) {

        if ((body.getStartTime() == null) || (body.getEndTime() == null)) {
            log.trace("body is null");
            return new BaseResponse(ResRepo.getC403());
        }
        아래 impl에 중요정보가 있다하여 지웠습니다
        return sccService.sccLogHistNL(body, request.getRemoteAddr());
    }
    */

    @PostMapping("/v1/sccVoiceStatus")
    public BaseResponse sccVoiceStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        return sccService.sccVoiceStatus(request.getRemoteAddr());
    }

    @PostMapping("/v1/sccMcrcSimulList")
    public BaseResponse sccMcrcSimulList(HttpServletRequest request,
            @RequestBody HashMap body) {

        return sccService.sccMcrcSimulList(body, request.getRemoteAddr());
    }

    @PostMapping("/v1/sccKamdSimulList")
    public BaseResponse sccKamdSimulList(HttpServletRequest request,
            @RequestBody HashMap body) {

        return sccService.sccKamdSimulList(body, request.getRemoteAddr());
    }

    @PostMapping("/v1/sccMcrcSimulAdd")
    public BaseResponse sccMcrcSimulAdd(HttpServletRequest request,
            @RequestBody McrcSimulReq body) {
        String sNo = body.getSimulNo();
        McrcSimulTrackReq track = body.getTrack();
        String cd = ((track == null) ? null : track.getMcrcCode());
        List<McrcSimulRouteReq> route = body.getRoutes();

        if ((route != null) && (!route.isEmpty())) {
            for (McrcSimulRouteReq r : route) {

                if (r.getMcrcRoute() == null) {
                    log.debug("route is null");
                    return new BaseResponse(ResRepo.getC403());
                }

                if (r.getCreateSys() == null) {
                    log.debug("createtime is null");
                    return new BaseResponse(ResRepo.getC403());
                }
            }

        } else {
            log.debug("route is null");
            return new BaseResponse(ResRepo.getC403());
        }

        if ((sNo != null) && (cd != null)) {
            log.trace("sNo and cd is null");
            return sccService.sccMcrcSimulAdd(body, request.getRemoteAddr());
        }

        return new BaseResponse(ResRepo.getC403());
    }

    @PostMapping("/v1/sccKamdSimulAdd")
    public BaseResponse sccKamdSimulAdd(HttpServletRequest request,
            @RequestBody KamdSimulReq body) {

        if (body.getData() == null) {
            log.trace("simul add param null");
            return new BaseResponse(ResRepo.getC403());
        }

        return sccService.sccKamdSimulAdd(body, request.getRemoteAddr());
    }

    @PostMapping("/v1/sccMcrcSimulDelete")
    public BaseResponse sccMcrcSimulDel(HttpServletRequest request,
            @RequestBody McrcSimulReq body) {
        String sNo = body.getSimulNo();

        if ((sNo != null)) {
            log.trace("mcrc simul delete param null");

            return sccService.sccMcrcSimulDel(body, request.getRemoteAddr());
        }

        return new BaseResponse(ResRepo.getC403());
    }

    @PostMapping("/v1/sccKamdSimulDelete")
    public BaseResponse sccKamdSimulDel(HttpServletRequest request,
            @RequestBody KamdSimulReq body) {
        String sNo = body.getSimulNo();

        if ((sNo != null)) {
            log.trace("kamd simul delete param null");

            return sccService.sccKamdSimulDel(body, request.getRemoteAddr());
        }

        return new BaseResponse(ResRepo.getC403());
    }

    @PostMapping("/v1/sessionValid")
    public BaseResponse sesValid(HttpServletRequest request,
            @RequestBody UserReq req) {
        return authCheck(request);

    }

    @PostMapping("/v1/sccDeviceStatusList")
    public BaseResponse sccDevStatus(HttpServletRequest request,
            @RequestBody HashMap body) {

        return sccService.sccDevStatus(request.getRemoteAddr());
    }

    private BaseResponse authCheck(HttpServletRequest request) {

        String auth = request.getHeader("Authorization");
        BaseResponse res = null;
        boolean isPass = true;

        if ((auth == null) || (!auth.startsWith("Bearer "))) {
            isPass = false;
            res = new BaseResponse(ResRepo.getC403());
        }

        if (isPass) {
            auth = auth.substring("Bearer ".length());
            res = loginSessionService.getSession(auth, request.getRemoteAddr());
        }

        return res;

    }

}
