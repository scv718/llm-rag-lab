/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SBit {

    @JsonProperty("no_card") private int noCard;

    @JsonIgnore private int isConnect;

    @JsonIgnore
    public String getAlarmInfo() { // 세부상태는 기입하지 않음
        String val = null;
        
        if (noCard == 1) {

            val = "카드 미실장";
        } else {

            if (isConnect > 0) {
                val = "암호장비 연결안됨";
            }
        }

        return val;
    }
}
