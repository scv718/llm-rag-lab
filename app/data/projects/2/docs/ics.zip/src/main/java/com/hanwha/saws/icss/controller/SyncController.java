/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.request.ActiveStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.sync.ActiveStatusBean;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.NodeUtil;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@RestController
@Slf4j
public class SyncController {

    private static final int M_LO = 0;
    private static final int M_REMO = 1;

    @Value("${prop.host-name}") String hostName;

    @Autowired PropConfig prop;
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired SyncHistInsertService syncHistInsertService;

    @PostMapping("/v1/icsSyncStatus")
    public BaseResponse getHa(HttpServletRequest request,
            @RequestBody HashMap body) {
        ActiveStatusBean res = new ActiveStatusBean();

        res.setId(hostName);
        res.setActive(prop.getActiveMode());

        return new BaseResponse(ResRepo.getC200(), res);
    }

    @PostMapping("/v1/icsSyncChangeMode")
    public BaseResponse setMode(HttpServletRequest request,
            @RequestBody ActiveStatusReq body) {
        prop.setActiveMode(body.getActive());
        return new BaseResponse(ResRepo.getC200());
    }

    @PostMapping("/v1/heartbeat")
    public BaseResponse getHeartBeat(HttpServletRequest request,
            @RequestBody HashMap body) {
        return new BaseResponse(ResRepo.getC200());
    }

    @PostMapping("/v1/modeActive")
    public BaseResponse setModeActive(HttpServletRequest request,
            @RequestBody ActiveStatusReq body) {
        StatusRepo code = null;

        StatusModel param = new StatusModel();

        AlarmHistModel m = new AlarmHistModel();

        try {
            code = StatusRepo.getSTANDBY();
            NodeUtil.setIcsStatusMode(hostName, param, code, M_LO);

            code = StatusRepo.getACTIVE();
            NodeUtil.setIcsStatusMode(hostName, param, code, M_REMO);

            statusConfigDao.updateStatus(param);

            prop.setActiveMode(body.getActive());

            syncHistInsertService.insertFailoverAlarmHist(m, "ACTIVE");

        } catch (RuntimeException e) {
            log.warn("[/v1/modeActive] " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

        return new BaseResponse(ResRepo.getC200());
    }

}
