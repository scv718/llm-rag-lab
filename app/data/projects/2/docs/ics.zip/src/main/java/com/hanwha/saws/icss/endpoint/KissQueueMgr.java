/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.service.KissService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KissQueueMgr {

    private static final int N30 = 30;
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");

    private final KissService kissService;
    @Autowired
    @Qualifier("kissRecvBulkQueue")
    private ConcurrentLinkedQueue<RecvMsgQueueBean> recvBulkQueue;

    @Autowired
    public KissQueueMgr(KissService kissService) {
        this.kissService = kissService;
    }

    @Scheduled(fixedDelayString = "30", initialDelayString = "3000")
    public void monitor() {
        final String lFormat = "[KAMD] Queue took : 1 , remain {}";
        RecvMsgQueueBean msg = null;
        
        while ((msg = recvBulkQueue.poll()) != null) {
            kissService.handleEvent(msg);
            qLog.debug(lFormat, recvBulkQueue.size());
        }

    }
}
