/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

public interface DecodeIf {

    public int getType();

    public byte[] encode();

}
