/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.SmsTcpMsgBean;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Component("SmsClientManager")
@Slf4j
public class SmsClientManager implements SmsClient {

    private static final int INIT_RUN = 1;
    private static final int INIT_WAIT = 0;
    private static final int N3000 = 3000;
    private static final int N12000 = 12000;
    private static final int N100 = 100;
    private static final int N1000 = 1000;
    private static final int N1024 = 1024;
    private static final int N2 = 2;

    @Autowired PropConfig prop;

    @Value("${sms.connect-port}") int tPort;

    private TcpClientManager smsA = null;
    private TcpClientManager smsB = null;

    @Autowired
    private ObjectFactory<TcpClientManager> clientHandler;
    
    @Autowired
    @Qualifier("smsEventQueue") 
    private ConcurrentLinkedQueue<SmsTcpEventBean> eventQueue;

    private boolean initialized = false;
    private int hTimeout = N3000;
    
    @Scheduled(fixedDelayString = "1000")
    public void initParam() {
        
        if (initialized) {
            return;
        }
        
        if (prop.getInitFlag() == INIT_RUN) {
            hTimeout = N3000;
            initialized = true;
            postWork();
        }
        
    }

    private void postWork() {
        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();

        String aIp = NodeUtil.getNodeIP(NodeRepo.getSmsA(), nHash);
        String bIp = NodeUtil.getNodeIP(NodeRepo.getSmsB(), nHash);

        smsA = clientHandler.getObject();
        smsA.setInfo(aIp, NodeRepo.getSmsA());
        smsB = clientHandler.getObject();
        smsB.setInfo(bIp, NodeRepo.getSmsB());
        
        log.info("SmsClientManager initialized: Receiver started.");
    }
    
    @Override
    public void addUnknownCount(NodeRepo code) {
        if ((code.getCode() == NodeRepo.getSmsA().getCode())) {
            smsA.addUnknownCount();
        }else {
            smsB.addUnknownCount();
        }
    }
    
    @Override
    public void setUnknownInit(NodeRepo code) {
        if ((code.getCode() == NodeRepo.getSmsA().getCode())) {
            smsA.setUnknownInit();
        }else {
            smsB.setUnknownInit();
        }
    }
    
    @Override
    public SmsTcpObjectBean sendRequestMsg(SmsTcpMsgBean bean, NodeRepo code)
            throws IOException, CompletionException {
        SmsTcpObjectBean rt = null;
        boolean isCon = false;
        short mTS = bean.getReqBean().getMsgType();
        short mOS = bean.getReqBean().getOpCode();
        String mTypeL = String.format("%04X", mTS & 0xFFFF);
        String mOpL = String.format("%04X", mOS & 0xFFFF);

        if ((code.getCode() == NodeRepo.getSmsA().getCode())) {

            isCon = ((smsA != null) && (smsA.isConnect()));

            if (isCon) {
                log.debug("send SMS A type : {} cmd : {}", mTypeL, mOpL);
                rt = smsA.sendAndWait(bean, hTimeout);
            }

        } else {

            isCon = ((smsB != null) && (smsB.isConnect()));

            if (isCon) {
                log.debug("send SMS B type : {} cmd : {}", mTypeL, mOpL);
                rt = smsB.sendAndWait(bean, hTimeout);
            }

        }

        return rt;
    }

    @Override
    public SmsTcpObjectBean sendRequestMsg(SmsTcpMsgBean bean, NodeRepo code,
            int timeout) throws IOException, CompletionException {

        SmsTcpObjectBean rt = null;
        boolean isCon = false;
        short mTS = bean.getReqBean().getMsgType();
        short mOS = bean.getReqBean().getOpCode();
        String mTypeL = String.format("%04X", mTS & 0xFFFF);
        String mOpL = String.format("%04X", mOS & 0xFFFF);

        if (code.getCode() == NodeRepo.getSmsA().getCode()) {

            isCon = (smsA != null) && (smsA.isConnect());

            if (isCon) {
                log.debug("send SMS A type : {} cmd : {}", mTypeL, mOpL);
                rt = smsA.sendAndWait(bean, (timeout * N1000));
            }

        } else {

            isCon = (smsB != null) && (smsB.isConnect());

            if (isCon) {
                log.debug("send SMS B type : {} cmd : {}", mTypeL, mOpL);
                rt = smsB.sendAndWait(bean, (timeout * N1000));
            }

        }

        return rt;
    }

    @Override
    public String smsIsAllConnect() {

        String rt = null;
        String tmp = "";
        String reVal = "";

        if ((smsA == null) || (!smsA.isConnect())) {

            if (smsA != null) {
                tmp = smsA.getNode().getName();
            }

            tmp += " is not connect";

            rt = (smsA.getNode() == null) ? NodeRepo.getSmsB().getName() : tmp;
        }

        if ((smsB == null) || (!smsB.isConnect())) {

            if (smsB != null) {
                tmp = smsB.getNode().getName();
            }

            tmp += " is not connect";

            if (smsB.getNode() == null) {
                reVal = NodeRepo.getSmsB().getName();
            } else {
                reVal = tmp;
            }

            return reVal;
        }

        return rt;

    }

}