/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.HashMap;
import java.util.List;

import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.UserModel;

public interface UserGroupDao {

    public List<UserModel> selectUserList();

    public List<GroupModel> selectGroupList();

    public GroupModel selectGroupInfo(GroupModel param);

    public UserModel selectUserInfo(UserModel param);

    public void updateUserInfo(UserModel param);

    public void deleteUserInfo(UserModel param);

    public List<UserModel> selectUserGroupList(HashMap<String, String> param);

    public void insertUserInfo(UserModel param);

    public List<GroupModel> selectGroupSearchList(
            HashMap<String, String> param);

    public void insertGroupInfo(GroupModel param);

    public void updateGroupInfo(GroupModel param);

    public List<GroupModel> selectGroupUserList(GroupModel param);

    public void deleteGroupInfo(GroupModel param);

}
