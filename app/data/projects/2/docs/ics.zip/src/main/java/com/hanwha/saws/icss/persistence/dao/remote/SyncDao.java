/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.remote;
import java.util.List;

import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.persistence.model.UserModel;

public interface SyncDao {

    public List<StatusModel> selectStatusList();

    public int updateStatus(StatusModel param);

    public int deleteStatusAll();

    public void syncStatusInfo(List<StatusModel> param);

    public int deleteNodeAll();

    public void syncNodeInfo(List<NodeModel> param);

    public int deleteUserAll();
    
    public int truncateUserAll();

    public void syncUserInfo(List<UserModel> param);

    public int deleteGroupAll();
    
    public int truncateGroupAll();

    public void syncGroupInfo(List<GroupModel> param);

    public int deleteThresholdAll();

    public void syncThresholdInfo(List<ThresholdModel> param);

    public int deleteCurrAlarmAll();
    
    public int truncateCurrAlarmAll();
    
    public void syncCurrAlarmInfo(List<CurrAlarmModel> param);

    public int deleteDefaultCodeAll();

    public void syncDefaultCode(List<DefaultCodeModel> param);

    public void insertMcrcHistBulkInsert(List<McrcHistModel> list);

    public void insertMcrcHistDetailBulkInsert(List<McrcHistDetailModel> list);
    
    public void insertKamdHistBulkInsert(List<KamdHistModel> list);
    
    public void insertKamdHistDetailBulkInsert(List<KamdHistDetailModel> list);
    
    public void insertAlarmHistInsert(AlarmHistModel param);

    public void insertMessageHist(MessageHistModel param);

    public void insertAirHist(AirRaidHistModel param);

    public void insertEmerHist(EmerHistModel param);

    public int deleteSawInfoAll();

    public void syncSawInfo(List<SawInfoModel> list);

    public void insertAirDefWarnHist(AirDefWarnHistModel param);

    public void insertStatusHist(StatusHistModel param);

    public void updateThresholdInfo(ThresholdModel param);

    public void updateSawInfo(SawInfoModel param);

    public void insertGroupInfo(GroupModel param);

    public void updateGroupInfo(GroupModel param);

    public void deleteGroupInfo(GroupModel param);

    public void updateUserInfo(UserModel param);

    public void deleteUserInfo(UserModel param);

    public void insertUserInfo(UserModel param);

    public void updateDefaultCode(DefaultCodeModel param);

    public void updateCurrentAlarmTally(CurrAlarmModel param);

    public void updateAlarmHistTally(CurrAlarmModel param);
        
    public void insertCurrentAlarm(CurrAlarmModel param);

    public void deleteCurrentAlarm(CurrAlarmModel param);

}
