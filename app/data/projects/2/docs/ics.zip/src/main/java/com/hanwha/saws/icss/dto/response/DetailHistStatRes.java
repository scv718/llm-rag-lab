/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data 
public class DetailHistStatRes {

    @JsonProperty("track_number")
    @JsonInclude(Include.NON_NULL) 
    private String trackNumber;
  
    @JsonProperty("identity")
    @JsonInclude(Include.NON_NULL) 
    private String identity;
    
    private String count;
    
}
