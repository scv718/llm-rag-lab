/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

public class CustomResponseWrapper extends HttpServletResponseWrapper {

    ByteArrayOutputStream byteArrayOutputStream;

    public CustomResponseWrapper(HttpServletResponse response)
            throws IOException {
        super(response);
        byteArrayOutputStream = new ByteArrayOutputStream();
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        ServletOutputStream outputStream = getResponse().getOutputStream();
        SoS sos = new SoS(outputStream, byteArrayOutputStream);

        return sos;
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        return super.getWriter();
    }

    public String getDataStreamToString() {
        byte[] ba = byteArrayOutputStream.toByteArray();

        return new String(ba, StandardCharsets.UTF_8);
    }

    
    public class SoS extends ServletOutputStream {

        
        private OutputStream os = null;
        private ByteArrayOutputStream bos = null;

        public SoS(OutputStream outStream, ByteArrayOutputStream bOutStream) {
            this.os = outStream;
            this.bos = bOutStream;
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setWriteListener(WriteListener listener) {}

        @Override
        public void write(int b) throws IOException {
            os.write(b);
            bos.write(b);
        }


    }
}
