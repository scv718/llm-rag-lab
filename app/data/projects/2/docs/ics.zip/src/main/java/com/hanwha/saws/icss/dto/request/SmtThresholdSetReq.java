/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SmtThresholdSetReq {

    @JsonProperty("node_id") private Integer nodeId;

    private List<SmtThresholdReq> list;

}
