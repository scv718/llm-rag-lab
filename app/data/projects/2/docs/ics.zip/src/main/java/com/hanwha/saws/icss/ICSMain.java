/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.boot.autoconfigure.http.client.*;

@EnableScheduling
@SpringBootApplication(exclude = { HttpClientAutoConfiguration.class })
public class ICSMain {

    public static void main(String[] args) {
        SpringApplication.run(ICSMain.class, args);
    }

}
