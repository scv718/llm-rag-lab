/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JasyptConfig {

    @Bean(name = "jasyptStringEncryptor")
    public StringEncryptor stringEncryptor() {
        String ctxProp = System.getProperty("jas.value");
        final int keyStech = 1000;
        String genName = "org.jasypt.salt.RandomSaltGenerator";

        if (ctxProp != null && !ctxProp.equals("")) {
            PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
            SimpleStringPBEConfig config = new SimpleStringPBEConfig();

            config.setPassword(ctxProp);
            config.setAlgorithm("PBEWITHHMACSHA256ANDAES_256");
            config.setKeyObtentionIterations(keyStech); // 키 스트레칭
            config.setPoolSize("4");
            config.setProviderName("SunJCE");
            config.setSaltGeneratorClassName(genName);
            config.setIvGeneratorClassName("org.jasypt.iv.RandomIvGenerator");
            config.setStringOutputType("base64");
            encryptor.setConfig(config);
            return encryptor;
        }

        return null;
    }
}