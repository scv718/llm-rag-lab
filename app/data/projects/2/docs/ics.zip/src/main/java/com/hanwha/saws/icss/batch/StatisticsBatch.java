/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.StatService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class StatisticsBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    
    @Autowired PropConfig prop;
    @Autowired IcsSyncService syncService;
    @Autowired StatService statService;

    @Scheduled(cron = "${cron.stat}")
    public void statBatch() throws IOException {

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        statusLog.debug("STATISTICS BATCH BATCH START");

        try {
            eventHandle();
        } catch (NoClassDefFoundError e) {
            log.warn("statBatch() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("statBatch batch " + e.toString());
        }

        statusLog.debug("STATISTICS BATCH BATCH END");

    }

    private void eventHandle() {

        statService.makeIcsAlarmStat();
        statService.makeMissAlarmStat();
        statService.makeKissAlarmStat();
        statService.makeSmsAlarmStat();
        statService.makeSwitchAlarmStat();
        statService.makeRouterAlarmStat();
        statService.makeMissHistStat();
        statService.makeKissHistStat();

    }

}
