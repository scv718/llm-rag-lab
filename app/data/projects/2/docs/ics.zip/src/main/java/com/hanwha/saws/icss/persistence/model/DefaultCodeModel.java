/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class DefaultCodeModel {

    private int codeId;
    private String codeData;
    private Date updateTime;

}