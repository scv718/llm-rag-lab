/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public interface SmsCodeTableEnumIf {

    int value();
}
