/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KissListener {
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");
    
    @Autowired
    @Qualifier("kissRecvBulkQueue")
    private ConcurrentLinkedQueue<RecvMsgQueueBean> recvBulkQueue;

    @PostConstruct
    public void init() {
        log.info("KissListener initialized: Receiver & QueueMgr started.");
    }
    
    public void putQueue(RecvMsgQueueBean bean) {
        
        String logTmp = "[KAMD] Queue put : 1 , remain {}";
        
        log.debug("Kiss Queue Insert ip : " + bean.getSenderIp());
        recvBulkQueue.offer(bean);
        qLog.debug(logTmp, recvBulkQueue.size());
    }

    public int getQueueSize() {
        return recvBulkQueue.size();
    }
}
