/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.IcsEtcService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.service.SyncHistInsertService;

import lombok.extern.slf4j.Slf4j;

@Service("IcsEtcService")
@Slf4j
public class IcsEtcServiceImpl implements IcsEtcService {

    private static final int N1 = 1;
    private static final int N2 = 2;

    @Autowired
    SyncHistInsertService syncHistInsertService;

    @Autowired
    PropConfig prop;

    @Autowired
    RestClientService restClient;
    @Autowired
    StatusConfigDao statusConfigDao;

    @Autowired
    AlarmService alarmService;

    @Override
    public void icsNodeUpdate(NodeModel bean) {

        if (bean.getNodeId() == null) {
            log.debug("Node is null");
            return;
        }

        try {
            statusConfigDao.updateNodeInfo(bean);
        } catch (DataAccessException e) { // SqlException은 이렇게 변환되어서 나옴
            log.warn(e.toString(), e);
        }

    }

    @Override
    public void icsStatusReport(MedStatusReq req, String senderIp) {
        ArrayList<Integer> keys = null;
        NodeModel node = null;
        NodeModel nModel = null;

        StatusHistModel insertBean = new StatusHistModel();
        ThresholdModel param = new ThresholdModel();
        List<ThresholdModel> tList = null;

        String summary = null;
        boolean isIpSame = false;
        boolean isNameSame = false;

        AlarmRepo ac = null;
        AlarmRepo lv = null;

        int nTy = 0;
        int nDa = 0;

        boolean isCpuGreen = true;
        int cpuLevel = -1; // 0: CRI 1 MAJ 2 MIN 3 WARN
        boolean isMemGreen = true;
        int memLevel = -1; // 0: CRI 1 MAJ 2 MIN 3 WARN
        boolean isHddGreen = true;
        int hddLevel = -1; // 0: CRI 1 MAJ 2 MIN 3 WARN
        boolean isAppGreen = true;
        StringBuilder sb = new StringBuilder();

        boolean cChk = false;
        boolean mChk = false;
        boolean hChk = false;
        int cpuMData = -1;
        int memMData = -1;
        int hddMData = -1;

        keys = new ArrayList<>(prop.getNodeInfoHash().keySet());

        for (Integer key : keys) {

            nModel = prop.getNodeInfoHash().get(key);
            isIpSame = nModel.getAddrIp().equals(senderIp);
            isNameSame = nModel.getName().startsWith("ICS");

            if (isIpSame && isNameSame) {
                node = nModel;
            }
        }

        if (node == null) {
            log.debug("Node is null");
            return;
        }

        insertBean.setIpAddr(node.getAddrIp());
        insertBean.setNodeId(node.getNodeId());
        insertBean.setNodeName(node.getName());
        insertBean.setType1(req.getCpu() + "");
        insertBean.setType2(req.getMem() + "");
        insertBean.setType3(req.getHdd() + "");
        insertBean.setType4(req.getApp() + "");
        syncHistInsertService.insertStatusHist(insertBean);

        param.setNodeId(node.getNodeId());

        tList = statusConfigDao.selectThresholdInfo(param);

        sb.append(node.getName() + " ");

        if ((tList != null) && (!tList.isEmpty())) {

            tList.sort(Comparator.comparingInt(ThresholdModel::getLevel));

            for (ThresholdModel m : tList) {
                nTy = m.getType();
                nDa = m.getData();

                if ((!cChk) && (nTy == 0) && (req.getCpu() >= nDa)) {
                    isCpuGreen = false;
                    cpuLevel = m.getLevel();
                    cpuMData = m.getData();
                    cChk = true;

                } else if ((!mChk) && (nTy == N1) && (req.getMem() >= nDa)) {
                    isMemGreen = false;
                    memLevel = m.getLevel();
                    memMData = m.getData();
                    mChk = true;

                } else if ((!hChk) && (nTy == N2) && (req.getHdd() >= nDa)) {
                    isHddGreen = false;
                    hddLevel = m.getLevel();
                    hddMData = m.getData();
                    hChk = true;
                }

                if (cChk && mChk && hChk) {
                    break;
                }
            }

        }

        if (!"Y".equals(req.getApp())) {
            isAppGreen = false;
        }

        summary = "";

        if (cpuMData > -1) {
            summary = (node.getName() + " " + req.getCpu() + " > " + cpuMData);
        }

        ac = AlarmRepo.getAlmCpu();
        lv = getLevelAlarmCode(cpuLevel);
        alarmService.alarmLevelUpdate(isCpuGreen, ac, node, lv, summary);
        summary = "";

        if (memMData > -1) {
            summary = (node.getName() + " " + req.getMem() + " > " + memMData);
        }

        ac = AlarmRepo.getAlmMem();
        lv = getLevelAlarmCode(memLevel);
        alarmService.alarmLevelUpdate(isMemGreen, ac, node, lv, summary);
        summary = "";

        if (hddMData > -1) {
            summary = (node.getName() + " " + req.getHdd() + " > " + hddMData);
        }

        ac = AlarmRepo.getAlmHdd();
        lv = getLevelAlarmCode(hddLevel);
        alarmService.alarmLevelUpdate(isHddGreen, ac, node, lv, summary);

        summary = "";

        if (!isAppGreen) {
            summary = (node.getName() + " connection problem");
        }

        ac = AlarmRepo.getAlmSystem();
        lv = getLevelAlarmCode(N2);
        alarmService.alarmUpdate(isAppGreen, ac, node, lv, summary);

    }

    private AlarmRepo getLevelAlarmCode(int level) {
        AlarmRepo rtCd = null;

        if (level == 0) {
            rtCd = AlarmRepo.getSvrCri();
        } else if (level == 1) {
            rtCd = AlarmRepo.getSvrMaj();
        } else if (level == N2) {
            rtCd = AlarmRepo.getSvrMin();
        } else {
            rtCd = AlarmRepo.getSvrMin();
        }

        return rtCd;
    }

}
