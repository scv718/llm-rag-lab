/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.nio.ByteBuffer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.modem.CBit;
import com.hanwha.saws.icss.dto.modem.IBit;
import com.hanwha.saws.icss.dto.modem.IBitStatus;
import com.hanwha.saws.icss.dto.modem.PBit;
import com.hanwha.saws.icss.dto.modem.SBit;
import com.hanwha.saws.icss.dto.modem.TBit;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.Data;

@Data
public class SmtSmsDiagnosisRes {

    private static final int S_FREQ_MIN = 950_000_000;
    private static final int S_FREQ_STEP = 2500;
    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N6 = 6;
    private static final int N7 = 7;
    private static final int N1000 = 1000;
    private static final int BFF = 0xFF;

    @JsonProperty("c_bit") private CBit cBit;

    @JsonProperty("t_bit") private TBit tBit;

    @JsonProperty("i_bit") private IBit iBit;

    @JsonProperty("p_bit") private PBit pBit;

    @JsonProperty("s_bit") private SBit sBit;

    @JsonIgnore private IBitStatus iBitStatus;

    public void setConvStatusData(SmsTcpObjectBean bean) {
        
        byte[] b = bean.getData();
        ByteBuffer buffer = ByteBuffer.wrap(b);
        IBitStatus ibd = new IBitStatus();
        IBit i = new IBit();
        byte convByte = 0;
        String conv = null;
        int val = buffer.getInt();        
        double freqKHz = (S_FREQ_MIN + (val * S_FREQ_STEP)) / (double) N1000;
        
        ibd.setUpc(freqKHz);
        ibd.setUpcAtt((int) buffer.get());
        val = buffer.getInt();
        freqKHz = (S_FREQ_MIN + (val * S_FREQ_STEP)) / (double) N1000;
        ibd.setDnc(freqKHz);
        ibd.setDncAtt((int) buffer.get());
        ibd.setLoopback((int) buffer.get());

        convByte = buffer.get();
        conv = HexByteUtil.getBinStr(convByte);
        
        if ((convByte & BFF) == BFF) {
            i.setNoCard(N1);
        } else {
            
            i.setExtInt(getBit(conv, N7));
            i.setUpc(getBit(conv, N6));
            i.setDnc(getBit(conv, N5));
            i.setUpcPll(getBit(conv, N4));
            i.setDncPll(getBit(conv, N3));
            i.setFixPll(getBit(conv, N2));
            i.setNoCard(N0);
        }
        
        this.iBit = i;
        
        ibd.setIbit(i);
        ibd.setDncRssi((int) buffer.get());
        ibd.setUpcRssi((int) buffer.get());
        ibd.setDncUpperBitSetLevel((int) buffer.get());
        ibd.setDncLowerBitSetLevel((int) buffer.get());
        ibd.setUpcUpperBitSetLevel((int) buffer.get());
        ibd.setUpcLowerBitSetLevel((int) buffer.get());
        
        this.iBit.setDncRssi(ibd.getDncRssi());
        this.iBit.setUpcRssi(ibd.getUpcRssi());
        
        this.iBitStatus = ibd;
    }

//    public void setControlStatusData(SmsTcpObjectBean bean) {
//        CBit c = new CBit();
//        PBit p = new PBit();
//        String power = null;
//
//        String ctl = bean.getCtlBit();
//
//        c.setMem(getBit(ctl, N7));
//        c.setVocoder(getBit(ctl, N6));
//        c.setIfUnit(getBit(ctl, N5));
//        c.setCrypto(getBit(ctl, N4));
//        c.setEthernet1(getBit(ctl, N3));
//        c.setEthernet2(getBit(ctl, N2));
//        c.setFlash(getBit(ctl, N1));
//
//        this.cBit = c;
//
//        power = bean.getPowerBit();
//        p.setV5One(getBit(power, N7));
//        p.setV5Two(getBit(power, N6));
//        p.setVTwelve(getBit(power, N5));
//
//        this.pBit = p;
//    }

    public void setModemStatusData(SmsTcpObjectBean bean) {
        TBit t = new TBit();
        String modem = bean.getModemBit();
        
        if ((bean.getModemByte() & BFF) == BFF) {
            
            t.setNoCard(1);
        } else {
            t.setFpga(getBit(modem, N7));
            t.setDac(getBit(modem, N6));
            t.setClk(getBit(modem, N5));
            t.setPwr(getBit(modem, N4));       
            t.setModemSync(getBit(modem, N3));            
            t.setNoCard(N0);
        }
        
        this.tBit = t;

    }

    public void setResData(SmsTcpObjectBean bean) {

        CBit c = new CBit();
        TBit t = new TBit();
        IBit i = new IBit();
        PBit p = new PBit();
        SBit s = new SBit();
        String ctl = bean.getCtlBit();
        String modem = null;
        String conv = null;
        String power = null;

        c.setMem(getBit(ctl, N7));
        c.setVocoder(getBit(ctl, N6));
        c.setIfUnit(getBit(ctl, N5));
        c.setCrypto(getBit(ctl, N4));
        c.setEthernet1(getBit(ctl, N3));
        c.setEthernet2(getBit(ctl, N2));
        c.setFlash(getBit(ctl, N1));

        this.cBit = c;

        modem = bean.getModemBit();

        if ((bean.getModemByte() & BFF) == BFF) {
            t.setNoCard(N1);
        } else {
            t.setFpga(getBit(modem, N7));
            t.setDac(getBit(modem, N6));
            t.setClk(getBit(modem, N5));
            t.setPwr(getBit(modem, N4));            
            t.setModemSync(getBit(modem, N3));            
            t.setNoCard(N0);            
        }
        
        this.tBit = t;

        conv = bean.getConvBit();

        if ((bean.getConvByte() & BFF) == BFF) {

            i.setNoCard(N1);
        } else {

            i.setExtInt(getBit(conv, N7));
            i.setUpc(getBit(conv, N6));
            i.setDnc(getBit(conv, N5));
            i.setUpcPll(getBit(conv, N4));
            i.setDncPll(getBit(conv, N3));
            i.setFixPll(getBit(conv, N2));            
            i.setNoCard(N0);
        }

        this.iBit = i;

        power = bean.getPowerBit();
        p.setV5One(getBit(power, N7));
        p.setV5Two(getBit(power, N6));
        p.setVTwelve(getBit(power, N5));

        this.pBit = p;

        s.setNoCard(((bean.getSModuleByte() & BFF) == BFF) ? N1 : N0);

        this.sBit = s;

    }

    private int getBit(String binary, int index) {
        return ((binary.charAt(index) == '0') ? N0 : N1);
    }

}
