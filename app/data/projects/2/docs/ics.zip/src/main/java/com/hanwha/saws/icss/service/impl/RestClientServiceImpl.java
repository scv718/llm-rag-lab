/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.ActiveStatusReq;
import com.hanwha.saws.icss.dto.request.MedReq;
import com.hanwha.saws.icss.dto.response.ActiveStatusRes;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.MedDiagnosisRes;
import com.hanwha.saws.icss.dto.sync.ActiveStatusBean;
import com.hanwha.saws.icss.service.RestClientService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Service("RestClientService")
@Slf4j
public class RestClientServiceImpl implements RestClientService {

    @Value("${ics.restPort}") int icsPort;
    @Value("${ics.url.status}") String icsIcsStatusUrl;
    @Value("${ics.url.changeMode}") String changeModeUrl;
    @Value("${ics.url.heartbeat}") String haUrl;
    @Value("${ics.url.activeMode}") String modeActive;

    @Value("${ics.url.med}") String medUrl;
    @Value("${ics.url.syncReset}") String syncReset;
    @Value("${ics.url.syncSession}") String syncSession;

    @Value("${med.send-port}") int medUrlPort;

    @Autowired private RestClient rClient;

    private String makeUrl(String url, String ip, int port) {
        StringBuilder sb = new StringBuilder();

        sb.append("http://").append(ip).append(":").append(port).append(url);
        return sb.toString();
    }

    @Override
    public BaseResponse getHeartBeat(String ip) {

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        ActiveStatusReq body = new ActiveStatusReq("", 0);
        ResponseEntity<BaseResponse> res = null;
        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;

        String hUrl = makeUrl(haUrl, ip, icsPort);

        try {
            postSpec = rClient.post();
            uriSpec = postSpec.uri(hUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(body).retrieve();
            res = responseSpec.toEntity(BaseResponse.class);

            if (res != null) {
                log.trace("heart Beat res : {}", res.getStatusCode());

                return res.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, haUrl);
        } catch (RuntimeException e) {
            log.debug("getHeartBeat() heartbeat failed " + e.toString());
        }

        return null;
    }

    @Override
    public Integer getIcsStatus(String ip) {

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        String sUrl = makeUrl(icsIcsStatusUrl, ip, icsPort);
        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<ActiveStatusRes> response = null;
        ActiveStatusBean data = null;

        try {
            postSpec = rClient.post();
            uriSpec = postSpec.uri(sUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(body).retrieve();
            response = responseSpec.toEntity(ActiveStatusRes.class);

            if (response != null) {
                data = (ActiveStatusBean) response.getBody().getData();
                return data.getActive();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, icsIcsStatusUrl);
        } catch (RuntimeException e) {
            log.debug("getIcsStatus() ics status failed " + e.toString());
        }

        return -1;
    }

    @Override
    public Integer setMode(ActiveStatusReq param, String ip) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<ActiveStatusReq> response = null;

        String modeUrl = makeUrl(changeModeUrl, ip, icsPort);

        try {

            postSpec = rClient.post();
            uriSpec = postSpec.uri(modeUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(param).retrieve();
            response = responseSpec.toEntity(ActiveStatusReq.class);

            if (response != null) {
                log.trace("setMode RES : {}", response);

                return response.getBody().getActive();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, changeModeUrl);
        } catch (RuntimeException e) {
            log.debug("setMode() failed " + e.toString());
        }

        return -1;
    }

    @Override
    public BaseResponse setActiveMode(String ip) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();

        String aUrl = makeUrl(modeActive, ip, icsPort);
        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<BaseResponse> response = null;

        try {

            postSpec = rClient.post();
            uriSpec = postSpec.uri(aUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(body).retrieve();
            response = responseSpec.toEntity(BaseResponse.class);

            if (response != null) {
                log.trace("setActiveMode RES : {}", response);

                return response.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, modeActive);
        } catch (RuntimeException e) {
            log.warn("setActiveMode() failed " + e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse getMedCommonReq(String ip, MedReq bean) {

        String mUrl = makeUrl(medUrl, ip, medUrlPort);
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<BaseResponse> response = null;

        try {
            postSpec = rClient.post();
            uriSpec = postSpec.uri(mUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(bean).retrieve();
            response = responseSpec.toEntity(BaseResponse.class);

            if (response != null) {
                log.trace("getMedCommonReq RES : {}", response);

                return response.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, medUrlPort, medUrl);
        } catch (RuntimeException e) {
            log.warn("getMedCommonReq() failed " + e.getMessage());
        }

        return null;
    }

    @Override
    public MedDiagnosisRes getMedDiagnosisReq(String ip, MedReq bean) {

        String dUrl = makeUrl(medUrl, ip, medUrlPort);
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        MedDiagnosisRes response = null;

        try {

            postSpec = rClient.post();
            uriSpec = postSpec.uri(dUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(bean).retrieve();
            response = responseSpec.body(MedDiagnosisRes.class);

            if (response != null) {
                log.trace("getMedDiagnosisReq RES : {}", response);

                return response;
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, medUrlPort, medUrl);
        } catch (RuntimeException e) {
            log.warn("getMedDiagnosisReq() failed " + e.toString());
        }

        return null;
    }

    @Override
    public BaseResponse setIcsResetReq(String ip, LoginSessionBean bean) {

        String rUrl = makeUrl(syncReset, ip, icsPort);
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<BaseResponse> response = null;

        try {

            postSpec = rClient.post();
            uriSpec = postSpec.uri(rUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(bean).retrieve();
            response = responseSpec.toEntity(BaseResponse.class);

            if (response != null) {
                log.trace("setIcsResetReq RES : {}", response);

                return response.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, syncReset);
        } catch (RuntimeException e) {
            log.warn("setIcsResetReq() failed " + e.toString());
        }

        return null;
    }

    @Override
    public BaseResponse icsSyncSession(String ip,
            ConcurrentHashMap<String, LoginSessionBean> bean) {

        String sUrl = makeUrl(syncSession, ip, icsPort);
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<BaseResponse> response = null;

        try {
            postSpec = rClient.post();
            uriSpec = postSpec.uri(sUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(bean).retrieve();
            response = responseSpec.toEntity(BaseResponse.class);

            if (response != null) {
                log.trace("icsSyncSession RES : {} ", response);

                return response.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, syncSession);
        } catch (RuntimeException e) {
            log.warn("setIcsResetReq fail " + e.toString(), e);
        }

        return null;
    }

    @Override
    public BaseResponse getIcsDiagnosisReq(String ip, MedReq bean) {
        String rUrl = makeUrl("/v1/req_diagnosis", ip, icsPort);
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        RestClient.RequestBodyUriSpec postSpec = null;
        RestClient.RequestBodySpec uriSpec = null;
        RestClient.RequestBodySpec contentTypeSpec = null;
        RestClient.RequestBodySpec headersSpec = null;
        RestClient.ResponseSpec responseSpec = null;
        ResponseEntity<BaseResponse> response = null;

        try {
            postSpec = rClient.post();
            uriSpec = postSpec.uri(rUrl);
            contentTypeSpec = uriSpec.contentType(MediaType.APPLICATION_JSON);

            headersSpec = contentTypeSpec.headers(new HeadersAdder(headers));

            responseSpec = headersSpec.body(bean).retrieve();
            response = responseSpec.toEntity(BaseResponse.class);

            if (response != null) {
                log.trace("getIcsDiagnosisReq RES : {}", response);

                return response.getBody();
            }

        } catch (ResourceAccessException e) {
            log.debug("{}:{} {} not connected", ip, icsPort, "req_diagnosis");
        } catch (RuntimeException e) {
            log.warn("getIcsDiagnosisReq() failed " + e.getMessage());
        }

        return null;
    }

    
    //private inner class 는 허용
    private class HeadersAdder implements Consumer<HttpHeaders> {

        private MultiValueMap<String, String> hParam;

        public HeadersAdder(MultiValueMap<String, String> headers) {
            this.hParam = new LinkedMultiValueMap<>(headers); // 방어적 복사
        }

        @Override
        public void accept(HttpHeaders httpHeaders) {
            if (hParam != null && !hParam.isEmpty()) {
                httpHeaders.addAll(hParam);
            }
        }
    }
}
