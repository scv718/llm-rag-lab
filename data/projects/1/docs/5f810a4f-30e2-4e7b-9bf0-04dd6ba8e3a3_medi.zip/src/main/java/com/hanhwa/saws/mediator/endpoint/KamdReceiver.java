/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.io.DataInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KamdReceiver implements Runnable {

    private final AtomicLong lastReceivedTime = new AtomicLong(0);
    private boolean timeoutCheckStarted = false;
    private volatile boolean keepListening;

    @Autowired @Qualifier("KamdListenerExecutor")
    private TaskExecutor kamdListenerExecutor;

    @Autowired private KamdTimeoutCheck kamdToutChk;

    @Autowired @Qualifier("kamdRecvQueue")
    private ConcurrentLinkedQueue<String> kamdRecvQueue;

    @Autowired private ObjectFactory<KamdClientHandler> clientHandlerFactory;

    @Value("${server.tcp-port}") private int tcpPort;

    public void run() {

        String errMsg = "Error during client connection or handling: {}";
        
        try (ServerSocket serverSocket = new ServerSocket(tcpPort)) {
            Socket cSocket = null;
            SocketAddress sockAddr = null;
            KamdClientHandler handler = null;

            log.info("TCP Server started on port: {}", tcpPort);
            keepListening = true;

            while (keepListening) {

                try {
                    cSocket = serverSocket.accept();
                    sockAddr = cSocket.getRemoteSocketAddress();
                    log.info("Client connected: {}", sockAddr);
                    handler = clientHandlerFactory.getObject()
                            .init(cSocket, lastReceivedTime, kamdRecvQueue);
                    kamdListenerExecutor.execute(handler);

                    kamdToutChk.setLastReceivedTime(System.currentTimeMillis());

                    if (!timeoutCheckStarted) {
                        kamdListenerExecutor.execute(kamdToutChk);
                        timeoutCheckStarted = true;
                    }

                } catch (Exception e) {
                    log.warn(errMsg, e.getMessage(), e);
                }
            }
        } catch (Exception e1) {
            log.warn("Error running TcpListener: {}", e1.getMessage(), e1);
        }
    }

}
