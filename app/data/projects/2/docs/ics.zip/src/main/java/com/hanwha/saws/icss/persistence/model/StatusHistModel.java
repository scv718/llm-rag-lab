/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;

@Data
public class StatusHistModel implements Serializable {
    private static final int N10 = 10;

    private long seqNo;
    private int nodeId;
    private String nodeName;
    private String ipAddr;
    private String type1;
    private String type2;
    private String type3;
    private String type4;
    private String type5;
    private Timestamp insertTime;

    private long idx;
    private String startTime;
    private String endTime;
    private int rowCount;
    private int startIdx;

    public void setPage(Integer page, Integer listCount) {
      
        if (page == null || page == 0) {
            page = 1;
        }

        if (listCount == null || listCount == 0) {
            listCount = N10;
        }

        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }

    public void setDateToday() {
        SimpleDateFormat sSdf = new SimpleDateFormat("yyyyMMdd000000");
        SimpleDateFormat eSdf = new SimpleDateFormat("yyyyMMdd235959");

        startTime = sSdf.format(new Date());
        endTime = eSdf.format(new Date());
    }
}
