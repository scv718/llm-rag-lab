/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class LogKeyUtil {
    private static final int N8 = 8;
    private static final int N10 = 10;

    private static SecureRandom rnd = new SecureRandom();

    private LogKeyUtil() {}
    
    public static String getRandomKey() {
        return UUID.randomUUID().toString();
    }

    public static String getTraceKey(String hostName) {
        SimpleDateFormat sdf = new SimpleDateFormat(
                "yyyyMMddHHmmssSSS", Locale.KOREA
        );
        
        return sdf.format(new Date()) + hostName + "DSS" +
                getRandInt() + "001";
    }

    private static String getRandInt() {
       
        StringBuilder buf = new StringBuilder();

        for (int i = 0; i < N8; i++) {
            buf.append(rnd.nextInt(N10));

        }

        return buf.toString().toUpperCase();
    }

    public static String getTransactionKey(String hostName) {
        SimpleDateFormat sdf = new SimpleDateFormat(
                "yyyyMMddHHmmssSSS", Locale.KOREA
        );
        
        return sdf.format(new Date()) + hostName + "DSS" +
                getRandInt();
    }

}
