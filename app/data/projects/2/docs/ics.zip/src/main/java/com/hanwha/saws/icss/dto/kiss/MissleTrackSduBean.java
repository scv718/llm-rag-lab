/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.kiss;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.hanwha.saws.icss.dto.CommonHeaderSduBean;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdSimulModel;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class MissleTrackSduBean {

    private static final int VO_SIZE = 53;
    private static final int SIMULATION_CODE = 1;
    private static final long L1000 = 1000L;

    private static final byte MSG_TYPE = 0x00;
    private int voCount = 0;

    private CommonHeaderSduBean header = null;
    private List<MissleTrackVOBean> vos = null;
    private byte[] originFilterByte = null;
    private Timestamp recvTime;
    
    public MissleTrackSduBean(byte[] pdu) throws IOException, RuntimeException {

        try {            
            decode(ByteBuffer.wrap(pdu));
        } catch (IOException | RuntimeException e) {
            log.warn("Missle data decoded InValid. skip");
            throw e;
        }
    }

    public MissleTrackSduBean() {}

    private void decode(ByteBuffer buffer) throws IOException {

        try {
            int length = 0;
            MissleTrackVOBean vo = null;

            header = new CommonHeaderSduBean(buffer.get(), buffer.get());

            length = header.getPayloadLengthInt();
            
            voCount = length / VO_SIZE;
            vos = new ArrayList<>();

            for (int i = 0; i < voCount; i++) {

                vo = new MissleTrackVOBean();

                vo.decode(buffer);
                vos.add(vo);
            }
            
            originFilterByte = encode();

        } catch (IOException e) {
            log.warn("Missle data decoded Exception");
            throw e;
        }
    }

    private byte[] encode() throws IOException {

        byte hLen = ((vos == null) ? 0x00 : ((byte) (voCount * VO_SIZE)));
        int packetLen = 0;
        ByteBuffer eBuf = null;
        byte[] a = null;

        header = new CommonHeaderSduBean(MSG_TYPE, hLen);

        packetLen = header.getHeader().length + VO_SIZE;

        eBuf = ByteBuffer.allocate(packetLen);

        eBuf.put(header.getType());
        eBuf.put(header.getPayloadLength());

        if (vos != null) {
            for (int i = 0; i < voCount; i++) {
                eBuf.put(vos.get(i).encode());
            }
        }
        
        a = eBuf.array();        
        return a;
    }

    public ArrayList<byte[]> getSimulEncode(ArrayList<KamdSimulModel> list) {

        ArrayList<byte[]> encodeByteList = new ArrayList<>();
        ArrayList<byte[]> packetList = new ArrayList<>();

        byte[] b = null;
        int packetLen = 0;
        ByteBuffer sBuf = null;

        for (KamdSimulModel m : list) {

            try {
                b = new MissleTrackVOBean().getSimulEncode(m);                
                encodeByteList.add(b);

            } catch (IOException | RuntimeException ee) {
                log.warn(ee.toString(), ee);
            }

        }

        for (byte[] bs : encodeByteList) {

            header = new CommonHeaderSduBean(MSG_TYPE, (byte) bs.length);

            packetLen = header.getHeader().length + VO_SIZE;            
            sBuf = ByteBuffer.allocate(packetLen);
            
            sBuf.put(header.getType());
            sBuf.put(header.getPayloadLength());
            sBuf.put(bs);

            packetList.add(sBuf.array());

        }

        return packetList;

    }
    
//    public String getDecodeDataResult() {
//        
//        StringBuilder sb = new StringBuilder();
//        long time = 0L;
//        
//        //byteString 바꾸고 싶으면 HexByteUtil.getHexStringToByte
//        sb.append("Header");
//        sb.append("\n       type : " + (int) header.getTypeInt());
//        sb.append("\n       length : " + header.getPayloadLengthInt());
//        sb.append("\n       SIZE : " + vos.size());
//        
//        for (int i = 0; i < vos.size(); i++) {
//            MissleTrackVOBean bean = vos.get(i);
//            sb.append("\n       Value Object " + i);
//            sb.append(
//                    "\n           Track Number : " +
//                            new String(bean.getTrackNumberString())
//            );
//            time = ((long) bean.getImpactTime()) * L1000;
//            sb.append("\n           Impact Time : " + new Date(time));
//            sb.append(
//                    "\n           ImpactLocation Latitude : " +
//                            bean.getImpactLocLatitudeStr()
//            );
//            sb.append(
//                    "\n           ImpactLocation Longitude : " +
//                            bean.getImpactLocLongitudeStr()
//            );
//            sb.append(
//                    "\n           ImpactLocation Altitude(feet) : " +
//                            bean.getImpactAltitude()
//            );
//            time = ((long) bean.getLaunchTime()) * L1000;
//            sb.append("\n           Launch Time : " + new Date(time));
//            sb.append(
//                    "\n           LaunchLocation Latitude : " +
//                            bean.getLaunchLocLatitudeStr()
//            );
//            sb.append(
//                    "\n           LaunchLocation Longitude : " +
//                            bean.getLaunchLocLongitudeStr()
//            );
//            sb.append(
//                    "\n           LaunchLocation Altitude(feet) : " +
//                            bean.getLaunchAltitude()
//            );
//            sb.append(
//                    "\n           MissileLocation Latitude : " +
//                            bean.getMissileLocLatitudeStr()
//            );
//            sb.append(
//                    "\n           MissileLocation Longitude : " +
//                            bean.getMissileLocLongitudeStr()
//            );
//            sb.append(
//                    "\n           MissileLocation Altitude(feet) : " +
//                            bean.getMissileAltitude()
//            );
//            sb.append(
//                    "\n           Velocity Course(0~360) : " +
//                            bean.getVelocityCourseStr()
//            );
//            sb.append(
//                    "\n           Velocity Speed(knot) : " +
//                            bean.getVelocitySpeedStr()
//            );
//            sb.append("\n           Amplication : " + bean.getAmplication());
//            sb.append("\n           Simulation : " + bean.getSimulation());
//            sb.append("\n           CUDM : " + bean.getCudmInt());
//        }
//        
//        sb.append("\n       length : " + header.getPayloadLengthInt());
//        
//        return sb.toString();
//        
//    }
        
}
