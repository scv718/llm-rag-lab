/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class OpHistRltRepo {

    private static final String F = "FAIL";
    private static final String FM = "RESULT_FAILED";
    private static final String S = "SUCCESS";
    private static final String SM = "RESULT_SUCCESS";

    private static final OpHistRltRepo R_FAILED = new OpHistRltRepo(F, FM);
    private static final OpHistRltRepo R_SUCCESS = new OpHistRltRepo(S, SM);

    private final String code;
    private final String name;

    private OpHistRltRepo(String cd, String nm) {
        this.code = cd;
        this.name = nm;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static OpHistRltRepo getResultFailed() {
        return R_FAILED;
    }

    public static OpHistRltRepo getResultSuccess() {
        return R_SUCCESS;
    }

}
