/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hanhwa.saws.mediator.miss.service.EncodeIF;
import com.hanhwa.saws.mediator.util.ByteUtil;
import com.hanhwa.saws.mediator.util.MulticastSenderUtil;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class McrcUdpSend implements Runnable {
    private static final byte MESSAGE_TYPE = 0x05;
    private static final byte SITE_MESSAGE_TYPE = 0x08;
    private static final int N2 = 2;
    private static final int N5 = 5;
    private static final int N10 = 10;
    private static final int B_FF = 0xFF;

    @Autowired @Qualifier("mcrcSendQueue")
    private ConcurrentLinkedQueue<EncodeIF> mcrcSendQueue;

    @Value("${sendserver.icss-host}") private String icssHost;

    @Value("${sendserver.mcrc-udp-port}") private int mcrcUdpPort;

    @Value("${sendserver.local-ip}") private String localIp;

    @Value("${mediator.mode}") private String mode;

    private volatile MulticastSenderUtil senderService;

    @PostConstruct
    public void setupSender() {

        if (!"mcrc".equalsIgnoreCase(mode)) {
            return;
        }

        try {
            this.senderService = new MulticastSenderUtil(icssHost, mcrcUdpPort,
                    localIp);
            log.debug("MCRC sender initialized: host={}, port={}, localIp={}",
                    icssHost, mcrcUdpPort, localIp);
        } catch (IOException e) {
            log.warn("Failed to initialize MulticastSenderService: {}",
                    e.getMessage(), e);
        }
    }

    @Override
    public void run() {

        ArrayList<byte[]> airTrackList = new ArrayList<>();
        EncodeIF encData = null;
        byte[] appendByte = null;
        String errUdpMsg = "MCRC UDP send thread interrupted: {}";

        while (true) {
            try {
                CompletableFuture<Void> delay = new CompletableFuture<>();

                encData = mcrcSendQueue.poll();

                if (encData == null) {
                    sendRemainAirTrackByte(airTrackList);
                    delay.completeOnTimeout(null, N10, TimeUnit.MILLISECONDS)
                            .join();
                    continue;
                }

                if (encData.getType() == SITE_MESSAGE_TYPE) {
                    sendRemainAirTrackByte(airTrackList);
                    log.debug("SITE LOCATION ENCODE 1");
                    sendByte(encData.encode(), SITE_MESSAGE_TYPE);
                } else {
                    airTrackList.add(encData.encode());
                }

                if (airTrackList.size() == N5) {
                    log.debug("AIR TRACK ENCODE " + airTrackList.size());
                    appendByte = mergeData(airTrackList);
                    if (appendByte != null) {
                        sendByte(appendByte, MESSAGE_TYPE);
                    }
                }

                if ((mcrcSendQueue.size() == 0) && (airTrackList.size() > 0)) {
                    sendRemainAirTrackByte(airTrackList);
                }

            } catch (RuntimeException e4) {
                log.warn(errUdpMsg, e4.getMessage(), e4);
            }
        }
    }

    public void sendRemainAirTrackByte(ArrayList<byte[]> airTrackList) {

        byte[] appendByte = null;

        if (!airTrackList.isEmpty()) {
            log.debug("AIR TRACK ENCODE REMAIN " + airTrackList.size());
            appendByte = mergeData(airTrackList);

            if (appendByte != null) {
                sendByte(appendByte, MESSAGE_TYPE);
            }
        }
    }

    public byte[] mergeData(ArrayList<byte[]> airTrackList) {
        
        try {
            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            byte[] appByte = null;

            for (byte[] b : airTrackList) {
                bao.write(b);
            }

            appByte = bao.toByteArray();
            airTrackList.clear();

            return appByte;
        } catch (IOException e) {
            airTrackList.clear();
            log.warn("Air track merge failed: {}", e.getMessage(), e);
            return null;
        }

    }

    public void sendByte(byte[] payload, byte type) {
        try {
            String udpMsg = "MCRC UDP send success: Type={}, Size={}";
            byte[] packetData = null;
            ByteBuffer sBuf = ByteBuffer.allocate(N2 + payload.length);

            sBuf.put(type);
            sBuf.put((byte) (payload.length & B_FF));
            sBuf.put(payload);

            packetData = sBuf.array();
            log.debug("mcrc send data : {}", ByteUtil.bytesToHex(packetData));
            senderService.send(packetData);

            log.info(udpMsg, type, payload.length);
        } catch (Exception e) {
            log.warn("MCRC UDP send failed: {}", e.getMessage(), e);
        }
    }

}
