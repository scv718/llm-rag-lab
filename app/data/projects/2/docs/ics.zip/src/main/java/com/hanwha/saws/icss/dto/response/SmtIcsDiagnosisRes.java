/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class SmtIcsDiagnosisRes {

    @JsonProperty("mode") private String mode = "작전모드";
    @JsonProperty("active_mode") private String activeMode = "Active";
    @JsonProperty("data_corrupt_yn") private String dataCorrupt = "N";
    @JsonProperty("no_data") private String noData = "N";
    @JsonProperty("send_err_yn") private String sendErrYn = "N";

    @JsonIgnore
    public void setDefault(String defStatus) {
        noData = defStatus;
        dataCorrupt = defStatus;
        sendErrYn = defStatus;
    }
}
