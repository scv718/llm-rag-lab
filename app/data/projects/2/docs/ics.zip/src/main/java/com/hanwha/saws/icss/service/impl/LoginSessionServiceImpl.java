/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.dao.local.UserGroupDao;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.UserModel;
import com.hanwha.saws.icss.service.LoginSessionService;

import lombok.extern.slf4j.Slf4j;

@Service("LoginSessionService")
@Slf4j
public class LoginSessionServiceImpl implements LoginSessionService {
    
    private static final int N2 = 2;    
    private static final int N3 = 3;
    
    @Autowired
    @Qualifier("sessionMap")
    private ConcurrentHashMap<String, LoginSessionBean> sessionMap;

    @Autowired UserGroupDao userGroupDao;

    @Value("${jas.value}") String userKey;
    
    @Value("${prop.s-timeout}") int sTimeout;
    
    @Autowired
    PropConfig propConfig;    
    
    @Override
    public void syncSession(ConcurrentHashMap<String, LoginSessionBean> bean) {
        log.debug("session sync from remote server");
        sessionMap = new ConcurrentHashMap<>(bean); // 방어적 복사
    }

    @Override
    public ConcurrentHashMap<String, LoginSessionBean> getSessionAll() {
        // return Collections.unmodifiableMap(sessionMap); 읽기전용 해도 될거같긴함
        return new ConcurrentHashMap<>(sessionMap);
    }

    @Override
    public void pSess(String ip) {
        ArrayList<String> keys = null;
        LoginSessionBean rt = null;

        if (ip.equals("127.0.0.1")) {
            keys = new ArrayList<>(sessionMap.keySet());

            for (String key : keys) {
                rt = sessionMap.get(key);
                log.debug(rt + "");

            }
        }
    }

    public BaseResponse getSession(String bearer, String ip) {

        boolean isContain = false;
        boolean isExpire = false;
        LoginSessionBean sBear = null;
        long exTime = 0;
        
        if (!validateToken(bearer)) {
            log.trace("validateToken failed");            
            return new BaseResponse(ResRepo.getC502());
        }

        sBear = sessionMap.get(bearer);

        if (sBear != null) {
            isContain = sessionMap.containsKey(bearer);
            exTime = sessionMap.get(bearer).getExpireTime();
            isExpire = exTime > System.currentTimeMillis();
        }

        if (isContain) {

            if (isExpire) {
                sessionMap.get(bearer).updateSessionTime(sTimeout);
                return new BaseResponse(ResRepo.getC200(), sBear);
            } else {
                sessionMap.remove(bearer);
                return new BaseResponse(ResRepo.getC501());
            }
        } else {

//            if (isContain) {
//                sessionMap.remove(bearer);
//            }

            return new BaseResponse(ResRepo.getC502());
        }

    }

    @Override
    public void deleteSession(String bearer) {
        sessionMap.remove(bearer);
    }

    @Override
    public LoginSessionBean getUserSession(String userId) {
        ArrayList<String> keys = new ArrayList<>(sessionMap.keySet());
        LoginSessionBean rt = null;

        for (String key : keys) {
            if ((sessionMap.get(key).getUserId()).equals(userId)) {
                rt = sessionMap.get(key);

                break;
            }
        }

        return rt;
    }

    @Override
    public boolean getCheckSession(String userId) {
        ArrayList<String> keys = new ArrayList<>(sessionMap.keySet());
        boolean isCheck = true;
        long exTime = 0;

        for (String key : keys) {
            if ((sessionMap.get(key).getUserId()).equals(userId)) {
                exTime = sessionMap.get(key).getExpireTime();
                if (exTime > System.currentTimeMillis()) {
                    isCheck = false;
                } else {
                    sessionMap.remove(key);
                }
                break;
            }
        }
        return isCheck;
    }

    @Override
    public LoginSessionBean genSession(UserModel bean, String senderIp)
            throws InvalidKeyException, NoSuchAlgorithmException {

        LoginSessionBean tmp = new LoginSessionBean();
        GroupModel param = new GroupModel();
        GroupModel group = null;

        tmp.setBearer(createToken(bean.getUserId()));

        param.setGroupId(bean.getGroupId());
        group = userGroupDao.selectGroupInfo(param);

        if (group == null) {
            tmp.setGroupId("NON");
            tmp.setGroupName("NONE");
        } else {
            tmp.setGroupId(group.getGroupId());
            tmp.setGroupName(group.getGroupName());
        }

        tmp.setPw(bean.getDecPw()); // 오리지날 pw
        tmp.setName(bean.getUserName());
        tmp.setUserId(bean.getUserId());
        tmp.updateSessionTime(sTimeout);
        tmp.setIp(senderIp);
        sessionMap.put(tmp.getBearer(), tmp);

        return tmp;
    }

    private String createToken(String userId)
            throws InvalidKeyException, NoSuchAlgorithmException {

        long timestamp = System.currentTimeMillis();
        String payload = userId + ":" + timestamp;
        String signature = hmacSha256(payload, userKey);
        String token = payload + ":" + signature;

        return Base64.getEncoder().encodeToString(token.getBytes());
    }

    private String hmacSha256(String data, String key)
            throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] rawHmac = null;

        mac.init(new SecretKeySpec(key.getBytes(), "HmacSHA256"));
        rawHmac = mac.doFinal(data.getBytes());

        return Base64.getEncoder().encodeToString(rawHmac);
    }

    private boolean validateToken(String base64Token) {
        String decoded = new String(Base64.getDecoder().decode(base64Token));
        String[] parts = decoded.split(":");
        String userId2 = null;
        String timestamp = null;
        String signature = null;
        String payload = null;
        String expectedSig = null;

        if (parts.length != N3) {
            log.warn("parts length : {} ", parts.length);

            return false;
        }

        userId2 = parts[0];
        timestamp = parts[1];
        signature = parts[N2];

        payload = userId2 + ":" + timestamp;

        try {
            expectedSig = hmacSha256(payload, userKey);

        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.warn("valToken " + e.toString());
            return false;
        }

        if (!expectedSig.equals(signature)) {
            log.trace("expectedSig not match");
            return false;
        }

        return true;
    }

}
