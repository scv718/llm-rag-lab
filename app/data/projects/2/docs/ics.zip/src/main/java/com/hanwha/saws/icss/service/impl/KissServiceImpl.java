/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.RecvObjectDupBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.kiss.MissleTrackSduBean;
import com.hanwha.saws.icss.dto.kiss.MissleTrackVOBean;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistListRes;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistRes;
import com.hanwha.saws.icss.persistence.dao.local.KamdHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.DBBulkService;
import com.hanwha.saws.icss.service.KissService;
import com.hanwha.saws.icss.service.ProcessMonitorService;
import com.hanwha.saws.icss.util.DataCrypt;
import com.hanwha.saws.icss.util.HexByteUtil;
import com.hanwha.saws.icss.util.LogKeyUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service("KissService")
@Slf4j
public class KissServiceImpl implements KissService {

    private static final int ACTIVE = 1;

    @Autowired
    DBBulkService dbBulkService;

    @Autowired
    StatusConfigDao statusConfigDao;

    @Autowired
    PropConfig prop;

    @Value("${prop.host-name}")
    String hostName;

    @Value("${sms.send-port}")
    int smsPort;

    @Value("${scc.send-port}")
    int sccPort;

    @Autowired
    KamdHistDao kamdHistDao;

    @Value("${ics.file-key}")
    String fileKey;

    private DataCrypt crypt = new DataCrypt();
    
    @Autowired
    ProcessMonitorService recvMonitor;

    @Autowired
    @Qualifier("kissRecvMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> kissRecvMap;
    
    @Autowired
    @Qualifier("kissDecQueue")
    private ConcurrentLinkedQueue<MissleTrackSduBean> kissDecQueue;
    
    @Override
    public void handleEvent(RecvMsgQueueBean param) {
        byte[] packet = param.getData();
        String senderIp = param.getSenderIp();
        Date sentTime = null;
        MissleTrackSduBean mBean = null;
        byte[] outByte = null;
        boolean sentResult = true;
        String logMsg = "";
        KamdHistModel model = null;
        NodeModel tNode = null;
        HashMap<Integer, NodeModel> nHash = null;
        String logK = null;
        List<MissleTrackVOBean> vos = null;
        
        MDC.remove("LOG_KEY");

        if (prop.getActiveMode() != ACTIVE) {
            log.debug("TYPE: KAMD - its standby");
            return;
        }

        try {

            log.debug("TYPE : KAMD ip :" + senderIp); // 타입이 0x00

            mBean = new MissleTrackSduBean(packet);
            mBean.setRecvTime(param.getInsertTime());
            outByte = mBean.getOriginFilterByte();

            if (!checkDuplicate(outByte, senderIp)) {
                log.trace("duplication");
                return;
            }

            logK = LogKeyUtil.getRandomKey();
            MDC.put("LOG_KEY", logK);

            log.debug("Filter KAMD");

            logMsg = "KAMD BYTE : {}";

            log.debug(logMsg, HexByteUtil.getByteArrayToHexString(outByte));

            nHash = prop.getNodeInfoHash();

            if (prop.isModemSendMode()) {
                log.debug("KAMD OPERATION MODE, SEND TO MODEM");
                tNode = nHash.get(NodeRepo.getSmsA().getCode());
                sentResult = sendUdpData(tNode, smsPort, outByte);

                tNode = nHash.get(NodeRepo.getSmsB().getCode());
                sentResult = sendUdpData(tNode, smsPort, outByte);
            } else {
                log.debug("KAMD STANDBY MODE, DO NOT SEND TO MODEM");
            }

            sentTime = new Date();

            log.debug("KAMD SEND TO SCC");

            tNode = nHash.get(NodeRepo.getSccA().getCode());
            sendUdpData(tNode, sccPort, outByte);

            tNode = nHash.get(NodeRepo.getSccB().getCode());
            sendUdpData(tNode, sccPort, outByte);

            model = makeInsertData(mBean, sentResult, sentTime);
            model.setLogKInfo(logK);

            dbBulkService.pushMissleQueue(model);
            
            vos = mBean.getVos();

            if (vos != null && vos.size() > 0) {
                MissleTrackVOBean bean = vos.get(0);
                if (bean.getCudmInt() == 1) {
                    log.debug("CUDM IS D MODE. SKIP");
                    return;
                }
            }
            kissDecQueue.offer(mBean);
                        

        } catch (IOException | RuntimeException e) {
            recvMonitor.markReceivedErrNow();
            log.warn("KissService handleEvent()" + e.toString());
        }
    }

    private boolean checkDuplicate(byte[] packet, String senderIp) {
        String data = HexByteUtil.getByteArrayToHexString(packet);
        String logMsg = "{} data: already received from {}";
        RecvObjectDupBean bean = new RecvObjectDupBean();
        RecvObjectDupBean  typeBean = kissRecvMap.get(data);
        
        log.debug("duplicate check key {}  ip : {}", data, senderIp);
   
        if (typeBean != null && (!senderIp.equals(typeBean.getSenderIp()))) {
            log.debug(logMsg, senderIp, typeBean.getSenderIp());
            return false;
        }

        bean.setRecvTime(System.currentTimeMillis());
        bean.setSenderIp(senderIp);
        kissRecvMap.put(data, bean);

        return true;
    }

    private boolean sendUdpData(NodeModel info, int port, byte[] data) {

        try (DatagramSocket socket = new DatagramSocket()) {

            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket dPacket = new DatagramPacket(data, data.length,
                    mcastaddr, port);

            socket.send(dPacket);

        } catch (IOException e) {
            log.warn("KissService sendUdpData() " + e.toString());
            return false;
        }

        return true;
    }

    private KamdHistModel makeInsertData(MissleTrackSduBean bean,
            boolean sentResult, Date sentTime) {

        KamdHistModel model = new KamdHistModel();
        String t = null;

        model.setSysId(hostName);

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {

            log.warn("KissService makeInsertData()" + e.toString());
            t = HexByteUtil.getByteArrayToHexString(bean.getOriginFilterByte());
            model.setData(t);
        }

        model.setDataSize(bean.getOriginFilterByte().length);

        model.setDataName(System.currentTimeMillis() + "");
        model.setDataType(bean.getHeader().getTypeInt() + "");
        model.setDataTypeName(STypeRepo.getMissleCmd().getMsg());
        model.setErrorFlag((sentResult ? "N" : "Y"));
        model.setInsertTime(null);
        model.setRecvGroup(hostName);
        model.setRecvTime(bean.getRecvTime());
        model.setSentTime(sentTime);

        return model;

    }

    @Override
    public BaseResponse getKamdHistList(HashMap body)
            throws IOException, RuntimeException {

        KamdHistModel kamdParam = new KamdHistModel();

        Integer page = (Integer) body.get("page");
        Integer lSize = (Integer) body.get("list_size");
        List<KamdHistModel> list = null;
        SmtDataSendRecvHistListRes resData = null;
        SmtDataSendRecvHistRes smtBean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        long tCnt = 0;
        long tPage = 0;
        long tRCnt = 0;

        kamdParam.setSt((String) body.get("start_time"));
        kamdParam.setEd((String) body.get("end_time"));
        kamdParam.setPage(page, lSize);

        list = kamdHistDao.selectKamdHistList(kamdParam);

        resData = new SmtDataSendRecvHistListRes();

        if ((list != null) && (list.size() > 0)) {
            tCnt = kamdHistDao.selectKamdHistTotalCount(kamdParam);
            resData.setTotalCount(tCnt);
            tRCnt = kamdParam.getRowCount();
            tPage = ((tCnt + tRCnt - 1) / tRCnt);
            resData.setTotalPage(tPage);
        }

        for (KamdHistModel hist : list) {
            smtBean = new SmtDataSendRecvHistRes();

            smtBean.setData(hist);
            resData.getList().add(smtBean);
        }

        res.setData(resData);
        return res;
    }

}
