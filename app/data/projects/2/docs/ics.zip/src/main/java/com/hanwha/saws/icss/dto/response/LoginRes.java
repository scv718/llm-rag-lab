/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LoginRes {

    private String key;
    private String name;

    @JsonProperty("group_id") private String groupId;

    @JsonProperty("group_name") private String groupName;

}
