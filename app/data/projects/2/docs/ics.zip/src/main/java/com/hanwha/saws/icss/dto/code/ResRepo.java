/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class ResRepo {

    private static final int R200 = 200; // 성공
    private static final int R204 = 204; // No Content
    private static final int R400 = 400; // Not ACTIVE
    private static final int R401 = 401; // STANDBY 미준비
    private static final int R402 = 402; // 인증 필요
    private static final int R403 = 403; // 파라미터 없음
    private static final int R404 = 404; // 연결 실패
    private static final int R405 = 405; // 권한 없음
    private static final int R406 = 406; // 권한 없음
    private static final int R501 = 501; // 로그인 시간 초과
    private static final int R502 = 502; // 세션 이상
    private static final int R503 = 503; // 로그인 실패
    private static final int R504 = 504; // 비밀번호 만료
    private static final int R505 = 505; // 로그인 차단
    private static final int R506 = 506; // 중복 로그인 차단
    private static final int R507 = 507; // 비번 변경 실패
    private static final int R508 = 508; // DB 연결 문제
    private static final int R509 = 509; // 절체 불가
    private static final int R510 = 510; // 절체 실패
    private static final int R511 = 511; // 설정 실패
    private static final int R512 = 512; // 조회 실패
    private static final int R513 = 513; // 허용 초과
    private static final int R514 = 514; // 수동키 자리수
    private static final int R515 = 515; // Group ID 삭제 불가
    private static final int R516 = 516; // SMS ACTIVE 전환 실패(양ACTIVE불가)
    private static final int R517 = 517; // SMS ACTIVE 전환 실패(양ACTIVE불가)
    private static final int R999 = 999; // 내부 오류

    private static final String M200 = "성공";
    private static final String M204 = "클라이언트의 요구를 처리했으나 전송할 데이터가 없음";
    private static final String M400 = "ACTIVE 서버가 아닙니다";
    private static final String M401 = "STANDBY 서버가 준비되지 않았습니다";
    private static final String M402 = "리소스접근권한이없습니다.인증 후 접근 가능";
    private static final String M403 = "param이 없습니다";
    private static final String M404 = "연결에 실패하였습니다.";
    private static final String M405 = "해당 권한은 관리자만 가능합니다.";
    private static final String M406 = "해당 권한은 관리자와 본인만 가능합니다.";
    private static final String M501 = "로그인 시간이 초과되었습니다";
    private static final String M502 = "로그인 세션이 올바르지 않습니다";
    private static final String M503 = "로그인이 실패하였습니다";
    private static final String M504 = "비밀번호 기한이 만료되었습니다";
    private static final String M505 = "로그인이 차단되었습니다";
    private static final String M506 = "중복로그인이 차단되었습니다";
    private static final String M507 = "비밀번호 변경에 실패하였습니다";
    private static final String M508 = "DB연결에 문제가 발생하였습니다";
    private static final String M509 = "송수신 모뎀의 상태가 절체를 할 수 없습니다";
    private static final String M510 = "송수신 모뎀의 절체에 실패하였습니다";
    private static final String M511 = "송수신 모뎀의 설정에 실패하였습니다";
    private static final String M512 = "송수신 모뎀의 조회에 실패하였습니다";
    private static final String M513 = "허용 범위가 초과되었습니다";
    private static final String M514 = "수동키코드는 20자리가 되어야 합니다";
    private static final String M515 = "Group ID를 사용하는 사용자가 있습니다. 삭제 불가";
    private static final String M516 = "다른 SMS가 이미 ACTIVE 상태입니다";
    private static final String M517 = "작전모드가 아닙니다";
    
    private static final String M999 = "내부 오류가 발생했습니다.";

    private static final ResRepo C200 = new ResRepo(R200, M200);
    private static final ResRepo C204 = new ResRepo(R204, M204);
    private static final ResRepo C400 = new ResRepo(R400, M400);
    private static final ResRepo C401 = new ResRepo(R401, M401);
    private static final ResRepo C402 = new ResRepo(R402, M402);
    private static final ResRepo C403 = new ResRepo(R403, M403);
    private static final ResRepo C404 = new ResRepo(R404, M404);
    private static final ResRepo C405 = new ResRepo(R405, M405);
    private static final ResRepo C406 = new ResRepo(R406, M406);
    private static final ResRepo C501 = new ResRepo(R501, M501);
    private static final ResRepo C502 = new ResRepo(R502, M502);
    private static final ResRepo C503 = new ResRepo(R503, M503);
    private static final ResRepo C504 = new ResRepo(R504, M504);
    private static final ResRepo C505 = new ResRepo(R505, M505);
    private static final ResRepo C506 = new ResRepo(R506, M506);
    private static final ResRepo C507 = new ResRepo(R507, M507);
    private static final ResRepo C508 = new ResRepo(R508, M508);
    private static final ResRepo C509 = new ResRepo(R509, M509);
    private static final ResRepo C510 = new ResRepo(R510, M510);
    private static final ResRepo C511 = new ResRepo(R511, M511);
    private static final ResRepo C512 = new ResRepo(R512, M512);
    private static final ResRepo C513 = new ResRepo(R513, M513);
    private static final ResRepo C514 = new ResRepo(R514, M514);
    private static final ResRepo C515 = new ResRepo(R515, M515);
    private static final ResRepo C516 = new ResRepo(R516, M516);
    private static final ResRepo C517 = new ResRepo(R517, M517);
    private static final ResRepo C999 = new ResRepo(R999, M999);

    private final int code;
    private final String msg;

    private ResRepo(int cd, String mg) {
        this.code = cd;
        this.msg = mg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
    
    public static ResRepo getC200() {
        return C200;
    }

    public static ResRepo getC204() {
        return C204;
    }

    public static ResRepo getC400() {
        return C400;
    }

    public static ResRepo getC401() {
        return C401;
    }

    public static ResRepo getC402() {
        return C402;
    }

    public static ResRepo getC403() {
        return C403;
    }

    public static ResRepo getC404() {
        return C404;
    }

    public static ResRepo getC405() {
        return C405;
    }

    public static ResRepo getC406() {
        return C406;
    }

    public static ResRepo getC501() {
        return C501;
    }

    public static ResRepo getC502() {
        return C502;
    }

    public static ResRepo getC503() {
        return C503;
    }

    public static ResRepo getC504() {
        return C504;
    }

    public static ResRepo getC505() {
        return C505;
    }

    public static ResRepo getC506() {
        return C506;
    }

    public static ResRepo getC507() {
        return C507;
    }

    public static ResRepo getC508() {
        return C508;
    }

    public static ResRepo getC509() {
        return C509;
    }

    public static ResRepo getC510() {
        return C510;
    }

    public static ResRepo getC511() {
        return C511;
    }

    public static ResRepo getC512() {
        return C512;
    }

    public static ResRepo getC513() {
        return C513;
    }

    public static ResRepo getC514() {
        return C514;
    }

    public static ResRepo getC515() {
        return C515;
    }
    
    public static ResRepo getC516() {
        return C516;
    }
    
    public static ResRepo getC517() {
        return C517;
    }
    
    public static ResRepo getC999() {
        return C999;
    }

}
