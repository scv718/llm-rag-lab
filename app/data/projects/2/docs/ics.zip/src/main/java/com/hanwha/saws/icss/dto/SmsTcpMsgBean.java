/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import com.hanwha.saws.icss.dto.code.SmsRepo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SmsTcpMsgBean {

    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N8 = 8;
    private static final int N21 = 21;
    
    private static int defSid = 0;
    private static final int CMD_HEARTBEAT = 0;
    private static final int CMD_RESET = 1;
    private static final int CMD_DIAGNOSIS = 2;
    private static final int CMD_FAILOVER = 3;
    private static final int CMD_CONTROL_UNIT_SET = 4;
    private static final int CMD_CONTROL_UNIT_STATUS = 5;
    private static final int SMS_MODEM_BER_THRES_STATUS = 6;
    private static final int SMS_MODEM_BER_THRES_SET = 7;
    private static final int SMS_MODEM_STATUS = 8;
    private static final int SMS_CONV_UPC_SET = 9;
    private static final int SMS_CONV_DNC_SET = 10;
    private static final int SMS_CONV_STATUS = 11;
    private static final int SMS_CONV_LOOPBACK_SET = 12;
    private static final int SMS_CONV_BITLEVEL_SET = 13;
    private static final int SMS_SMODULE_INFO = 14;
    private static final int SMS_SMODULE_DIAGNOSIS = 15;
    private static final int SMS_SMODULE_LOGIN = 16;
    private static final int SMS_SMODULE_PIN_CHANGE = 17;
    private static final int SMS_SMODULE_LOGOUT = 18;
    private static final int SMS_SMODULE_CRYPTO_SET = 19;
    private static final int SMS_SMODULE_CRYPTO_STATUS = 20;
    private static final int SMS_SMODULE_BOARD_STATUS = 21;
    private static final int SMS_SMODULE_INSERT_KEY_CODE = 22;

    private SmsTcpObjectBean reqBean;

    private SmsTcpObjectBean resBean;

    public byte[] getReqBeanByte() throws IOException {
        return reqBean.encode();
    }

    public void setReqInfo(int type, Object[] args) {

        switch (type) {
            case CMD_HEARTBEAT: {
                setReqHeartbeat();
                break;
            }
            case CMD_RESET: {
                setReqReset();
                break;
            }
            case CMD_DIAGNOSIS: {
                setReqDiagnosis();
                break;
            }
            case CMD_FAILOVER: {
                setReqFailover(args);
                break;
            }
            case CMD_CONTROL_UNIT_SET: {
                setReqControlUnitSet(args);
                break;
            }
            case CMD_CONTROL_UNIT_STATUS: {
                setReqControlUnitStatus();
                break;
            }
            case SMS_MODEM_BER_THRES_STATUS: {
                setReqModemBerThresStatus();
                break;
            }
            case SMS_MODEM_BER_THRES_SET: {
                setReqModemBerThresSet(args);
                break;
            }
            case SMS_MODEM_STATUS: {
                setReqModemStatus();
                break;
            }
            case SMS_CONV_UPC_SET: {
                setReqConvUpcSet(args);
                break;
            }
            case SMS_CONV_DNC_SET: {
                setReqConvDncSet(args);
                break;
            }
            case SMS_CONV_STATUS: {
                setReqConvStatus();
                break;
            }
            case SMS_CONV_LOOPBACK_SET: {
                setReqConvLoopback(args);
                break;
            }
            case SMS_CONV_BITLEVEL_SET: {
                setReqConvBitLevelSet(args);
                break;
            }
            case SMS_SMODULE_INFO: {
                setReqSModuleInfo();
                break;
            }
            case SMS_SMODULE_DIAGNOSIS: {
                setReqSModuleDiagnosis();
                break;
            }
            case SMS_SMODULE_LOGIN: {
                setReqSModuleLogin(args);
                break;
            }
            case SMS_SMODULE_PIN_CHANGE: {
                setReqSModulePinChange(args);
                break;
            }
            case SMS_SMODULE_LOGOUT: {
                setReqSModuleLogout();
                break;
            }
            case SMS_SMODULE_CRYPTO_SET: {
                setReqSModuleCryptoSet(args);
                break;
            }
            case SMS_SMODULE_CRYPTO_STATUS: {
                setReqSModuleCryptoStatus();
                break;
            }
            case SMS_SMODULE_BOARD_STATUS: {
                setReqSModuleBoardStatus();
                break;
            }
            case SMS_SMODULE_INSERT_KEY_CODE: {
                setReqSModuleInsertKeyCode(args);
                break;
            }
            default: {
                throw new IllegalArgumentException("none Req type");
            }
        }
    }

    private void setReqSModuleInsertKeyCode(Object[] args) {
        
        int byteAlloc = N21;
        int maxInt = 0xFF;
        boolean isLen = false;
        
        String groupId = (String) args[0];
        String keyNum = (String) args[1];

        byte[] value = new byte[1];
        byte[] keyNumBytes = null;
        ByteBuffer buffer = null;
        
        byte[] b = null;

        short cmdType = 0;
        short typeReq = 0;
        boolean isEqGidA = false;
        boolean isEqGidB = false;
        boolean isEqGidC = false;
        
        reqBean = new SmsTcpObjectBean();
        isEqGidA = (groupId.equals("0") || groupId.equals("5"));
        isEqGidB = (groupId.equals("6") || groupId.equals("7"));
        isEqGidC = groupId.equals("8");
        
        if (isEqGidA || isEqGidB || isEqGidC) {
            
            buffer = ByteBuffer.allocate(byteAlloc);
            isLen = (groupId.length() > 0);
            
            value[0] = (isLen ? (Byte.parseByte(groupId)) : ((byte) maxInt));
            keyNumBytes = keyNum.getBytes();

            buffer.put(value);
            buffer.put(keyNumBytes);

        } else {
            buffer = ByteBuffer.allocate(1);
            isLen = (groupId.length() > 0);
            
            value[0] = (isLen ? (Byte.parseByte(groupId)) : ((byte) maxInt));
            buffer.put(value);
        }

        b = buffer.array();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleInsertKeyCode().getCode();
        
        reqBean.setHeader(cmdType, typeReq, nextSid(), b.length);
        
        reqBean.setData(b);
    }

    private void setReqSModuleBoardStatus() {
        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;
        
        reqBean = new SmsTcpObjectBean();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleBoardStatus().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        
        reqBean.setData(null);
    }

    private void setReqSModuleCryptoStatus() {
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;
        
        reqBean = new SmsTcpObjectBean();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleCryptoStatus().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        
        reqBean.setData(null);
    }

    private void setReqSModuleCryptoSet(Object[] args) {

        short normalKey = 0x1000;
        short encKey = 0x0001;

        ByteBuffer buffer = null;
        int key = (int) args[0];
        short keyMode = 0;
        byte[] b = null;

        short cmdType = 0;
        short typeReq = 0;
        int bLen = N2;

        reqBean = new SmsTcpObjectBean();
        
        if (key == 0) {
            keyMode = normalKey; // 평문
        } else {
            keyMode = encKey; // 비문
        }

        buffer = ByteBuffer.allocate(bLen);
        buffer.putShort(keyMode);
        b = buffer.array();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleCryptoSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        reqBean.setData(buffer.array());
    }

    private void setReqSModuleLogout() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleLogout().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        
        reqBean.setData(null);
    }

    private void setReqSModulePinChange(Object[] args) {
        String oldPinNum = (String) args[0];
        String pinNum = (String) args[1];

        byte[] oldPinBytes = oldPinNum.getBytes();
        byte[] pinBytes = pinNum.getBytes();
        int len = N4 + oldPinBytes.length + pinBytes.length;

        short cmdType = 0;
        short typeReq = 0;

        ByteBuffer buffer = ByteBuffer.allocate(len);

        reqBean = new SmsTcpObjectBean();

        buffer.putShort((short) oldPinBytes.length);
        buffer.put(oldPinBytes);
        buffer.putShort((short) pinBytes.length);
        buffer.put(pinBytes);

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmodulePinChange().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), len);
        
        reqBean.setData(buffer.array());
    }

    private void setReqSModuleLogin(Object[] args) {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        int bfLen = N2;
        String pinNum = (String) args[0];
        byte[] pinBytes = pinNum.getBytes();

        ByteBuffer buffer = ByteBuffer.allocate(bfLen + pinBytes.length);

        reqBean = new SmsTcpObjectBean();

        buffer.putShort((short) pinBytes.length);
        buffer.put(pinBytes);

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleLogin().getCode();
        bLen = bfLen + pinBytes.length;

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(buffer.array());
    }

    private void setReqSModuleDiagnosis() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleDiagnosis().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    private void setReqSModuleInfo() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeSmoduleInfo().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    private void setReqConvBitLevelSet(Object[] args) {
        int bff = 0XFF;
        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = N4;

        int arg0 = 0;
        int arg1 = 1;
        int arg2 = N2;
        int arg3 = N3;

        byte b = 0;

        ByteBuffer buffer = null;
        int uul = 0;
        int ull = 0;
        int dul = 0;
        int dll = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeConvBitlevelSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        uul = (int) args[arg0];
        ull = (int) args[arg1];
        dul = (int) args[arg2];
        dll = (int) args[arg3];

        buffer = ByteBuffer.allocate(bLen);
        b = (byte) (dul & bff);
        buffer.put(b);

        b = (byte) (dll & bff);
        buffer.put(b);

        b = (byte) (uul & bff);
        buffer.put(b);

        b = (byte) (ull & bff);
        buffer.put(b);

        reqBean.setData(buffer.array());
    }

    private void setReqConvLoopback(Object[] args) {

        int maxInt = 0xFF;
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 1;

        int loopback = 0;
        byte result = 0;

        ByteBuffer buffer = null;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeConvLoopbackSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        loopback = (int) args[0];
        result = (byte) (loopback & maxInt);

        buffer = ByteBuffer.allocate(bLen);
        buffer.put(result);

        reqBean.setData(buffer.array());
    }

    private void setReqConvStatus() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeConvStatus().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        reqBean.setData(null);
    }

    private void setReqConvDncSet(Object[] args) {

        int maxInt = 0xFF;        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = N5;

        int arg0 = 0;
        int arg1 = 1;

        int dnc = (int) args[arg0];
        int dncAtt = (int) args[arg1];

        ByteBuffer buffer = null;
        byte b = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeConvDncSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        buffer = ByteBuffer.allocate(bLen);
        buffer.putInt(dnc);

        b = (byte) (dncAtt & maxInt);
        buffer.put(b);

        reqBean.setData(buffer.array());
    }

    private void setReqConvUpcSet(Object[] args) {

        int maxInt = 0xFF;
        short cmdType = 0;
        short typeReq = 0;
        int bLen = N5;

        int arg0 = 0;
        int arg1 = 1;

        int upc = (int) args[arg0];
        int upcAtt = (int) args[arg1];

        ByteBuffer buffer = null;
        byte b = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeConvUpcSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        buffer = ByteBuffer.allocate(bLen);
        buffer.putInt(upc);

        b = (byte) (upcAtt & maxInt);
        buffer.put(b);

        reqBean.setData(buffer.array());
    }

    private void setReqModemStatus() {
        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeModemStatus().getCode();
        
        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        
        reqBean.setData(null);

    }

    private void setReqModemBerThresSet(Object[] args) {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = N8;
        long threshold = 0;

        ByteBuffer buffer = null;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeModemBerThresSet().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);

        buffer = ByteBuffer.allocate(bLen);

        threshold = (long) args[0];
        buffer.putLong(threshold);

        reqBean.setData(buffer.array());

    }

    private void setReqModemBerThresStatus() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeModemBerThresStatus().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        
        reqBean.setData(null);

    }

    private void setReqControlUnitSet(Object[] args) {

        int byteLen = N8;
        int ipLen = N4;
        
        String ipAddr = (String) args[0];
        String remoteAddr = (String) args[1];
        
        byte[] result = null;
        byte[] ipByte = null;
        byte[] rIpByte = null;
        short cmdType = 0;
        short typeReq = 0;
        
        reqBean = new SmsTcpObjectBean();
        
        try {
            
            ipByte = InetAddress.getByName(ipAddr).getAddress();
            rIpByte = InetAddress.getByName(remoteAddr).getAddress();

            result = new byte[byteLen];
            
            System.arraycopy(ipByte, 0, result, 0, ipLen); // IP 복사
            System.arraycopy(rIpByte, 0, result, ipLen, ipLen);
            
        } catch (UnknownHostException e) {
            log.error("Unknown host: {}", e.getMessage(), e);            
        }
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeControlUnitSet().getCode();
        
        reqBean.setHeader(cmdType, typeReq, nextSid(), byteLen);
        reqBean.setData(result);

    }

    private void setReqFailover(Object[] args) {

        int maxInt = 0xFF;
        short cmdType = 0;
        short typeReq = 0;
        int bLen = N5;
        int ipLen = N4;
        
        byte[] result = null;
        byte[] bytes = null;
        int mode = 0;
        
        int arg0 = 0;
        int arg1 = 1;
        
        String ipAddr = (String) args[arg0];
        
        reqBean = new SmsTcpObjectBean();
        
        try {
            
            bytes = InetAddress.getByName(ipAddr).getAddress();
            mode = (int) args[arg1];

            result = new byte[bLen];
            
            System.arraycopy(bytes, 0, result, 0, ipLen); // IP 복사
            
            result[ipLen] = (byte) (mode & maxInt);
            
        } catch (UnknownHostException e) {
            log.error("Unknown host: {}", e.getMessage(), e); 
        }

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeFailover().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(result);
    }

    private void setReqDiagnosis() {
        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;
        
        reqBean = new SmsTcpObjectBean();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeDiagnosis().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    private void setReqControlUnitStatus() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeControlUnitStatus().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    private void setReqHeartbeat() {
        
        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;
        
        reqBean = new SmsTcpObjectBean();
        
        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeHeartbeat().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    private void setReqReset() {

        short cmdType = 0;
        short typeReq = 0;
        int bLen = 0;

        reqBean = new SmsTcpObjectBean();

        cmdType = SmsRepo.getTypeReq().getCode();
        typeReq = SmsRepo.getTypeReset().getCode();

        reqBean.setHeader(cmdType, typeReq, nextSid(), bLen);
        reqBean.setData(null);
    }

    public synchronized int nextSid() {
        defSid++;
        
        if (defSid < 0) { // int overflow 발생 시 (2^31 초과 → 음수)
            defSid = 0;
        }
        
        return defSid;
    }
}
