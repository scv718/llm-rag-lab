/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class McrcQueueMonitor implements Runnable {

    private static final int N10 = 10;

    @Autowired @Qualifier("mcrcRecvQueue")
    private ConcurrentLinkedQueue<byte[]> mcrcRecvQueue;

    @Override
    public void run() {
        while (true) {
            try {
                int qSize = (mcrcRecvQueue != null) ? mcrcRecvQueue.size() : -1;
                CompletableFuture<Void> delay = new CompletableFuture<>();
                log.debug("MCRC recvQueue size: {}", qSize);
                delay.completeOnTimeout(null, N10, TimeUnit.SECONDS).join();
            } catch (RuntimeException e) {
                log.warn("Queue monitor error: {}", e.getMessage(), e);
            }
        }
    }
}
