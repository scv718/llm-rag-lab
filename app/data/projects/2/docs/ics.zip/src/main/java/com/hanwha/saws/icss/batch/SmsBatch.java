/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.SmsRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.SmsService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SmsBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    private static final int ACTIVE = 1;
    private static final int STANDBY = 0;
    private boolean isFirstPass = false;
    @Autowired PropConfig prop;

    @Autowired SmsService smsService;
    
    @Autowired StatusConfigDao stConfDao;

    @Scheduled(
            fixedDelayString = "${cron.sms-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void smsHeartBeat() throws IOException {
        
        boolean isSmsAUnknown = false;
        boolean isSmsBUnknown = false;
        
        boolean isSmsAStandby = false;
        boolean isSmsBStandby = false;    
        
        boolean isSmsAActive = false;
        boolean isSmsBActive = false;
        
        NodeModel tNode = null;
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        List<StatusModel> statusList = null;
        int smsAMode = 0;
        int smsBMode = 0;
        
        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }
        
        if (prop.getActiveMode() != ACTIVE) {
            log.trace("stand by");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        statusLog.debug("SMS HEARTBEAT BATCH START");

        try {            
            smsService.heartbeat(NodeRepo.getSmsA());
            smsService.heartbeat(NodeRepo.getSmsB());
            
            statusList = stConfDao.selectStatusList();
            if ((statusList == null) || (statusList.size() == 0)) {
                return;
            }

            nH.get(NodeRepo.getSmsA().getCode())
                    .setActiveMode(statusList.get(0).getSmsA());
            nH.get(NodeRepo.getSmsB().getCode())
                    .setActiveMode(statusList.get(0).getSmsB());
          
            smsAMode = statusList.get(0).getSmsA();
            smsBMode = statusList.get(0).getSmsB();
            
            tNode = nH.get(NodeRepo.getSmsA().getCode());
            
            if (smsAMode == StatusRepo.getUNKNOWN().getCode() 
                    || smsAMode == StatusRepo.getWARNING().getCode()) {
                isSmsAUnknown = true;
            } else if (smsAMode == SmsRepo.getStatusStandby().getCode()) {
                isSmsAStandby = true;
            } else if (smsAMode == SmsRepo.getStatusActive().getCode()) {
                isSmsAActive = true;
            }

            tNode = nH.get(NodeRepo.getSmsB().getCode());

            if (smsBMode == StatusRepo.getUNKNOWN().getCode() 
                    || smsBMode == StatusRepo.getWARNING().getCode()) {
                isSmsBUnknown = true;
            } else if (smsBMode == SmsRepo.getStatusStandby().getCode()) {
                isSmsBStandby = true;
            } else if (smsBMode == SmsRepo.getStatusActive().getCode()) {
                isSmsBActive = true;
            }
            
            if (prop.isModemSendMode()) {
                
                if (isSmsAUnknown && isSmsBStandby) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(),
                            tNode.getNodeId());
                } else if (isSmsBUnknown && isSmsAStandby) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(),
                            tNode.getNodeId());
                }
                
                if (isSmsAStandby && isSmsBStandby) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getACTIVE().getCode(),
                            tNode.getNodeId());
                }
              
                if (isSmsAActive && isSmsBActive) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                }
            }else {
                if (isSmsAActive) {
                    tNode = nH.get(NodeRepo.getSmsA().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                }
                
                if (isSmsBActive) {
                    tNode = nH.get(NodeRepo.getSmsB().getCode());
                    smsService.smsModeChangeAuto(
                            StatusRepo.getSTANDBY().getCode(),
                            tNode.getNodeId());
                }
                
            }
            
        } catch (NoClassDefFoundError e) {
            log.warn("smsHeartBeat() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("smsHeartBeat batch " + e.toString(),e);
        }
        
        statusLog.debug("SMS HEARTBEAT BATCH END");

    }

    @Scheduled(
            fixedDelayString = "${cron.sms-status-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void smsStatusMonitor() throws IOException {

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }
        
        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }
        
        if (prop.getActiveMode() == STANDBY) {
            log.trace("stand by");
            return;
        }
        
        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());
        
        statusLog.debug("SMS STATUS MONITOR BATCH START");
        
        try {

            smsService.monitorDiagnosis(NodeRepo.getSmsA());
            smsService.monitorDiagnosis(NodeRepo.getSmsB());
            
        } catch (NoClassDefFoundError e) {
            log.warn("smsStatusMonitor() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("smsStatusMonitor batch " + e.toString());
        }

        statusLog.debug("SMS STATUS MONITOR BATCH END");

    }
    
}
