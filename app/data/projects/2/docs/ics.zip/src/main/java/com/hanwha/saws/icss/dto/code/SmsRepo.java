/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.hanwha.saws.icss.service.impl.SmsServiceImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SmsRepo {

    private static final Map<Short, SmsRepo> CODE_MAP = new HashMap<>();
    
    private static final short REQ = 0x0010;
    private static final short RES = 0x0011;
    private static final short EVT = 0x0020;

    private static final short HB = 0x0500; // HEARTBEAT
    private static final short RST = 0x0501; // RESET
    private static final short DIA = 0x0502; // DIAGNOSIS
    private static final short FO = 0x0503; // FAILOVER

    private static final short CU_SET = 0x0510;
    private static final short CU_STAT = 0x0511;

    private static final short MB_STAT = 0x0520;
    private static final short MB_SET = 0x0521;
    private static final short M_STAT = 0x0522;

    private static final short C_UP = 0x0530;
    private static final short C_DOWN = 0x0531;
    private static final short C_STAT = 0x0532;
    private static final short C_LOOP = 0x0533;
    private static final short C_BIT = 0x0534;

    private static final short SM_INFO = 0x0540;
    private static final short SM_DIA = 0x0541;
    private static final short SM_LOGIN = 0x0542;
    private static final short SM_PIN = 0x0543;
    private static final short SM_LOGOUT = 0x0544;
    private static final short SM_C_SET = 0x0546;
    private static final short SM_C_STAT = 0x0547;
    private static final short SM_B_STAT = 0x0548;
    private static final short SM_KEY = 0x0549; // 규약 외 키 삽입

    private static final short EVT_M_STAT = 0x1500;
    private static final short EVT_C_CLK = 0x1531;

    private static final short E_C_FAULT = 0x1510;
    private static final short E_C_RESTART = 0x1511;
    private static final short E_M_FAULT = 0x1520;
    private static final short E_M_BER = 0x1521;
    private static final short E_C_FAULT2 = 0x1530;
    private static final short E_SM_OFF = 0x1540;
    private static final short E_SM_DEL = 0x1541;
    private static final short E_SM_FAULT = 0x1542;
    private static final short E_PWR = 0x1550;
    private static final short E_TRAFFIC = 0x1560;

    private static final short ST_UNKNOWN = 0x0000;
    private static final short ST_WARNING = 0x0001;
    private static final short ST_ACTIVE = 0x0002;
    private static final short ST_STANDBY = 0x0003;
    
    private static final SmsRepo REQ_T = new SmsRepo(REQ);
    private static final SmsRepo RES_T = new SmsRepo(RES);
    private static final SmsRepo EVT_T = new SmsRepo(EVT);
    private static final SmsRepo HB_T = new SmsRepo(HB);
    private static final SmsRepo RST_T = new SmsRepo(RST);
    private static final SmsRepo DIA_T = new SmsRepo(DIA);
    private static final SmsRepo FO_T = new SmsRepo(FO);
    private static final SmsRepo CU_SET_T = new SmsRepo(CU_SET);
    private static final SmsRepo CU_STAT_T = new SmsRepo(CU_STAT);
    private static final SmsRepo MB_STAT_T = new SmsRepo(MB_STAT);
    private static final SmsRepo MB_SET_T = new SmsRepo(MB_SET);
    private static final SmsRepo M_STAT_T = new SmsRepo(M_STAT);
    private static final SmsRepo C_UP_T = new SmsRepo(C_UP);
    private static final SmsRepo C_DOWN_T = new SmsRepo(C_DOWN);
    private static final SmsRepo C_STAT_T = new SmsRepo(C_STAT);
    private static final SmsRepo C_LOOP_T = new SmsRepo(C_LOOP);
    private static final SmsRepo C_BIT_T = new SmsRepo(C_BIT);
    private static final SmsRepo SM_INFO_T = new SmsRepo(SM_INFO);
    private static final SmsRepo SM_DIA_T = new SmsRepo(SM_DIA);
    private static final SmsRepo SM_LOGIN_T = new SmsRepo(SM_LOGIN);
    private static final SmsRepo SM_PIN_T = new SmsRepo(SM_PIN);
    private static final SmsRepo SM_LOGOUT_T = new SmsRepo(SM_LOGOUT);
    private static final SmsRepo SM_C_SET_T = new SmsRepo(SM_C_SET);
    private static final SmsRepo SM_C_STAT_T = new SmsRepo(SM_C_STAT);
    private static final SmsRepo SM_B_STAT_T = new SmsRepo(SM_B_STAT);
    private static final SmsRepo SM_KEY_T = new SmsRepo(SM_KEY);
    private static final SmsRepo EVT_M_STAT_T = new SmsRepo(EVT_M_STAT);
    private static final SmsRepo EVT_C_CLK_T = new SmsRepo(EVT_C_CLK);
    private static final SmsRepo E_C_FLT_T = new SmsRepo(E_C_FAULT);
    private static final SmsRepo E_C_RST_T = new SmsRepo(E_C_RESTART);
    private static final SmsRepo E_M_FLT_T = new SmsRepo(E_M_FAULT);
    private static final SmsRepo E_M_BER_T = new SmsRepo(E_M_BER);
    private static final SmsRepo E_C_FLT2_T = new SmsRepo(E_C_FAULT2);
    private static final SmsRepo E_SM_OFF_T = new SmsRepo(E_SM_OFF);
    private static final SmsRepo E_SM_DEL_T = new SmsRepo(E_SM_DEL);
    private static final SmsRepo E_SM_FLT_T = new SmsRepo(E_SM_FAULT);
    private static final SmsRepo E_PWR_T = new SmsRepo(E_PWR);
    private static final SmsRepo E_TRA_T = new SmsRepo(E_TRAFFIC);
    private static final SmsRepo ST_UNK_T = new SmsRepo(ST_UNKNOWN);
    private static final SmsRepo ST_ACT_T = new SmsRepo(ST_ACTIVE);
    private static final SmsRepo ST_STB_T = new SmsRepo(ST_STANDBY);
    private static final SmsRepo ST_WRN_T = new SmsRepo(ST_WARNING);

    private final short code;

    static {
        CODE_MAP.put(REQ, REQ_T);
        CODE_MAP.put(RES, RES_T);
        CODE_MAP.put(EVT, EVT_T);
        CODE_MAP.put(HB, HB_T);
        CODE_MAP.put(RST, RST_T);
        CODE_MAP.put(DIA, DIA_T);
        CODE_MAP.put(FO, FO_T);
        CODE_MAP.put(CU_SET, CU_SET_T);
        CODE_MAP.put(CU_STAT, CU_STAT_T);
        CODE_MAP.put(MB_STAT, MB_STAT_T);
        CODE_MAP.put(MB_SET, MB_SET_T);
        CODE_MAP.put(M_STAT, M_STAT_T);
        CODE_MAP.put(C_UP, C_UP_T);
        CODE_MAP.put(C_DOWN, C_DOWN_T);
        CODE_MAP.put(C_STAT, C_STAT_T);
        CODE_MAP.put(C_LOOP, C_LOOP_T);
        CODE_MAP.put(C_BIT, C_BIT_T);
        CODE_MAP.put(SM_INFO, SM_INFO_T);
        CODE_MAP.put(SM_DIA, SM_DIA_T);
        CODE_MAP.put(SM_LOGIN, SM_LOGIN_T);
        CODE_MAP.put(SM_PIN, SM_PIN_T);
        CODE_MAP.put(SM_LOGOUT, SM_LOGOUT_T);
        CODE_MAP.put(SM_C_SET, SM_C_SET_T);
        CODE_MAP.put(SM_C_STAT, SM_C_STAT_T);
        CODE_MAP.put(SM_B_STAT, SM_B_STAT_T);
        CODE_MAP.put(SM_KEY, SM_KEY_T);
        CODE_MAP.put(EVT_M_STAT, EVT_M_STAT_T);
        CODE_MAP.put(EVT_C_CLK, EVT_C_CLK_T);
        CODE_MAP.put(E_C_FAULT, E_C_FLT_T);
        CODE_MAP.put(E_C_RESTART, E_C_RST_T);
        CODE_MAP.put(E_M_FAULT, E_M_FLT_T);
        CODE_MAP.put(E_M_BER, E_M_BER_T);
        CODE_MAP.put(E_C_FAULT2, E_C_FLT2_T);
        CODE_MAP.put(E_SM_OFF, E_SM_OFF_T);
        CODE_MAP.put(E_SM_DEL, E_SM_DEL_T);
        CODE_MAP.put(E_SM_FAULT, E_SM_FLT_T);
        CODE_MAP.put(E_PWR, E_PWR_T);
        CODE_MAP.put(E_TRAFFIC, E_TRA_T);
        CODE_MAP.put(ST_UNKNOWN, ST_UNK_T);
        CODE_MAP.put(ST_ACTIVE, ST_ACT_T);
        CODE_MAP.put(ST_STANDBY, ST_STB_T);
        CODE_MAP.put(ST_WARNING, ST_WRN_T);
        
    }
    
    SmsRepo(short cd) {
        this.code = cd;
    }

    public short getCode() {
        return code;
    }

    public static SmsRepo from(int cd) {
        
        SmsRepo result = CODE_MAP.get((short) cd);

        if (result != null) {
            
            return result;
        }else {
            log.debug("Unknown code: " + cd);
            
            return CODE_MAP.get(ST_UNKNOWN);
        }
     
    }

    public static SmsRepo getTypeReq() {
        return REQ_T;
    }

//    public static SmsRepo getTypeRes() {
//        return RES_T;
//    }

    public static SmsRepo getTypeEvt() {
        return EVT_T;
    }

    public static SmsRepo getTypeHeartbeat() {
        return HB_T;
    }

    public static SmsRepo getTypeReset() {
        return RST_T;
    }

    public static SmsRepo getTypeDiagnosis() {
        return DIA_T;
    }

    public static SmsRepo getTypeFailover() {
        return FO_T;
    }

    public static SmsRepo getTypeControlUnitSet() {
        return CU_SET_T;
    }

    public static SmsRepo getTypeControlUnitStatus() {
        return CU_STAT_T;
    }

    public static SmsRepo getTypeModemBerThresStatus() {
        return MB_STAT_T;
    }

    public static SmsRepo getTypeModemBerThresSet() {
        return MB_SET_T;
    }

    public static SmsRepo getTypeModemStatus() {
        return M_STAT_T;
    }

    public static SmsRepo getTypeConvUpcSet() {
        return C_UP_T;
    }

    public static SmsRepo getTypeConvDncSet() {
        return C_DOWN_T;
    }

    public static SmsRepo getTypeConvStatus() {
        return C_STAT_T;
    }

    public static SmsRepo getTypeConvLoopbackSet() {
        return C_LOOP_T;
    }

    public static SmsRepo getTypeConvBitlevelSet() {
        return C_BIT_T;
    }

    public static SmsRepo getTypeSmoduleInfo() {
        return SM_INFO_T;
    }

    public static SmsRepo getTypeSmoduleDiagnosis() {
        return SM_DIA_T;
    }

    public static SmsRepo getTypeSmoduleLogin() {
        return SM_LOGIN_T;
    }

    public static SmsRepo getTypeSmodulePinChange() {
        return SM_PIN_T;
    }

    public static SmsRepo getTypeSmoduleLogout() {
        return SM_LOGOUT_T;
    }

    public static SmsRepo getTypeSmoduleCryptoSet() {
        return SM_C_SET_T;
    }

    public static SmsRepo getTypeSmoduleCryptoStatus() {
        return SM_C_STAT_T;
    }

    public static SmsRepo getTypeSmoduleBoardStatus() {
        return SM_B_STAT_T;
    }

    public static SmsRepo getTypeSmoduleInsertKeyCode() {
        return SM_KEY_T;
    }

    public static SmsRepo getEventModemStatus() {
        return EVT_M_STAT_T;
    }

    public static SmsRepo getEventConvClockChange() {
        return EVT_C_CLK_T;
    }

    public static SmsRepo getEventFaultControl() {
        return E_C_FLT_T;
    }

    public static SmsRepo getEventRestartControl() {
        return E_C_RST_T;
    }

    public static SmsRepo getEventFaultModem() {
        return E_M_FLT_T;
    }

    public static SmsRepo getEventFaultBerThresModem() {
        return E_M_BER_T;
    }

    public static SmsRepo getEventFaultConv() {
        return E_C_FLT2_T;
    }

    public static SmsRepo getEventFaultSmoduleOff() {
        return E_SM_OFF_T;
    }

    public static SmsRepo getEventFaultSmoduleDelete() {
        return E_SM_DEL_T;
    }

    public static SmsRepo getEventFaultSmodule() {
        return E_SM_FLT_T;
    }

    public static SmsRepo getEventFaultPower() {
        return E_PWR_T;
    }

    public static SmsRepo getEventFaultTraffic() {
        return E_TRA_T;
    }

    public static SmsRepo getStatusUnknown() {
        return ST_UNK_T;
    }

    public static SmsRepo getStatusActive() {        
        return ST_ACT_T;
    }

    public static SmsRepo getStatusStandby() {
        return ST_STB_T;
    }

    public static SmsRepo getStatusWarning() {
        return ST_WRN_T;
    }
}
