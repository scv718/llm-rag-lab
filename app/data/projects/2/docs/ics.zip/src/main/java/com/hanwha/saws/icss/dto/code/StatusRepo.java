/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.HashMap;
import java.util.Map;

public class StatusRepo {

    private static final Map<Integer, StatusRepo> CODE_MAP = new HashMap<>();
    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;

    private static final StatusRepo OK = new StatusRepo(N0, "OK");
    private static final StatusRepo UNKNOWN = new StatusRepo(N1, "UNKNOWN");
    private static final StatusRepo ACTIVE = new StatusRepo(N2, "ACTIVE");
    private static final StatusRepo STANDBY = new StatusRepo(N3, "STANDBY");
    private static final StatusRepo WARNING = new StatusRepo(N4, "WARNING");
    
    private final int code;
    private final String name;

    static {
        CODE_MAP.put(OK.getCode(), OK);
        CODE_MAP.put(UNKNOWN.getCode(), UNKNOWN);
        CODE_MAP.put(ACTIVE.getCode(), ACTIVE);
        CODE_MAP.put(STANDBY.getCode(), STANDBY);
        CODE_MAP.put(WARNING.getCode(), WARNING);
        
    }

    private StatusRepo(int cd, String nm) {
        this.code = cd;
        this.name = nm;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static StatusRepo getOK() {
        return OK;
    }

    public static StatusRepo getUNKNOWN() {
        return UNKNOWN;
    }

    public static StatusRepo getWARNING() {
        return WARNING;
    }

    public static StatusRepo getACTIVE() {
        return ACTIVE;
    }

    public static StatusRepo getSTANDBY() {
        return STANDBY;
    }

//    public static StatusRepo fromCode(int code) {
//        StatusRepo result = CODE_MAP.get(code);
//        
//        if (result == null) {
//            throw new IllegalArgumentException("Unknown StatusCode: " + code);
//        }
//        return result;
//    }
}