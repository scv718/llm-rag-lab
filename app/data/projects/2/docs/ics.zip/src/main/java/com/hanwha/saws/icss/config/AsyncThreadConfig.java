/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.util.concurrent.Executor;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.aop.interceptor.SimpleAsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableAsync(proxyTargetClass = true)
public class AsyncThreadConfig implements AsyncConfigurer {
    
    private static final int N2 = 2;
    private static final int N5 = 5;
    private static final int N6 = 6;
    private static final int N100 = 100;
    
    @Value("${async-thread.core-pool-size}")
    int aCorePoolSize;

    @Value("${async-thread.max-pool-size}")
    int aMaxPoolSize;

    @Value("${async-thread.queue-capacity}")
    int aQueueCapacity;

    @Bean(name = "ASyncExecutor")
    @Override
    public Executor getAsyncExecutor() {

        final int keelAliveSec = 60000;
        CustThPoolTaskExec taskExecutor = new CustThPoolTaskExec(
                "ASyncExecutor");

        taskExecutor.setCorePoolSize(aCorePoolSize);
        taskExecutor.setMaxPoolSize(aMaxPoolSize);
        taskExecutor.setQueueCapacity(aQueueCapacity);
        taskExecutor.setThreadNamePrefix("ASyncExecutor-");
        taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
        taskExecutor.setKeepAliveSeconds(keelAliveSec);
        taskExecutor.setAllowCoreThreadTimeOut(false);
        taskExecutor.initialize();
        return taskExecutor;
    }

    @Bean(name = "voiceSaveExecutor")
    public Executor voiceSaveExecutor() {
        
        final int keelAliveSec = 60000;
        CustThPoolTaskExec taskExecutor = new CustThPoolTaskExec("VoiceSave");

        taskExecutor.setCorePoolSize(N2);
        taskExecutor.setMaxPoolSize(N5);
        taskExecutor.setQueueCapacity(N100);
        taskExecutor.setThreadNamePrefix("VoiceSave-");
        taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
        taskExecutor.setKeepAliveSeconds(keelAliveSec);
        taskExecutor.setAllowCoreThreadTimeOut(false);
        taskExecutor.initialize();
        return taskExecutor;
    }

    @Bean(name = "smsListenerExecutor")
    public Executor smsListenerExecutor() {

        final int keelAliveSec = 60000;
        CustThPoolTaskExec taskExecutor = new CustThPoolTaskExec("smsListener");

        taskExecutor.setCorePoolSize(N6);
        taskExecutor.setMaxPoolSize(N6);
        taskExecutor.setQueueCapacity(N6);
        taskExecutor.setThreadNamePrefix("smsListener-");
        taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
        taskExecutor.setKeepAliveSeconds(keelAliveSec);
        taskExecutor.setAllowCoreThreadTimeOut(false);
        taskExecutor.initialize();
        return taskExecutor;
    }
    
    @Bean(name = "smsAirTrackExecutor")
    public Executor smsAirTrackExecutor() {

        final int keelAliveSec = 60000;
        CustThPoolTaskExec taskExecutor = new CustThPoolTaskExec(
                "smsAirTrackExecutor");

        taskExecutor.setCorePoolSize(N2);
        taskExecutor.setMaxPoolSize(N2);
        taskExecutor.setQueueCapacity(N100);
        taskExecutor.setThreadNamePrefix("smsAirTrackExecutor-");
        taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
        taskExecutor.setKeepAliveSeconds(keelAliveSec);
        taskExecutor.setAllowCoreThreadTimeOut(false);
        taskExecutor.initialize();
        return taskExecutor;
    }
    
    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return new SimpleAsyncUncaughtExceptionHandler();
    }
}
