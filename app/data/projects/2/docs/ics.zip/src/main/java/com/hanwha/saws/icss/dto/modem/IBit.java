/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IBit {

    @JsonProperty("ext_int") private int extInt = 0;
    private int upc = 0;
    private int dnc = 0;

    @JsonProperty("upc_pll") private int upcPll = 0;
    @JsonProperty("dnc_pll") private int dncPll = 0;
    @JsonProperty("fix_pll") private int fixPll = 0;
    @JsonProperty("no_card") private int noCard = 0;
    @JsonProperty("dnc_rssi") private Integer dncRssi = 0;
    @JsonProperty("upc_rssi") private Integer upcRssi = 0;
    @JsonIgnore private String binaryString;

    @JsonIgnore
    public String getErrCode() {
        return binaryString;
    }

    @JsonIgnore
    public String getAlarmInfo() {
        
        String val = null;
        boolean isN = (noCard == 1);
        boolean isU = (upc == 1);
        boolean isD = (dnc == 1);
        boolean isUP = (upcPll == 1);
        boolean isDP = (dncPll == 1);
        boolean isFP = (fixPll == 1);
        

        StringBuilder sb = new StringBuilder();

        if (isN || isU || isD || isUP || isDP || isFP) {

            if (noCard > 0) {
                sb.append("no card");

            } else {

                if (upc > 0) {
                    setComma(sb);
                    sb.append("UPC bit");
                }

                if (dnc > 0) {
                    setComma(sb);
                    sb.append("DNC bit");
                }

                if (upcPll > 0) {
                    setComma(sb);
                    sb.append("UPC PLL bit");
                }

                if (dncPll > 0) {
                    setComma(sb);
                    sb.append("DNC PLL bit");
                }

                if (fixPll > 0) {
                    setComma(sb);
                    sb.append("FIX PLL bit");
                }

            }

            val = sb.toString();

        }
        
        return val;
    }

    @JsonIgnore
    private void setComma(StringBuilder sb) {
        if (!sb.isEmpty()) {
            sb.append(", ");
        }
    }
}