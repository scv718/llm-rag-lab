/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import java.util.Base64;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UserReq {

    private String id;
    private String pw;
    private String name;
    @JsonProperty("old_pw") private String oldPw;

    @JsonProperty("group_id") private String groupId;

    private String phone;
    private String tel;
    private String email;
    private String desc;
    private String deny;

    public String getDecPw() {
        byte[] decodedBytes = Base64.getDecoder().decode(pw);
        
        return new String(decodedBytes);
    }

    public String getDecOldPw() {
        byte[] decodedBytes = Base64.getDecoder().decode(oldPw);
        
        return new String(decodedBytes);
    }

}
