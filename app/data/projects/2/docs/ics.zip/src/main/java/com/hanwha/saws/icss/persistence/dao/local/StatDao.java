/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.AlarmHistStatModel;
import com.hanwha.saws.icss.persistence.model.HistStatModel;
import com.hanwha.saws.icss.persistence.model.ServerAlarmStatModel;
import com.hanwha.saws.icss.persistence.model.ServerHistStatModel;

public interface StatDao {

    public ServerHistStatModel selectKamdLastHistStat();
    
    public List<HistStatModel> selectKamdHistStat(ServerHistStatModel param);
    
    public List<HistStatModel> selectMcrcHistStat(ServerHistStatModel param);
    
    public List<ServerHistStatModel> selectKamdHistCount(
            ServerHistStatModel param);
    
    public void insertKamdHistStat(List<ServerHistStatModel> list);
    
    public ServerHistStatModel selectMcrcLastHistStat();
    
    public List<ServerHistStatModel> selectMcrcHistCount(
            ServerHistStatModel param);

    public void insertMcrcHistStat(List<ServerHistStatModel> list);
    
    public List<ServerAlarmStatModel> selectIcssLastAlarmStat();

    public List<ServerAlarmStatModel> selectMissLastAlarmStat();

    public List<ServerAlarmStatModel> selectKissLastAlarmStat();

    public List<ServerAlarmStatModel> selectSmsLastAlarmStat();

    public List<ServerAlarmStatModel> selectSwitchLastAlarmStat();

    public List<ServerAlarmStatModel> selectRouterLastAlarmStat();

    public List<AlarmHistStatModel> selectAlarmHistCount(
            AlarmHistStatModel param);

    public void insertIcssAlarmStat(List<ServerAlarmStatModel> list);

    public void insertMissAlarmStat(List<ServerAlarmStatModel> list);

    public void insertKissAlarmStat(List<ServerAlarmStatModel> list);

    public void insertSmsAlarmStat(List<ServerAlarmStatModel> list);

    public void insertSwitchAlarmStat(List<ServerAlarmStatModel> list);

    public void insertRouterAlarmStat(List<ServerAlarmStatModel> list);

    public List<ServerAlarmStatModel> selectIcssAlarmStatList(
            ServerAlarmStatModel param);

    public int selectIcssAlarmStatTotalCount(ServerAlarmStatModel param);

    public List<ServerAlarmStatModel> selectMissAlarmStatList(
            ServerAlarmStatModel param);

    public int selectMissAlarmStatTotalCount(ServerAlarmStatModel param);

    public List<ServerAlarmStatModel> selectKissAlarmStatList(
            ServerAlarmStatModel param);

    public int selectKissAlarmStatTotalCount(ServerAlarmStatModel param);

    public List<ServerAlarmStatModel> selectModemAlarmStatList(
            ServerAlarmStatModel param);

    public int selectModemAlarmStatTotalCount(ServerAlarmStatModel param);

    public List<ServerAlarmStatModel> selectSwitchAlarmStatList(
            ServerAlarmStatModel param);

    public int selectSwitchAlarmStatTotalCount(ServerAlarmStatModel param);

    public List<ServerAlarmStatModel> selectRouterAlarmStatList(
            ServerAlarmStatModel param);

    public int selectRouterAlarmStatTotalCount(ServerAlarmStatModel param);

}