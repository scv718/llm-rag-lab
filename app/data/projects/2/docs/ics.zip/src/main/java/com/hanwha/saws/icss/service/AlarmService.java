/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import java.util.HashMap;
import java.util.List;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;

public interface AlarmService {

    void alarmUpdate(boolean status, AlarmRepo code, NodeModel nodeInfo,
            AlarmRepo levelCode, String summary);

    BaseResponse currAlarmList(LoginSessionBean session, Integer nodeId,
            String remoteAddr, String operation);

    BaseResponse alarmHistSearch(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);
    
    BaseResponse msgAlarmList(LoginSessionBean data, HashMap body,
            String remoteAddr, String requestURI);
    
    BaseResponse alarmIdList(LoginSessionBean data, String remoteAddr,
            String requestURI);

    List<CurrAlarmModel> getCurrentAlarmDeviceInfo(Integer nodeId);

    void alarmLevelUpdate(boolean status, AlarmRepo code, NodeModel nodeInfo,
            AlarmRepo levelCode, String summary);

    List<CurrAlarmModel> getCurrAlarmSearch(Integer nodeId);

}
