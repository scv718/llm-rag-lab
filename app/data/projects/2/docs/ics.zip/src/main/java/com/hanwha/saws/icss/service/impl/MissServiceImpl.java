/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.RecvObjectDupBean;
import com.hanwha.saws.icss.dto.SmsQueueBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.miss.AirTrackMOBean;
import com.hanwha.saws.icss.dto.miss.AirTrackSduBean;
import com.hanwha.saws.icss.dto.miss.TimerSduBean;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistListRes;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistRes;
import com.hanwha.saws.icss.persistence.dao.local.McrcHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.DBBulkService;
import com.hanwha.saws.icss.service.MissService;
import com.hanwha.saws.icss.service.ProcessMonitorService;
import com.hanwha.saws.icss.util.DataCrypt;
import com.hanwha.saws.icss.util.HexByteUtil;
import com.hanwha.saws.icss.util.LogKeyUtil;

import lombok.extern.slf4j.Slf4j;

@Service("MissService")
@Slf4j
public class MissServiceImpl implements MissService {

    private static final int N5000 = 5000;

    private static final byte MSG_TYPE = 0x08;

    private static final int ACTIVE = 1;

    @Autowired
    McrcHistDao mcrcHistDao;
    @Autowired
    StatusConfigDao statusConfigDao;

    @Autowired
    PropConfig prop;
    @Autowired
    DBBulkService dbBulkService;

    @Value("${prop.host-name}")
    String hostName;

    @Value("${sms.send-port}")
    int smsPort;

    @Value("${scc.send-port}")
    int sccPort;

    @Value("${ics.file-key}")
    String fileKey;

    private DataCrypt crypt = new DataCrypt();

    @Autowired
    @Qualifier("missRecvMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> missRecvMap;
    
    @Autowired
    @Qualifier("missPrevKnotMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> missPrevKnotMap;

    private long siteLocationRecvTime = 0L;

    @Autowired
    ProcessMonitorService recvMonitor;
    
    @Autowired
    @Qualifier("airTrackSmsAQueue")
    private ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsAQueue;

    @Autowired
    @Qualifier("airTrackSmsBQueue")
    private ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsBQueue;
    
    @Autowired
    @Qualifier("missDecQueue")
    private ConcurrentLinkedQueue<AirTrackSduBean> missDecQueue;
    
    @Override
    public void handleEvent(RecvMsgQueueBean param) {
        byte[] recvP = param.getData();
        String senderIp = param.getSenderIp();        

        MDC.remove("LOG_KEY");

        if (prop.getActiveMode() != ACTIVE) {
            log.debug("TYPE: MCRC - its standby");
            return;
        }

        try {
            log.debug("TYPE: MCRC ip : " + senderIp);

            if (((byte[]) recvP)[0] == MSG_TYPE) {
                setTimer(recvP, senderIp);
            } else {
                setAirTrack(param.getInsertTime(), recvP, senderIp);
            }

        } catch (IOException | RuntimeException e) {
            recvMonitor.markReceivedErrNow();
            log.warn("MissService handleEvent()" + e.toString(),e);
        }

    }

    private boolean checkSiteLocationDuplicate(byte[] packet, String sIp) {
        long cTime = System.currentTimeMillis();
        long locTime = siteLocationRecvTime;

        if ((locTime == 0L) || ((cTime - locTime) > N5000)) {
            siteLocationRecvTime = cTime;
            return true;
        }

        return false;
    }

    private void setTimer(byte[] packet, String senderIp)
            throws IOException, RuntimeException {
        NodeModel nm = null;
        TimerSduBean bean = new TimerSduBean();
        String logT = "";

        if (!checkSiteLocationDuplicate(packet, senderIp)) {
            log.trace("site location duplicate");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        log.debug("MSG_TYPE : Site location (Timer)");

        bean = new TimerSduBean(packet);
        log.debug("TIME : " + new String(bean.getDateTime()));

        logT = HexByteUtil.getByteArrayToHexString(bean.getOriginFilterByte());

        log.debug("MCRC BYTE : {}", logT);

        if (prop.isModemSendMode()) {
            log.debug("site location MCRC OPERATION MODE, SEND TO MODEM");

            nm = prop.getNodeInfoHash().get(NodeRepo.getSmsA().getCode());
            sendUdpData(nm, smsPort, bean.getOriginFilterByte());

            nm = prop.getNodeInfoHash().get(NodeRepo.getSmsB().getCode());
            sendUdpData(nm, smsPort, bean.getOriginFilterByte());
        } else {
            log.debug("site location MCRC STANDBY MODE, DO NOT SEND TO MODEM");
        }

        log.debug("site location MCRC SEND TO SCC");
        nm = prop.getNodeInfoHash().get(NodeRepo.getSccA().getCode());
        sendUdpData(nm, sccPort, bean.getOriginFilterByte());

        nm = prop.getNodeInfoHash().get(NodeRepo.getSccB().getCode());
        sendUdpData(nm, sccPort, bean.getOriginFilterByte());

    }

    private boolean checkAirtrackDuplicate(AirTrackSduBean data, String sIp) {

        List<AirTrackMOBean> moList = new ArrayList<>();
        String key = null;
        String logT = null;
        RecvObjectDupBean bean = new RecvObjectDupBean();
        boolean isDup = true;
        String trackNum = null;
        RecvObjectDupBean typeBean = null;  
        
        for (AirTrackMOBean mo : data.getMos()) {

            trackNum = HexByteUtil.getByteArrayToHexString(mo.getTrackNumber());
            key = mo.getSimLiveState() + "_" + trackNum;

            typeBean = missRecvMap.get(key);  
            log.debug(
                    "duplicate check key {}  ip : {} contkey : {}", key, sIp,
                    (typeBean == null) ? false : true
            );

            if (typeBean != null && (!sIp.equals(typeBean.getSenderIp()))) {

                logT = key + " data: already received from ";
                logT += typeBean.getSenderIp();
                log.debug(logT);

                continue;
            }

            moList.add(mo);

            bean.setRecvTime(System.currentTimeMillis());
            bean.setSenderIp(sIp);

            missRecvMap.put(key, bean);
            if (missPrevKnotMap.containsKey(key)) {
                missPrevKnotMap.get(key).setRecvTime(bean.getRecvTime());
            } else {
                missPrevKnotMap.put(key, bean.copy());
            }

        }

        if (moList.size() == 0) {
            isDup = false;
            return isDup;
        }

        data.setFilterMoList(moList);
        return isDup;
    }

    private void setAirTrack(Timestamp recvTime, byte[] packet, String senderIp)
            throws IOException, RuntimeException {        
        AirTrackSduBean bean = new AirTrackSduBean(packet);
        boolean sentResult = true;
        NodeModel nm = null;
        Date sentTime = null;
        String logT = "";
        McrcHistModel rt = null;
        String logK = null;

        bean.setRecvTime(recvTime);
        log.debug("MSG_TYPE : Air Track ip : " + senderIp);

        if (!checkAirtrackDuplicate(bean, senderIp)) {
            log.trace("checkAirtrackDuplicate Err");

            return;
        }
       
        logK = LogKeyUtil.getRandomKey();
        MDC.put("LOG_KEY", logK);

        log.debug("Filter Air Track count " + bean.getMoCnt());

        logT = HexByteUtil.getByteArrayToHexString(bean.getOriginFilterByte());
        
        log.debug("MCRC BYTE : {}", logT);

        if (prop.isModemSendMode()) {
            log.debug("Air Track MCRC OPERATION MODE, SEND TO MODEM");

            nm = prop.getNodeInfoHash().get(NodeRepo.getSmsA().getCode());   
//            sendSms(nm,bean.getOriginFilterByte());
            sentResult = sendUdpData(nm, smsPort, bean.getOriginFilterByte());

            nm = prop.getNodeInfoHash().get(NodeRepo.getSmsB().getCode());
//            sendSms(nm,bean.getOriginFilterByte());
            sentResult = sendUdpData(nm, smsPort, bean.getOriginFilterByte());
        } else {
            log.debug("Air Track MCRC STANDBY MODE, DO NOT SEND TO MODEM");
        }

        sentTime = new Date();

        log.debug("Air Track MCRC SEND TO SCC");
        nm = prop.getNodeInfoHash().get(NodeRepo.getSccA().getCode());
        sendUdpData(nm, sccPort, bean.getOriginFilterByte());

        nm = prop.getNodeInfoHash().get(NodeRepo.getSccB().getCode());
        sendUdpData(nm, sccPort, bean.getOriginFilterByte());

        rt = makeInsertData(bean, sentResult, sentTime);
        rt.setLogKInfo(logK);

        dbBulkService.pushAirTrackQueue(rt); // bulk 입력
        missDecQueue.offer(bean);
    }

//    private void sendSms(NodeModel nm, byte[] b) {
//
//        SmsQueueBean bean = new SmsQueueBean(b, nm.getAddrIp(), smsPort);
//
//        if (nm.getNodeId() == NodeRepo.getSmsA().getCode()) {
//            airTrackSmsAQueue.offer(bean);
//        } else if (nm.getNodeId() == NodeRepo.getSmsB().getCode()) {
//            airTrackSmsBQueue.offer(bean);
//        }
//
//    }

    private boolean sendUdpData(NodeModel info, int port, byte[] data) {

        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket dPacket = null;

            dPacket = new DatagramPacket(data, data.length, mcastaddr, port);

            socket.send(dPacket);

        } catch (IOException | RuntimeException e) {
            log.warn("MissService sendUdpData() " + e.toString());

            return false;
        }

        return true;
    }

    private McrcHistModel makeInsertData(AirTrackSduBean bean,
            boolean sentResult, Date sentTime) {

        McrcHistModel model = new McrcHistModel();
        String logT = null;
        byte[] bT = null;

        model.setSysId(hostName);

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("MissService makeInsertData()" + e.toString());

            bT = bean.getOriginFilterByte();
            logT = HexByteUtil.getByteArrayToHexString(bT);

            model.setData(logT);
        }

        model.setSysId(hostName);
        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setDataName(System.currentTimeMillis() + "");
        model.setDataType(bean.getHeader().getTypeInt() + "");
        model.setDataTypeName(STypeRepo.getAirTrackCmd().getMsg());

        model.setErrorFlag((sentResult ? "N" : "Y"));
        model.setInsertTime(null);
        model.setRecvGroup(hostName);
        model.setRecvTime(bean.getRecvTime());
        model.setSentTime(sentTime);

        return model;

    }

    @Override
    public BaseResponse getMcrcHistList(HashMap body)
            throws IOException, RuntimeException {

        McrcHistModel mcrcParam = new McrcHistModel();
        Integer pSize = null;
        Integer lSize = null;
        List<McrcHistModel> list = null;
        SmtDataSendRecvHistListRes resData = new SmtDataSendRecvHistListRes();
        SmtDataSendRecvHistRes smtBean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        long tCnt = 0;
        long tPages = 0;
        long tRCnt = 0;

        mcrcParam.setSt((String) body.get("start_time"));
        mcrcParam.setEd((String) body.get("end_time"));
        pSize = (Integer) body.get("page");
        lSize = (Integer) body.get("list_size");

        mcrcParam.setPage(pSize, lSize);

        list = mcrcHistDao.selectMcrcHistList(mcrcParam);

        if ((list != null) && (list.size() > 0)) {
            tCnt = mcrcHistDao.selectMcrcHistTotalCount(mcrcParam);
            resData.setTotalCount(tCnt);
            tRCnt = mcrcParam.getRowCount();
            tPages = (tCnt + tRCnt - 1) / tRCnt;
            resData.setTotalPage(tPages);
        }

        for (McrcHistModel hist : list) {
            smtBean = new SmtDataSendRecvHistRes();
            smtBean.setData(hist);
            resData.getList().add(smtBean);
        }

        res.setData(resData);

        return res;
    }

}
