/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import lombok.Data;

@Data
public class RSyncB {
    private Object dataObj;
    private String type;

    public RSyncB(Object dObj, String dType) {
        dataObj = dObj;
        type = dType;
    }
}
