/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvObjectDupBean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MissPrevKnotTimer {

    private static final int N4000 = 4000;
    @Autowired
    @Qualifier("missPrevKnotMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> missPrevKnotMap;

    private long currTime = 0;
    private long recT = 0;
    private List<String> keys = null;

    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {

        if (missPrevKnotMap.size() != 0) {

            currTime = System.currentTimeMillis();

            keys = new ArrayList(missPrevKnotMap.keySet());
            for (String key : keys) {
                recT = missPrevKnotMap.get(key).getRecvTime();

                if ((currTime - recT) > N4000) {
                    missPrevKnotMap.remove(key);
                }

            }

        }

    }
}
