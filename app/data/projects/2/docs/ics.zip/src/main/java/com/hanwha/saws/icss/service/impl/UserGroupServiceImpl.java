/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.GroupReq;
import com.hanwha.saws.icss.dto.request.HistoryReq;
import com.hanwha.saws.icss.dto.request.UserReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.GroupSearchRes;
import com.hanwha.saws.icss.dto.response.LoginHistListRes;
import com.hanwha.saws.icss.dto.response.LoginHistRes;
import com.hanwha.saws.icss.dto.response.LoginRes;
import com.hanwha.saws.icss.dto.response.UserSearchRes;
import com.hanwha.saws.icss.dto.response.UserSessionRes;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.UserGroupDao;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.LoginHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.persistence.model.UserModel;
import com.hanwha.saws.icss.service.LoginSessionService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.service.UserGroupService;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Service("UserGroupService")
@Slf4j
public class UserGroupServiceImpl implements UserGroupService {

    private static final int N1000 = 1000;
    private static final int N900 = 900;
    private static final int N3 = 3;
    private static final int N2 = 2;
    private static final int N8 = 8;
    private static final int N16 = 16;
    private static final String ADM = "Administrator";

    private static final String OPTYPE_LOGIN = "LOGIN";
    private static final String OPTYPE_LOGOUT = "LOGOUT";
    private static final String OPRESULT_SUCCESS = "SUCCESS";
    private static final String OPRESULT_FAIL = "FAIL";

    @Autowired
    PropConfig propConfig;
    @Autowired
    RestClientService restClient;
    @Autowired
    LoginSessionService loginSessionService;
    @Autowired
    NonSyncHistDao nonSyncHistDao;
    @Autowired
    UserGroupDao userGroupDao;
    @Autowired
    RdbSyncRtService rtSync;

    @Value("${prop.host-name}")
    String hostName;

    @Value("${ics.user-key}")
    String userKey;

    private OperationHistModel getOpHistBean(LoginSessionBean bean,
            OpCmdRepo code, NodeModel nm) {
        OperationHistModel model = new OperationHistModel();
        String addInfo = hostName + " " + nm.getName() + " " + nm.getAddrIp();
        String opResult = OpHistRltRepo.getResultSuccess().getCode();

        model.setStartTime(new Date());
        model.setUserId(bean.getUserId());
        model.setUserName(bean.getName());
        model.setUserIp(bean.getIp());
        model.setOperation(code.getMsg());
        model.setAdditionalInfo(addInfo);
        model.setOperationResult(opResult);
        model.setEndTime(new Date());

        return model;
    }

    private void insertOperationHist(OperationHistModel bean, String resultCode,
            String oMsg) {
        try {

            bean.setOperationResult(resultCode);

            if (oMsg.length() > N1000) {
                oMsg = oMsg.substring(0, N900);
            }

            bean.setAdditionalInfo(oMsg);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);

        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString());
        }

    }

    @Override
    public BaseResponse login(UserReq req, String remoteAddr) {
        try {
            UserModel param = new UserModel();
            UserModel uIBean = null;
            boolean isAdm = false;
            boolean isDeny = false;
            LoginSessionBean session = null;
            BaseResponse res = new BaseResponse(ResRepo.getC200());
            LoginRes data = new LoginRes();
            String tmpIp = "";
            ConcurrentHashMap<String, LoginSessionBean> tmpSs = null;
            String t1 = null;
            String t2 = null;

            param.setUserId(req.getId());
            param.setPassword(req.getDecPw());
            param.setUserKey(userKey);
            uIBean = userGroupDao.selectUserInfo(param);
            if (uIBean == null) {

                param.setPassword(null);
                uIBean = userGroupDao.selectUserInfo(param);

                if (uIBean == null) {
                    log.trace("login bean null");
                    return new BaseResponse(ResRepo.getC503());
                }

                param = new UserModel();
                param.setUserId(req.getId());
                param.setFailCount(uIBean.getFailCount() + 1);
                userGroupDao.updateUserInfo(param);
                t1 = uIBean.getUserId();
                t2 = uIBean.getUserName();

                inLogHst(t1, t2, OPTYPE_LOGIN, OPRESULT_FAIL, remoteAddr);

                return new BaseResponse(ResRepo.getC503());
            }

            isAdm = (uIBean.getGroupId().equals(ADM) ? true : false);
            isDeny = (uIBean.getDenyFlag().equals("Y") ? true : false);

            if ((!isAdm) && (isDeny || (uIBean.getFailCount() > N3))) {

                param = new UserModel();
                param.setUserId(req.getId());
                param.setFailCount(uIBean.getFailCount() + 1);

                if (uIBean.getFailCount() > N3) {
                    param.setDenyFlag("Y");
                }

                userGroupDao.updateUserInfo(param);
                t1 = uIBean.getUserId();
                t2 = uIBean.getUserName();

                inLogHst(t1, t2, OPTYPE_LOGIN, OPRESULT_FAIL, remoteAddr);

                return new BaseResponse(ResRepo.getC505());
            }

            if (System.currentTimeMillis() > uIBean.getExpireTime().getTime()) {
                t1 = uIBean.getUserId();
                t2 = uIBean.getUserName();

                inLogHst(t1, t2, OPTYPE_LOGIN, OPRESULT_FAIL, remoteAddr);

                return new BaseResponse(ResRepo.getC504());
            }

            if (!loginSessionService.getCheckSession(uIBean.getUserId())) {
                t1 = uIBean.getUserId();
                t2 = uIBean.getUserName();

                inLogHst(t1, t2, OPTYPE_LOGIN, OPRESULT_FAIL, remoteAddr);

                return new BaseResponse(ResRepo.getC506());
            }

            uIBean.setDecPw(req.getDecPw());

            try {
                session = loginSessionService.genSession(uIBean, remoteAddr);
            } catch (InvalidKeyException | NoSuchAlgorithmException ee) {
                log.warn("login() genSession " + ee.toString());
                return new BaseResponse(ResRepo.getC999());
            }

            param = new UserModel(); // FAILCOUNT 초기화
            param.setUserId(req.getId());
            param.setFailCount(0);
            userGroupDao.updateUserInfo(param);

            t1 = uIBean.getUserId();
            t2 = uIBean.getUserName();

            inLogHst(t1, t2, OPTYPE_LOGIN, OPRESULT_SUCCESS, remoteAddr);

            data.setKey(session.getBearer());
            data.setName(session.getName());
            data.setGroupId(session.getGroupId());
            data.setGroupName(session.getGroupName());
            res.setData(data);

            tmpIp = propConfig.getRIcsIp();
            tmpSs = loginSessionService.getSessionAll();

            restClient.icsSyncSession(tmpIp, tmpSs);

            return res;

        } catch (RuntimeException e) {
            log.warn("login() " + e.toString());
        }
        return new BaseResponse(ResRepo.getC999());
    }

    private void inLogHst(String userId, String userName, String type,
            String result, String remoteAddr) {
        try {
            LoginHistModel hist = new LoginHistModel();

            HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
            NodeModel nodeModel = NodeUtil.getNodeInfoP(hostName, nH);

            hist.setUserId(userId);
            hist.setUserName(userName);
            hist.setUserIp(remoteAddr);

            hist.setNodeId(nodeModel.getNodeId());
            hist.setOperationType(type);
            hist.setOperationResult(result);

            nonSyncHistDao.insertLoginHist(hist);

        } catch (DataAccessException e) {
            log.warn("insertLoginOutHist() " + e.toString());
        }
    }

    @Override
    public BaseResponse logout(LoginSessionBean data, String remoteAddr) {
        try {

            String t1 = data.getUserId();
            String t2 = data.getName();
            ConcurrentHashMap<String, LoginSessionBean> ses = null;
            BaseResponse res = new BaseResponse(ResRepo.getC200());

            loginSessionService.deleteSession(data.getBearer());

            inLogHst(t1, t2, OPTYPE_LOGOUT, OPRESULT_SUCCESS, remoteAddr);

            ses = loginSessionService.getSessionAll();
            restClient.icsSyncSession(propConfig.getRIcsIp(), ses);

            return res;

        } catch (RuntimeException e) {
            log.warn("logout() " + e.toString());
        }
        return new BaseResponse(ResRepo.getC999());
    }
//
//    @Override
//    public BaseResponse unLock(LoginSessionBean session, UserReq req,
//            String remoteAddr, String operation) {
//        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
//        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
//        OpCmdRepo cd = OpCmdRepo.getSawUserUnlock();
//        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);
//
//        String tmpCd = "";
//        UserModel uParam = new UserModel();
//
//        try {
//            OpHistRltRepo.getResultFailed().getCode();
//            if (!(ADM.equals(session.getGroupId()))) {
//                tmpCd = OpHistRltRepo.getResultFailed().getName();
//                insertOperationHist(histBean, tmpCd, "unlock");
//                return new BaseResponse(ResRepo.getC405());
//            }
//
//            uParam = new UserModel();
//            uParam.setUserId(req.getId());
//            uParam.setDenyFlag("N");
//            userGroupDao.updateUserInfo(uParam);
//
//            tmpCd = OpHistRltRepo.getResultSuccess().getName();
//            insertOperationHist(histBean, tmpCd, "unlock");
//
//            return new BaseResponse(ResRepo.getC200());
//        } catch (RuntimeException e) {
//            log.warn("unLock()  " + e.toString());
//            tmpCd = OpHistRltRepo.getResultFailed().getName();
//            insertOperationHist(histBean, tmpCd, e.toString());
//        }
//        return new BaseResponse(ResRepo.getC999());
//    }

    @Override
    public BaseResponse userPwChange(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawUserChangePw();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);

        OperationHistModel histBean = null;
        UserModel uIBean = null;
        String msg = "";
        String tmpCd = "";
        UserModel param = new UserModel();
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        String tmpIp = "";
        ConcurrentHashMap<String, LoginSessionBean> tmpSs = null;
        boolean isAdm = false;
        boolean isAdmMyChange = false;
        String tmpId = null;

        try {

            tmpCd = OpHistRltRepo.getResultFailed().getName();
            histBean = getOpHistBean(session, cd, nodeInfo);
           
            isAdm = ADM.equals(session.getGroupId());
            tmpId = session.getUserId();

            if (isAdm && (data.getId() != null) && tmpId.equals(data.getId())) {
                isAdmMyChange = true;
            }

            if (isAdm && (!isAdmMyChange)) {
                msg = validatePw(data.getDecOldPw(), data.getDecPw());
            } else {
                msg = validatePw(session.getPw(), data.getDecPw());
            }

            if (msg != null) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();

                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            param = new UserModel();

            if (isAdm && (!isAdmMyChange)) {
                param.setUserId(data.getId());
            } else {
                param.setUserId(session.getUserId());
            }

            param.setPassword(data.getDecPw());

            param.updateExpireTime();
            param.setUserKey(userKey);
            userGroupDao.updateUserInfo(param);
            session.setPw(data.getDecPw());

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, "change pw");

            if ((!ADM.equals(session.getGroupId())) && (data.getId() == null)) {
                loginSessionService.deleteSession(session.getBearer());
            }

            tmpIp = propConfig.getRIcsIp();
            tmpSs = loginSessionService.getSessionAll();

            restClient.icsSyncSession(tmpIp, tmpSs);

            return res;

        } catch (RuntimeException e) {
            log.warn("userPwChange() " + e.toString(), e);
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    private String validatePw(String prevPw, String nowPw) {

        boolean isValLen = ((nowPw.length() >= N8) && (nowPw.length() <= N16));

        boolean hasUpper = nowPw.matches(".*[A-Z].*");
        boolean hasLower = nowPw.matches(".*[a-z].*");
        boolean hasDigit = nowPw.matches(".*[0-9].*");
        String pt = ".*[^a-zA-Z0-9].*";

        boolean hasSpecial = nowPw.matches(pt);

        boolean hasSequential = false;
        boolean hasRepeats = false;

        char c1 = 0;
        char c2 = 0;
        char c3 = 0;

        boolean isSame = false;
        boolean hasAll = false;

        if (!isValLen) {
            log.trace("pw failed");
            return "비밀번호는 8~16자 사이여야 합니다.";
        }
        
        hasAll = (hasUpper && hasLower && hasDigit && hasSpecial);

        if (!hasAll) {
            log.trace("val failed");
            return "대문자, 소문자, 숫자, 특수문자를 모두 포함해야 합니다.";
        }

        for (int i = 0; i < (nowPw.length() - N2); i++) {

            c1 = nowPw.charAt(i);
            c2 = nowPw.charAt(i + 1);
            c3 = nowPw.charAt(i + N2);

            if ((c2 == c1 + 1) && (c3 == c2 + 1)) {
                hasSequential = true;
                break;
            }

            if ((c1 == c2) && (c2 == c3)) {
                hasRepeats = true;
                break;
            }

        }

        if (hasSequential) {
            log.trace("val failed");
            return "연속된 키보드 배열이나 숫자는 사용할 수 없습니다.";
        }
        if (hasRepeats) {
            log.trace("val failed");
            return "같은 문자를 3번 이상 반복할 수 없습니다.";
        }

        if (prevPw != null) {
            isSame = prevPw.equals(nowPw);

            if (isSame) {
                log.trace("val failed");
                return "이전 비밀번호와 동일할 수 없습니다.";
            }
        }

        return null;
    }

    @Override
    public BaseResponse getUserList(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawUserList();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);
        HashMap<String, String> param = new HashMap<>();
        List<UserModel> list = null;
        ArrayList<UserSearchRes> resData = new ArrayList<>();
        UserSearchRes d = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<UserSearchRes>> resHash = null;
        String tmpCd = "";

        try {

            if ((data.getId() != null) && (!data.getId().isBlank())) {
                param.put("userId", data.getId());
            }

            if ((data.getName() != null) && (!data.getName().isBlank())) {
                param.put("userName", data.getName());
            }

            list = userGroupDao.selectUserGroupList(param);

            for (UserModel m : list) {
                d = new UserSearchRes();
                d.setData(m);
                resData.add(d);
            }

            if (resData != null) {
                resHash = new HashMap<>();
                resHash.put("list", resData);
                res.setData(resHash);
            }
            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, " search user");

            return res;

        } catch (RuntimeException e) {
            log.warn("getUserList() " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse userAdd(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawUserAdd();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        UserModel uParam = new UserModel();
        GroupModel gParam = new GroupModel();
        String tmpCd = "";
        String msg = "";
        UserModel iUP = new UserModel();

        try {
            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "user add");
                return new BaseResponse(ResRepo.getC405());
            }

            uParam.setUserId(data.getId());
            if (userGroupDao.selectUserInfo(uParam) != null) {
                msg = "동일한 ID가 있습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            gParam.setGroupId(data.getGroupId());

            if (userGroupDao.selectGroupInfo(gParam) == null) {
                msg = "Group ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            msg = validatePw(null, data.getDecPw());
            if (msg != null) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            iUP = new UserModel();
            iUP.setUserId(data.getId());
            iUP.setSysId(nodeInfo.getName());
            iUP.setUserName(data.getName());
            iUP.setPassword(data.getDecPw());
            iUP.setUserKey(userKey);
            iUP.setEmail(data.getEmail());
            iUP.setDesc64(data.getDesc());
            iUP.setTelephone(data.getPhone());
            iUP.setMobile(data.getPhone());
            iUP.setGroupId(data.getGroupId());
            userGroupDao.insertUserInfo(iUP);

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, data.getId() + " user add");

            return res;

        } catch (RuntimeException e) {
            log.warn("userAdd() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse userModify(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawUserModify();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        UserModel uParam = new UserModel();
        GroupModel gParam = new GroupModel();
        String tmpCd = "";
        String msg = "";
        boolean isMatchId = false;
        UserModel uIP = new UserModel();

        try {

            isMatchId = session.getUserId().equals(data.getId());

            if (!ADM.equals(session.getGroupId()) && !isMatchId) {

                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "user modify");
                return new BaseResponse(ResRepo.getC406());
            }

            uParam.setUserId(data.getId());
            if (userGroupDao.selectUserInfo(uParam) == null) {
                msg = "동일한 ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);
                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            gParam.setGroupId(data.getGroupId());

            if (userGroupDao.selectGroupInfo(gParam) == null) {
                msg = "Group ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);
                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            uIP = new UserModel();
            uIP.setUserId(data.getId());
            uIP.setSysId(nodeInfo.getName());
            uIP.setUserName(data.getName());
            uIP.setEmail(data.getEmail());
            uIP.setDesc64(data.getDesc());
            uIP.setTelephone(data.getPhone());
            uIP.setMobile(data.getPhone());
            uIP.setGroupId(data.getGroupId());
            uIP.setDenyFlag(data.getDeny());
            userGroupDao.updateUserInfo(uIP);

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, data.getId() + " user modify");

            return res;

        } catch (RuntimeException e) {
            log.warn("userModify() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }
        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse userDelete(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawUserDelete();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        UserModel uParam = new UserModel();
        UserModel param = new UserModel();

        LoginSessionBean uSess = null;
        String tmpCd = "";
        String msg = "";
        long cTime = 0;

        String tmpIp = "";
        ConcurrentHashMap<String, LoginSessionBean> tmpSs = null;
        String t1 = null;
        String t2 = null;

        try {
            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "user delete");
                return new BaseResponse(ResRepo.getC405());
            }

            uParam.setUserId(data.getId());
            if (userGroupDao.selectUserInfo(uParam) == null) {
                msg = "동일한 ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);
                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            param.setUserId(data.getId());
            userGroupDao.deleteUserInfo(param);

            tmpCd = OpHistRltRepo.getResultSuccess().getName();

            insertOperationHist(histBean, tmpCd, data.getId() + " user delete");

            uSess = loginSessionService.getUserSession(data.getId());

            cTime = System.currentTimeMillis();

            if ((uSess != null) && (uSess.getExpireTime() > cTime)) {

                t1 = uSess.getUserId();
                t2 = uSess.getName();

                inLogHst(t1, t2, OPTYPE_LOGOUT, OPRESULT_SUCCESS, remoteAddr);

                tmpIp = propConfig.getRIcsIp();
                tmpSs = loginSessionService.getSessionAll();

                restClient.icsSyncSession(tmpIp, tmpSs);
                loginSessionService.deleteSession(uSess.getBearer());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (RuntimeException e) {
            log.warn("userDelete() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse getGroupList(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawGroupList();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        HashMap<String, String> param = new HashMap<>();
        List<GroupModel> list = null;
        ArrayList<GroupSearchRes> resData = new ArrayList<>();
        GroupSearchRes d = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        String tmpCd = "";
        HashMap<String, List<GroupSearchRes>> resH = null;

        try {

            if (data.getId() != null) {
                param.put("id", data.getId());
            }

            if (data.getName() != null) {
                param.put("name", data.getName());
            }

            list = userGroupDao.selectGroupSearchList(param);

            for (GroupModel m : list) {
                d = new GroupSearchRes();
                d.setData(m);
                resData.add(d);
            }

            if (resData != null) {
                resH = new HashMap<>();
                resH.put("list", resData);
                res.setData(resH);
            }
            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, " search group");

            return res;

        } catch (RuntimeException e) {
            log.warn("getGroupList() " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse groupAdd(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawGroupAdd();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";
        String msg = "";
        GroupModel gParam = new GroupModel();
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        try {

            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "group add");
                return new BaseResponse(ResRepo.getC405());
            }

            gParam.setGroupId(data.getId());

            if (userGroupDao.selectGroupInfo(gParam) != null) {
                msg = "Group ID가 이미 있습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);
                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            gParam.setSysId(nodeInfo.getName());
            gParam.setGroupName(data.getName());
            gParam.setDesc64(data.getDesc());
            userGroupDao.insertGroupInfo(gParam);
            rtSync.insertQueue(gParam, "INSERT");

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            insertOperationHist(histBean, tmpCd, data.getId() + " group add");

            return res;

        } catch (RuntimeException e) {
            log.warn("groupAdd() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse groupModify(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawGroupModify();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";
        String msg = "";
        GroupModel gParam = new GroupModel();
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        try {
            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "group modify");
                return new BaseResponse(ResRepo.getC405());
            }

            gParam.setGroupId(data.getId());

            if (userGroupDao.selectGroupInfo(gParam) == null) {
                msg = "Group ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            gParam.setSysId(nodeInfo.getName());
            gParam.setGroupName(data.getName());
            gParam.setDesc64(data.getDesc());
            userGroupDao.updateGroupInfo(gParam);
            rtSync.insertQueue(gParam, "UPDATE");

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            msg = " group modify";
            insertOperationHist(histBean, tmpCd, data.getId() + msg);

            return res;

        } catch (RuntimeException e) {
            log.warn("groupModify() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse groupDelete(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawGroupDelete();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";
        String msg = "";
        GroupModel gParam = new GroupModel();
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        List<GroupModel> tmpList = null;

        try {
            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "group delete");
                return new BaseResponse(ResRepo.getC405());
            }

            gParam.setGroupId(data.getId());

            if (userGroupDao.selectGroupInfo(gParam) == null) {
                msg = "Group ID가 없습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC507().getCode(), msg);
            }

            tmpList = userGroupDao.selectGroupUserList(gParam);

            if ((tmpList != null) && (tmpList.size() > 0)) {
                msg = "Group ID를 사용하는 사용자가 있습니다";
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, msg);

                return new BaseResponse(ResRepo.getC515().getCode(), msg);
            }

            userGroupDao.deleteGroupInfo(gParam);
            rtSync.insertQueue(gParam, "DELETE");

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            msg = " group delete";
            insertOperationHist(histBean, tmpCd, data.getId() + msg);

            return new BaseResponse(ResRepo.getC200());

        } catch (RuntimeException e) {
            log.warn("groupDelete() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse getSessionList(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawSessionList();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";
        String msg = "";

        String searchId = null;
        String searchName = null;
        boolean hasSearchId = false;
        boolean hasSearchName = false;

        ConcurrentHashMap<String, LoginSessionBean> sessionList = null;
        List<LoginSessionBean> snapshot = null;
        List<UserSessionRes> resData = new ArrayList<>();
        UserSessionRes res = null;
        boolean match = false;
        HashMap<String, List<UserSessionRes>> resHash = new HashMap<>();

        try {

            sessionList = loginSessionService.getSessionAll();

            searchId = data.getId();
            searchName = data.getName();
            hasSearchId = ((searchId != null) && (!searchId.isBlank()));
            hasSearchName = ((searchName != null) && (!searchName.isBlank()));
            snapshot = new ArrayList<>(sessionList.values());

            for (LoginSessionBean ss : snapshot) {
                match = false;
                res = new UserSessionRes();

                if ((!hasSearchId) && (!hasSearchName)) {
                    match = true;
                } else {
                    if (hasSearchId && (ss.getUserId().contains(searchId))) {
                        match = true;
                    }
                    if (hasSearchName && (ss.getName().contains(searchName))) {
                        match = true;
                    }
                }

                if (match) {
                    res.setData(ss);
                    resData.add(res);
                }

            }

            if (resData.size() > 0) {
                resHash.put("list", resData);
            }

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            msg = data.getId() + " login session search";
            insertOperationHist(histBean, tmpCd, msg);

            return new BaseResponse(ResRepo.getC200(), resHash);

        } catch (RuntimeException e) {
            log.warn("getSessionList() " + data.getId() + " " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse forceLogout(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawForceLogout();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";
        String msg = "";

        LoginSessionBean userSess = null;
        long cTime = 0;

        String tmpIp = "";
        ConcurrentHashMap<String, LoginSessionBean> tmpSs = null;
        String t1 = null;
        String t2 = null;

        try {
            if (!ADM.equals(session.getGroupId())) {
                tmpCd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tmpCd, "force-logout");
                return new BaseResponse(ResRepo.getC405());
            }

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
            msg = data.getId() + " force-logout";
            insertOperationHist(histBean, tmpCd, msg);

            userSess = loginSessionService.getUserSession(data.getId());
            cTime = System.currentTimeMillis();

            if ((userSess != null) && (userSess.getExpireTime() > cTime)) {
                t1 = userSess.getUserId();
                t2 = userSess.getName();

                inLogHst(t1, t2, OPTYPE_LOGOUT, OPRESULT_SUCCESS, remoteAddr);

                tmpIp = propConfig.getRIcsIp();

                loginSessionService.deleteSession(userSess.getBearer());

                tmpSs = loginSessionService.getSessionAll();
                restClient.icsSyncSession(tmpIp, tmpSs);

            }

            return new BaseResponse(ResRepo.getC200());

        } catch (RuntimeException e) {
            log.warn(data.getId() + " forceLogout " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse getLoginHistoryList(LoginSessionBean session,
            HistoryReq data, String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nH = propConfig.getNodeInfoHash();
        OpCmdRepo cd = OpCmdRepo.getSawLoginHist();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nH);
        OperationHistModel histBean = getOpHistBean(session, cd, nodeInfo);

        String tmpCd = "";

        LoginHistModel param = new LoginHistModel();
        List<LoginHistModel> list = null;
        LoginHistListRes resData = new LoginHistListRes();

        int tCnt = 0;
        int tPage = 0;
        LoginHistRes tmp = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        try {

            if ((data.getEndTime() == null) || (data.getStartTime() == null)) {
                data.setLastMonth();
            }

            param.setPage(data.getPage(), data.getListSize());
            param.setStartTime(data.getStartTime());
            param.setEndTime(data.getEndTime());

            if ((data.getId() != null) && (!data.getId().isBlank())) {
                param.setUserId(data.getId());
            }

            param.setSearchOPType(data.getType());

            list = nonSyncHistDao.selectLoginHistList(param);

            if ((list != null) || (list.size() > 0)) {
                tCnt = nonSyncHistDao.selectLoginHistListTotalCount(param);
                tPage = (tCnt + data.getListSize() - 1) / data.getListSize();
                resData.setTotalPage(tPage);
                resData.setTotalCount(tCnt);
            }

            for (LoginHistModel m : list) {
                resData.setTotalPage(m.getTotalPage());
                tmp = new LoginHistRes();

                tmp.setData(m);
                resData.getList().add(tmp);
            }

            res.setData(resData);

            tmpCd = OpHistRltRepo.getResultSuccess().getName();
        
            insertOperationHist(histBean, tmpCd, " search login history");

            return res;

        } catch (RuntimeException e) {
            log.warn("getLoginHistoryList() " + e.toString());
            tmpCd = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tmpCd, e.toString());
        }

        return new BaseResponse(ResRepo.getC999());
    }

}
