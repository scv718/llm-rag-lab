/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.UncheckedIOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.util.LogKeyUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SyncFailoverBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    
    @Autowired PropConfig prop;
    @Value("${ics.failover-dir.mcrc}") String mcrcDir;
    @Value("${ics.failover-dir.kamd}") String kamdDir;
    @Value("${ics.failover-dir.mcrc-detail}") String mcrcDetailDir;
    @Value("${ics.failover-dir.kamd-detail}") String kamdDetailDir;
    @Value("${ics.failover-dir.alarm-hist}") String alarmHistDir;
    @Value("${ics.failover-dir.msg-hist}") String msgHistDir;
    @Value("${ics.failover-dir.air-hist}") String airHistDir;
    @Value("${ics.failover-dir.emer-hist}") String emerHistDir;
    @Value("${ics.failover-dir.airdefwarn-hist}") String airDefWarnDir;
    @Value("${ics.failover-dir.status-hist}") String statusHistDir;
    @Autowired IcsSyncService syncService;
    
    private String today = "";

    @Scheduled(
            fixedDelayString = "${cron.failover-sync-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void dbSyncMonitor() throws IOException {

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());
        
        statusLog.debug("DB FAILOVER SYNC MONITOR BATCH START");

        try {
            eventHandle();
        } catch (NoClassDefFoundError e) {
            log.warn("dbSyncMonitor() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("dbSyncMonitor batch " + e.toString());
        }

        statusLog.debug("DB FAILOVER SYNC MONITOR BATCH END");

    }

    private void eventHandle() {
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        
        today = formatter.format(LocalDateTime.now());

        mcrcFailover();
        mcrcDetailFailover();
        kamdFailover();
        kamdDetailFailover();
        alarmHistFailover();
        msgHistFailover();
        airRaidHistFailover();
        emerHistFailover();
        airDefWarnHistFailover();
        statusHistFailover();
        
    }

    private void airDefWarnHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();        
        List<Path> subDirNames = new ArrayList<>();        
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> aStream = Files.list(Paths.get(airDefWarnDir))) {
            
            for (Path subDir : aStream.toList()) {
                
                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }
                
            }            
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("airDefWarnHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("airDefWarnHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {

                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {   
                        fNames.add(file);
                    }

                }
                
                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("AIR DEF WARN HIST file {} insert", failoverFile);
                    airDefWarnHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }
                
            } catch (RuntimeException | IOException e2) {
                log.info("airDefWarnHistFailover failed {}", e2.toString());
            }
            
        }
        
    }

    private void statusHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(statusHistDir))) {

            for (Path subDir : stream.toList()) {
                
                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }
                
            }            

            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("statusHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("statusHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }
                
                fNames.sort(new PathCreationTimeComparator());

                for (Path failoverFile : fNames) {
                    log.debug("STATUS HIST file {} insert", failoverFile);
                    statusHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("statusHistFailover work failed {}", e2.toString());
            }
            
        }
        
    }

    private void emerHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(emerHistDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }            
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("emerHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("emerHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("EMERGENCY HIST file {} insert", failoverFile);
                    emerHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("emerHistFailover work dir failed {}", e2.toString());
            }

        }

    }

    private void airRaidHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(airHistDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }   
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("airRaidHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("airRaidHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("AIR WARN HIST file {} insert", failoverFile);
                    airHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("airRaidHistFailover work failed {}", e2.toString());
            }

        }
        
    }

    private void msgHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(msgHistDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("msgHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("msgHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("MESSAGE HIST file {} insert", failoverFile);
                    msgHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("msgHistFailover work dir failed {}", e2.toString());
            }

        }
        
    }

    private void alarmHistFailover() {
        
        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(alarmHistDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);
            
        } catch (NoSuchFileException e) {
            log.debug("alarmHistFailover Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("alarmHistFailover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("ALARM HIST file {} insert", failoverFile);
                    alarmHistObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("alarmHistFailover work dir failed {}", e2.toString());
            }

        }

    }

    private void kamdFailover() {

        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(kamdDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }

            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);

        } catch (NoSuchFileException e) {
            log.debug("KAMDHist Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("KAMDHist Failover work dir failed {}", e.toString());
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {

                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("KAMD HIST file {} insert", failoverFile);
                    kamdObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("KAMD Failover work dir failed {}", e2.toString());
            }

        }

        for (Path path : dateDir) {

            try {

                if (Files.isDirectory(path) && isDirectoryEmpty(path)) {
                    Files.delete(path);
                }

            } catch (IOException e3) {
                log.warn("KAMD Failover dir del failed " + e3.toString());
            }
            
        }

    }

    private void kamdDetailFailover() {

        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(kamdDetailDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }

            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);

        } catch (NoSuchFileException e) {
            log.debug("KAMDDetailHist Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn(
                    "KAMDDetailHist Failover work dir failed {}", e.toString()
            );
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {

                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("KAMD DETAIL HIST file {} insert", failoverFile);
                    kamdDetailObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("KAMD DETAIL Failover work dir failed {}",
                        e2.toString());
            }

        }

        for (Path path : dateDir) {

            try {

                if (Files.isDirectory(path) && isDirectoryEmpty(path)) {
                    Files.delete(path);
                }

            } catch (IOException e3) {
                log.warn("KAMD Failover dir del failed " + e3.toString());
            }
            
        }

    }
    
    private void mcrcFailover() {

        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(mcrcDir))) {
            
            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }
            
            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);

        } catch (NoSuchFileException e) {
            log.debug("MCRCHIST Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn("MCRCHIST Failover work dir failed {}", e.toString());
        }
        
        for (Path path : dateDir) {
            try (Stream<Path> fStream = Files.list(path)) {
                
                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {                        
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("MCRC HIST file {} insert", failoverFile);
                    mcrcObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("MCRCHIST Failover work dir failed {}", e2.toString());
            }

        }

        for (Path path : dateDir) {

            try {

                if (Files.isDirectory(path) && isDirectoryEmpty(path)) {
                    Files.delete(path);
                }

            } catch (IOException e3) {
                log.warn("MCRCHIST Failover dir del failed " + e3.toString());
            }

        }

    }

    private void mcrcDetailFailover() {

        ArrayList<Path> dateDir = new ArrayList<>();
        List<Path> subDirNames = new ArrayList<>();
        List<Path> fNames = new ArrayList<>();
        
        try (Stream<Path> stream = Files.list(Paths.get(mcrcDetailDir))) {

            for (Path subDir : stream.toList()) {

                if (Files.isDirectory(subDir)) {
                    subDirNames.add(subDir);
                }

            }

            dateDir.addAll(subDirNames);
            Collections.sort(dateDir);

        } catch (NoSuchFileException e) {
            log.debug("MCRCDetailHist Failover work dir none");
        } catch (RuntimeException | IOException e) {
            log.warn(
                    "MCRCDetailHist Failover work dir failed {}", e.toString()
            );
        }

        for (Path path : dateDir) {
            
            try (Stream<Path> fStream = Files.list(path)) {

                for (Path file : fStream.toList()) {

                    if (!Files.isDirectory(file)) {
                        fNames.add(file);
                    }

                }

                fNames.sort(new PathCreationTimeComparator());
                
                for (Path failoverFile : fNames) {
                    log.debug("MCRC DETAIL HIST file {} insert", failoverFile);
                    mcrcDetailObjectRead(failoverFile.toString());
                }

                if (fNames.isEmpty()) {
                    deleteDir(path);
                }

            } catch (RuntimeException | IOException e2) {
                log.info("MCRC DETAIL Failover work dir failed {}",
                        e2.toString());
            }

        }

        for (Path path : dateDir) {

            try {

                if (Files.isDirectory(path) && isDirectoryEmpty(path)) {
                    Files.delete(path);
                }

            } catch (IOException e3) {
                log.warn("MCRC Failover dir del failed " + e3.toString());
            }
            
        }

    }
    
    private boolean isDirectoryEmpty(Path dirPath) throws IOException {

        boolean isDirEmpty = false;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dirPath)) {

            isDirEmpty = !stream.iterator().hasNext();

            return isDirEmpty;

        }

    }

    /*
     * ObjectInputStream ois 부분은 아래 한칸만 띄우면 된다는 이유로 이상태로 실험 
     * 아닐경우 전통적인 try catch로 변경
     */
    private void mcrcObjectRead(String file) {

        ArrayList<McrcHistModel> bulkList = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("MCRCHIST File is empty: {}", file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("MCRCHIST exception");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            bulkList = (ArrayList<McrcHistModel>) ois.readObject();

            syncService.syncMcrcHistBulkInsert(bulkList);
        } catch (IllegalStateException e) {
            log.warn("MCRCHIST Failover Remote DB not alive {}",
                    e.getMessage());
            return;
        } catch (DataAccessException e) {
            log.error("MCRCHIST Failover Remote DB insert failed {}",
                    e.getMessage());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("MCRCHIST Failover Remote DB insert failed  " +
                    e.toString());
            return;
        }

        try {
            log.debug("MCRC HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("MCRCHIST Failover file delete failed  " + e2.toString());
        }
    }
    
    private void mcrcDetailObjectRead(String file) {

        ArrayList<McrcHistDetailModel> bulkList = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("MCRCHIST File is empty: {}", file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("MCRCHIST File exception");
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            bulkList = (ArrayList<McrcHistDetailModel>) ois.readObject();
            syncService.syncMcrcDetailHistBulkInsert(bulkList);
        } catch (IllegalStateException e) {
            log.warn("MCRCHIST Failover Remote DB not alive {}",
                    e.getMessage());
            return;
        } catch (DataAccessException e) {
            log.error("MCRCHIST Failover Remote DB insert failed {}",
                    e.getMessage());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("MCRCHIST Failover Remote DB insert failed  " +
                    e.toString());
            return;
        }

        try {
            log.debug("MCRC DETAIL HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("MCRCDDETAILHIST Failover file delete failed  " +
                    e2.toString());
        }

    }

    private void kamdObjectRead(String file) {

        ArrayList<KamdHistModel> bulkList = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("KAMDHIST File is empty: {}", file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("KAMDHIST File exception");
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            bulkList = (ArrayList<KamdHistModel>) ois.readObject();
            syncService.syncKamdHistBulkInsert(bulkList);
        } catch (IllegalStateException e) {
            log.warn("KAMDHIST Failover Remote DB not alive {}",
                    e.getMessage());
            return;
        } catch (DataAccessException e) {
            log.error("KAMDHIST Failover Remote DB insert failed {}",
                    e.getMessage());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("KAMDHIST Failover Remote DB insert failed  " +
                    e.toString());
            return;
        }

        try {
            log.debug("KAMD HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("KAMDHIST Failover file delete failed  " + e2.toString());
        }

    }
    
    private void kamdDetailObjectRead(String file) {

        ArrayList<KamdHistDetailModel> bulkList = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("KAMDHIST File is empty: {}", file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("KAMDHIST File exception");
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            bulkList = (ArrayList<KamdHistDetailModel>) ois.readObject();
            syncService.syncKamdDetailHistBulkInsert(bulkList);
        } catch (IllegalStateException e) {
            log.warn("KAMDDETAILHIST Failover Remote DB not alive {}",
                    e.getMessage());
            return;
        } catch (DataAccessException e) {
            log.error("KAMDDETAILHIST Failover Remote DB insert failed {}",
                    e.getMessage());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("KAMDDETAILHIST Failover Remote DB insert failed  " +
                    e.toString());
            return;
        }

        try {
            log.debug("KAMD DETAIL HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("KAMDDETAILHIST Failover file delete failed  " +
                    e2.toString());
        }

    }

    private void alarmHistObjectRead(String file) {
        
        String logT = "AlarmHistObjectRead";
        AlarmHistModel model = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("file excep");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (AlarmHistModel) ois.readObject();
            syncService.insertAlarmHistInsert(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("ALARM HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }

    }

    private void msgHistObjectRead(String file) {

        String logT = "msgHistObjectRead";
        MessageHistModel model = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("msgHist exception");
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (MessageHistModel) ois.readObject();

            syncService.insertMessageHist(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("MESSAGE HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }

    }

    private void airHistObjectRead(String file) {

        String logT = "airHistObjectRead";
        AirRaidHistModel model = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("airHist file exception");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (AirRaidHistModel) ois.readObject();

            syncService.insertAirHist(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("AIR WARN HIST file {} delete", file);
            Files.delete(Paths.get(file));
            
        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }
        
    }

    private void emerHistObjectRead(String file) {
        
        String logT = "emerHistObjectRead";
        EmerHistModel model = null;

        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("emerHist file exception");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (EmerHistModel) ois.readObject();
            syncService.insertEmerHist(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("EMERGENCY HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }

    }

    private void airDefWarnHistObjectRead(String file) {

        String logT = "airDefWarnHistObjectRead";
        AirDefWarnHistModel model = null;
        
        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("file excep");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (AirDefWarnHistModel) ois.readObject();
            syncService.insertAirDefWarnHist(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("AIR DEFENCE WARN HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }

    }

    private void statusHistObjectRead(String file) {

        String logT = "statusHistObjectRead";
        StatusHistModel model = null;
        Path filePath = Paths.get(file);
        long size = 0;
        
        try {
            
            size = Files.size(filePath);
            if (size == 0) {
                log.warn("{} File is empty: {}", logT, file);
                Files.delete(filePath); 
                return;
            }            
        } catch (Exception e) {
            log.trace("statusHist file exception");
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (StatusHistModel) ois.readObject();
            syncService.insertStatusHist(model);
        } catch (IllegalStateException e) {
            log.warn("{} Failover Remote DB not alive {}", logT, e.toString());
            return;
        } catch (DataAccessException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        } catch (IOException | ClassNotFoundException e) {
            log.warn("{} Failover db insert failed {}", logT, e.toString());
            return;
        }

        try {
            log.debug("STATUS HIST file {} delete", file);
            Files.delete(Paths.get(file));

        } catch (IOException e2) {
            log.warn("{} Failover file delete failed {}", logT, e2.toString());
        }

    }

    private void deleteDir(Path path) {

        String dateName = path.getFileName().toString();

        if (!today.equals(dateName)) {

            try {

                Files.deleteIfExists(path);

            } catch (IOException ioE) {
                log.warn("Dir Delete failed  " + path);
            }
            
        }
        
    }
    

    private class PathCreationTimeComparator implements Comparator<Path> {
       
        private FileTime getCreationTime(Path path) {

            Class<BasicFileAttributes> type = BasicFileAttributes.class;

            try {

                return Files.readAttributes(path, type).creationTime();

            } catch (IOException e) {
                throw new UncheckedIOException("파일 속성 없음: " + path, e);
            }

        }
        
        @Override
        public int compare(Path o1, Path o2) {
            FileTime fa1 = getCreationTime(o1);
            FileTime fa2 = getCreationTime(o2);
            
            return fa1.compareTo(fa2);
        }
    }
    
}
