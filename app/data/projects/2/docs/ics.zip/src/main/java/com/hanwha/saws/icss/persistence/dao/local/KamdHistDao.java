/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.KamdHistModel;

public interface KamdHistDao {

    public List<KamdHistModel> selectKamdHistList(KamdHistModel model);

    public List<KamdHistModel> selectKamdHistSccSearch(KamdHistModel model);

    public long selectKamdHistTotalCount(KamdHistModel model);

    public void insertKamdHistInfo(KamdHistModel model);

    public void insertKamdHistBulkInsert(List<KamdHistModel> list);
}
