/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service.impl;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import com.hanhwa.saws.mediator.miss.service.EncodeIF;
import com.hanhwa.saws.mediator.miss.service.McrcService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Service("McrcService")
@Slf4j
public class McrcServiceImpl implements McrcService {

    @Autowired @Qualifier("mcrcSendQueue")
    private ConcurrentLinkedQueue<EncodeIF> mcrcSendQueue;

    @Autowired @Qualifier("McrcSenderExecutor")
    private TaskExecutor mcrcSenderExecutor;

    @Value("${mediator.mode}") private String mode;

    @Autowired private McrcUdpSend mcrcUdpSend;

    @PostConstruct
    public void init() {

        if (!"mcrc".equalsIgnoreCase(mode)) {
            log.debug("McrcService not running. mode: {}", mode);
            return;
        }

        log.debug("MCRC Send UDP thread start");
        mcrcSenderExecutor.execute(mcrcUdpSend);

    }

    @Override
    public void putRasd(EncodeIF encodedData) {
        mcrcSendQueue.offer(encodedData);
    }

}
