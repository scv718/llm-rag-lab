/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.SmsTcpMsgBean;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.SmsARepo;
import com.hanwha.saws.icss.dto.code.SmsBRepo;
import com.hanwha.saws.icss.dto.code.SmsCodeTableEnumIf;
import com.hanwha.saws.icss.dto.code.SmsRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.modem.IBitStatus;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.SmtModemRes;
import com.hanwha.saws.icss.dto.response.SmtSmsDiagnosisRes;
import com.hanwha.saws.icss.endpoint.SmsClient;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.SmsService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.NetworkPingUtil;

import lombok.extern.slf4j.Slf4j;

@Service("SmsService")
@Slf4j
public class SmsServiceImpl implements SmsService {

    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N12 = 12;
    private static final int N8 = 8;
    private static final int N900 = 900;
    private static final int N1000 = 1000;
    private static final int N100 = 100;

    private static final int SMS_FREQ_MIN = 950_000_000;
    private static final int SMS_FREQ_STEP = 2500;

    private static final int CMD_HEARTBEAT = 0;
    private static final int CMD_RESET = 1;
    private static final int CMD_DIAGNOSIS = 2;
    private static final int CMD_FAILOVER = 3;
    private static final int CMD_CONTROL_UNIT_SET = 4;
    private static final int CMD_CONTROL_UNIT_STATUS = 5;
    private static final int SMS_MODEM_BER_THRES_STATUS = 6;
    private static final int SMS_MODEM_BER_THRES_SET = 7;
    private static final int SMS_MODEM_STATUS = 8;
    private static final int SMS_CONV_UPC_SET = 9;
    private static final int SMS_CONV_DNC_SET = 10;
    private static final int SMS_CONV_STATUS = 11;
    private static final int SMS_CONV_LOOPBACK_SET = 12;
    private static final int SMS_CONV_BITLEVEL_SET = 13;

    @Autowired PropConfig prop;

    @Autowired StatusConfigDao stConfDao;
    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired NonSyncHistDao nonSyncHistDao;

    @Autowired RdbSyncRtService rtSync;

    @Autowired AlarmService alarmService;

//    @Autowired SmsEService smsEService;
    
    @Value("${prop.host-name}") String hostName;

    private final SmsClient smsClientMgr; // 인터페이스만 의존

    @Autowired
    public SmsServiceImpl(SmsClient smsClient) {
        this.smsClientMgr = smsClient;
    }

//    @Override
//    public BaseResponse setControlUnit(int nodeId, String targetIp,
//            String remoteIp, LoginSessionBean bean) {
//
//        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
//        NodeRepo nCd = NodeRepo.getSmsA();
//        NodeModel node = prop.getNodeInfoHash().get(nodeId);
//        OpCmdRepo cCd = OpCmdRepo.getSmsControlUnitSet();
//        String tMsg = null;
//        String tLog = null;
//        OperationHistModel oHBean = getOpHistBean(bean, cCd, node);
//        int resetCdRes = -1;
//        SmsTcpObjectBean sTOB = null;
//
//        if (node.getNodeId() == NodeRepo.getSmsB().getCode()) {
//            nCd = NodeRepo.getSmsB();
//        }
//
//        try {
//            
//            stmB.setReqInfo(CMD_CONTROL_UNIT_SET,
//                    new Object[] { targetIp, remoteIp });
//            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);
//
//            if ((sTOB != null) && (sTOB.getData() != null)) {
//                resetCdRes = (int) sTOB.getData()[0];
//            }
//
//            if (resetCdRes == 0) {
//                tMsg = OpHistRltRepo.getResultSuccess().getName();
//                tLog = nCd.getName() + " Control unit set";
//                insertOperationHist(oHBean, tMsg, tLog);
//
//            } else {
//                tMsg = OpHistRltRepo.getResultFailed().getName();
//                tLog = nCd.getName() + " Control unit set failed";
//                insertOperationHist(oHBean, tMsg, tLog);
//
//                return new BaseResponse(ResRepo.getC404());
//            }
//
//            return new BaseResponse(ResRepo.getC200());
//        } catch (IOException | CompletionException e) {
//            tLog = "setControlUnit() Control unit set {} {}";
//            log.warn(tLog, nCd, e.toString());
//            tMsg = OpHistRltRepo.getResultFailed().getName();
//            insertOperationHist(oHBean, tMsg, e.toString());
//
//            return new BaseResponse(ResRepo.getC999());
//        }
//    }

    @Override
    public void heartbeat(NodeRepo code) {

        try {
            
            HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
            NodeModel smsANode = nHash.get(NodeRepo.getSmsA().getCode());
            NodeModel smsBNode = nHash.get(NodeRepo.getSmsB().getCode());
            boolean isPing = false;
            SmsTcpMsgBean bean = new SmsTcpMsgBean();
            SmsTcpObjectBean data = null;
            int heartbeatType = 0;
            
            //ping 체크 우선 
            if ((code.getCode() == NodeRepo.getSmsA().getCode())) {
                isPing = new NetworkPingUtil(smsANode.getAddrIp(), 0, N100)
                        .isHostAliveByPing();
            } else {
                isPing = new NetworkPingUtil(smsBNode.getAddrIp(), 0, N100)
                        .isHostAliveByPing();
            }
            if (!isPing) {
                log.debug("SMS {} ping failed", smsANode.getAddrIp());

            } else {

                bean.setReqInfo(CMD_HEARTBEAT, null);
                data = smsClientMgr.sendRequestMsg(bean, code);

                if (data != null) {
                    byte[] buf = data.getData();
                    if (buf != null && buf.length > 0) {
                        heartbeatType = buf[0] & 0xFF;
                    }
                }
            }
          
            setSmsStatus(code, heartbeatType);

        } catch (IOException | CompletionException e) {
            log.warn("Sms heartbeat() " + code + "  " + e.toString());
            setSmsStatus(code, SmsRepo.getStatusUnknown().getCode());
        }
    }

    @Override
    public BaseResponse reset(OperationHistModel histBean, NodeModel nodeInfo,
            LoginSessionBean bean) {

        String tMsg = null;

        try {
            SmsTcpMsgBean stmB = new SmsTcpMsgBean();
            NodeRepo nCd = NodeRepo.getSmsA();
            SmsTcpObjectBean sTOB = null;
            int resetCdRes = -1;

            stmB.setReqInfo(CMD_RESET, null);

            if ((nodeInfo.getNodeId()) == (NodeRepo.getSmsB().getCode())) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(histBean, tMsg, nCd.getName() + " reset");
                heartbeat(NodeRepo.getSmsA());
                heartbeat(NodeRepo.getSmsB());
            } else {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tMsg, nCd.getName() + " failed");
                return new BaseResponse(ResRepo.getC404());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {
            log.warn("Sms reset() " + nodeInfo.getName() + "  " + e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse failover(LoginSessionBean bean) {
        
        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
        NodeModel smsANode = nHash.get(NodeRepo.getSmsA().getCode());
        NodeModel smsBNode = nHash.get(NodeRepo.getSmsB().getCode());

        NodeModel nInfo = smsANode;
        OpCmdRepo cCd = OpCmdRepo.getFailoverModem();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        ArrayList<NodeModel> params = new ArrayList<>();
        String connectMsg = null;
        String tMsg = null;
        String tLog = null;
        List<StatusModel> statusList = null;
        int smsAMode = 0;
        int smsBMode = 0;
        StatusRepo unCd = StatusRepo.getUNKNOWN();
        StatusRepo waCd = StatusRepo.getWARNING();
        NodeRepo nowCode = null;
        AlarmRepo ac = null;

        boolean isAStd = false;
        boolean isBStd = false;
        boolean isAAct = false;
        boolean isBAct = false;
        int modeChange = 0;
        SmsTcpMsgBean stmB = null;
        SmsTcpObjectBean sTOB = null;
        int result = 1;
        boolean isFailoverReady = false;
        
        boolean isModeA = true;
        boolean isModeB = true;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
       
        NodeModel activeNode = null;
        NodeModel standbyNode = null;
        List<NodeModel> orderedNodes = new ArrayList<>();

        if (!prop.isModemSendMode()) {
            log.debug("SMS failover set data failed");
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog =  "Not operation mode failover fail";
            insertOperationHist(oHBean, tMsg, tLog);
            return new BaseResponse(ResRepo.getC517());
        }

        try {

            connectMsg = smsClientMgr.smsIsAllConnect();

            if (connectMsg != null) {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(oHBean, tMsg, connectMsg);

                return new BaseResponse(ResRepo.getC404());
            }

            statusList = stConfDao.selectStatusList();
            if ((statusList == null) || (statusList.size() == 0)) {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(oHBean, tMsg, connectMsg);

                return  new BaseResponse(ResRepo.getC508());
            }

            smsAMode = statusList.get(0).getSmsA();
            smsBMode = statusList.get(0).getSmsB();

            smsANode.setActiveMode(smsAMode);
            smsBNode.setActiveMode(smsBMode);

            params.add(new NodeModel(smsANode));
            params.add(new NodeModel(smsBNode));
            
            if (smsAMode == unCd.getCode() || smsBMode == unCd.getCode() 
                    || smsAMode == waCd.getCode() 
                    || smsBMode == waCd.getCode()) {
                log.trace("unknown value");
                return new BaseResponse(ResRepo.getC509());
            }

            isAStd = (smsAMode == StatusRepo.getSTANDBY().getCode());
            isBStd = (smsBMode == StatusRepo.getSTANDBY().getCode());
            isAAct = (smsAMode == StatusRepo.getACTIVE().getCode());
            isBAct = (smsBMode == StatusRepo.getACTIVE().getCode());

            //둘다 ACT,STD만 존재할때 수행
            if ((isAStd && isBAct) || (isAAct && isBStd)) {
                isFailoverReady = true;
            }

            if (!isFailoverReady) {
                log.debug("sms A Mode: {} sms B Mode: {}", isAAct, isBAct);
                return new BaseResponse(ResRepo.getC509());
            }
            
            for (NodeModel nP : params) {
                if (nP.getActiveMode() == StatusRepo.getACTIVE().getCode()) {
                    activeNode = nP;
                } else {
                    standbyNode = nP;
                }
            }

            orderedNodes.add(activeNode);
            orderedNodes.add(standbyNode);

            //작업 수행 FAIL나면 롤백 해야함 
            for (int i = 0; i < orderedNodes.size(); i++) {
                NodeModel nP = orderedNodes.get(i);
                boolean isMA = false;
                
                if (nP.getNodeId() == NodeRepo.getSmsA().getCode()) {
                    nowCode = NodeRepo.getSmsA();
                    isMA = true;
                } else {
                    nowCode = NodeRepo.getSmsB();
                }
                
                if (nP.getActiveMode() == StatusRepo.getACTIVE().getCode()) {
                    modeChange = N1; // STANDBY
                } else {
                    modeChange = N2; // ACTIVE
                }
                
                stmB = new SmsTcpMsgBean();
                stmB.setReqInfo(CMD_FAILOVER,
                        new Object[] { nP.getAddrIp(), modeChange });
                
                if (stmB.getReqBean().getData() == null) {
                    log.debug("SMS failover set data failed");
                    tMsg = OpHistRltRepo.getResultFailed().getName();
                    tLog = nowCode.getName() + " fail";
                    insertOperationHist(oHBean, tMsg, tLog);
                    res = new BaseResponse(ResRepo.getC999());
                    break;
                }
                
                sTOB = smsClientMgr.sendRequestMsg(stmB, nowCode, N5);

                if ((sTOB != null) && (sTOB.getData() != null)) {
                    result = (int) sTOB.getData()[0];
                }

                if (result == N1) {
                    tMsg = OpHistRltRepo.getResultFailed().getName();
                    tLog = nowCode.getName() + " result fail";
                    insertOperationHist(oHBean, tMsg, tLog);
                    res = new BaseResponse(ResRepo.getC510());
                    
                    if (isMA) {
                        isModeA = false;
                    }else {
                        isModeB = false;
                    }
                    
                    break;                    
                } else {
                    ac = AlarmRepo.getAlmFailover();
                    if (modeChange == N1) {
                        tLog = nowCode.getName() + " STANDBY success";
                    } else {
                        tLog = nowCode.getName() + " ACTIVE success";
                    }
                    insertAlarmHist(nowCode, ac, AlarmRepo.getSvrInfo(), tLog);
                }                
            }
                
            //둘중 하나 실패하면 롤백해야함 
            if (!isModeA || !isModeB) {
                NodeModel nP = null;

                if (!isModeA) {
                    nP = orderedNodes.get(0);
                } else {
                    nP = orderedNodes.get(1);
                }

                if (nP.getNodeId() == NodeRepo.getSmsA().getCode()) {
                    nowCode = NodeRepo.getSmsA();                   
                } else {
                    nowCode = NodeRepo.getSmsB();
                }
                if (nP.getActiveMode() == StatusRepo.getACTIVE().getCode()) {
                    modeChange = N2; // 원래대로
                } else {
                    modeChange = N1; 
                }
                
                stmB = new SmsTcpMsgBean();
                stmB.setReqInfo(CMD_FAILOVER,
                        new Object[] { nP.getAddrIp(), modeChange });
                
                sTOB = smsClientMgr.sendRequestMsg(stmB, nowCode, N5);

                if ((sTOB != null) && (sTOB.getData() != null)) {
                    result = (int) sTOB.getData()[0];
                }

                if (result == N1) {
                    log.debug("FAILOVER ROLLBACK FAILED");
                }  
                
            }
            
            heartbeat(NodeRepo.getSmsA());
            heartbeat(NodeRepo.getSmsB());

        } catch (IOException | CompletionException e) {

            log.warn("Sms failover() " + nInfo.getName() + "  " + e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, tMsg, e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

        tMsg = OpHistRltRepo.getResultSuccess().getName();
        insertOperationHist(oHBean, tMsg, " result SUCCESS");

        return res;

    }

//    내부 자동 처리용 예외처리는 다 제거 
    @Override
    public boolean smsModeChangeAuto(Integer mode,Integer noId) {

        NodeModel nInfo = prop.getNodeInfoHash().get(noId);
        SmsTcpObjectBean sTOB = null;
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        int modeChange = 0;
        NodeRepo nowCode = null;
        int result = -1;
        String tLog = null;
        
        try {
            
            if (mode == StatusRepo.getSTANDBY().getCode()) { // standby 세팅
                modeChange = N1;               
            } else { // active 세팅
                modeChange = N2;
            }
            
            stmB.setReqInfo(CMD_FAILOVER,
                    new Object[] { nInfo.getAddrIp(), modeChange });
            
            if (noId == NodeRepo.getSmsA().getCode()) {
                nowCode = NodeRepo.getSmsA();
            }else {
                nowCode = NodeRepo.getSmsB();                
            }
            
            sTOB = smsClientMgr.sendRequestMsg(stmB, nowCode, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                result = (int) sTOB.getData()[0];
            }
            
            if (result == N1) {
                return false;
            }
           
        } catch (IOException | CompletionException e) {
            tLog = "Sms smsModeChangeAuto() " + nInfo.getName();
            log.warn(tLog + "  " + e.toString());
            return false;

        }

        return true;

    }
    
    /*
     * 0x01: Active->Standby 0x02: Standby->Active 0x10: Active 지정
     */
    @Override
    public BaseResponse modeChange(LoginSessionBean bean, Integer mode,
            Integer noId) {

        NodeModel nInfo = prop.getNodeInfoHash().get(noId);
        SmsTcpObjectBean sTOB = null;
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        int modeChange = 0;
        String tMsg = null;
        String tLog = null;
        OpCmdRepo cCd = OpCmdRepo.getFailoverModem();
        NodeRepo nowCode = null;
        OperationHistModel oHBean = null;
        int result = -1;
        AlarmRepo ac = null;
        NodeModel alterNode = null;
        List<StatusModel> statusList = null;
        
        int smsAMode = 0;
        int smsBMode = 0;
        int smsAlterMode = 0;
        
        if (bean != null) {
            oHBean = getOpHistBean(bean, cCd, nInfo);
        }

        try {            
            statusList = stConfDao.selectStatusList();

            prop.getNodeInfoHash().get(NodeRepo.getSmsA().getCode())
                    .setActiveMode(statusList.get(0).getSmsA());
            prop.getNodeInfoHash().get(NodeRepo.getSmsB().getCode())
                    .setActiveMode(statusList.get(0).getSmsB());
            
            smsAMode = statusList.get(0).getSmsA();
            smsBMode = statusList.get(0).getSmsB();
            
            if (noId == NodeRepo.getSmsA().getCode()) {
                tLog = NodeRepo.getSmsA().getName();
                nowCode = NodeRepo.getSmsA();
                alterNode = prop.getNodeInfoHash()
                        .get(NodeRepo.getSmsB().getCode());
                smsAlterMode = smsBMode;
            } else {
                tLog = NodeRepo.getSmsB().getName();
                nowCode = NodeRepo.getSmsB();
                alterNode = prop.getNodeInfoHash()
                        .get(NodeRepo.getSmsA().getCode());
                smsAlterMode = smsAMode;
            }
            
//          쌍 ACTIVE 차단
            if (smsAlterMode == StatusRepo.getACTIVE().getCode() 
                    && mode == StatusRepo.getACTIVE().getCode()) {
                log.debug("SMS {} Already Active",alterNode.getName());
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog += " fail";
                
                if (bean != null) {
                    insertOperationHist(oHBean, tMsg, tLog);    
                }                
                return new BaseResponse(ResRepo.getC516());
            }
            
//            standby 처리 하는데 ALTER가 ACTIVE가 아니거나, 
            if (mode == StatusRepo.getSTANDBY().getCode()) { // standby 세팅
                modeChange = N1;
                tLog += (" " + StatusRepo.getSTANDBY().getName());
            } else { // active 세팅
                tLog += (" " + StatusRepo.getACTIVE().getName());
                modeChange = N2;
            }

            stmB.setReqInfo(CMD_FAILOVER,
                    new Object[] { nInfo.getAddrIp(), modeChange });

            if (stmB.getReqBean().getData() == null) {
                log.debug("SMS change mode set data failed");
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog += " fail";
                
                if (bean != null) {
                    insertOperationHist(oHBean, tMsg, tLog);    
                }

                return new BaseResponse(ResRepo.getC999());
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nowCode, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                result = (int) sTOB.getData()[0];
            }

            if (result == N1) {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nowCode.getName() + " result fail";
                
                if (bean != null) {
                    insertOperationHist(oHBean, tMsg, tLog);
                }

                return new BaseResponse(ResRepo.getC510());
            } else {

                ac = AlarmRepo.getAlmFailover();

                if (modeChange == N2) {
                    tLog = " ACTIVE success";
                } else {
                    tLog = " STANDBY success";
                }

                insertAlarmHist(nowCode, ac, AlarmRepo.getSvrInfo(), tLog);

            }

        } catch (Exception e) {
            tLog = "Sms modeChange() " + nInfo.getName();
            log.warn(tLog + "  " + e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            
            if (bean != null) {
                insertOperationHist(oHBean, tMsg, e.toString());
            }            
            return new BaseResponse(ResRepo.getC999());

        }
        
        heartbeat(NodeRepo.getSmsA());
        heartbeat(NodeRepo.getSmsB());
        
        tMsg = OpHistRltRepo.getResultSuccess().getName();
        
        if (bean != null) {
            insertOperationHist(oHBean, tMsg, " result SUCCESS");    
        }  
        
        return new BaseResponse(ResRepo.getC200());

    }

    @Override
    public void changeOpMode() {
        List<StatusModel> sList = null;
        SmsTcpObjectBean sTOB = null;
        int result = N1; // 무조건 실패 초기값
        
        HashMap<Integer, NodeModel> nHash = prop.getNodeInfoHash();
        NodeModel smsANode = nHash.get(NodeRepo.getSmsA().getCode());
        NodeModel smsBNode = nHash.get(NodeRepo.getSmsB().getCode());
        StatusRepo unCd = StatusRepo.getUNKNOWN();
        StatusRepo aCd = StatusRepo.getACTIVE();
        StatusRepo sCd = StatusRepo.getSTANDBY();
        StatusRepo waCd = StatusRepo.getWARNING();
        
        NodeRepo aCode = NodeRepo.getSmsA();
        NodeRepo bCode = NodeRepo.getSmsB();
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        Integer aSt = 0;
        Integer bSt = 0;
        
        heartbeat(NodeRepo.getSmsA());
        heartbeat(NodeRepo.getSmsB());
        
        prop.readNodeSawStatus();
        
        sList = stConfDao.selectStatusList();
        aSt = sList.get(0).getSmsA();
        bSt = sList.get(0).getSmsB();
        try {

            if (prop.isModemSendMode()) { // 작전모드로 바뀌었을때

//            둘중의 하나가 죽어있는 상태라 작전모드 두개다 세팅 불가 
                if (aSt == unCd.getCode() || bSt == unCd.getCode() 
                        || aSt == waCd.getCode() || bSt == waCd.getCode()) {
                
                    if (sCd.getCode() == aSt) { //standby면 active
                        stmB.setReqInfo(CMD_FAILOVER,
                                new Object[] { smsANode.getAddrIp(), N2 });
                        smsClientMgr.sendRequestMsg(stmB, aCode, N5);
                    }

                    if (sCd.getCode() == aSt) { //standby면 active
                        stmB.setReqInfo(CMD_FAILOVER,
                                new Object[] { smsBNode.getAddrIp(), N2 });
                        smsClientMgr.sendRequestMsg(stmB, bCode, N5);
                    }

                } else { // 둘다 살아있음
//                   둘 다 standby일 경우
                    if (aCd.getCode() != aSt && aCd.getCode() != bSt) {

                        stmB.setReqInfo(CMD_FAILOVER,
                                new Object[] { smsANode.getAddrIp(), N2 });
                        sTOB =  smsClientMgr.sendRequestMsg(stmB, aCode, N5);
                       
                        if ((sTOB != null) && (sTOB.getData() != null)) {
                            result = (int) sTOB.getData()[0];
                        }
                        
                        if (result == N1) { // 실패 응답시 B를 ACTIVE로 변경
                            log.debug("SMS A ACTIVE CHANGE FAILED");
                            stmB.setReqInfo(CMD_FAILOVER,
                                    new Object[] { smsBNode.getAddrIp(), N2 });
                            smsClientMgr.sendRequestMsg(stmB, bCode, N5);
                        }
                        
//                      둘 다 active일 경우                        
                    }else if (aCd.getCode() == aSt && aCd.getCode() == bSt) {
                        
                        stmB.setReqInfo(CMD_FAILOVER,
                                new Object[] { smsBNode.getAddrIp(), N1 });
                        sTOB =  smsClientMgr.sendRequestMsg(stmB, aCode, N5);
                       
                        if ((sTOB != null) && (sTOB.getData() != null)) {
                            result = (int) sTOB.getData()[0];
                        }
                        
                        if (result == N1) { // 실패 응답시 A를 STANDBY로 변경
                            log.debug("SMS A STANDBY CHANGE FAILED");
                            stmB.setReqInfo(CMD_FAILOVER,
                                    new Object[] { smsANode.getAddrIp(), N1 });
                            smsClientMgr.sendRequestMsg(stmB, bCode, N5);
                        }
                        
                    }

                }

            } else { // 대기모드면 ACTIVE 찾아 STANDBY로 변경 

                if (aCd.getCode() == aSt) {
                    stmB.setReqInfo(CMD_FAILOVER,
                            new Object[] { smsANode.getAddrIp(), N1 });
                    smsClientMgr.sendRequestMsg(stmB, aCode, N5);
                }
                
                if (aCd.getCode() == bSt) {
                    stmB.setReqInfo(CMD_FAILOVER,
                            new Object[] { smsBNode.getAddrIp(), N1 });
                    smsClientMgr.sendRequestMsg(stmB, bCode, N5);
                }
            }
            
            heartbeat(NodeRepo.getSmsA());
            heartbeat(NodeRepo.getSmsB());
        } catch (Exception e) {
            log.warn("Sms changeOpMode() " + e.toString());

        }
    }

    @Override
    public BaseResponse diagnosis(OperationHistModel histBean,
            NodeModel nodeInfo, LoginSessionBean bean) {
        String tMsg = null;
        String tLog = null;
        
        try {
            SmsTcpMsgBean stmB = new SmsTcpMsgBean();
            NodeRepo nCd = NodeRepo.getSmsA();
            SmsTcpObjectBean stoB = null;
            BaseResponse res = new BaseResponse(ResRepo.getC200());
            SmtSmsDiagnosisRes resData = new SmtSmsDiagnosisRes();
            boolean isPass = false;

            stmB.setReqInfo(CMD_DIAGNOSIS, null);
            if (nodeInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            stoB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if (stoB != null) {
                isPass = (stoB.getData() != null) && (stoB.parseDiagnosis());
            }

            if (isPass) {

                resData.setResData(stoB);
                parseDiagnosisAlarm(resData, nodeInfo, null);

                res.setData(resData);
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " diagnosis success";
                insertOperationHist(histBean, tMsg, tLog);

                return res;
            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " diagnosis failed";
            insertOperationHist(histBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "Sms diagnosis() {} {}";
            log.warn(tLog, nodeInfo.getName(), e.toString());
            insertOperationHist(histBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public void monitorDiagnosis(NodeRepo nodeCode) {
        String tLog = null;

        try {
            SmsTcpMsgBean stmB = new SmsTcpMsgBean();
            NodeModel nInfo = prop.getNodeInfoHash().get(nodeCode.getCode());
            SmsTcpObjectBean sTOB = null;
            SmtSmsDiagnosisRes resData = new SmtSmsDiagnosisRes();
            boolean isPass = false;
            StatusHistModel hBean = new StatusHistModel();

            stmB.setReqInfo(CMD_DIAGNOSIS, null);

            sTOB = smsClientMgr.sendRequestMsg(stmB, nodeCode, N5);

            if (sTOB != null) {
                isPass = ((sTOB.getData() != null) && (sTOB.parseDiagnosis()));
            }

            if (isPass) {
                resData.setResData(sTOB);
                hBean.setIpAddr(nInfo.getAddrIp());
                hBean.setNodeId(nInfo.getNodeId());
                hBean.setNodeName(nInfo.getName());
                parseDiagnosisAlarm(resData, nInfo, hBean);

                syncHistInsertService.insertStatusHist(hBean);
            }

        } catch (IOException | CompletionException e) {
            tLog = "Sms monitorDiagnosis() {} {}";
            log.warn(tLog, nodeCode, e.toString());
        }

    }

    @Override
    public BaseResponse getModemBerInfo(int nodeId, LoginSessionBean bean) {
        String tLog = null;
        String tMsg = null;
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsModemBerThresStatus();
        SmsTcpObjectBean sTOB = null;
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        boolean isPass = false;
        SmtModemRes resData = new SmtModemRes();

        try {

            stmB.setReqInfo(SMS_MODEM_BER_THRES_STATUS, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                isPass = (sTOB.getData().length == N8);
            }

            if (isPass) {

                resData.setThreshold(ByteBuffer.wrap(sTOB.getData()).getLong());
                res.setData(resData);
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " modem ber threshold status success";
                insertOperationHist(oHBean, tMsg, tLog);

                return res;
            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " modem ber threshold status failed";

            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {

            tLog = "getModemBerInfo() modem ber threshold status {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse setModemBerInfo(int nodeId, long threshold,
            LoginSessionBean bean) {

        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsModemBerThresSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        int resetCdRes = -1;
        String tMsg = null;
        String tLog = null;

        try {

            stmB.setReqInfo(SMS_MODEM_BER_THRES_SET,
                    new Object[] { threshold });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " modem ber threshold set success";
                insertOperationHist(oHBean, tMsg, tLog);
            } else {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nCd.getName() + " modem ber threshold set failed";
                insertOperationHist(oHBean, tMsg, tLog);

                return new BaseResponse(ResRepo.getC404());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "setModemBerInfo() modem ber threshold set {} {}";

            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse getModemStatus(int nodeId, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsModemStatus();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmtSmsDiagnosisRes resData = new SmtSmsDiagnosisRes();
        boolean isPass = false;
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_MODEM_STATUS, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                isPass = sTOB.parseModemUnitStatus();
            }
            
            if (isPass) {

                resData.setModemStatusData(sTOB);

                parseDiagnosisAlarm(resData, nInfo, null);

                res.setData(resData.getTBit());
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " modem unit status success";

                insertOperationHist(oHBean, tMsg, tLog);

                return res;
            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " modem unit status failed";

            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "getModemStatus() modem per threshold status {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

//    @Override
//    public BaseResponse controlUnitStatus(int nodeId, LoginSessionBean bean) {
//        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
//        OpCmdRepo cCd = OpCmdRepo.getSmsControlUnitStatus();
//        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
//        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
//        NodeRepo nCd = NodeRepo.getSmsA();
//        SmsTcpObjectBean sTOB = null;
//        BaseResponse res = new BaseResponse(ResRepo.getC200());
//        SmtSmsDiagnosisRes resData = new SmtSmsDiagnosisRes();
//        boolean isPass = false;
//        String tLog = null;
//        String tMsg = null;
//
//        try {
//
//            stmB.setReqInfo(CMD_CONTROL_UNIT_STATUS, null);
//
//            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
//                nCd = NodeRepo.getSmsB();
//            }
//
//            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);
//
//            if ((sTOB != null) && (sTOB.getData() != null)) {
//                isPass = sTOB.parseControlUnitStatus();
//            }
//
//            if (isPass) {
//
//                resData.setControlStatusData(sTOB);
//                parseDiagnosisAlarm(resData, nInfo, null);
//                res.setData(resData);
//
//                tMsg = OpHistRltRepo.getResultSuccess().getName();
//                tLog = nCd.getName() + " control unit status success";
//
//                insertOperationHist(oHBean, tMsg, tLog);
//                return res;
//            }
//
//            tMsg = OpHistRltRepo.getResultFailed().getName();
//            tLog = nCd.getName() + " control unit status failed";
//            insertOperationHist(oHBean, tMsg, tLog);
//
//            return new BaseResponse(ResRepo.getC404());
//
//        } catch (IOException | CompletionException e) {
//
//            tMsg = OpHistRltRepo.getResultFailed().getName();
//            tLog = "controlUnitStatus() control unit status {} {}";
//            log.warn(tLog, nInfo.getName(), e.toString());
//
//            insertOperationHist(oHBean, tMsg, e.toString());
//
//            return new BaseResponse(ResRepo.getC999());
//        }
//    }

    @Override
    public BaseResponse convUpcUpdate(int nodeId, Double upc, int upcAtt,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvUpcSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        Double upcHz = upc;
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;        
        int resetCdRes = -1;
        String tLog = null;
        String tMsg = null;
        String tmp = null;

        try {

            if (upc > -1) {
                upcHz = ((upc * N1000) - SMS_FREQ_MIN) / SMS_FREQ_STEP;
            }

            stmB.setReqInfo(SMS_CONV_UPC_SET,
                    new Object[] { upcHz.intValue(), upcAtt });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " conv upc set success";
                insertOperationHist(oHBean, tMsg, tLog);
            } else {

                if (resetCdRes == N1) {
                    tmp = "upc fault";
                } else if (resetCdRes == N2) {
                    tmp = "upc attenuation fault";
                }

                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nCd.getName() + "  conv upc set failed " + tmp;
                insertOperationHist(oHBean, tMsg, tLog);

                return new BaseResponse(ResRepo.getC511());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "convUpcUpdate() conv upc set {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());

            insertOperationHist(oHBean, tMsg, e.toString());
            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse convDncUpdate(int nodeId, Double dnc, int dncAtt,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvDncSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        Double dncHz = dnc;
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        int resetCdRes = -1;
        String tLog = null;
        String tMsg = null;
        String msg = "";

        try {

            if (dnc > -1) {
                dncHz = ((dnc * N1000) - SMS_FREQ_MIN) / SMS_FREQ_STEP;
            }

            stmB.setReqInfo(SMS_CONV_DNC_SET,
                    new Object[] { dncHz.intValue(), dncAtt });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " conv dnc set success";
                insertOperationHist(oHBean, tMsg, tLog);
            } else {

                if (resetCdRes == N1) {
                    msg = "dnc fault";
                } else if (resetCdRes == N2) {
                    msg = "dnc attenuation fault";
                }

                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nCd.getName() + " conv dnc set failed " + msg;

                insertOperationHist(oHBean, tMsg, tLog);
                return new BaseResponse(ResRepo.getC511());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "convDncUpdate() conv dnc set {} {}";

            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse convLoopbackUpdate(int nodeId, int loopback,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvLoopbackSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        int resetCdRes = -1;
        String tLog = null;
        String tMsg = null;

        try {
            stmB.setReqInfo(SMS_CONV_LOOPBACK_SET, new Object[] { loopback });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " conv loopback set success";
                insertOperationHist(oHBean, tMsg, tLog);
            } else {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nCd.getName() + " conv loopback set failed ";
                insertOperationHist(oHBean, tMsg, tLog);

                return new BaseResponse(ResRepo.getC511());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {
            
            tLog = "convLoopbackUpdate() conv loopback set {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse convBitLevelUpdate(int nodeId, int uul, int ull,
            int dul, int dll, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvBitlevelSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpObjectBean sTOB = null;
        int resetCdRes = -1;
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_CONV_BITLEVEL_SET,
                    new Object[] { uul, ull, dul, dll });

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                resetCdRes = (int) sTOB.getData()[0];
            }

            if (resetCdRes == 0) {
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " conv bitlevel set success";
                insertOperationHist(oHBean, tMsg, tLog);
            } else {
                tMsg = OpHistRltRepo.getResultFailed().getName();
                tLog = nCd.getName() + " conv bitlevel set failed";
                insertOperationHist(oHBean, tMsg, tLog);

                return new BaseResponse(ResRepo.getC511());
            }

            return new BaseResponse(ResRepo.getC200());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "convBitLevelUpdate() conv bitlevel set {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse convStatus(int nodeId, int type,
            LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvStatus();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsTcpMsgBean stmB = new SmsTcpMsgBean();
        SmsTcpObjectBean sTOB = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());
        SmtSmsDiagnosisRes resData = new SmtSmsDiagnosisRes();
        boolean isPass = false;
        SmsCodeTableEnumIf codeMainEnum = null;
        SmsCodeTableEnumIf codeSubEnum = null;
        IBitStatus resBean = null;
        DefaultCodeModel val = null;
        String tLog = null;
        String tMsg = null;

        try {

            stmB.setReqInfo(SMS_CONV_STATUS, null);

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            prop.getNodeInfoHash().get(nInfo.getNodeId());
            sTOB = smsClientMgr.sendRequestMsg(stmB, nCd, N5);

            if ((sTOB != null) && (sTOB.getData() != null)) {
                isPass = (sTOB.getData().length != N12);
            }

            if (isPass) {
                resData.setConvStatusData(sTOB);

                parseDiagnosisAlarm(resData, nInfo, null);

                switch (type) {
                    case N1:
                        codeMainEnum = SmsARepo.getUpcMain();
                        codeSubEnum = SmsARepo.getUpcSub();

                        if (nCd.getCode() == NodeRepo.getSmsB().getCode()) {
                            codeMainEnum = SmsBRepo.getUpcMain();
                            codeSubEnum = SmsBRepo.getUpcSub();
                        }
                        break;

                    case N2:
                        codeMainEnum = SmsARepo.getDncMain();
                        codeSubEnum = SmsARepo.getDncSub();

                        if (nCd.getCode() == NodeRepo.getSmsB().getCode()) {
                            codeMainEnum = SmsBRepo.getDncMain();
                            codeSubEnum = SmsBRepo.getDncSub();
                        }
                        break;

                    default:
                        codeMainEnum = SmsARepo.getUpcMain();
                        codeSubEnum = SmsARepo.getUpcSub();
                        break;
                }

                switch (type) {
                    case N1:
                        resBean = resData.getIBitStatus().getUpcResponse();
                        val = stConfDao
                                .selectDefaultCodeInfo(codeMainEnum.value());
                        resBean.setUpcMain(val.getCodeData());
                        val = stConfDao
                                .selectDefaultCodeInfo(codeSubEnum.value());
                        resBean.setUpcSub(val.getCodeData());
                        res.setData(resBean);
                        break;

                    case N2:
                        resBean = resData.getIBitStatus().getDncResponse();
                        val = stConfDao
                                .selectDefaultCodeInfo(codeMainEnum.value());
                        resBean.setDncMain(val.getCodeData());
                        val = stConfDao
                                .selectDefaultCodeInfo(codeSubEnum.value());
                        resBean.setDncSub(val.getCodeData());
                        res.setData(resBean);
                        break;

                    case N3:
                        res.setData(
                                resData.getIBitStatus().getLoopbackResponse());
                        break;

                    case N4:
                        res.setData(
                                resData.getIBitStatus().getBitlevelResponse());
                        break;

                    case N5:
                        res.setData(
                                resData.getIBitStatus().getDiagnosisResponse());
                        break;

                    default:
                        throw new IllegalArgumentException("none Res type");
                }
                
                tMsg = OpHistRltRepo.getResultSuccess().getName();
                tLog = nCd.getName() + " conv status success";
                insertOperationHist(oHBean, tMsg, tLog);

                return res;
            }

            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = nCd.getName() + " conv status failed";
            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC404());

        } catch (IOException | CompletionException e) {
            
            tMsg = OpHistRltRepo.getResultFailed().getName();
            tLog = "convStatus() conv status {} {}";

            log.warn(tLog, nInfo.getName(), e.toString());

            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    private void parseDiagnosisAlarm(SmtSmsDiagnosisRes resData,
            NodeModel nodeInfo, StatusHistModel bean) {
        String summary = null;
        boolean isAlarmClear = false;
        AlarmRepo ac = null;
        AlarmRepo lv = null;
        boolean isIBitNull = false;
        boolean isIBitStNull = false;

        if (resData.getCBit() != null) {

            summary = resData.getCBit().getAlarmInfo();
            isAlarmClear = (summary == null);

            if (bean != null) {
                bean.setType1(isAlarmClear ? "Y" : "N");
            }

            ac = AlarmRepo.getAlmSmsControl();
            lv = AlarmRepo.getSvrMaj();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);

        }

        if (resData.getTBit() != null) {
            summary = resData.getTBit().getAlarmInfo();
            isAlarmClear = (summary == null);

            if (bean != null) {
                bean.setType2(isAlarmClear ? "Y" : "N");
            }

            ac = AlarmRepo.getAlmSmsModem();
            lv = AlarmRepo.getSvrMaj();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);
        }

        if (resData.getIBit() != null) {
            summary = resData.getIBit().getAlarmInfo();
            isAlarmClear = (summary == null);

            if (bean != null) {
                bean.setType3(isAlarmClear ? "Y" : "N");
            }

            ac = AlarmRepo.getAlmSmsConv();
            lv = AlarmRepo.getSvrMaj();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);
        }

        if (resData.getPBit() != null) {
            summary = resData.getPBit().getAlarmInfo();
            isAlarmClear = (summary == null);

            if (bean != null) {
                bean.setType4(isAlarmClear ? "Y" : "N");
            }

            ac = AlarmRepo.getAlmSmsPwr();
            lv = AlarmRepo.getSvrMaj();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);
        }

        if (resData.getSBit() != null) {
            summary = resData.getSBit().getAlarmInfo();
            isAlarmClear = (summary == null);

            if (bean != null) {
                bean.setType5(isAlarmClear ? "Y" : "N");
            }

            ac = AlarmRepo.getAlmSmsCrypto();
            lv = AlarmRepo.getSvrMaj();

            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);
        }

        isIBitNull = (resData.getIBitStatus() != null);

        if (isIBitNull) {
            isIBitStNull = (resData.getIBitStatus().getIbit() != null);
        }

        if (isIBitNull && isIBitStNull) {
            summary = resData.getIBitStatus().getIbit().getAlarmInfo();
            isAlarmClear = (summary == null);

            ac = AlarmRepo.getAlmSmsConv();
            lv = AlarmRepo.getSvrMaj();
            alarmService.alarmUpdate(isAlarmClear, ac, nodeInfo, lv, summary);
        }

    }

    private OperationHistModel getOpHistBean(LoginSessionBean bean,
            OpCmdRepo code, NodeModel nm) {
        OperationHistModel model = new OperationHistModel();
        String addInfo = hostName + " " + nm.getName() + " " + nm.getAddrIp();
        String tMsg = OpHistRltRepo.getResultSuccess().getCode();

        model.setStartTime(new Date());
        model.setUserId(bean.getUserId());
        model.setUserName(bean.getName());
        model.setUserIp(bean.getIp());
        model.setOperation(code.getMsg());
        model.setAdditionalInfo(addInfo);
        model.setOperationResult(tMsg);
        model.setEndTime(new Date());

        return model;
    }

    // LM_OPERATION_HIST 관리단말 명령 이력 저장
    private void insertOperationHist(OperationHistModel bean, String resultCode,
            String oHMsg) {
        try {

            bean.setOperationResult(resultCode);

            if (oHMsg.length() > N1000) {
                oHMsg = oHMsg.substring(0, N900);
            }

            bean.setAdditionalInfo(oHMsg);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);
        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString(), e);
        }
    }

//    @Override
//    public void eventHandle(SmsTcpEventBean event) {
//        smsEService.eventHandle(event);
//    }

    private void insertAlarmHist(NodeRepo nodeCode, AlarmRepo code,
            AlarmRepo svrLevel, String summaryMsg) {

        NodeModel node = prop.getNodeInfoHash().get(nodeCode.getCode());
        AlarmHistModel aHMBean = new AlarmHistModel();

        aHMBean.setTime();
        aHMBean.setCurrUuid(UUID.randomUUID().toString().replace("-", ""));
        aHMBean.setNodeId(node.getNodeId());
        aHMBean.setNodeName(node.getName());
        aHMBean.setAddrIp(node.getAddrIp());
        aHMBean.setAlarmId(code.getCode());
        aHMBean.setAlarmName(code.getMsg());
        aHMBean.setServerity(svrLevel.getCode());
        aHMBean.setLocation(node.getAddrIp());
        aHMBean.setSummary(summaryMsg);
        aHMBean.setRecoverReason(null);
        aHMBean.setRecoverTime(null);
        aHMBean.setTally(1);
        aHMBean.setFirstOccurrence(new Date());
        aHMBean.setLastOccurrence(new Date());
        syncHistInsertService.insertAlarmHist(aHMBean);

    }

    private void setSmsStatus(NodeRepo code, int type) {
        List<StatusModel> statusList = null;
        StatusRepo parseType = StatusRepo.getACTIVE();
        boolean isUpdate = false;
        StatusModel param = new StatusModel();
        boolean isATmp = false;
        boolean isBTmp = false;
        String tMsg = "UPDATE NODE STATUS  {} {}";
        NodeModel node = prop.getNodeInfoHash().get(code.getCode());
        String summary = null;
        boolean isPUnk = false;
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrMin();
        String tLogMsg2 = "";
        int codeTmp1 = 0;
        SmsRepo smsHB = null;
        int cd = 0;
        boolean cdUnk = false;
        boolean cdWar = false;
        
        try {
            smsHB = SmsRepo.from(type);
            if (smsHB.getCode() == SmsRepo.getStatusUnknown().getCode()) {
                tLogMsg2 = code.getName() + " heartbeat ";
                log.debug(tLogMsg2 + "UNKNOWN");   
                smsClientMgr.addUnknownCount(code);
            }else {
                smsClientMgr.setUnknownInit(code);
            }

            statusList = stConfDao.selectStatusList();

            if ((statusList == null) || (statusList.size() == 0)) {
                log.trace("status list is null");
                return;
            }

            if (type == SmsRepo.getStatusStandby().getCode()) {
                parseType = StatusRepo.getSTANDBY();
            } else if (type == SmsRepo.getStatusUnknown().getCode()) {
                parseType = StatusRepo.getUNKNOWN();
            } else if (type == SmsRepo.getStatusWarning().getCode()) {
                parseType = StatusRepo.getWARNING();
            }

            isATmp = (statusList.get(0).getSmsA() != parseType.getCode());
            isBTmp = (statusList.get(0).getSmsB() != parseType.getCode());

            codeTmp1 = code.getCode();
            if ((codeTmp1 == NodeRepo.getSmsA().getCode()) && isATmp) {
                isUpdate = true;
                param.setSmsA(parseType.getCode());
            } else if (codeTmp1 == NodeRepo.getSmsB().getCode() && isBTmp) {
                isUpdate = true;
                param.setSmsB(parseType.getCode());
            }

            if (isUpdate) {
                log.debug(tMsg, code.getName(), parseType.getName());
                stConfDao.updateStatus(param);
                rtSync.insertQueue(param, "UPDATE");
            }

            summary = node.getName() + " " + parseType.getName();
            
            cd = parseType.getCode();
            cdUnk = cd != StatusRepo.getUNKNOWN().getCode(); 
            cdWar = cd != StatusRepo.getWARNING().getCode();
            
            isPUnk = (cdUnk && cdWar);
            
            alarmService.alarmUpdate(isPUnk, ac, node, lv, summary);

        } catch (RuntimeException e) {
            log.warn("setSmsStatus() " + e.toString(), e);
        }
    }

    @Override
    public BaseResponse convDncDefaultUpdate(int nodeId, Number dncMain,
            Integer dncSub, LoginSessionBean bean) {

        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvDefaultDncSet();
        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsCodeTableEnumIf codeMainEnum = null;
        SmsCodeTableEnumIf codeSubEnum = null;
        DefaultCodeModel param = new DefaultCodeModel();
        String tMsg = OpHistRltRepo.getResultSuccess().getName();
        String tLog = null;

        try {

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            if (nCd.getCode() == NodeRepo.getSmsA().getCode()) {
                codeMainEnum = SmsARepo.getDncMain();
                codeSubEnum = SmsARepo.getDncSub();
            } else if (nCd.getCode() == NodeRepo.getSmsB().getCode()) {
                codeMainEnum = SmsBRepo.getDncMain();
                codeSubEnum = SmsBRepo.getDncSub();
            } else {
                throw new IllegalArgumentException("none Res type");
            }

            if (dncMain != null) {
                param.setCodeId(codeMainEnum.value());
                param.setCodeData(dncMain.toString());
                stConfDao.updateDefaultCode(param);
                rtSync.insertQueue(param, "UPDATE");
            }

            if (dncSub != null) {
                param.setCodeId(codeSubEnum.value());
                param.setCodeData(dncSub.toString());
                stConfDao.updateDefaultCode(param);
                rtSync.insertQueue(param, "UPDATE");
            }

            tLog = nCd.getName() + " DNC Default Code update success ";
            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC200());

        } catch (RuntimeException e) {
            tLog = "convDncDefaultUpdate() DNC Default Code update  {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse convUpcDefaultUpdate(int nodeId, Number upcMain,
            Integer upcSub, LoginSessionBean bean) {
        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo cCd = OpCmdRepo.getSmsConvDefaultUpcSet();

        OperationHistModel oHBean = getOpHistBean(bean, cCd, nInfo);
        NodeRepo nCd = NodeRepo.getSmsA();
        SmsCodeTableEnumIf codeMainEnum = null;
        SmsCodeTableEnumIf codeSubEnum = null;
        DefaultCodeModel param = new DefaultCodeModel();
        String tMsg = null;
        String tLog = null;

        try {

            if (nInfo.getNodeId() == NodeRepo.getSmsB().getCode()) {
                nCd = NodeRepo.getSmsB();
            }

            if (nCd.getCode() == NodeRepo.getSmsA().getCode()) {
                codeMainEnum = SmsARepo.getUpcMain();
                codeSubEnum = SmsARepo.getUpcSub();
            } else if (nCd.getCode() == NodeRepo.getSmsB().getCode()) {
                codeMainEnum = SmsBRepo.getUpcMain();
                codeSubEnum = SmsBRepo.getUpcSub();
            } else {
                throw new IllegalArgumentException("none Res type");
            }

            if (upcMain != null) {
                param.setCodeId(codeMainEnum.value());
                param.setCodeData(upcMain.toString());
                stConfDao.updateDefaultCode(param);
                rtSync.insertQueue(param, "UPDATE");
            }

            if (upcSub != null) {
                param.setCodeId(codeSubEnum.value());
                param.setCodeData(upcSub.toString());
                stConfDao.updateDefaultCode(param);
                rtSync.insertQueue(param, "UPDATE");
            }

            tMsg = OpHistRltRepo.getResultSuccess().getName();
            tLog = nCd.getName() + " UPC Default Code update success ";

            insertOperationHist(oHBean, tMsg, tLog);

            return new BaseResponse(ResRepo.getC200());

        } catch (RuntimeException e) {
            tLog = "convUpcDefaultUpdate() UPC Default Code update {} {}";
            log.warn(tLog, nInfo.getName(), e.toString());
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(oHBean, tMsg, e.toString());

            return new BaseResponse(ResRepo.getC999());
        }
    }

}
