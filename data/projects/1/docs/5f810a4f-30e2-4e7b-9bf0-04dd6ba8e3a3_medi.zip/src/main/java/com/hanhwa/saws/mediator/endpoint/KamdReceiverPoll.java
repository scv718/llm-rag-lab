/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanhwa.saws.mediator.kiss.service.KmtfParseService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KamdReceiverPoll implements Runnable {

    private static final int N10 = 10;

    @Autowired @Qualifier("kamdRecvQueue")
    private ConcurrentLinkedQueue<String> kamdRecvQueue;

    @Autowired private KmtfParseService kmtfParseService;

    @Override
    public void run() {
        while (true) {
            try {
                String data = kamdRecvQueue.poll();

                if (data != null) {
                    kmtfParseService.processCompleteKmtfData(data);
                } else {
                    CompletableFuture<Void> delay = new CompletableFuture<>();
                    delay.completeOnTimeout(null, N10, TimeUnit.MILLISECONDS)
                            .join();
                }

            } catch (RuntimeException e) {
                log.warn("Error parse KMTF data: {}", e.getMessage(), e);
            }
        }
    }
}
