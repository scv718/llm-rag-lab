/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.sync.ActiveStatusBean;

import lombok.Data;

@Data
public class ActiveStatusRes {

    @JsonProperty("data") private ActiveStatusBean data;

}
