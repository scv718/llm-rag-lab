/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;

public interface McrcHistDetailDao {
    public void insertMcrcHistDetailBulkInsert(List<McrcHistDetailModel> list);

    public List<McrcHistDetailModel>
            selectMcrcDetailHistList(McrcHistDetailModel param);

    public long selectMcrcDetailHistTotalCount(McrcHistDetailModel param);
}
