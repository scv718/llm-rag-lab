/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;


import com.hanwha.saws.icss.dto.code.AlarmRepo;
import lombok.Data;

@Data
public class AlarmCodeRes {

    private String id;
    private String name;

    public AlarmCodeRes(AlarmRepo code) {
        id = code.getCode();
        name = code.getMsg();
    }
}
