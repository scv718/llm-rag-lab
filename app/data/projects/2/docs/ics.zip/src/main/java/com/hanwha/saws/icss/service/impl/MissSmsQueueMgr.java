/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.SmsQueueBean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MissSmsQueueMgr {

    private final static int N200 = 200;

    @Autowired
    @Qualifier("airTrackSmsAQueue")
    private ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsAQueue;

    @Autowired
    @Qualifier("airTrackSmsBQueue")
    private ConcurrentLinkedQueue<SmsQueueBean> airTrackSmsBQueue;

    @Autowired
    @Qualifier("smsAirTrackExecutor")
    private Executor smsExecutor;

    @Scheduled(fixedRateString = "1000", initialDelayString = "3000")
    public void monitor() {

        smsExecutor.execute(() -> drainAndSend(airTrackSmsAQueue, "SMS_A"));
        smsExecutor.execute(() -> drainAndSend(airTrackSmsBQueue, "SMS_B"));

    }

    private void drainAndSend(ConcurrentLinkedQueue<SmsQueueBean> queue,
            String tag) {
        
        int count = 0;
        
        try (DatagramSocket socket = new DatagramSocket()) {
            while (count < N200) {
                SmsQueueBean bean = queue.poll();
                if (bean == null) {
                    break;
                }
                sendUdpData(bean, socket); // 소켓 재사용
                count++;
            }
        } catch (IOException e) {
            log.warn("Failed to create DatagramSocket: " + e.toString());
        }
        if (count > 0) {
            log.debug("{} airTrack queue send Count={}", tag, count);
        }

    }

    private boolean sendUdpData(SmsQueueBean bean, DatagramSocket socket) {

        try {
            InetAddress mcastaddr = InetAddress.getByName(bean.getSmsIp());
            DatagramPacket dPacket = new DatagramPacket(bean.getData(),
                    bean.getData().length, mcastaddr, bean.getPort());

            socket.send(dPacket);

        } catch (IOException | RuntimeException e) {
            log.warn("MissService sendUdpData() " + e.toString());

            return false;
        }

        return true;
    }

}
