/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SmtDataSendRecvHistListRes {

    @JsonProperty("total_page") private long totalPage = 0;
    @JsonProperty("total_count") private long totalCount = 0;
    private List<SmtDataSendRecvHistRes> list = new ArrayList<>();

}
