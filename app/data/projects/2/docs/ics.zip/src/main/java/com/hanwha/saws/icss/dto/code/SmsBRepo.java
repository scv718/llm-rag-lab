/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class SmsBRepo implements SmsCodeTableEnumIf {
    private static final int B_U_M_VAL = 5;
    private static final int B_U_S_VAL = 6;
    private static final int B_D_M_VAL = 7;
    private static final int B_D_S_VAL = 8;

    private static final SmsBRepo UPC_MAIN = new SmsBRepo(B_U_M_VAL);
    private static final SmsBRepo UPC_SUB = new SmsBRepo(B_U_S_VAL);
    private static final SmsBRepo DNC_MAIN = new SmsBRepo(B_D_M_VAL);
    private static final SmsBRepo DNC_SUB = new SmsBRepo(B_D_S_VAL);

    private int code;

    SmsBRepo(int cd) {
        this.code = cd;
    }

    @Override
    public int value() {
        return code;
    }

    public static SmsBRepo getUpcMain() {
        return UPC_MAIN;
    }

    public static SmsBRepo getUpcSub() {
        return UPC_SUB;
    }

    public static SmsBRepo getDncMain() {
        return DNC_MAIN;
    }

    public static SmsBRepo getDncSub() {
        return DNC_SUB;
    }
}
