/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvObjectDupBean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KissDupTimer {

    private static final int N4000 = 4000;
    @Autowired
    @Qualifier("kissRecvMap")
    private ConcurrentHashMap<String, RecvObjectDupBean> kissRecvMap;

    private long spTime = 0;
    private List<String> keys = null;
    long currTime = 0;

    @Scheduled(fixedDelayString = "100", initialDelayString = "3000")
    public void monitor() {

        if (kissRecvMap.size() != 0) {
            currTime = System.currentTimeMillis();

            keys = new ArrayList(kissRecvMap.keySet());

            for (String key : keys) {

                spTime = (currTime - kissRecvMap.get(key).getRecvTime());

                if (spTime > N4000) {
                    kissRecvMap.remove(key);
                }
            }

        }

    }
}
