/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.msg;

public class SequenceHeader {

    private int sequenceType;
    private int sequenceSize;

    String toMsg = "SequenceHeader { Type: %d, Size: %d }";

    public SequenceHeader(int seqType, int seqSize) {
        this.sequenceType = seqType;
        this.sequenceSize = seqSize;
    }

    public int getSequenceType() {
        return sequenceType;
    }

    public int getSequenceSize() {
        return sequenceSize;
    }

    @Override
    public String toString() {
        return String.format(toMsg, sequenceType, sequenceSize);
    }
}
