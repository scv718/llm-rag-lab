/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service;

import java.util.ArrayList;

public interface McrcService {

    void putRasd(EncodeIF encodedData);


}
