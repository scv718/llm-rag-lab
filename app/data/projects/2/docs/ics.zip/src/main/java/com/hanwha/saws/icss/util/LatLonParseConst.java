/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

public abstract class LatLonParseConst {
    
    protected static final int N0 = 0;
    protected static final int N1 = 1;
    protected static final int N2 = 2;
    protected static final int N3 = 3;
    protected static final int N4 = 4;
    protected static final int N5 = 5;
    
    protected static final double D0 = 0.0;
    protected static final double D1 = 1.0;
    protected static final double D2 = 2.0;
    protected static final double D3 = 3.0;
    protected static final double D4 = 4.0;
    protected static final double D5 = 5.0;
    protected static final double D8 = 8.0;
    protected static final double D7 = 7.0;
    protected static final double D9 = 9.0;
    protected static final double D10 = 10.0;
    protected static final double D12 = 12.0;
    protected static final double D15 = 15.0;
    protected static final double D17 = 17.0;
    protected static final double D180 = 180.0;
    protected static final double D315 = 315.0;

    // DMS 변환용
    protected static final double MIN = 60.0;
    protected static final double HOUR = 3600.0;

    /*
     * 지구 모델 
     * 가상 지구 반경(NM)
     */
    protected static final double CONFORMAL_SPHERE_RADIUS = 3430.619;
//    수치안정을 위한 수렴오차
    protected static final double NUMERIC_EPSILON = 0.000000953674;
//    적도반경 해리
    protected static final double EARTH_EQUATORIAL_RADIUS_NM = 3443.9185;
//    편평률
    protected static final double EARTH_FLATTENING = 1.0 / 298.2572;

    protected static final float SCALE_IN_SITE_INCREMENTS = 1000.0f; // yards
    private static final float YARD_FACTOR = (1.012685914f * 6000.0f) / 3.0f;
    protected static final float YARD_TO_NM = (float) (1.0f / YARD_FACTOR);
    protected static final float FIRST_NEG_X = (float) Math.pow(2.0, 11.0f);

    protected static final int[] DAEGU = { 128, 39, 9, 35, 54, 21 };
    protected static final int[] OSAN  = { 127,  2, 7, 37,  4, 50 };
        
    protected LatLonParseConst() {}
}
