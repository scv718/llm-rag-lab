/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hanhwa.saws.mediator.miss.service.EncodeIF;

@Configuration
public class QueueConfig {

    @Bean(name = "mcrcRecvQueue")
    public ConcurrentLinkedQueue<byte[]> mcrcRecvQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "mcrcSendQueue")
    public ConcurrentLinkedQueue<EncodeIF> mcrcSendQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "kamdRecvQueue")
    public ConcurrentLinkedQueue<String> kamdRecvQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean(name = "kamdSendQueue")
    public  ConcurrentLinkedQueue<ArrayList<byte[]>> kamdSendQueue() {
        return new ConcurrentLinkedQueue<>();
    }


}