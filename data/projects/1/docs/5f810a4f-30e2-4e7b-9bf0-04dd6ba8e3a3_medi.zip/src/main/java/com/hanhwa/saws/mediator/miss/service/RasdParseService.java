/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service;

import com.hanhwa.saws.mediator.miss.msg.McrcSeqBean;

public interface RasdParseService {

    void parse(McrcSeqBean seqBean);

}
