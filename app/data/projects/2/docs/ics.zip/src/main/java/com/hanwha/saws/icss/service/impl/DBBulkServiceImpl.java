/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.service.DBBulkService;

import lombok.extern.slf4j.Slf4j;

@Service("DBBulkService")
@Slf4j
public class DBBulkServiceImpl implements DBBulkService {

    @Autowired
    @Qualifier("missBulkQueue")
    private ConcurrentLinkedQueue<McrcHistModel> missBulkQueue;

    @Autowired
    @Qualifier("missFileQueue")
    private ConcurrentLinkedQueue<McrcHistModel> missFileQueue;

    @Autowired
    @Qualifier("kissBulkQueue")
    private ConcurrentLinkedQueue<KamdHistModel> kissBulkQueue;

    @Autowired
    @Qualifier("kissFileQueue")
    private ConcurrentLinkedQueue<KamdHistModel> kissFileQueue;

    @Override
    public void pushAirTrackQueue(McrcHistModel model) {
        model.setTime();
        log.debug("AirTrack DB Bulk Queue Insert");
        missBulkQueue.offer(model);
    }

    @Override
    public void pushMissleQueue(KamdHistModel model) {
        model.setTime();
        log.debug("Missle DB Bulk Queue Insert");
        kissBulkQueue.offer(model);

    }
}