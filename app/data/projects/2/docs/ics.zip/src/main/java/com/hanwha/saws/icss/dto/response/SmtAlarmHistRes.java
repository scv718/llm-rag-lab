/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;

import lombok.Data;

@Data
public class SmtAlarmHistRes {

    private Long seq;
    @JsonProperty("node_id") private Integer nodeId;
    @JsonProperty("node_name") private String nodeName;
    @JsonProperty("ip") private String addrIp;
    @JsonProperty("alarm_id") private String alarmId;
    @JsonProperty("alarm_name") private String alarmName;
    private String serverity;
    private String summary;
    @JsonProperty("first_occur") private String firstOccurrence;
    @JsonProperty("last_occur") private String lastOccurrence;
    @JsonProperty("recover_time") private String recoveryTime;
    @JsonProperty("insert_time") private String insertTime;
    private int tally;

    @JsonIgnore
    public void setData(AlarmHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        seq = data.getIdx();
        nodeId = data.getNodeId();
        nodeName = data.getNodeName();
        addrIp = data.getAddrIp();
        alarmId = data.getAlarmId();
        alarmName = data.getAlarmName();
        serverity = data.getServerity();
        summary = data.getSummary();
        firstOccurrence = sdf.format(data.getFirstOccurrence());
        lastOccurrence = sdf.format(data.getLastOccurrence());
        if (data.getRecoverTime() != null) {
            recoveryTime = sdf.format(data.getRecoverTime());
        }
        insertTime = sdf.format(data.getInsertTime());
        tally = data.getTally();

    }
}
