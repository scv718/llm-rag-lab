/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import lombok.Data;

@Data
public class LoginSessionBean {
    private static final int N15 = 15;
    private static final int N1000 = 1000;
    
	private String bearer;
	private String ip;
	private long expireTime;
	private String userId;
	private String pw;
	private String name;
	private String groupId;
	private String groupName;

    public void updateSessionTime(int time) {
        if (time < N15) {
            time = N15;
        }
        expireTime = System.currentTimeMillis() + (time * N1000);
    }

}
