/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.sync;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Data;

@Data
public class ActiveStatusBean {

    @JsonProperty("id") @SerializedName("id") private String id;

    @JsonProperty("active") @SerializedName("active") private int active;

}
