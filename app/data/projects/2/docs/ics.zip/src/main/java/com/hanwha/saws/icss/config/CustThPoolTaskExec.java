/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

import org.springframework.core.task.TaskRejectedException;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustThPoolTaskExec extends ThreadPoolTaskExecutor {
    
    private final String executorName;
    
    public CustThPoolTaskExec(String name) {
        this.executorName = name;
        this.setThreadNamePrefix(name + "-"); // 스레드 이름에도 반영
    }

    @Override
    public <T> Future<T> submit(Callable<T> task) {

        log.debug(
                "[ASYNC POOL] executor={}, task={}", executorName,
                task.toString()
        );

        try {
            return super.submit(task);
        } catch (RejectedExecutionException ex) {
            throw new TaskRejectedException(
                    "Executor did not accept task: " + task, ex
            );
        }
    }

    @Override
    public void execute(Runnable task) {
        if (!"smsAirTrackExecutor".equals(executorName)) {
            log.debug("[ASYNC POOL] executor={}, task={}", executorName,
                    simpleTaskName(task));
        }        
        super.execute(task);
    }

    private String simpleTaskName(Object task) {
        
        String fullName = task.getClass().getName();
        int idx = fullName.lastIndexOf('.');
        
        return (idx != -1) ? fullName.substring(idx + 1) : fullName;
    }
}
