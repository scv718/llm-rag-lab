/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.response.VoiceStatusRes;
import com.hanwha.saws.icss.dto.scc.SccCommandBean;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccVoiceTimer {
    private static final int FST_START = 0;
    private static final int FST_STOP = 1;
    private static final int SND_START = 2;
    private static final int SND_STOP = 3;
    private static final int SAVE_START = 1;
    private static final int SAVE_END = 2;

    private String rcvGroupId = "030000";

    private int voiceAuthStatus = SND_STOP;
    private boolean isVoiceInsertRefresh = false;
    private String voiceAuthIp = "127.0.0.1";

    @Value("${scc.send-port}")
    int sccPort;

    @Autowired
    PropConfig prop;

    @Autowired
    @Qualifier("voiceFileQueue")
    private ConcurrentLinkedQueue<SccCommandBean> voiceFileQueue;
    
    public void setVoiceInsertRefresh(boolean voiceInfo) {
        isVoiceInsertRefresh = voiceInfo;
    }

    public String getVoiceAuthIp() {
        return voiceAuthIp;
    }

    public int getVoiceAuthStatus() {
        return voiceAuthStatus;
    }

    public boolean checkVoicePriority(String sIp) {
        int vs = voiceAuthStatus;
        String vIp = voiceAuthIp;
        boolean isVoiceStart = ((vs == FST_START) || (vs == SND_START));
        boolean isSameSource = vIp.equals(sIp);
        
        if (isVoiceStart && isSameSource) {
            isVoiceInsertRefresh = true;
            return true;
        }

        return false;
    }

    public VoiceStatusRes getVoiceStatus() {
        VoiceStatusRes vRes = new VoiceStatusRes();
        int vs = voiceAuthStatus;
        boolean isVoiceStart = ((vs == FST_START) || (vs == SND_START));
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel nm = null;

        if (isVoiceStart) {
            vRes.setActiveYn("Y");
            vRes.setIp(voiceAuthIp);
            vRes.setPrioritry((vs == FST_START) ? "1" : "2");
            nm = nH.get(NodeRepo.getSccA().getCode());
            if (!nm.getAddrIp().equals(voiceAuthIp)) {
                nm = nH.get(NodeRepo.getSccB().getCode());
            }

            vRes.setName(nm.getName());
        }
        return vRes;
    }

    public boolean setVoicePriority(SccCommandBean vPCB, String vPIp) {
        int vs = voiceAuthStatus;
        int type = vPCB.getFrame();
        SccCommandBean sCB = null;

        MDC.put("LOG_KEY", vPCB.getLogKInfo());

        log.debug("setVoicePriority " + type);
        if (type == FST_STOP) {

            if ((vs == FST_STOP) || (vs == SND_STOP)) {
                log.debug("Already voice stop");
                return false;
            }

            rcvGroupId = vPCB.getCmdGroupId();
            sCB = new SccCommandBean();
            sCB.setFileSaveType(SAVE_END);
            voiceFileQueue.offer(sCB);
            voiceAuthStatus = type;
            voiceAuthIp = vPIp;
            return true;
        }

        if (type == SND_STOP) {
            if ((vs == FST_STOP) || (vs == SND_STOP)) {
                log.debug("Already voice stop");
                return false;
            }

            if (vs == FST_START) {
                log.debug("First priority dont stop by this code " + type);
                return false;
            }

            rcvGroupId = vPCB.getCmdGroupId();
            sCB = new SccCommandBean();
            sCB.setFileSaveType(SAVE_END);
            voiceFileQueue.offer(sCB);
            voiceAuthStatus = type;
            voiceAuthIp = vPIp;
            return true;
        }

        if (type == SND_START) {

            if (vs == FST_START) {
                log.debug("Fst priority dont disconnect this code " + type);
                return false;
            }
            
            rcvGroupId = vPCB.getCmdGroupId();

            sCB = new SccCommandBean();

            sCB.setFileSaveType(SAVE_START);
            voiceFileQueue.offer(sCB);
            voiceAuthStatus = type;
            isVoiceInsertRefresh = true;
            voiceAuthIp = vPIp;
            return true;
        }

        if (type == FST_START) { // 1순위 시작

            if (vs == FST_START) {
                log.debug("Already first priority voice start");
                return false;
            }

            if (vs == SND_START) {
                log.debug("first priority voice start, second stop");
                sCB = new SccCommandBean();
                sCB.setFileSaveType(SAVE_END);
                voiceFileQueue.offer(sCB);
            }
            
            rcvGroupId = vPCB.getCmdGroupId();

            sCB = new SccCommandBean();
            sCB.setFileSaveType(SAVE_START);
            voiceFileQueue.offer(sCB);
            voiceAuthStatus = type;
            isVoiceInsertRefresh = true;
            
            voiceAuthIp = vPIp;
            return true;
        }

        return true;
    }

    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {
        int vs = voiceAuthStatus;
        boolean ref = isVoiceInsertRefresh;
        
        SccCommandBean sccTmp = null;
        HashMap<Integer, NodeModel> nodeH = prop.getNodeInfoHash();
        NodeModel tNode = null;
        String vStopCode = "06050300000101";
        byte[] vStop = null;

        if ((!ref) && ((vs == FST_START) || (vs == SND_START))) {

            sccTmp = new SccCommandBean();
            sccTmp.setFileSaveType(SAVE_END);
            voiceFileQueue.offer(sccTmp);
            voiceAuthStatus = SND_STOP;

            log.info("Voice Force stop : no data for 2 seconds");

            vStopCode = "0605" + rcvGroupId + "01";

            if (vs == FST_START) {
                vStopCode += "01";
            } else {
                vStopCode += "03";
            }

            vStop = HexFormat.of().parseHex(vStopCode);

            log.info("Voice Force stop code " + vStopCode);
            tNode = nodeH.get(NodeRepo.getSccA().getCode());
            sendUdp(tNode, sccPort, vStop);
            tNode = nodeH.get(NodeRepo.getSccB().getCode());
            sendUdp(tNode, sccPort, vStop); // 둘다에게 강제종료 전송
        }

    }

    private boolean sendUdp(NodeModel info, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket packet = null;
            
            packet = new DatagramPacket(data, data.length, mcastaddr, port);
            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccService sendUdpData()" + e.toString());
            return false;
        }

        return true;
    }
}
