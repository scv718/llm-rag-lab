/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class STypeRepo {

    private static final byte M_C = 0x00; // 탄도탄 정보
    private static final byte VO_C = 0x01; // 음성명령
    private static final byte AR_C = 0x02; // 경계/공습경보
    private static final byte AD_C = 0x03; // 방공통제명령
    private static final byte EM_C = 0x04; // 긴급메시지
    private static final byte AT_C = 0x05; // 항공기 항적정보
    private static final byte CT_C = 0x06; // 제어메시지
    private static final byte AW_C = 0x09; // 방공경보구역(수동)
    public static final byte AA_C = 0x0A; // 방공경보구역 경계/공습
    private static final byte ETC = (byte) 0xFF; // 기타

    private static final String M_MSL = "탄도탄 정보";
    private static final String M_VO = "음성명령";
    private static final String M_AR = "경계 공습경보";
    private static final String M_ADC = "방공통제명령";
    private static final String M_EM = "긴급메시지";
    private static final String M_AT = "항공기 항적정보";
    private static final String M_CTL = "제어메시지";
    private static final String M_AW = "방공경보구역(수동)";
    private static final String M_AA = "방공경보구역 경계 공습";
    private static final String M_ETC = "기타";

    private static final Map<Byte, STypeRepo> CODE_MAP = new HashMap<>();

    private static final STypeRepo MSL_R = new STypeRepo(M_C, M_MSL, true);
    private static final STypeRepo VO_R = new STypeRepo(VO_C, M_VO, false);
    private static final STypeRepo AR_R = new STypeRepo(AR_C, M_AR, false);
    private static final STypeRepo ADC_R = new STypeRepo(AD_C, M_ADC, true);
    private static final STypeRepo EM_R = new STypeRepo(EM_C, M_EM, true);
    private static final STypeRepo AT_REPO = new STypeRepo(AT_C, M_AT, true);
    private static final STypeRepo CTL_R = new STypeRepo(CT_C, M_CTL, false);
    private static final STypeRepo AW_R = new STypeRepo(AW_C, M_AW, true);
    private static final STypeRepo AA_R = new STypeRepo(AA_C, M_AA, true);
    private static final STypeRepo ETC_R = new STypeRepo(ETC, M_ETC, false);

    static {
        CODE_MAP.put(MSL_R.getCode(), MSL_R);
        CODE_MAP.put(VO_R.getCode(), VO_R);
        CODE_MAP.put(AR_R.getCode(), AR_R);
        CODE_MAP.put(ADC_R.getCode(), ADC_R);
        CODE_MAP.put(EM_R.getCode(), EM_R);
        CODE_MAP.put(AT_REPO.getCode(), AT_REPO);
        CODE_MAP.put(CTL_R.getCode(), CTL_R);
        CODE_MAP.put(AW_R.getCode(), AW_R);
        CODE_MAP.put(AA_R.getCode(), AA_R);
        CODE_MAP.put(ETC_R.getCode(), ETC_R);
    }

    private final byte code;
    private final String msg;
    private final boolean use;

    /*
     * SCC SMS SEND RECV TYPE 각 COMMAND들 전부 다 구분용
     */
    private STypeRepo(byte cd, String mg, boolean u) {
        this.code = cd;
        this.msg = mg;
        this.use = u;
    }

    public byte getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public boolean isUse() {
        return use;
    }

    public static STypeRepo fromCode(byte cd) {
        return CODE_MAP.getOrDefault(cd, ETC_R);
    }

    public static STypeRepo getMissleCmd() {
        return MSL_R;
    }

    public static STypeRepo getVoCmd() {
        return VO_R;
    }

    public static STypeRepo getArCmd() {
        return AR_R;
    }

    public static STypeRepo getAdcCmd() {
        return ADC_R;
    }

    public static STypeRepo getEmCmd() {
        return EM_R;
    }

    public static STypeRepo getAirTrackCmd() {
        return AT_REPO;
    }

    public static STypeRepo getCtlCmd() {
        return CTL_R;
    }

    public static STypeRepo getAdwCmd() {
        return AW_R;
    }

    public static STypeRepo getAdwArCmd() {
        return AA_R;
    }

    public static STypeRepo getEtcCmd() {
        return ETC_R;
    }

    public static List<STypeRepo> getOpOnlyCodes() {
        List<STypeRepo> list = new ArrayList<>();

        for (STypeRepo item : CODE_MAP.values()) {
            if (item.isUse()) {
                list.add(item);
            }
        }

        list.sort(Comparator.comparingInt(STypeRepo::getCode));
        return list;
    }

//    private static Comparator<STypeRepo> codeComparator() {
//        return Comparator.comparingInt(STypeRepo::getCode);
//    }

}
