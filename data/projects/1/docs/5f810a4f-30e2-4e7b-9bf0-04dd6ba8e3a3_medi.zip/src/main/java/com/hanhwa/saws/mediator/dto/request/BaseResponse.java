/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.hanhwa.saws.mediator.dto.code.ResponseCode;
import lombok.Data;

@Data
public class BaseResponse {

    @JsonProperty("code") private int resCd;

    @JsonProperty("message") private String resMsg;

    @JsonProperty("data") private Object data;

    public BaseResponse() {}

    public BaseResponse(ResponseCode code) {
        setData(code.getCode(), code.getMsg());
    }

    public BaseResponse(ResponseCode code, Object obj) {
        setData(code.getCode(), code.getMsg());
        this.data = obj;
    }

    public BaseResponse(int reCd, String reMsg, Object obj) {
        setData(reCd, reMsg);
        this.data = obj;
    }

    public BaseResponse(int reCd, String reMsg) {
        setData(reCd, reMsg);
    }

    private void setData(int rCd, String rMsg) {
        this.resCd = rCd;
        this.resMsg = rMsg;
    }
}
