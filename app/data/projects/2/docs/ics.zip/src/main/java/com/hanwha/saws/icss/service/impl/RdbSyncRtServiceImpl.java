/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.dto.RSyncB;
import com.hanwha.saws.icss.service.RdbSyncRtService;

import lombok.extern.slf4j.Slf4j;

@Service("RdbSyncRtService")
@Slf4j
public class RdbSyncRtServiceImpl implements RdbSyncRtService {

    @Autowired
    @Qualifier("rSyncQueue")
    private ConcurrentLinkedQueue<RSyncB> rSyncQueue;

    public void insertQueue(Object qObj, String qType) {
        RSyncB bean = new RSyncB(qObj, qType);
        
        rSyncQueue.offer(bean);
    }

}
