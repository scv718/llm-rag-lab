/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.scc.SccCommandBean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccVoiceFileSaveMgr {
    private static final int N1000 = 1000;
    private static final int N2000 = 2000;
    private static final int BYTE_BUFFER_SIZE = 960000;

    private static final int SAVE_START = 1;
    private static final int SAVE_END = 2;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;

    private long lastProcTime = System.currentTimeMillis();
    private ByteArrayOutputStream bos = null;
    private String fileName = null;
    private String sFStr = "yyyyMMddHHmmss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(sFStr);

    @Autowired
    @Qualifier("voiceFileQueue")
    private ConcurrentLinkedQueue<SccCommandBean> voiceFileQueue;

    @Value("${ics.voice-dir}")
    String voiceDir;

    @Autowired
    SccVoiceTimer voiceTimer;

    @Autowired
    private SccVoiceSaveTask saveTaskService;

    private void prepareBuffer() throws IOException {
        log.debug("voice file prepareBuffer");
        fileName = formatter.format(LocalDateTime.now());
        bos = new ByteArrayOutputStream(BYTE_BUFFER_SIZE);
        lastProcTime = System.currentTimeMillis();
    }
   
    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {

        long currentTime = 0;
        boolean isTOut = false;
        SccCommandBean sccComBean = null;

        currentTime = System.currentTimeMillis();

        if (voiceFileQueue.size() == 0) {

            if (bos != null) {
                isTOut = (currentTime - lastProcTime > N1000);
                if (isTOut 
                        || (bos.size() > BYTE_BUFFER_SIZE)) {
                    saveFile();
                }

            }

            isTOut = (currentTime - lastProcTime > N2000);
            if (isTOut) {
                voiceTimer.setVoiceInsertRefresh(false);
            }

            return;
        }

        try {
            while (!voiceFileQueue.isEmpty()) {
                sccComBean = voiceFileQueue.poll();
                MDC.put("LOG_KEY", sccComBean.getLogKInfo());

                if (sccComBean.getFileSaveType() == SAVE_START) {
                    prepareBuffer();
                } else if (sccComBean.getFileSaveType() == SAVE_END) {
                    saveFile();
                } else {

                    if (bos == null) {
                        prepareBuffer();
                    }
                    bos.write(sccComBean.getVoiceToSave());
                    lastProcTime = currentTime;

                }
            }
        } catch (IOException e) {
            log.warn("SaveTask warn " + e.toString());
        }

        if (bos != null) {
            isTOut = (currentTime - lastProcTime > N1000);

            if (isTOut 
                    || (bos.size() > BYTE_BUFFER_SIZE)) {
                saveFile();
            }
        }
    }

    private void saveFile() {
        if ((bos != null) && (bos.size() > 0)) {
            log.debug("voice file save");
            saveTaskService.save(fileName, bos.toByteArray(), voiceDir);
            try {
                bos.close();
            } catch (IOException ee) {
                log.warn("SaveTask outputstream " + ee.toString());
            }

        }

        fileName = null;
        bos = null;
    }

}
