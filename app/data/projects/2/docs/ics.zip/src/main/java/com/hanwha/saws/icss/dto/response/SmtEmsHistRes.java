/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hanwha.saws.icss.persistence.model.EmsHistModel;

import lombok.Data;

@Data
public class SmtEmsHistRes {

    private int idx;
    private String type;
    private String result;

    private String time;

    @JsonIgnore
    public void setData(EmsHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

        idx = data.getIdx();
        type = data.getOperationType();
        result = data.getOperationResult();

        time = sdf.format(data.getInsertTime());

    }
}
