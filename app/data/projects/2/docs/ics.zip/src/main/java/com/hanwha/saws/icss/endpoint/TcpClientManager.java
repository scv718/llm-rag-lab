/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.SmsTcpMsgBean;
import com.hanwha.saws.icss.dto.SmsTcpObjectBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.SmsRepo;

import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Scope("prototype")
public class TcpClientManager {

    private static final int N1000 = 1000;
    private static final int N1024 = 1024;
    private static final int N2 = 2;
    
    private final AtomicBoolean receiving = new AtomicBoolean(false);
    
    private final TaskScheduler taskScheduler; 
    
    private String host;
    @Value("${sms.connect-port}") int port;
    private NodeRepo code;
    
    @Autowired
    @Qualifier("smsEventQueue") 
    private ConcurrentLinkedQueue<SmsTcpEventBean> eventQueue;
    
    private Map<Integer, CompletableFuture<SmsTcpObjectBean>> objMap;
      
    private volatile Socket socket;
    
    @Autowired
    @Qualifier("smsListenerExecutor")
    private Executor smsExecutor;
    
    private SmsSockListener listener;
    private ScheduledFuture<?> listenerTask;

    public TcpClientManager(TaskScheduler taskScheduler) {        
        this.taskScheduler = taskScheduler;
    }

    @PreDestroy
    public void onDestroy() {
        closeSocket();
    }
    
    public void addUnknownCount() {
        listener.addUnknownCount();
    }
    
    public void setUnknownInit() {
        listener.setUnknownInit();
    }
    
    public void setInfo(String ip, NodeRepo repo) {
        host = ip;
        code = repo;
        objMap = new ConcurrentHashMap<>();
        startConnectionThread();
    }
    
    public NodeRepo getNode() {
        return code;
    }

    public boolean isConnect() {
        return socket != null && socket.isConnected() && !socket.isClosed();
    }

    private void startConnectionThread() {
        this.listener = new SmsSockListener(this, smsExecutor);
        this.listenerTask = taskScheduler.scheduleAtFixedRate(
                listener::tryConnect, Duration.ofSeconds(1));

    }

    public SmsTcpObjectBean sendAndWait(SmsTcpMsgBean swBean,
            long timeoutMillis) throws IOException, CompletionException {
        
        int sid = swBean.getReqBean().getSid();
        
        try {

            String sendBStr = HexFormat.of().formatHex(swBean.getReqBeanByte());

            CompletableFuture<SmsTcpObjectBean> fu = new CompletableFuture<>();

            objMap.put(sid, fu);

            log.debug("send sms byte: {}", sendBStr);
            sendBytes(swBean.getReqBeanByte());
            
            return fu.orTimeout(timeoutMillis, TimeUnit.MILLISECONDS).join();
        } catch (IOException e) {
            log.warn("IOException {}", sid);
            throw e;
        } catch (CompletionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof TimeoutException) {
                log.warn("Timeout for SID {}", sid);
            } else if (cause instanceof ExecutionException) {
                log.warn("Execution error for SID {}", sid);
            } else {
                log.warn("Unexpected error for SID {}", sid);
            }
            throw e;
        } finally {
            objMap.remove(sid);
        }
    }

    public synchronized void sendBytes(byte[] data) throws IOException {
        boolean isConnected = socket != null && socket.isConnected();
        boolean isAlive = !socket.isClosed() && !socket.isOutputShutdown();
        
        if (isConnected && isAlive) {
            OutputStream out = socket.getOutputStream();
            out.write(data);
            out.flush();
        } else {
            throw new IOException(host + " Not connected to server");
        }
    }

    protected void onReceive(byte[] data) {
        short header = ByteBuffer.wrap(data, 0, N2).getShort();
        
        CompletableFuture<SmsTcpObjectBean> future = null;
        SmsTcpObjectBean oBean = new SmsTcpObjectBean();
        int oSid = 0;
        SmsTcpEventBean eBean = null;
        
        log.debug("Modem Recv origin = {}", HexFormat.of().formatHex(data));
        
        if (header == SmsRepo.getTypeEvt().getCode()) {
            eBean = new SmsTcpEventBean();
            
            try {
                eBean.decode(data);
                eBean.setCode(code);
                eventQueue.offer(eBean);
                log.debug("Modem Recv Queue Insert");
            } catch (IOException e) {
                log.warn("SMS EventCode decode failed", e);
            }
        } else {
            oBean = new SmsTcpObjectBean();
            oBean.decode(data);
            
            oSid = oBean.getSid();
            future = objMap.get(oSid);
            
            if (future != null) {
                future.complete(oBean);
            } else {
                log.warn("No matching future for SID: {}", oSid);
            }
        }
    }

    public void closeSocket() {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            log.warn("Error closing socket", e);
        } finally {
            socket = null;
        }
    }

    public boolean startReceiver(Executor executor) {
        if (receiving.compareAndSet(false, true)) {
            executor.execute(new SmsSockReceiver(this));
            return true;
        }
        return false;
    }
    
    public void receiverFinished() {
        receiving.set(false);
    }
   
    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

}
