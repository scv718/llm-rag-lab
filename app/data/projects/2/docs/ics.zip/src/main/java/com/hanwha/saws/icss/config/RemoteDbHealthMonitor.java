/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RemoteDbHealthMonitor {

    private final DataSource remoteDataSource;
    private volatile boolean remoteAlive = true; // 현재 상태 캐시
    private volatile long lastCheckedTime = 0L; // 최근 체크 시각(ms)

    public RemoteDbHealthMonitor(@Qualifier("remoDS") DataSource rDSrc) {
        remoteDataSource = rDSrc;
    }

    @PostConstruct
    public void startHealthCheck() {
        log.info("[RemoteDB] Health monitor initialized");
    }

    @Scheduled(fixedDelay = 3000)
    public void checkRemoteDb() {

        boolean prev = remoteAlive;

        try (Connection conn = remoteDataSource.getConnection()) {
            remoteAlive = conn.isValid(1); // 1초 내 응답 확인
        } catch (SQLException e) {
            remoteAlive = false;
        }

        lastCheckedTime = System.currentTimeMillis();

        if (prev != remoteAlive) {
            log.warn("[RemoteDB] CONNECTION STATUS CHANGE : {}",
                    remoteAlive ? "conn" : "disconn");
        } else {            
            log.trace("[RemoteDB] alive {} (time: {})", remoteAlive,
                    lastCheckedTime);
        }

    }

    public boolean isRemoteAlive() {
        return remoteAlive;
    }

    public long getLastCheckedTime() {
        return lastCheckedTime;
    }
}