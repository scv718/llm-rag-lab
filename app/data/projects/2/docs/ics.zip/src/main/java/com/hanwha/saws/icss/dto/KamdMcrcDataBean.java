/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import static java.time.format.DateTimeFormatter.ofPattern;
import lombok.Data;

@Data
public class KamdMcrcDataBean {

    @JsonIgnore private static final String F_TYPE = "yyyyMMddHHmmssSSS";
    @JsonIgnore private LocalDateTime insertTime;
    private String time;
    private String data;
    @JsonIgnore DateTimeFormatter formatter = ofPattern(F_TYPE);

    public void setInsertTimeToTime(LocalDateTime iTime) {
        time = formatter.format(iTime);
        insertTime = iTime;
    }

    @JsonIgnore
    public void setDataDec(byte[] b) {
        data = HexFormat.of().formatHex(b);
    }
}
