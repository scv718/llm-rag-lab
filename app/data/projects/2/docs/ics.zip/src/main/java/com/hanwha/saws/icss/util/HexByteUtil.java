/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.util.HexFormat;

public class HexByteUtil {
    
    private static final int BFF = 0xFF;
    
    private HexByteUtil() {}

    public static byte[] getHexStringToByteArray(String hexString) {
        return HexFormat.of().parseHex(hexString);
    }

    public static byte getHexStringToByte(String hexString) {
        return HexFormat.of().parseHex(hexString)[0];
    }

    public static String getByteArrayToHexString(byte[] b) {
        return HexFormat.of().formatHex(b);
    }

    public static String getHexStringToBynaryString(String hexString) {
        byte[] bytes = HexFormat.of().parseHex(hexString);
        StringBuilder sb = new StringBuilder();
        String tmp = "";

        for (byte hb : bytes) {
            tmp = Integer.toBinaryString(BFF & hb);

            sb.append(String.format("%8s", tmp).replace(' ', '0'));
        }

        return sb.toString();
    }

    public static String getByteArrayToBynaryString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        String tmp = "";

        for (byte by : bytes) {
            tmp = Integer.toBinaryString(BFF & by);
            sb.append(String.format("%8s", tmp).replace(' ', '0'));
        }

        return sb.toString();
    }

    public static String getBinStr(byte b) {
        String tmp = Integer.toBinaryString(b & BFF);
        String binary = String.format("%8s", tmp).replace(' ', '0');

        return binary;
    }

    public static String getByteToBynaryString(byte b) {
        String tmp = Integer.toBinaryString(BFF & b);

        return String.format("%8s", tmp).replace(' ', '0');
    }

    public static String getIntToBynaryString(int i) {
        String tmp = Integer.toBinaryString(BFF & i);

        return String.format("%8s", tmp).replace(' ', '0');
    }

}
