/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.hanwha.saws.icss.dto.code.ResRepo;

import lombok.Data;

@Data
public class BaseResponse {

    @JsonProperty("code") private int resCd;

    @JsonProperty("message") private String resMsg;
    
    @JsonProperty("t_cnt") @JsonInclude(Include.NON_NULL) private Long tCnt;
    
    @JsonProperty("t_page") @JsonInclude(Include.NON_NULL) private Long tPage;
    @JsonProperty("n_page") @JsonInclude(Include.NON_NULL) private Long nPage;

    @JsonProperty("data") private Object data;

    public BaseResponse() {}

    public BaseResponse(ResRepo code) {
        setData(code.getCode(), code.getMsg());
    }

    public BaseResponse(ResRepo code, Object obj) {
        setData(code.getCode(), code.getMsg());
        this.data = obj;
    }

    public BaseResponse(ResRepo code,long totalCnt, Object obj) {
        setData(code.getCode(), code.getMsg());
        tCnt = totalCnt;
        this.data = obj;
    }

    public BaseResponse(
            ResRepo code, long totalCnt, long totalP, long nowP, Object obj) {
        setData(code.getCode(), code.getMsg());
        tCnt = totalCnt;
        tPage = totalP;
        nPage = nowP;
        this.data = obj;
    }

//    public BaseResponse(int rCd, String rMsg, Object obj) {
//        setData(rCd, rMsg);
//        this.data = obj;
//    }

    public BaseResponse(int rCd, String rMsg) {
        setData(rCd, rMsg);
    }

    private void setData(int rCd, String rMsg) {
        this.resCd = rCd;
        this.resMsg = rMsg;
    }
}
