/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.dto.LoginSessionBean;

import lombok.Data;

@Data
public class UserSessionRes {

    private String id;
    private String name;
    @JsonProperty("group_id") private String groupId;
    @JsonProperty("group_name") private String groupName;
    private String ip;

    public void setData(LoginSessionBean model) {
        id = model.getUserId();
        name = model.getName();
        ip = model.getIp();
        groupId = model.getGroupId();
        groupName = model.getGroupName();
    }

}
