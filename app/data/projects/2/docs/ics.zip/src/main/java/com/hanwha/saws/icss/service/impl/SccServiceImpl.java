/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.request.KamdSimulArrReq;
import com.hanwha.saws.icss.dto.request.KamdSimulReq;
import com.hanwha.saws.icss.dto.request.McrcSimulReq;
import com.hanwha.saws.icss.dto.request.McrcSimulRouteReq;
import com.hanwha.saws.icss.dto.request.SccStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.KamdLogDetailHistRes;
import com.hanwha.saws.icss.dto.response.KamdSimulRes;
import com.hanwha.saws.icss.dto.response.McrcLogDetailHistRes;
import com.hanwha.saws.icss.dto.response.McrcSimulRes;
import com.hanwha.saws.icss.dto.response.SccDeviceStatusRes;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistListRes;
import com.hanwha.saws.icss.dto.response.SmtDataSendRecvHistRes;
import com.hanwha.saws.icss.dto.scc.SccCommandBean;
import com.hanwha.saws.icss.persistence.dao.local.AirDefWarnHistDao;
import com.hanwha.saws.icss.persistence.dao.local.AirRaidHistDao;
import com.hanwha.saws.icss.persistence.dao.local.EmerHistDao;
import com.hanwha.saws.icss.persistence.dao.local.KamdHistDao;
import com.hanwha.saws.icss.persistence.dao.local.KamdHistDetailDao;
import com.hanwha.saws.icss.persistence.dao.local.McrcHistDao;
import com.hanwha.saws.icss.persistence.dao.local.McrcHistDetailDao;
import com.hanwha.saws.icss.persistence.dao.local.MessageHistDao;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.SimulDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.KamdHistDetailModel;
import com.hanwha.saws.icss.persistence.model.KamdSimulModel;
import com.hanwha.saws.icss.persistence.model.LoginHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistDetailModel;
import com.hanwha.saws.icss.persistence.model.McrcSimulModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.ServerHistStatModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.SccService;
import com.hanwha.saws.icss.service.StatService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.DataCrypt;
import com.hanwha.saws.icss.util.HexByteUtil;
import com.hanwha.saws.icss.util.LogKeyUtil;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Service("SccService")
@Slf4j
public class SccServiceImpl implements SccService {
    
    private static final String LOGIN = "login";
    
    private static final byte CMD_VOICE = 0x01;
    private static final byte TRAIN_MODE = 0x03;
    private static final byte MCRC_TRAIN_START = 0x04;
    private static final byte MCRC_TRAIN_END = 0x05;
    private static final byte KAMD_TRAIN_START = 0x06;
    private static final byte KAMD_TRAIN_END = 0x07;
    
    private static final int ACTIVE = 1;

    private static final int DB_STATUS_UNKNOWN = 1;

    private static final String OPTYPE_LOGIN = "LOGIN";
    private static final String OPTYPE_LOGOUT = "LOGOUT";
    private static final String OPRESULT_SUCCESS = "SUCCESS";    

    private static final String ICSS_A_DIR = "ICSS_A";
    private static final String ICSS_B_DIR = "ICSS_B";
    private static final int N30 = 30;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N26 = 26;
    private static final int N100 = 100;
    
    @Autowired PropConfig prop;

    @Value("${scc-voice.send-port}") int sccVPort;
    @Value("${scc.send-port}") int sccPort;
    @Value("${sms.send-port}") int smsPort;
    @Value("${ics.group-byte-length}") int groupByteLength;
    @Value("${ics.hist-data-file-dir.default}") String defaultDataDir;
    @Value("${ics.hist-data-file-dir.mcrc}") String mcrcDataDir;
    @Value("${ics.hist-data-file-dir.kamd}") String kamdDataDir;
    @Value("${ics.file-key}") String fileKey;
    @Value("${prop.host-name}") String hostName;
    @Value("${ics.user-key}") String uK;

    @Autowired SyncHistInsertService syncHistInsertService;
    @Autowired StatService statService;
    
    @Autowired SimulDao simulDao;
    @Autowired NonSyncHistDao nonSyncHistDao;
    @Autowired MessageHistDao msgHistDao;
    @Autowired EmerHistDao emerHistDao;
    @Autowired AirRaidHistDao airRaidHistDao;
    @Autowired AirDefWarnHistDao airDefWarnHistDao;
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired McrcHistDao mcrcHistDao;
    @Autowired KamdHistDao kamdHistDao;
    @Autowired AlarmService alarmService;
    @Autowired KamdHistDetailDao kamdRealHistDao;
    @Autowired McrcHistDetailDao mcrcRealHistDao;
    
    
    @Autowired SccVoiceTimer voiceTimer;

    private DataCrypt crypt = new DataCrypt();
    @Autowired
    @Qualifier("voiceFileQueue")
    private ConcurrentLinkedQueue<SccCommandBean> voiceFileQueue;
    
    @Autowired
    @Qualifier("mcrcSimulMap")
    private ConcurrentHashMap<String, Integer> mcrcSimulMap;

    @Autowired
    @Qualifier("kamdSimulMap")
    private ConcurrentHashMap<String, Integer> kamdSimulMap;

    private String simulSenderIp;
    
    @Override
    public String getSimulSenderIp() {
        return simulSenderIp;
    }
    
    @Override
    public BaseResponse sccLoginOut(SccStatusReq req, String senderIp) {

        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel nodeModel = NodeUtil.getNodeInfoP(hostName, nH);

        LoginHistModel bean = new LoginHistModel();

        bean.setUserId(req.getLoginId());
        bean.setUserName(req.getLoginName());
        bean.setUserIp(senderIp);
        bean.setNodeId(nodeModel.getNodeId());

        if (req.getLoginType().equals(LOGIN)) {
            bean.setOperationType(OPTYPE_LOGIN);
        } else {
            bean.setOperationType(OPTYPE_LOGOUT);
        }

        bean.setOperationResult(OPRESULT_SUCCESS);

        try {
            nonSyncHistDao.insertLoginHist(bean);
        } catch (RuntimeException e) {
            log.warn("sccLoginOut() " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

        return new BaseResponse(ResRepo.getC200());
    }

    @Override
    public void handleEvent(RecvMsgQueueBean param) {
        byte[] evtP = param.getData();
        String sIp = param.getSenderIp();

        SccCommandBean bean = null;
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel rSccNode = null;
        STypeRepo code = null;
        STypeRepo tmpCd = null;
        STypeRepo tmpCdN = null;
        NodeModel tmpNode = null;
        byte[] tmpByte = null;
        String logK = null;

        String tmp = "";
        boolean sentResult = false;
        boolean isS = false;

        MDC.remove("LOG_KEY");

        if (prop.getActiveMode() != ACTIVE) {
            log.debug("TYPE: SCC - its standby");
            return;
        }

        try {
            logK = LogKeyUtil.getRandomKey();
            MDC.put("LOG_KEY", logK);
            bean = new SccCommandBean(evtP, groupByteLength);
            bean.setLogKInfo(logK);
            rSccNode = NodeUtil.getNdAltScc(nH, sIp);

            code = STypeRepo.fromCode(bean.getType());
            tmp = HexByteUtil.getByteArrayToHexString(evtP);
            log.debug("SCC " + code.getMsg() + " RECV BYTE: " + tmp);

            tmpCd = STypeRepo.getVoCmd();
            tmpCdN = STypeRepo.getCtlCmd();

            if ((code != tmpCd) && (code != tmpCdN)) {

                log.debug("SCC BYTE: " + bean.getOriginFilterByte());

                log.debug("SCC SEND TO ALT SCC");
                sendUdp(rSccNode, sccPort, bean.getOriginFilterByte());

                if (prop.isModemSendMode()) {
                    log.debug("SCC OPERATION MODE, SEND TO MODEM");
                    tmpNode = nH.get(NodeRepo.getSmsA().getCode());
                    tmpByte = bean.getOriginFilterByte();
                    sentResult = sendUdp(tmpNode, smsPort, tmpByte);

                    tmpNode = nH.get(NodeRepo.getSmsB().getCode());
                    isS = sendUdp(tmpNode, smsPort, tmpByte);

                    if (isS) {
                        sentResult = isS;
                    }

                } else {
                    log.debug("SCC STANDBY MODE, DO NOT SEND TO MODEM");
                }
            }

            if (code.getCode() == STypeRepo.getArCmd().getCode()) {
                airRaidHistInsert(bean, sentResult);
            } else if (code.getCode() == STypeRepo.getAdcCmd().getCode()) {
                msgHistInsert(bean, sentResult);
            } else if (code.getCode() == STypeRepo.getEmCmd().getCode()) {
                emHistInsert(bean, sentResult);
            } else if (code.getCode() == STypeRepo.getAdwCmd().getCode()) {
                airDefWarnHistInsert(bean, sentResult);
            } else if (code.getCode() == STypeRepo.getCtlCmd().getCode()) {
                controlMsgProcess(bean, sIp, rSccNode);
            } else if (code.getCode() == STypeRepo.getAdwArCmd().getCode()) {
                airDefWarnAirRaidHistInsert(bean, sentResult);
            } else {
                log.debug("NON CODE" + code);
            }

        } catch (IOException | RuntimeException e) {
            tmp = HexByteUtil.getByteArrayToHexString(evtP);
            log.warn("SccService handleEvent() " + e.toString() + " " + tmp);
        }

    }

    @Override
    public void handleEventV(RecvMsgQueueBean param) {
        byte[] evtP = param.getData();
        String sIp = param.getSenderIp();

        SccCommandBean bean = null;
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel rSccNode = null;
        STypeRepo code = null;
        String logK = null;
        String tmp = "";

        MDC.remove("LOG_KEY");

        if (prop.getActiveMode() != ACTIVE) {
            log.debug("TYPE: SCC Voice - its standby");
            return;
        }

        try {
            logK = LogKeyUtil.getRandomKey();
            MDC.put("LOG_KEY", logK);
            bean = new SccCommandBean(evtP, groupByteLength);
            bean.setLogKInfo(logK);
            rSccNode = NodeUtil.getNdAltScc(nH, sIp);

            code = STypeRepo.fromCode(bean.getType());
            tmp = HexByteUtil.getByteArrayToHexString(evtP);
//            log.debug("SCC Voice " + code.getMsg() + " RECV BYTE: " + tmp);

            voiceProcess(bean, rSccNode, sIp);

        } catch (IOException | RuntimeException e) {
            tmp = HexByteUtil.getByteArrayToHexString(evtP);
            log.warn("SccService handleEventV() " + e.toString() + " " + tmp);
        }

    }

    private void controlMsgProcess(SccCommandBean bean, String senderIp,
            NodeModel remoteSccNode) {

        boolean isVoice = (bean.getFrameId() == CMD_VOICE);
        HashMap<Integer, NodeModel> nH = prop.getNodeInfoHash();
        NodeModel tmpNode = null;
        byte id = 0;
        String frameKey = null;
        Set<Byte> sendFrameSet = null;

        if (isVoice && (!voiceTimer.setVoicePriority(bean, senderIp))) {
            log.trace("not match voice");
            return;
        }

        if (prop.isModemSendMode()) { // 기존 시스템에도 보냄

            tmpNode = nH.get(NodeRepo.getSmsA().getCode());
            sendUdp(tmpNode, smsPort, bean.getOriginFilterByte());
            tmpNode = nH.get(NodeRepo.getSmsB().getCode());
            sendUdp(tmpNode, smsPort, bean.getOriginFilterByte());
        }

        sendFrameSet = new HashSet<>();

        sendFrameSet.add(CMD_VOICE);
        sendFrameSet.add(KAMD_TRAIN_START);
        sendFrameSet.add(MCRC_TRAIN_START);
        sendFrameSet.add(KAMD_TRAIN_END);
        sendFrameSet.add(MCRC_TRAIN_END);
        sendFrameSet.add(TRAIN_MODE);

        if (sendFrameSet.contains(bean.getFrameId())) {
            sendUdpDataByIP(senderIp, sccPort, bean.getOriginFilterByte());
        }

        log.debug("SCC BYTE: " + bean.getOriginFilterByte());
        log.debug("SCC SEND TO ALT SCC");

        sendUdp(remoteSccNode, sccPort, bean.getOriginFilterByte());

        id = bean.getFrameId();
        frameKey = bean.getFrame() + "";

        if ((id == KAMD_TRAIN_START) || (id == MCRC_TRAIN_START)) {
            simulSenderIp = senderIp;

            if (id == KAMD_TRAIN_START) {
                log.debug("KAMD SIMUL START");
                kamdSimulMap.put(frameKey, 1);
            } else { // MCRC_TRAIN_START
                log.debug("MCRC SIMUL START");
                mcrcSimulMap.put(frameKey, 1);
            }

        } else if ((id == KAMD_TRAIN_END) || (id == MCRC_TRAIN_END)) {

            if (id == KAMD_TRAIN_END) {
                log.debug("KAMD SIMUL END");
                kamdSimulMap.remove(frameKey);
            } else { // MCRC_TRAIN_END
                log.debug("MCRC SIMUL END");
                mcrcSimulMap.remove(frameKey);
            }
        }

    }
    
    private void voiceProcess(SccCommandBean bean, NodeModel remoteSccNode,
            String senderIp) throws RuntimeException {
        if (prop.isModemSendMode()) { // 작전모드일때만 저장
            log.debug("Scc Voice File Queue Insert");
            voiceFileQueue.offer(bean);
        } else {
            log.debug("SCC STANDBY MODE, DO NOT SEND TO MODEM");
        }
    }

    private void msgHistInsert(SccCommandBean bean, boolean sentResult)
            throws RuntimeException {
        MessageHistModel model = new MessageHistModel();
        byte[] tmpB = null;

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("msgHistInsert() " + e.toString());
            tmpB = bean.getOriginFilterByte();
            model.setData(HexByteUtil.getByteArrayToHexString(tmpB));
        }

        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setErrorFlag((sentResult ? "N" : "Y"));

        syncHistInsertService.insertMessageHist(model);
    }

    private void airRaidHistInsert(SccCommandBean bean, boolean sentResult)
            throws RuntimeException {
        AirRaidHistModel model = new AirRaidHistModel();
        byte[] tmpB = null;

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("airRaidHistInsert() " + e.toString());
            tmpB = bean.getOriginFilterByte();
            model.setData(HexByteUtil.getByteArrayToHexString(tmpB));
        }

        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setErrorFlag((sentResult ? "N" : "Y"));

        syncHistInsertService.insertAirRaidHist(model);
    }

    private void airDefWarnAirRaidHistInsert(SccCommandBean bean,
            boolean sentResult) throws RuntimeException {
        AirRaidHistModel model = new AirRaidHistModel();
        byte[] tmpB = null;

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("airDefWarnAirRaidHistInsert() " + e.toString());
            tmpB = bean.getOriginFilterByte();
            model.setData(HexByteUtil.getByteArrayToHexString(tmpB));
        }

        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setErrorFlag((sentResult ? "N" : "Y"));

        syncHistInsertService.insertAirDefWarnAirRaidHist(model);
    }

    private void emHistInsert(SccCommandBean bean, boolean sentResult)
            throws RuntimeException {
        EmerHistModel model = new EmerHistModel();
        byte[] tmpB = null;

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("emHistInsert() " + e.toString());
            tmpB = bean.getOriginFilterByte();

            model.setData(HexByteUtil.getByteArrayToHexString(tmpB));
        }

        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setErrorFlag((sentResult ? "N" : "Y"));

        syncHistInsertService.insertEmHist(model);
    }

    private void airDefWarnHistInsert(SccCommandBean bean, boolean sentResult)
            throws RuntimeException {
        AirDefWarnHistModel model = new AirDefWarnHistModel();
        byte[] tmpB = null;

        try {
            model.setData(crypt.encrypt(bean.getOriginFilterByte(), fileKey));
        } catch (RuntimeException e) {
            log.warn("airDefWarnHistInsert() " + e.toString());
            tmpB = bean.getOriginFilterByte();
            model.setData(HexByteUtil.getByteArrayToHexString(tmpB));
        }

        model.setDataSize(bean.getOriginFilterByte().length + "");
        model.setErrorFlag((sentResult ? "N" : "Y"));

        syncHistInsertService.insertAirDefWarnHist(model);
    }

    private boolean sendUdp(NodeModel info, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket packet = null;

            packet = new DatagramPacket(data, data.length, mcastaddr, port);
            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccService sendUdpData()" + e.toString());
            return false;
        }

        return true;
    }

    private boolean sendUdpDataByIP(String ip, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            DatagramPacket packet = null;
            InetAddress mcastaddr = InetAddress.getByName(ip);

            packet = new DatagramPacket(data, data.length, mcastaddr, port);
            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccService sendUdpDataByIP()" + e.toString());
            return false;
        }

        return true;
    }

    @Override
    public BaseResponse getMsgHistList(HashMap body)
            throws IOException, RuntimeException {

        MessageHistModel mgParam = new MessageHistModel();
        Integer lPage = (Integer) body.get("page");
        Integer lSize = (Integer) body.get("list_size");
        List<MessageHistModel> list = null;
        SmtDataSendRecvHistListRes resData = new SmtDataSendRecvHistListRes();

        int tCnt = 0;
        int tPage = 0;

        SmtDataSendRecvHistRes smtDsBean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        mgParam.setSt((String) body.get("start_time"));
        mgParam.setEd((String) body.get("end_time"));
        mgParam.setPage(lPage, lSize);

        list = msgHistDao.selectMessageHistList(mgParam);

        if ((list != null) && (list.size() > 0)) {
            tCnt = msgHistDao.selectMessageHistTotalCount(mgParam);
            resData.setTotalCount(tCnt);
            tPage = (tCnt + mgParam.getRowCount() - 1) / mgParam.getRowCount();
            resData.setTotalPage(tPage);
        }

        for (MessageHistModel hist : list) {
            smtDsBean = new SmtDataSendRecvHistRes();
            smtDsBean.setData(hist);
            resData.getList().add(smtDsBean);
        }

        res.setData(resData);
        return res;
    }

    @Override
    public BaseResponse getEmHistList(HashMap body)
            throws IOException, RuntimeException {
        EmerHistModel emParam = new EmerHistModel();
        List<EmerHistModel> list = null;
        SmtDataSendRecvHistListRes resData = new SmtDataSendRecvHistListRes();

        Integer lPage = (Integer) body.get("page");
        Integer lSize = (Integer) body.get("list_size");

        int tCnt = 0;
        int tPage = 0;

        SmtDataSendRecvHistRes smtDbean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        emParam.setSt((String) body.get("start_time"));
        emParam.setEd((String) body.get("end_time"));
        emParam.setPage(lPage, lSize);

        list = emerHistDao.selectEmerHistList(emParam);

        if ((list != null) && (list.size() > 0)) {
            tCnt = emerHistDao.selectEmerHistTotalCount(emParam);
            resData.setTotalCount(tCnt);
            tPage = (tCnt + emParam.getRowCount() - 1) / emParam.getRowCount();
            resData.setTotalPage(tPage);
        }

        for (EmerHistModel hist : list) {
            smtDbean = new SmtDataSendRecvHistRes();
            smtDbean.setData(hist);
            resData.getList().add(smtDbean);
        }

        res.setData(resData);
        return res;
    }

    @Override
    public BaseResponse getAirDefWarnHistList(HashMap body)
            throws IOException, RuntimeException {
        AirDefWarnHistModel adParam = new AirDefWarnHistModel();

        Integer lPage = (Integer) body.get("page");
        Integer lSize = (Integer) body.get("list_size");

        int tCnt = 0;
        int tPage = 0;

        SmtDataSendRecvHistListRes resData = new SmtDataSendRecvHistListRes();
        List<AirDefWarnHistModel> list = null;
        SmtDataSendRecvHistRes smtDatabean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        adParam.setSt((String) body.get("start_time"));
        adParam.setEd((String) body.get("end_time"));
        adParam.setPage(lPage, lSize);

        list = airDefWarnHistDao.selectAirDefWarnHistList(adParam);

        if ((list != null) && (list.size() > 0)) {
            tCnt = airDefWarnHistDao.selectAirDefWarnHistTotalCount(adParam);
            resData.setTotalCount(tCnt);
            tPage = (tCnt + adParam.getRowCount() - 1) / adParam.getRowCount();
            resData.setTotalPage(tPage);
        }

        for (AirDefWarnHistModel hist : list) {
            smtDatabean = new SmtDataSendRecvHistRes();
            smtDatabean.setData(hist);
            resData.getList().add(smtDatabean);
        }

        res.setData(resData);

        return res;
    }

    @Override
    public BaseResponse getAirDefWarnAirRaidHistList(HashMap body)
            throws IOException, RuntimeException {
        AirRaidHistModel aParam = new AirRaidHistModel();

        Integer lPage = (Integer) body.get("page");
        Integer lSize = (Integer) body.get("list_size");

        int tCnt = 0;
        int tPage = 0;

        List<AirRaidHistModel> list = null;
        SmtDataSendRecvHistListRes resData = new SmtDataSendRecvHistListRes();
        SmtDataSendRecvHistRes smtBean = null;
        BaseResponse res = new BaseResponse(ResRepo.getC200());

        aParam.setSt((String) body.get("start_time"));
        aParam.setEd((String) body.get("end_time"));
        aParam.setPage(lPage, lSize);

        list = airRaidHistDao.selectAirRaidHistList(aParam);

        if ((list != null) && (list.size() > 0)) {
            tCnt = airRaidHistDao.selectAirRaidHistTotalCount(aParam);
            resData.setTotalCount(tCnt);
            tPage = (tCnt + aParam.getRowCount() - 1) / aParam.getRowCount();
            resData.setTotalPage(tPage);
        }

        for (AirRaidHistModel hist : list) {
            smtBean = new SmtDataSendRecvHistRes();
            smtBean.setData(hist);
            resData.getList().add(smtBean);
        }

        res.setData(resData);

        return res;
    }

    @Override
    public BaseResponse sccDetailLogHist(SccStatusReq body, String remoteAddr) {
        
        if (body.getType() == null) {
            return new BaseResponse(ResRepo.getC403());
        }

        if (body.getType().equals("MCRC")) {
            return sccMcrcLogHist(body, remoteAddr);
        } else {
            return sccKamdLogHist(body, remoteAddr);
        }

    }

    private BaseResponse sccMcrcLogHist(SccStatusReq body, String remoteAddr) {
        int pSize = (body.getPage() == null) ? 1 : body.getPage();
        int lSize = (body.getListSize() == null) ? N100 : body.getListSize();
        List<McrcHistDetailModel> list = null;                
        McrcHistDetailModel param = new McrcHistDetailModel();
        long tCnt = 0;
        long tPage = 0;
        
        try {
            
            param.setDetailParam(body, uK, pSize, lSize);
            list = mcrcRealHistDao.selectMcrcDetailHistList(param);
            tCnt = mcrcRealHistDao.selectMcrcDetailHistTotalCount(param);
            
            tPage = (int) Math.ceil((double) tCnt / lSize);
            
            if (list == null || list.size() == 0) {
                return new BaseResponse(ResRepo.getC204());
            }

            return new BaseResponse(ResRepo.getC200(), tCnt, tPage, pSize,
                    parseMcrcLogDetailHist(list));
            
        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.warn("sccMcrcLogHist() " + e.toString());
        } catch (DataAccessException e) {
            log.warn("sccMcrcLogHist db " + e.toString());
        } catch (GeneralSecurityException e) {
            log.warn("sccMcrcLogHist decrypt " + e.toString());
        }
                
        return new BaseResponse(ResRepo.getC999());
    }
    
    private List<McrcLogDetailHistRes> parseMcrcLogDetailHist(
            List<McrcHistDetailModel> rList)
            throws RuntimeException, GeneralSecurityException {
        List<McrcLogDetailHistRes> list = new ArrayList<>();
        McrcLogDetailHistRes bean = null;

        for (McrcHistDetailModel r : rList) {
            bean = new McrcLogDetailHistRes();
            bean.setDefaultData(r);
//            암호화 정보 해석 
            bean.setTrackNumber(
                    new String(crypt.decrypt(r.getTrackNumberEnc(), fileKey)));
            bean.setLatitude(
                    new String(crypt.decrypt(r.getLatitudeEnc(), fileKey)));
            bean.setLongitude(
                    new String(crypt.decrypt(r.getLongitudeEnc(), fileKey)));
            bean.setIdentity(
                    new String(crypt.decrypt(r.getIdentityEnc(), fileKey)));
            bean.setFlSize(
                    new String(crypt.decrypt(r.getFlightSizeEnc(), fileKey)));
            list.add(bean);
        }
        
        return list;
         
    }
    
    private BaseResponse sccKamdLogHist(SccStatusReq body, String remoteAddr) {
        int pSize = (body.getPage() == null) ? 1 : body.getPage();
        int lSize = (body.getListSize() == null) ? N100 : body.getListSize();
        List<KamdHistDetailModel> list = null;                
        KamdHistDetailModel param = new KamdHistDetailModel();
        long tCnt = 0;
        long tPage = 0;
        
        try {
            
            param.setDetailParam(body, uK, pSize, lSize);
            list = kamdRealHistDao.selectKamdDetailHistList(param);
            tCnt = kamdRealHistDao.selectKamdDetailHistTotalCount(param);
            
            tPage = (int) Math.ceil((double) tCnt / lSize);
            
            if (list == null || list.size() == 0) {
                return new BaseResponse(ResRepo.getC204());
            }

            return new BaseResponse(ResRepo.getC200(), tCnt, tPage, pSize,
                    parseKamdLogDetailHist(list));

        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            log.warn("sccKamdLogHist() " + e.toString());
        } catch (DataAccessException e) {
            log.warn("sccKamdLogHist db " + e.toString());
        } catch (GeneralSecurityException e) {
            log.warn("sccKamdLogHist decrypt " + e.toString());
        }
        
        
        return new BaseResponse(ResRepo.getC999());
    }
    
    private List<KamdLogDetailHistRes> parseKamdLogDetailHist(
            List<KamdHistDetailModel> rList)
            throws RuntimeException, GeneralSecurityException {
        List<KamdLogDetailHistRes> list = new ArrayList<>();
        KamdLogDetailHistRes bean = null;

        for (KamdHistDetailModel r : rList) {
            bean = new KamdLogDetailHistRes();            
            bean.setDefaultData(r);
//            암호화 정보 해석 
            bean.setTrackNumber(
                    new String(crypt.decrypt(r.getTrackNumberEnc(), fileKey)));
            bean.setLatitude(
                    new String(crypt.decrypt(r.getLatitudeEnc(), fileKey)));
            bean.setLongitude(
                    new String(crypt.decrypt(r.getLongitudeEnc(), fileKey)));
            list.add(bean);
        }
        
        return list;
         
    }

    @Override
    public BaseResponse sccDetailStatHist(SccStatusReq body,
            String remoteAddr) {
        
        if (body.getType() == null) {
            return new BaseResponse(ResRepo.getC403());
        }

        if (body.getType().equals("MCRC")) {
            return statService.getMissHistStat(body);
        } else {
            return statService.getKissHistStat(body);
        }    
      
    }
    
    @Override
    public BaseResponse sccVoiceStatus(String remoteAddr) {
        return new BaseResponse(ResRepo.getC200(), voiceTimer.getVoiceStatus());
    }

    public boolean getFilePatternCheck(String line, LocalDateTime start,
            LocalDateTime end) {

        String[] parts = line.split(",", N2);
        String timestampStr = parts[0];
        String trimmedTs = null;
        LocalDateTime logTime = null;
        Boolean filePathTf = false;

        if (parts.length != N2) {
            log.trace("File Parts len : {} ", parts.length);

            return false;
        }

        try {
            if ((timestampStr.length() > N26)) {
                trimmedTs = timestampStr.substring(0, N26);
            } else {
                trimmedTs = timestampStr;
            }

            logTime = LocalDateTime.parse(trimmedTs);
            filePathTf = (logTime.isAfter(start) && !logTime.isAfter(end));

            return filePathTf;

        } catch (RuntimeException e) {
            System.err.println("getFilePatternCheck() " + timestampStr);
            return false;
        }

    }
    
    public BaseResponse sccMcrcSimulList(HashMap body, String remoteAddr) {

        try {
            McrcSimulModel mSMP = new McrcSimulModel();
            String simulNo = (String) body.get("simul_no");
            List<McrcSimulRes> rList = new ArrayList<>();
            List<McrcSimulModel> mSList = null;
            McrcSimulRes mBean = null;
            HashMap<String, List<McrcSimulRes>> rDataList = new HashMap<>();

            if (simulNo == null) { // SIMUL 전체 조회
                mSList = simulDao.selectMcrcSimulNoList();

            } else {
                mSMP.setSimulNo(Integer.parseInt(simulNo));
                mSList = simulDao.selectMcrcSimulRouteList(mSMP);
            }

            for (McrcSimulModel mcrcSimulModel : mSList) {
                mBean = new McrcSimulRes();
                mBean.setBeanData(mcrcSimulModel);
                rList.add(mBean);
            }

            rDataList.put("list", rList);

            return new BaseResponse(ResRepo.getC200(), rDataList);

        } catch (RuntimeException e) {
            log.warn("sccMcrcSimulList() " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }
    }

    public BaseResponse sccKamdSimulList(HashMap body, String remoteAddr) {

        try {

            KamdSimulModel kSMP = new KamdSimulModel();
            String simulNo = (String) body.get("simul_no");
            List<KamdSimulRes> rList = new ArrayList<>();
            List<KamdSimulModel> ksList = null;
            KamdSimulRes kBean = null;
            HashMap<String, List<KamdSimulRes>> rDataList = new HashMap<>();

            if (simulNo == null) { // SIMUL 전체 조회
                ksList = simulDao.selectKamdSimulNoList();

            } else {
                kSMP.setSimulNo(Integer.parseInt(simulNo));
                ksList = simulDao.selectKamdSimulRouteList(kSMP);
            }

            for (KamdSimulModel kamdSimulModel : ksList) {
                kBean = new KamdSimulRes();
                kBean.setBeanData(kamdSimulModel);
                rList.add(kBean);
            }

            rDataList.put("list", rList);

            return new BaseResponse(ResRepo.getC200(), rDataList);

        } catch (RuntimeException e) {
            log.warn("sccMcrcSimulList() " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }
    }

    public BaseResponse sccMcrcSimulAdd(McrcSimulReq body, String remoteAddr) {

        try {
            McrcSimulModel mSMP = new McrcSimulModel();
            List<McrcSimulRouteReq> routes = body.getRoutes();

            for (McrcSimulRouteReq r : routes) {
                mSMP = new McrcSimulModel();
                mSMP.setData(body.getSimulNo(), body.getTrack(), r, hostName);
                simulDao.insertMcrcSimul(mSMP);
            }

            return new BaseResponse(ResRepo.getC200());
        } catch (RuntimeException e) {
            log.info("sccMcrcSimulDel " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }
    }

    public BaseResponse sccKamdSimulAdd(KamdSimulReq body, String remoteAddr) {

        boolean isPass = false;
        ArrayList<KamdSimulModel> pList = new ArrayList<>();
        KamdSimulModel kSMP = null;

        try {

            for (KamdSimulArrReq arrData : body.getData()) {
                isPass = (arrData.getSimulNo() != null);
                isPass = (isPass && (arrData.getKamdCode() != null));
                isPass = (isPass && (arrData.getKamdRoute() != null));
                isPass = (isPass && (arrData.getCreateSys() != null));

                if (isPass) {
                    kSMP = new KamdSimulModel();

                    arrData.setSysId(hostName);
                    kSMP.setData(arrData);
                    pList.add(kSMP);

                }
            }

            if (pList.size() > 0) {
                simulDao.insertKamdArrSimul(pList);
            }

        } catch (RuntimeException e) {
            log.info("sccMcrcSimulDel " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

        return new BaseResponse(ResRepo.getC200());

    }

    public BaseResponse sccMcrcSimulDel(McrcSimulReq body, String remoteAddr) {

        try {
            McrcSimulModel mSMP = new McrcSimulModel();

            mSMP.setSimulNo(Integer.parseInt(body.getSimulNo()));
            mSMP.setMcrcCode(body.getMcrcCode());

            simulDao.deleteMcrcSimul(mSMP);

            return new BaseResponse(ResRepo.getC200());
        } catch (RuntimeException e) {
            log.info("sccMcrcSimulDel " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

    }

    public BaseResponse sccKamdSimulDel(KamdSimulReq body, String remoteAddr) {

        try {
            KamdSimulModel param = new KamdSimulModel();

            param.setSimulNo(Integer.parseInt(body.getSimulNo()));

            simulDao.deleteKamdSimul(param);

            return new BaseResponse(ResRepo.getC200());
        } catch (RuntimeException e) {
            log.info("sccMcrcSimulDel " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }

    }

    @Override
    public BaseResponse sccDevStatus(String remoteAddr) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        List<StatusModel> statusList = null;
        StatusModel statusInfo = null;
        List<NodeModel> nArrLst = null;
        List<SccDeviceStatusRes> data = null;
        SccDeviceStatusRes dBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<SccDeviceStatusRes>> resData = new HashMap<>();
        List<CurrAlarmModel> cAL = null;
        
        try {

            statusList = statusConfigDao.selectStatusList();
            if ((statusList == null) || (statusList.size() == 0)) {
                return new BaseResponse(ResRepo.getC508());
            }

            statusInfo = statusList.get(0);

            data = new ArrayList<SccDeviceStatusRes>();
            nArrLst = new ArrayList<>(nList.values());

            for (NodeModel nAInfo : nArrLst) {
                NodeRepo code = NodeRepo.from(nAInfo.getNodeId());

                if (code.getCode() == NodeRepo.getSmtA().getCode()) {
                    continue;
                } else if (code.getCode() == NodeRepo.getSmtB().getCode()) {
                    continue;
                }

                dBean = new SccDeviceStatusRes();
                dBean.setData(statusInfo, nAInfo);

                if (DB_STATUS_UNKNOWN == dBean.getStatus()) {
                    // DB에서 장애코드 발생시간 조회
                    cAL = alarmService.getCurrAlarmSearch(nAInfo.getNodeId());
                    dBean.setTime(cAL);
                }

                data.add(dBean);
            }

            resData.put("Failures", data);
            resp.setData(resData);

            return resp;
        } catch (RuntimeException e) {
            log.warn("sccDevStatus() " + e.toString());
        }

        return new BaseResponse(ResRepo.getC999());

    }

    /*
    private class KMTimeComparator implements Comparator<KamdMcrcDataBean> {
        @Override
        public int compare(KamdMcrcDataBean b1, KamdMcrcDataBean b2) {
            return b1.getTime().compareTo(b2.getTime());
        }
    }
    */
}
