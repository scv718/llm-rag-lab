/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hanwha.saws.icss.persistence.model.AirDefWarnHistModel;
import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;
import com.hanwha.saws.icss.persistence.model.EmerHistModel;
import com.hanwha.saws.icss.persistence.model.KamdHistModel;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.persistence.model.MessageHistModel;

import lombok.Data;

@Data
public class SmtDataSendRecvHistRes {

    @JsonInclude(JsonInclude.Include.NON_NULL) private Integer idx;
    @JsonProperty("data_name") private String dataName;
    @JsonProperty("data_type") private String dataType;
    @JsonProperty("data_size") private String dataSize;
    @JsonProperty("error_flag") private String errorFlag;
    @JsonProperty("recv_time") private String recvTime;
    @JsonProperty("sent_time") private String sentTime;

    @JsonIgnore
    public void setData(AirRaidHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        idx = data.getIdx();
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }

    @JsonIgnore
    public void setData(AirDefWarnHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        idx = data.getIdx();
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }

    @JsonIgnore
    public void setData(EmerHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        idx = data.getIdx();
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }

    @JsonIgnore
    public void setData(MessageHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        
        idx = data.getIdx();
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }

    @JsonIgnore
    public void setData(KamdHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }

    @JsonIgnore
    public void setData(McrcHistModel data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
        
        dataName = data.getDataName();
        dataType = data.getDataTypeName();
        dataSize = data.getDataSize() + "";
        errorFlag = data.getErrorFlag();
        
        recvTime = sdf.format(data.getRecvTime());
        sentTime = sdf.format(data.getSentTime());

    }
}
