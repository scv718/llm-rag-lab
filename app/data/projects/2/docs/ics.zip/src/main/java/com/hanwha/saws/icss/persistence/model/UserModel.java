/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class UserModel {

    private static final int N30 = 30;

    private String userId;
    private String sysId;
    private String groupId;
    private String groupName;
    private String password;
    private String userName;
    private String telephone;
    private String mobile;
    private String email;
    private String desc64;
    private int failCount;
    private String denyFlag;
    private Date updateTime;
    private Date expireTime;
    private String userKey;

    private String decPw;

    public void updateExpireTime() {
        
        LocalDateTime dt = LocalDateTime.now();
        
        expireTime = java.sql.Timestamp.valueOf(dt.plusDays(N30));

    }
}
