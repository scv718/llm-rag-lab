/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.RecvObjectDupBean;

@Configuration
public class MapConfig {

    @Bean(name = "kissRecvMap")
    public ConcurrentHashMap<String, RecvObjectDupBean> kissRecvMap() {
        return new ConcurrentHashMap<>();
    }

    @Bean(name = "sessionMap")
    public ConcurrentHashMap<String, LoginSessionBean> sessionMap() {
        return new ConcurrentHashMap<>();
    }
 
    @Bean(name = "missRecvMap")
    public ConcurrentHashMap<String, RecvObjectDupBean> missRecvMap() {
        return new ConcurrentHashMap<>();
    }
    
    @Bean(name = "missPrevKnotMap")
    public ConcurrentHashMap<String, RecvObjectDupBean> missPrevKnotMap() {
        return new ConcurrentHashMap<>();
    }
    
    @Bean(name = "mcrcSimulMap")
    public ConcurrentHashMap<String, Integer> mcrcSimulMap() {
        return new ConcurrentHashMap<>();
    }
    
    @Bean(name = "kamdSimulMap")
    public ConcurrentHashMap<String, Integer> kamdSimulMap() {
        return new ConcurrentHashMap<>();
    }
    
}