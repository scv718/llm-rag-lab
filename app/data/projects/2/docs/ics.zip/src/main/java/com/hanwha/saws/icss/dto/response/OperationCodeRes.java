/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;

import lombok.Data;

@Data
public class OperationCodeRes {

    private String id;
    private String name;

    public OperationCodeRes(OpCmdRepo code) {
        id = code.getCode();
        name = code.getMsg();
    }

    public OperationCodeRes(STypeRepo code) {
        id = (int) code.getCode() + "";
        name = code.getMsg();
    }

}
