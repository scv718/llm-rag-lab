/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.SwitchRouterService;
import com.hanwha.saws.icss.util.LogKeyUtil;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SwitchRouterBatch {

    private static Logger statusLog = null;
    private static final int INIT_WAIT = 0;
    private static final int ACTIVE = 1;
    
    @Autowired PropConfig prop;
    @Autowired SwitchRouterService switchRouterService;

    @Scheduled(
            fixedDelayString = "${cron.switch-router-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void switchRouterBatch() throws IOException {

        NodeModel paramModel = null;
        HashMap<Integer, NodeModel> nHash = null;
        
        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("BATCH_STATUS");
        }

        if (prop.getInitFlag() == INIT_WAIT) {
            log.debug("Cold Start");
            return;
        }

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("stand by");
            return;
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        statusLog.debug("SWITCH ROUTER HEARTBEAT BATCH START");

        try {
            nHash = prop.getNodeInfoHash();
            
            paramModel = nHash.get(NodeRepo.getSwitchA().getCode());
            switchRouterService.heartbeatRequest(paramModel); // 라인실험용

            paramModel = nHash.get(NodeRepo.getSwitchB().getCode());
            switchRouterService.heartbeatRequest(paramModel);
            
            paramModel = nHash.get(NodeRepo.getRouterA().getCode());
            switchRouterService.medMcrcRouterRequest(paramModel);

            paramModel = nHash.get(NodeRepo.getRouterB().getCode());
            switchRouterService.medKamdRouterRequest(paramModel);

            paramModel = nHash.get(NodeRepo.getRouterM().getCode());
            switchRouterService.heartbeatRequest(paramModel);

        } catch (NoClassDefFoundError e) {
            log.warn("switchRouterBatch() NoClassDefFound ");
        } catch (RuntimeException e) {
            log.warn("switchRouterBatch batch " + e.toString());
        }

        statusLog.debug("SWITCH ROUTER HEARTBEAT BATCH END");

    }

}
