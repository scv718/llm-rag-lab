/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

import java.util.HashMap;
import java.util.Map;

public class NodeRepo {

    private static final int ICA = 1; // ICSS_A
    private static final int ICB = 2; // ICSS_B
    private static final int MIA = 3; // MISS_A
    private static final int MIB = 4; // MISS_B
    private static final int KIA = 5; // KISS_A
    private static final int KIB = 6; // KISS_B
    private static final int SCA = 7; // SCC_A
    private static final int SCB = 8; // SCC_B
    private static final int SMA = 9; // SMT_A
    private static final int SMB = 10; // SMT_B
    private static final int SSA = 11; // SMS_A
    private static final int SSB = 12; // SMS_B
    private static final int SWA = 13; // SWITCH_A
    private static final int SWB = 14; // SWITCH_B
    private static final int RTA = 15; // ROUTER_A
    private static final int RTB = 16; // ROUTER_B
    private static final int RTM = 17; // ROUTER_M

    private static final Map<Integer, NodeRepo> CODE_MAP = new HashMap<>();

    private static final NodeRepo ICSS_A = new NodeRepo(ICA, "ICSS_A");
    private static final NodeRepo ICSS_B = new NodeRepo(ICB, "ICSS_B");
    private static final NodeRepo MISS_A = new NodeRepo(MIA, "MISS_A");
    private static final NodeRepo MISS_B = new NodeRepo(MIB, "MISS_B");
    private static final NodeRepo KISS_A = new NodeRepo(KIA, "KISS_A");
    private static final NodeRepo KISS_B = new NodeRepo(KIB, "KISS_B");
    private static final NodeRepo SCC_A = new NodeRepo(SCA, "SCC_A");
    private static final NodeRepo SCC_B = new NodeRepo(SCB, "SCC_B");
    private static final NodeRepo SMT_A = new NodeRepo(SMA, "SMT_A");
    private static final NodeRepo SMT_B = new NodeRepo(SMB, "SMT_B");
    private static final NodeRepo SMS_A = new NodeRepo(SSA, "SMS_A");
    private static final NodeRepo SMS_B = new NodeRepo(SSB, "SMS_B");
    private static final NodeRepo SWITCH_A = new NodeRepo(SWA, "SWITCH_A");
    private static final NodeRepo SWITCH_B = new NodeRepo(SWB, "SWITCH_B");
    private static final NodeRepo ROUTER_A = new NodeRepo(RTA, "ROUTER_A");
    private static final NodeRepo ROUTER_B = new NodeRepo(RTB, "ROUTER_B");
    private static final NodeRepo ROUTER_M = new NodeRepo(RTM, "ROUTER_M");

    static {
        CODE_MAP.put(ICSS_A.getCode(), ICSS_A);
        CODE_MAP.put(ICSS_B.getCode(), ICSS_B);
        CODE_MAP.put(MISS_A.getCode(), MISS_A);
        CODE_MAP.put(MISS_B.getCode(), MISS_B);
        CODE_MAP.put(KISS_A.getCode(), KISS_A);
        CODE_MAP.put(KISS_B.getCode(), KISS_B);
        CODE_MAP.put(SCC_A.getCode(), SCC_A);
        CODE_MAP.put(SCC_B.getCode(), SCC_B);
        CODE_MAP.put(SMT_A.getCode(), SMT_A);
        CODE_MAP.put(SMT_B.getCode(), SMT_B);
        CODE_MAP.put(SMS_A.getCode(), SMS_A);
        CODE_MAP.put(SMS_B.getCode(), SMS_B);
        CODE_MAP.put(SWITCH_A.getCode(), SWITCH_A);
        CODE_MAP.put(SWITCH_B.getCode(), SWITCH_B);
        CODE_MAP.put(ROUTER_A.getCode(), ROUTER_A);
        CODE_MAP.put(ROUTER_B.getCode(), ROUTER_B);
        CODE_MAP.put(ROUTER_M.getCode(), ROUTER_M);
    }

    private final int code;
    private final String name;

    
    private NodeRepo(int cd, String nm) {
        this.code = cd;
        this.name = nm;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static NodeRepo getIcssA() {
        return ICSS_A;
    }

    public static NodeRepo getIcssB() {
        return ICSS_B;
    }

    public static NodeRepo getMissA() {
        return MISS_A;
    }

    public static NodeRepo getMissB() {
        return MISS_B;
    }

    public static NodeRepo getKissA() {
        return KISS_A;
    }

    public static NodeRepo getKissB() {
        return KISS_B;
    }

    public static NodeRepo getSccA() {
        return SCC_A;
    }

    public static NodeRepo getSccB() {
        return SCC_B;
    }

    public static NodeRepo getSmtA() {
        return SMT_A;
    }

    public static NodeRepo getSmtB() {
        return SMT_B;
    }

    public static NodeRepo getSmsA() {
        return SMS_A;
    }

    public static NodeRepo getSmsB() {
        return SMS_B;
    }

    public static NodeRepo getSwitchA() {
        return SWITCH_A;
    }

    public static NodeRepo getSwitchB() {
        return SWITCH_B;
    }

    public static NodeRepo getRouterA() {
        return ROUTER_A;
    }

    public static NodeRepo getRouterB() {
        return ROUTER_B;
    }

    public static NodeRepo getRouterM() {
        return ROUTER_M;
    }

    public static NodeRepo from(int cd) {
        NodeRepo result = CODE_MAP.get(cd);
        
        if (result == null) {
            throw new IllegalArgumentException("Unknown NodeRepo code: " + cd);
        }
        return result;
    }
}
