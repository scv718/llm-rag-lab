/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import org.springframework.util.StreamUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

public class CustomRequestWrapper extends HttpServletRequestWrapper {

    private byte[] body = null;

    private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private String tmpStr = null;

    public CustomRequestWrapper(HttpServletRequest req) throws IOException {
        super(req);

        if ((req.getContentType() != null)) {
            if (req.getContentType().toLowerCase().startsWith("multipart")) {
                tmpStr = gson.toJson(req.getParameterMap());
                this.body = tmpStr.getBytes();
            } else {
                this.body = StreamUtils.copyToByteArray(req.getInputStream());
            }
        } else {
            this.body = StreamUtils.copyToByteArray(req.getInputStream());
        }

    }

    public byte[] getBody() {

        return Arrays.copyOf(body, body.length);
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {

        final ByteArrayInputStream BIS = new ByteArrayInputStream(body);

        return new ServletImpl(BIS);

    }

//    public byte[] getContentAsByteArray() {
//        return Arrays.copyOf(body, body.length);
//    }

    
    class ServletImpl extends ServletInputStream {

            
        private InputStream is;

        public ServletImpl(InputStream bis) {
            is = bis;
        }

        @Override
        public int read() throws IOException {
            return is.read();
        }

        @Override
        public int read(byte[] b) throws IOException {
            return is.read(b);
        }

        @Override
        public boolean isFinished() {
            return false;
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setReadListener(ReadListener listener) {}

    }

}
