/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */

package com.hanhwa.saws.mediator.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class StatusUtil {

    private static final int N2 = 2;
    private static final int N100 = 100;
    
    private StatusUtil() {}
    
    public static int getCpuUsage() {
        try {
            StringBuilder sb = new StringBuilder();
            String cmd = null;
            BufferedReader reader = null;
            ProcessBuilder processBuilder = null;
            Process process = null;
            InputStream inputStream = null;
            String line = null;
            int lineInt = 0;

            sb.append("top -bn1 | grep \"Cpu(s)\" | sed ");
            sb.append("\"s/.*, *\\([0-9.]*\\)%* id.*/\\1/\" ");
            sb.append("| awk '{print 100 - $1}'");

            cmd = sb.toString();
            processBuilder = new ProcessBuilder("sh", "-c", cmd);
            process = processBuilder.start();
            inputStream = process.getInputStream();

            reader = new BufferedReader(new InputStreamReader(inputStream));
            line = reader.readLine();

            if (line != null) {
                lineInt = (int) Float.parseFloat(line.trim());
                return lineInt;
            }

        } catch (IOException e) {
            log.warn("Error fetching CPU usage", e);
        }

        return -1;
    }

    public static int getDiskUsage() {
        try {
            String cmd = "df / | tail -1 | awk '{print $5}' | tr -d '%'";
            ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", cmd);
            Process process = processBuilder.start();
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = null;
            String line = null;
            int rtVal = 0;

            reader = new BufferedReader(new InputStreamReader(inputStream));
            line = reader.readLine();

            if (line != null) {
                rtVal = Integer.parseInt(line.trim());
                return rtVal;
            }

        } catch (IOException e) {
            log.warn("Error fetching disk usage", e);
        }

        return -1;
    }

    public static int getMemUsage() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("free", "-m");
            Process process = processBuilder.start();
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = null;
            String line = null;
            int total = 0;
            int used = 0;

            reader = new BufferedReader(new InputStreamReader(inputStream));

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Mem:")) {
                    String[] parts = line.split("\\s+");
                    total = Integer.parseInt(parts[1]);
                    used = Integer.parseInt(parts[N2]);
                    return (used * N100) / total;
                }
            }

        } catch (IOException e) {
            log.warn("Error fetching memory usage", e);
        }

        return -1;
    }


}
