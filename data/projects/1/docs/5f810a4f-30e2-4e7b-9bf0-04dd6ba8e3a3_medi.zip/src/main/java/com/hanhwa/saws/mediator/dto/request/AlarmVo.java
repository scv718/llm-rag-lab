/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.request;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class AlarmVo {

    private static final List<AlarmVo> AlarmVo = new ArrayList<>();

    @JsonProperty("alarm_type") private String alarmType;

    @JsonProperty("sev") private String severity;

    @JsonProperty("time") private String time;

    public static void setList(AlarmVo vo) {
        String alType = vo.getAlarmType();

        if ("CLE".equals(vo.getSeverity())) {
            for (int i = 0; i < AlarmVo.size(); i++) {
                AlarmVo exi = AlarmVo.get(i);
                if (exi.getAlarmType().equals(alType)) {
                    AlarmVo.remove(i);
                    i--;
                }
            }

        } else if ("MIN".equals(vo.getSeverity())) {
            boolean exists = false;

            for (int i = 0; i < AlarmVo.size(); i++) {
                AlarmVo exi = AlarmVo.get(i);
                if (exi.getAlarmType().equals(alType)) {
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                AlarmVo.add(vo);
            }
        }
    }

    public static List<AlarmVo> getList() {
        return List.copyOf(AlarmVo);
    }

}
