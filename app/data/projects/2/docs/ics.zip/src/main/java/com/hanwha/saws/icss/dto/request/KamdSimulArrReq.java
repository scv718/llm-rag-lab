/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class KamdSimulArrReq {
    @JsonProperty("simul_no") private String simulNo;
    @JsonProperty("code") private String kamdCode;
    @JsonProperty("type") private String kamdType;
    @JsonProperty("route") private Integer kamdRoute;

    @JsonProperty("location_x_start") private String kamdLocationXStart;
    @JsonProperty("location_y_start") private String kamdLocationYStart;
    @JsonProperty("location_x") private String kamdLocationX;
    @JsonProperty("location_y") private String kamdLocationY;
    @JsonProperty("location_x_end") private String kamdLocationXEnd;
    @JsonProperty("location_y_end") private String kamdLocationYEnd;
    @JsonProperty("knot") private Integer kamdKnot;
    @JsonProperty("feet") private Integer kamdFeet;
    @JsonProperty("direction") private Integer kamdDirection;

    private String sysId;
    @JsonProperty("create_time") private String createSys;

}
