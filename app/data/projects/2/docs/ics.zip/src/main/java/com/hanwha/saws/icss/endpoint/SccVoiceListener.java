/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccVoiceListener {

    @Autowired
    @Qualifier("voiceQueue") 
    private ConcurrentLinkedQueue<RecvMsgQueueBean> voiceQueue;

    @PostConstruct
    public void init() {
        log.info("SccVoiceListener initialized: Receiver & QueueMgr started.");
    }

    public int getQueueSize() {
        return voiceQueue.size();
    }

}
