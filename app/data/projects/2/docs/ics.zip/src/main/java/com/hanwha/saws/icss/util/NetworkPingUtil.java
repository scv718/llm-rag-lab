/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;

public class NetworkPingUtil {

    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;

    private String ip;
    private int port;
    private int timeoutMillis;
    

    public NetworkPingUtil(String nIp, int nPort, int nTimeoutMillis) {
        this.ip = nIp;
        this.port = nPort;
        this.timeoutMillis = nTimeoutMillis;
    }

    public int check() throws IOException, CompletionException {

        int rt = 0;

        if (isPortOpen()) {

            rt = N0; // 정상

        } else {

            if (isHostAliveByPing()) {

                rt = N1; // 서버는 살아있지만 포트가 닫힘
            } else {

                rt = N2; // 네트워크 단절 or 서버 꺼짐
            }
        }

        return rt;
    }

    private boolean isPortOpen() {
        try (Socket socket = new Socket()) {

            socket.connect(new InetSocketAddress(ip, port), timeoutMillis);

            return true;
        } catch (IOException e) {

            return false;
        }
    }

    public boolean isHostAliveByPing()
            throws IOException, CompletionException {
        
        String thrStr = "";
        
        try {
            Process process = new ProcessBuilder("ping", "-c", "1", "-W", "1",
                    ip).start();

            int returnCode = process.onExit().orTimeout(1, TimeUnit.SECONDS)
                    .join().exitValue();

            return returnCode == 0;

        } catch (IOException | CompletionException e) {
            thrStr = e.getMessage();
            throw e;
        }
    }

}
