/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class ThCodeBean {

    private int code;
    private String msg;
    private String group;

    public ThCodeBean(int code, String msg, String group) {
        this.code = code;
        this.msg = msg;
        this.group = group;
    }

    public int getCode() {
        return code;
    }

//    public void setCode(int code) {
//        this.code = code;
//    }

    public String getMsg() {
        return msg;
    }

//    public void setMsg(String msg) {
//        this.msg = msg;
//    }

    public String getGroup() {
        return group;
    }

//    public void setGroup(String group) {
//        this.group = group;
//    }

}
