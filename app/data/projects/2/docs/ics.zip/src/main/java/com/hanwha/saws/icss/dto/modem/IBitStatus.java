/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IBitStatus {

    private Double upc;
    
    @JsonProperty("upc_att") private Integer upcAtt;

    @JsonInclude(Include.NON_NULL) private Double dnc;
    
    @JsonProperty("dnc_att") private Integer dncAtt;
 
    @JsonInclude(Include.NON_NULL) private Integer loopback;
    @JsonInclude(Include.NON_NULL) private IBit ibit;
    @JsonInclude(Include.NON_NULL) private Integer dncRssi;
    @JsonInclude(Include.NON_NULL) private Integer upcRssi;

    @JsonProperty("dnc_upper_level") private Integer dncUpperBitSetLevel;
    
    @JsonProperty("dnc_lower_level") private Integer dncLowerBitSetLevel;
    
    @JsonProperty("upc_upper_level") private Integer upcUpperBitSetLevel;
    
    @JsonProperty("upc_lower_level") private Integer upcLowerBitSetLevel;

    @JsonProperty("upc_main") private String upcMain;
    
    @JsonProperty("upc_sub") private String upcSub;

    @JsonProperty("dnc_main") private String dncMain;
    
    @JsonProperty("dnc_sub") private String dncSub;

//    @JsonIgnore
//    public String getAlarmInfo() {
//
//        String val = null;
//
//        if (ibit != null) {
//            val = ibit.getAlarmInfo();
//        }
//        
//        return val;
//    }

    @JsonIgnore
    public IBitStatus getUpcResponse() { // 세부상태는 기입하지 않음
        IBitStatus bean = new IBitStatus();

        bean.setUpc(upc);
        bean.setUpcAtt(upcAtt);
        return bean;
    }

    @JsonIgnore
    public IBitStatus getDncResponse() { // 세부상태는 기입하지 않음
        IBitStatus bean = new IBitStatus();
        
        bean.setDnc(dnc);
        bean.setDncAtt(dncAtt);
        return bean;
    }

    @JsonIgnore
    public IBitStatus getLoopbackResponse() { // 세부상태는 기입하지 않음
        IBitStatus bean = new IBitStatus();
        
        bean.setLoopback(loopback);
        return bean;
    }

    @JsonIgnore
    public IBitStatus getBitlevelResponse() { // 세부상태는 기입하지 않음
        IBitStatus bean = new IBitStatus();
        
        bean.setUpcUpperBitSetLevel(upcUpperBitSetLevel);
        bean.setUpcLowerBitSetLevel(upcLowerBitSetLevel);
        bean.setDncUpperBitSetLevel(dncUpperBitSetLevel);
        bean.setDncLowerBitSetLevel(dncLowerBitSetLevel);
        return bean;
    }

    @JsonIgnore
    public IBit getDiagnosisResponse() { // 세부상태는 기입하지 않음
        return ibit;

    }
}
