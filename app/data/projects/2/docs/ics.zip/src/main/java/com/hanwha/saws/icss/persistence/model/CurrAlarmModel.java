/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class CurrAlarmModel {
    private static final int N1000 = 1000;
    
    private String uuid;
    private Integer seq;
    private Integer nodeId;
    private String nodeName;
    private String addrIp;
    private String alarmId;
    private String alarmName;
    private String serverity;
    private String location;
    private String summary;
    private Date firstOccurrence;
    private Date lastOccurrence;
    private int tally;
    private Timestamp insertTime;
    
    private String startTime;
    private String endTime;
    
    public void setTime() {
        LocalDateTime now = LocalDateTime.now();

        now = now.plusNanos(System.nanoTime() % N1000); // 미세한 차이 추가
        insertTime = Timestamp.valueOf(now);
        lastOccurrence = insertTime;
    }
}
