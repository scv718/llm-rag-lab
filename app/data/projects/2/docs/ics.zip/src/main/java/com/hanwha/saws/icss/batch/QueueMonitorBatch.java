/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.batch;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hanwha.saws.icss.endpoint.KissListener;
import com.hanwha.saws.icss.endpoint.MissListener;
import com.hanwha.saws.icss.endpoint.SccListener;
import com.hanwha.saws.icss.endpoint.SccVoiceListener;
import com.hanwha.saws.icss.util.LogKeyUtil;

@Component
public class QueueMonitorBatch {
    
    private static Logger statusLog = null;
    @Autowired KissListener kissListener;
    @Autowired MissListener missListener;
    @Autowired SccListener sccListener;
    @Autowired SccVoiceListener sccVListener;

    @Scheduled(
            fixedDelayString = "${cron.queue-monitor}000",
            initialDelayString = "${cron.init-delay}000")
    public void qMonitor() throws IOException {
        int kQ = 0;
        int mQ = 0;
        int sQ = 0;
        int sVQ = 0;
        String logFormat = "[Queue Monitor] ";
        
        logFormat += "[KAMD] : {} [MCRC] : {}  [SCC CMD] :{} [SCC VOICE] : {}";

        if (statusLog == null) {
            statusLog = LoggerFactory.getLogger("QUEUE_MONITOR");
        }

        MDC.put("LOG_KEY", LogKeyUtil.getRandomKey());

        kQ = kissListener.getQueueSize();
        mQ = missListener.getQueueSize();
        sQ = sccListener.getQueueSize();
        sVQ = sccVListener.getQueueSize();

        statusLog.info(logFormat, kQ, mQ, sQ, sVQ);

    }
}
