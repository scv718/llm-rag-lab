/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.MedAlarmReq;
import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.service.MedService;

import jakarta.servlet.http.HttpServletRequest;

@CrossOrigin
@RestController
public class MedController {

    @Autowired MedService medService;

    @RequestMapping(
            value = { "/v1/medAlarmReport" },
            method = RequestMethod.POST)
    public BaseResponse medAlarmReport(HttpServletRequest request,
            @RequestBody MedAlarmReq body) {

        medService.medAlarmReport(body, request.getRemoteAddr());

        return new BaseResponse(ResRepo.getC200());
    }

    @RequestMapping(
            value = { "/v1/medStatusReport" },
            method = RequestMethod.POST)
    public BaseResponse medStatusReport(HttpServletRequest request,
            @RequestBody MedStatusReq body) {

        medService.medStatusReport(body, request.getRemoteAddr());

        return new BaseResponse(ResRepo.getC200());
    }

}
