/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SmtStatusHistListRes {

    @JsonProperty("total_page") private int totalPage = 0;
    @JsonProperty("total_count") private int totalCount = 0;
    private List<SmtStatusHistRes> list = new ArrayList<>();

}
