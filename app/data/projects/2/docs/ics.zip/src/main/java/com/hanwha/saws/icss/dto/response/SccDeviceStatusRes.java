/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;

import lombok.Data;

@Data
public class SccDeviceStatusRes {

    @JsonProperty("Name") private String name;
    @JsonProperty("Status") private int status;
    @JsonInclude(Include.NON_NULL)
    @JsonProperty("EventTime") private String tm;  
    
    @JsonIgnore
    public void setTime(List<CurrAlarmModel> list) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String sysAlarmId = AlarmRepo.getAlmSystem().getCode();
        
        tm = sdf.format(new Date());
        
        for (CurrAlarmModel cAM : list) {
            if (sysAlarmId.equals(cAM.getAlarmId())) {
                tm = sdf.format(cAM.getFirstOccurrence());     
            }           
        }        
    }
    
    @JsonIgnore
    public void setData(StatusModel sm, NodeModel nm) {
        
        NodeRepo code = NodeRepo.from(nm.getNodeId());
        
        name = nm.getName();

        if (code.getCode() == NodeRepo.getIcssA().getCode()) {
            status = sm.getIcssA();
            name = "통합제어서버 A";
        } else if (code.getCode() == NodeRepo.getIcssB().getCode()) {
            status = sm.getIcssB();
            name = "통합제어서버 B";
        } else if (code.getCode() == NodeRepo.getMissA().getCode()) {
            status = sm.getMissA();
            name = "MCRC 연동서버 A";
        } else if (code.getCode() == NodeRepo.getMissB().getCode()) {
            status = sm.getMissB();
            name = "MCRC 연동서버 B";
        } else if (code.getCode() == NodeRepo.getKissA().getCode()) {
            status = sm.getKissA();
            name = "KAMD 연동서버 A";
        } else if (code.getCode() == NodeRepo.getKissB().getCode()) {
            status = sm.getKissB();
            name = "KAMD 연동서버 B";
        } else if (code.getCode() == NodeRepo.getSccA().getCode()) {
            status = sm.getSccA();
            name = "통제용 단말 A";
        } else if (code.getCode() == NodeRepo.getSccB().getCode()) {
            status = sm.getSccB();
            name = "통제용 단말 B";
        } else if (code.getCode() == NodeRepo.getSmsA().getCode()) {
            status = sm.getSmsA();
            name = "송수신모뎀 A";
        } else if (code.getCode() == NodeRepo.getSmsB().getCode()) {
            status = sm.getSmsB();
            name = "송수신모뎀 B";
        } else if (code.getCode() == NodeRepo.getSwitchA().getCode()) {
            status = sm.getSwitchA();
            name = "스위치 A";
        } else if (code.getCode() == NodeRepo.getSwitchB().getCode()) {
            status = sm.getSwitchB();
            name = "스위치 B";
        } else if (code.getCode() == NodeRepo.getRouterA().getCode()) {
            status = sm.getRouterA();
            name = "라우터 A";
        } else if (code.getCode() == NodeRepo.getRouterB().getCode()) {
            status = sm.getRouterB();
            name = "라우터 B";
        } else if (code.getCode() == NodeRepo.getRouterM().getCode()) {
            status = sm.getRouterM();
            name = "라우터 M";
        } else {
            status = sm.getIcssA();
        }

    }

}
