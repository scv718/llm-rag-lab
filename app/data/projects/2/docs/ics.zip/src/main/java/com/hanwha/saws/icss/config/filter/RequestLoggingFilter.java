/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.config.filter;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Map;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.AbstractRequestLoggingFilter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonReader;
import com.hanwha.saws.icss.config.CustomRequestWrapper;
import com.hanwha.saws.icss.config.CustResWrapper;
import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.util.LogKeyUtil;
import com.hanwha.saws.icss.util.LogParamUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RequestLoggingFilter extends AbstractRequestLoggingFilter {

    private static final int INIT_WAIT = 0;
    private static volatile boolean isSet = false;

    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping()
            .create();

    @Autowired PropConfig prop;

    private void setConf() {
        final int sizeLim = 512000;

        if (!isSet) {
            setIncludeQueryString(true);
            setIncludeClientInfo(true);
            setIncludePayload(true);
            setMaxPayloadLength(sizeLim);
            isSet = true;
        }

    }

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {

        long timeMil = Calendar.getInstance().getTimeInMillis();
        RequestInfo info = null;
        JsonReader reader = null;
        String ip = "";
        String param = "";
        String reqLog = "[{}][{}][{}] [BEFORE_REQ] {}";

        try {
            reader = new JsonReader(new StringReader(message));

            request.setAttribute("API_TIME", timeMil);
            info = GSON.fromJson(reader, RequestInfo.class);

            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            info.setRemoteAddr(ip);
            request.setAttribute("remoteaddr", ip);

            if ("POST".equals(info.getMethod())) {
                param = GSON.toJson(info.getPayload());
            }

            if (!prop.isBlockMatch(info.getUrl())) {

                log.debug(reqLog, info.getUrl(), ip, info.getMethod(), param);
            }

        } catch (RuntimeException e) {
            log.warn(e.getMessage());
        }
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {

        JsonReader reader = null;
        RequestInfo info = null;
        String ip = "";
        String lMsg = "[{}][{}][{}] [AFTER_REQ] [{} sec]";
        String url = "";
        String spT = "";
        Long apiTime = null;

        try {
            reader = new JsonReader(new StringReader(message));

            info = GSON.fromJson(reader, RequestInfo.class);

            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            info.setRemoteAddr(ip);

            if (!prop.isBlockMatch(info.getUrl())) {
                url = info.getUrl();
                apiTime = (Long) request.getAttribute("API_TIME");
                spT = LogParamUtil.getCheckTime(apiTime);

                log.debug(lMsg, url, ip, info.getMethod(), spT);
            }

            request.removeAttribute("API_TIME");
            request.removeAttribute("LOG_KEY");

        } catch (RuntimeException e) {
            log.warn(e.getMessage());
        }

    }

    @Override
    public void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String uri = request.getRequestURI();
        boolean isMatch = false;
        BaseResponse br = null;
        int errCode = 0;
        String logKey = LogKeyUtil.getRandomKey();
        String transactionId = request.getHeader("TransactionId");
        CustomRequestWrapper requestToUse = null;
        HttpServletResponse responseToUse = null;
        int byteLength = 0;
        final int initByte = 512;
        double sizeInKb = 0;
        String lMsg = "";
        String ip = "";
        String cntT = "";
        final double d10240 = 1024.0;
        boolean isMthod = false;
        boolean isCType = false;
        String cType = null;
        CustResWrapper wrapper = null;
        String res = null;

        if (prop.getInitFlag() == INIT_WAIT) {
            errCode = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
            response.sendError(errCode, "Now Cold Starting");

            return;
        }

        isMthod = HttpMethod.POST.name().equalsIgnoreCase(request.getMethod());

        if ((!isMthod) && (!request.getRemoteAddr().equals("127.0.0.1"))) {
            errCode = HttpServletResponse.SC_METHOD_NOT_ALLOWED;
            response.sendError(errCode, "Only POST method is allowed");

            return;
        }

        if (!prop.isRemoteOnlyMatch(uri, request.getRemoteAddr())) {
            errCode = HttpServletResponse.SC_METHOD_NOT_ALLOWED;
            response.sendError(errCode, "Only Remote ip is allowed");

            return;
        }

        if ((transactionId == null) || (transactionId.equals(""))) {
            transactionId = logKey;
        }

        MDC.put("TransactionId", transactionId);
        MDC.put("LOG_KEY", transactionId);

        try {
            requestToUse = new CustomRequestWrapper(request);

        } catch (IOException e) {
            log.warn("doFilterInternal " + e.toString());
            throw e;
        }

        beforeRequest(requestToUse, createMessage(requestToUse, "", ""));

        try {
            responseToUse = new CustResWrapper(response);

            filterChain.doFilter(requestToUse, responseToUse);

            ip = request.getHeader("X-FORWARDED-FOR");

            if (ip == null) {
                ip = request.getRemoteAddr();
            }

            if (responseToUse instanceof CustResWrapper) {

                wrapper = (CustResWrapper) responseToUse;
                res = wrapper.getDataStreamToString();

                byteLength = res.getBytes(StandardCharsets.UTF_8).length;
                sizeInKb = byteLength / d10240;

                if (sizeInKb > initByte) {
                    res = "over 512k non print log";
                }

                try {

                    isMatch = prop.isBlockMatch(uri);
                    isCType = (response.getContentType() != null);

                    if (isCType) {
                        cType = response.getContentType();
                    }

                    if (isCType && (!cType.matches("(.*)json(.*)"))) {

                        if (!isMatch) {
                            lMsg = "[{}][{}][{}] [RES] type :{}";
                            cntT = response.getContentType();
                            log.debug(lMsg, uri, ip, request.getMethod(), cntT);
                        }

                    } else {

                        if (!isMatch) {
                            lMsg = "[{}][{}][{}] [RES_PAYLOAD] {}";
                            log.debug(lMsg, uri, ip, request.getMethod(), res);
                        }

                        br = GSON.fromJson(res, BaseResponse.class);
                    }

                } catch (Exception e2) {
                    lMsg = "[{}][{}][{}] [RES] {}";
                    log.debug(lMsg, uri, ip, request.getMethod(), res);
                }

            }

        } finally {
            afterRequest(requestToUse, createMessage(requestToUse, "", ""));
            MDC.remove("LOG_KEY");
            MDC.remove("TransactionId");
        }
    }

    @Override
    @SneakyThrows
    protected String createMessage(HttpServletRequest request, String prefix,
            String suffix) {

        byte[] buf = null;
        int length = 0;
        String payload = null;
        String method = request.getMethod();
        String ip = "";
        String queryString = "";
        Map<String, String[]> paramMap = null;
        String url = "";
        String enc = "";
        String user = "";
        CustomRequestWrapper wrapper = null;

        StringBuilder msg = new StringBuilder();

        RequestInfo requestInfo = new RequestInfo();

        requestInfo.setMethod(method);
        requestInfo.setContentType(request.getContentType());
        requestInfo.setAccept(request.getHeader("Accept"));
        requestInfo.setRemoteAddr(request.getRemoteAddr());

        ip = request.getHeader("X-FORWARDED-FOR");

        if (ip == null) {
            ip = request.getRemoteAddr();
        }

        requestInfo.setRemoteAddr(ip);
        url = request.getRequestURI();

        if (isIncludeQueryString()) {

            queryString = request.getQueryString();

            if ((queryString != null) && ("GET".equals(method))) {
                requestInfo.setGetParam(queryString);
            }

            if ("POST".equals(method)) {

                paramMap = request.getParameterMap();

                if ((paramMap != null) && (!paramMap.isEmpty())) {
                    requestInfo.setPostParam(paramMap);
                }

            }

        }

        requestInfo.setUrl(url);

        if (isIncludeClientInfo()) {

            HttpSession session = request.getSession(false);

            if (session != null) {
                requestInfo.setSession(session.getId());
            }

            user = request.getRemoteUser();

            if (user != null) {
                requestInfo.setUser(user);
            }
        }

        setConf();

        wrapper = (CustomRequestWrapper) request;
        buf = wrapper.getBody();
        length = Math.min(buf.length, getMaxPayloadLength());

        try {

            enc = wrapper.getCharacterEncoding();

            payload = new String(buf, 0, buf.length, enc);
            requestInfo.setPayload(GSON.fromJson(payload, LinkedTreeMap.class));

        } catch (UnsupportedEncodingException e) {
            payload = "[unknown]";
        }

        msg.append(GSON.toJson(requestInfo));
        return msg.toString();
    }

    
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class RequestInfo {

        @JsonProperty("Method") private String method;

        @JsonProperty("Content-Type") private String contentType;

        @JsonProperty("Accept") private String accept;

        @JsonProperty("RemoteAddr") private String remoteAddr;

        @JsonProperty("URL") private String url;

        @JsonProperty("session") private String session;

        @JsonProperty("User") private String user;

        @JsonProperty("GET-Parameter") private String getParam;

        @JsonProperty("POST-Parameter") private Map<String, String[]> postParam;

        @JsonProperty("Payload") private LinkedTreeMap<String, Object> payload;

    }

}
