/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.hanhwa.saws.mediator.dto.miss.AirTrackBean;
import com.hanhwa.saws.mediator.dto.miss.SiteLocationBean;
import com.hanhwa.saws.mediator.miss.msg.McrcSeqBean;
import com.hanhwa.saws.mediator.miss.service.McrcService;
import com.hanhwa.saws.mediator.miss.service.RasdParseService;
import lombok.extern.slf4j.Slf4j;

@Service("RasdParseService")
@Slf4j
public class RasdParseServiceImpl implements RasdParseService {

    private static final int N128 = 128;
    private static final int N129 = 129;

    @Autowired McrcService mcrcService;

    @Value("${server.ref-position}") int refPo;

    @Override
    public void parse(McrcSeqBean seqBean) {
        int sequenceType = seqBean.getSeqHeader().getSequenceType();
        SiteLocationBean siteLocationBean = null;
        AirTrackBean airTrackBean = null;

        try {

            switch (sequenceType) {
                case N128: {
                    siteLocationBean = new SiteLocationBean();
                    mcrcService.putRasd(siteLocationBean);
                    break;
                }
                case N129: {
                    airTrackBean = new AirTrackBean(seqBean.getBody(), refPo);
                    mcrcService.putRasd(airTrackBean);
                    break;
                }
                default: {
                    log.warn("Unsupported sequence type: {}", sequenceType);
                    return;
                }
            }

        } catch (Exception e) {
            log.warn("Rasd data encode failed: {}", e.getMessage(), e);
            throw e;
        }
    }
}
