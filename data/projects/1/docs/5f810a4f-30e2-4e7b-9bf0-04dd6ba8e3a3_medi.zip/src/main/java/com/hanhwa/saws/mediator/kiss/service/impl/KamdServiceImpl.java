/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.kiss.service.impl;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import com.hanhwa.saws.mediator.kiss.service.KamdService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Service("KamdService")
@Slf4j
public class KamdServiceImpl implements KamdService {

    @Autowired @Qualifier("kamdSendQueue")
    private ConcurrentLinkedQueue<ArrayList<byte[]>> kamdSendQueue;

    @Autowired @Qualifier("KamdSenderExecutor")
    private TaskExecutor kamdSenderExecutor;

    @Value("${mediator.mode}") private String mode;

    @Autowired private KamdUdpSend kamdUdpSend;

    @PostConstruct
    public void init() {

        if (!"kamd".equalsIgnoreCase(mode)) {
            log.debug("KamdService not running. mode: {}", mode);
            return;
        }

        log.debug("KAMD Send UDP thread start");
        kamdSenderExecutor.execute(kamdUdpSend);

    }

    @Override
    public void putKamd(ArrayList<byte[]> kmtfBean) {
        kamdSendQueue.offer(kmtfBean);
    }

}
