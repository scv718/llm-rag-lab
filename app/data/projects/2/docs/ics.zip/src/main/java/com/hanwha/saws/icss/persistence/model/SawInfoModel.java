/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.util.Date;

import lombok.Data;

@Data
public class SawInfoModel {
    private int nodeId;
    private String sysId;
    private String operation;
    private Date updateTime;
}
