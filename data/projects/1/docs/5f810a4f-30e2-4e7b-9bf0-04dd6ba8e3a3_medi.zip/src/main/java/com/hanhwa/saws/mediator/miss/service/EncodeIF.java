/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.miss.service;

public interface EncodeIF {

    byte getType();

    byte[] encode();
}
