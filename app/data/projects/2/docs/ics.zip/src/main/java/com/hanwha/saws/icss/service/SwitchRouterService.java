/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.persistence.model.NodeModel;

public interface SwitchRouterService {

    public void heartbeatRequest(NodeModel nodeInfo);

    void medMcrcRouterRequest(NodeModel nodeInfo);

    void medKamdRouterRequest(NodeModel nodeInfo);
}
