/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.service.SmsEService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SmsQueueMgr {

    private final SmsEService handleService;

    @Autowired
    @Qualifier("smsEventQueue") 
    private ConcurrentLinkedQueue<SmsTcpEventBean> eventQueue;

    public SmsQueueMgr(SmsEService smsService) {
        handleService = smsService;
    }

    @Scheduled(fixedDelayString = "100", initialDelayString = "3000")
    public void monitor() {

        SmsTcpEventBean msg = null;

        while ((msg = eventQueue.poll()) != null) {
            handleService.eventHandle(msg);
        }

    }

}
