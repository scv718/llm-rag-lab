/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.miss;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.hanhwa.saws.mediator.miss.service.EncodeIF;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SiteLocationBean implements EncodeIF {

    private static final byte MESSAGE_TYPE = 0x08;
    //String DATE_PATTERN = "yyyyMMddHHmmss";

//    @Override
//    public byte[] encode() {
//
//       DateTimeFormatter formatter = DateTimeFormatter.ofPattern(datePattern);
//
//        return LocalDateTime.now().format(formatter).getBytes();
//    }
    
    @Override
    public byte[] encode() {

        DateTimeFormatter formatter = DateTimeFormatter
                .ofPattern("yyyyMMddHHmmss");
        LocalDateTime now = LocalDateTime.now();
        String formattedDate = now.format(formatter);

        log.info("SiteLocation Date: {}", formattedDate);

        return formattedDate.getBytes();
    }

    @Override
    public byte getType() {
        return MESSAGE_TYPE;
    }
}
