/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.RemoteDbHealthMonitor;
import com.hanwha.saws.icss.dto.RSyncB;
import com.hanwha.saws.icss.persistence.dao.remote.SyncDao;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;
import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.GroupModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.persistence.model.UserModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class RdbSyncRtMgr {

    private final static int N30 = 30;

    @Qualifier("rSyncQueue")
    private final  ConcurrentLinkedQueue<RSyncB> rSyncQueue;
    
    private final RemoteDbHealthMonitor remoteDbHealthMonitor;
    private final SyncDao syncDao;
    
    @Value("${prop.host-name}") String hostName;

    private String lFormat = "Remote DB Realtime Sync";

    @Scheduled(fixedDelayString = "30", initialDelayString = "3000")
    public void monitor() {

        if (rSyncQueue.size() != 0) {
            handleEvent(rSyncQueue.poll());
        }

    }

    private void handleEvent(RSyncB rSyncB) {
        
        Object rObj = rSyncB.getDataObj();
        
        try {

            if (rObj instanceof ThresholdModel) {
                thresholdEvent(rSyncB);
            } else if (rObj instanceof SawInfoModel) {
                sawEvent(rSyncB);
            } else if (rObj instanceof GroupModel) {
                groupEvent(rSyncB);
            } else if (rObj instanceof UserModel) {
                userEvent(rSyncB);
            } else if (rObj instanceof DefaultCodeModel) {
                dCodeEvent(rSyncB);
            } else if (rObj instanceof CurrAlarmModel) {
                cAlarmEvent(rSyncB);
            } else if (rObj instanceof StatusModel) {
                cStatusEvent(rSyncB);
            } else {
                log.warn("데이터 타입 불일치");
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void thresholdEvent(RSyncB rSyncB) {
        
        ThresholdModel tmpM = null;
        
        try {
            tmpM = (ThresholdModel) rSyncB.getDataObj();
            switch (rSyncB.getType()) {
                case "INSERT":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateThresholdInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }                   
                    break;
                case "DELETE":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void sawEvent(RSyncB rSyncB) {
        
        SawInfoModel tmpM = null;
        
        try {
            tmpM = (SawInfoModel) rSyncB.getDataObj();
            tmpM.setSysId(hostName);
            
            switch (rSyncB.getType()) {
                case "INSERT":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateSawInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void groupEvent(RSyncB rSyncB) {

        GroupModel tmpM = null;

        try {
            tmpM = (GroupModel) rSyncB.getDataObj();

            switch (rSyncB.getType()) {
                case "INSERT":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.insertGroupInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateGroupInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.deleteGroupInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void userEvent(RSyncB rSyncB) {

        UserModel tmpM = null;

        try {
            tmpM = (UserModel) rSyncB.getDataObj();
            switch (rSyncB.getType()) {
                case "INSERT":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.insertUserInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateUserInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.deleteUserInfo(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void dCodeEvent(RSyncB rSyncB) {
        
        DefaultCodeModel tmpM = null;
        
        try {
            tmpM = (DefaultCodeModel) rSyncB.getDataObj();

            switch (rSyncB.getType()) {
                case "INSERT":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateDefaultCode(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void cAlarmEvent(RSyncB rSyncB) {
        
        CurrAlarmModel tmpM = null;
        
        try {
            tmpM = (CurrAlarmModel) rSyncB.getDataObj();

            switch (rSyncB.getType()) {
                case "INSERT":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.insertCurrentAlarm(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateCurrentAlarmTally(tmpM);
                        syncDao.updateAlarmHistTally(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.deleteCurrentAlarm(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }

    private void cStatusEvent(RSyncB rSyncB) {
        
        StatusModel tmpM = null;
        
        try {
            tmpM = (StatusModel) rSyncB.getDataObj();

            switch (rSyncB.getType()) {
                case "INSERT":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                case "UPDATE":
                    if (remoteDbHealthMonitor.isRemoteAlive()) {
                        syncDao.updateStatus(tmpM);
                    } else {
                        log.debug("remote db not alived");
                    }
                    break;
                case "DELETE":
                    log.debug("not allow " + rSyncB.getType());
                    break;
                default:
                    log.warn("알 수 없는 작업 타입: " + rSyncB.getType());
                    break;
            }

        } catch (DataAccessException e) {
            log.warn(lFormat + " " + e.toString());
        }
    }
}
