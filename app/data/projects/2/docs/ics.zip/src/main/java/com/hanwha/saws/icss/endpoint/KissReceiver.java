/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.util.Arrays;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.service.ProcessMonitorService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KissReceiver {

    private static final int N512 = 512;
    private static final int INIT_WAIT = 0;
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");
    private final PropConfig propConfig;
    private final ProcessMonitorService recvMonitor;

    @Value("${listener.bond-ip}") private String bondIp;
    @Value("${listener.kamd.ip}") private String ip;
    @Value("${listener.kamd.port}") private int port;

    @Autowired @Qualifier("kissRecvBulkQueue") 
    private ConcurrentLinkedQueue<RecvMsgQueueBean> recvBulkQueue;

    @Autowired
    public KissReceiver(
            PropConfig propConfig, ProcessMonitorService recvMonitor) {
        this.propConfig = propConfig;
        this.recvMonitor = recvMonitor;
    }

    public void putQueue(RecvMsgQueueBean bean) {

        String logTmp = "[KAMD] Queue put : 1 , remain {}";
        
        log.debug("Kiss Queue Insert ip : " + bean.getSenderIp());
        recvBulkQueue.offer(bean);
        qLog.debug(logTmp, recvBulkQueue.size());
    }

    @Scheduled(fixedDelayString = "1000", initialDelayString = "3000")
    public void monitor() {
        final byte[] mBuf = new byte[N512];

        MulticastSocket socket = null;
        NetworkInterface netIf = null;
        InetSocketAddress group = null;
        InetAddress mcastAddr = null;
        InetAddress localAddr = null;
        DatagramPacket packet = null;
        byte[] copy = null;
        int pLen = 0;
        String recvIp = null;

        String logIMsg = "Kiss MulticastReceiver inner error: {}";
        String logOMsg = "Kiss MulticastReceiver outer error: {}";
        String logFMsg = "Kiss service leaveGroup failed: {}";
        String logSMsg = "Kiss service leaveGroup";
        String[] ipList = ip.trim().split(",");
        boolean isClose = false;
        
        while (true) {
            
            if (socket == null || socket.isClosed()) {
                try {
                    
                    localAddr = InetAddress.getByName(bondIp);
                    netIf = NetworkInterface.getByInetAddress(localAddr);
                    socket = new MulticastSocket(port);

                    for (String mIp : ipList) {
                        mcastAddr = InetAddress.getByName(mIp.trim());
                        group = new InetSocketAddress(mcastAddr, port);
                        socket.joinGroup(group, netIf);
                        log.info("Kiss service joinGroup: {}:{}", mIp.trim(),
                                port);                    
                    }
               
                    while (true) {

                        try {
                            packet = new DatagramPacket(mBuf, mBuf.length);
                            socket.receive(packet);

                            recvMonitor.markReceivedNow();

                            if (propConfig.getInitFlag() == INIT_WAIT) {
                                continue;
                            }

                            pLen = packet.getLength();
                            copy = Arrays.copyOf(packet.getData(), pLen);
                            recvIp = packet.getAddress().getHostAddress();

                            putQueue(new RecvMsgQueueBean(copy, recvIp));

                        } catch (IOException | RuntimeException e2) {
                            log.warn(logIMsg, e2.toString());
                        }
                    }

                } catch (IOException | RuntimeException e) {
                    log.error(logOMsg, e.toString());

                }
                
                if (socket == null || netIf == null) {
                    isClose = true;
                } else {
                    isClose = false;
                }

                if (!isClose) {
                    for (String mIp : ipList) {

                        if (!mIp.isEmpty()) {
                            try {
                                mcastAddr = InetAddress.getByName(mIp);
                                group = new InetSocketAddress(mcastAddr, port);
                                socket.leaveGroup(group, netIf);
                                log.debug("{} complete: {}:{}", logSMsg, mIp,
                                        port);
                            } catch (IOException e3) {
                                log.warn("{} failed for {}:{} - {}", logSMsg,
                                        mIp, port, e3.toString());
                            }
                        }
                    }
                    socket.close();
                    log.info("Kiss socket closed");
                }
             
            }

        }
    }

}
