/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.endpoint;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.dto.RecvMsgQueueBean;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccListener {
    private static final Logger qLog = LoggerFactory.getLogger("QUEUE_MONITOR");

    @Autowired
    @Qualifier("sccQueue") 
    private ConcurrentLinkedQueue<RecvMsgQueueBean> sccQueue;

    @PostConstruct
    public void init() {
        log.info("SccListener initialized: Receiver & QueueMgr started.");
    }

    public int getQueueSize() {
        return sccQueue.size();
    }

}
