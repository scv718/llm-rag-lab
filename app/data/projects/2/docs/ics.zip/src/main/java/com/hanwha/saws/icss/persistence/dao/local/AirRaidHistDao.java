/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.AirRaidHistModel;

public interface AirRaidHistDao {

    public void insertAirHist(AirRaidHistModel param);

    public int selectAirRaidHistTotalCount(AirRaidHistModel param);

    public List<AirRaidHistModel> selectAirRaidHistList(AirRaidHistModel param);

}
