/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CBit {

    private int mem = 0;
    private int vocoder = 0;
    @JsonProperty("if") private int ifUnit = 0;
    private int crypto = 0;
    private int ethernet1 = 0;
    private int ethernet2 = 0;
    private int flash = 0;
    @JsonIgnore private String binaryString;

    @JsonIgnore
    public String getAlarmInfo() { // 세부상태는 기입하지 않음
        
        String val = null; 
        
        boolean isM = (mem == 1);
        boolean isV = (vocoder == 1);
        boolean isI = (ifUnit == 1);
        boolean isC = (crypto == 1);
        boolean isE1 = (ethernet1 == 1);
        boolean isE2 = (ethernet2 == 1);
        boolean isF = (flash == 1);

        StringBuilder sb = new StringBuilder();
        
        if (isM || isV || isI || isC || isE1 || isE2 || isF) {
            
            if (mem > 0) {
                setComma(sb);
                sb.append("memory");
            }
            
            if (vocoder > 0) {
                setComma(sb);
                sb.append("Vocoder");
            }
            
            if (ifUnit > 0) {
                setComma(sb);
                sb.append("중간주파수처리반");
            }
            
            if (crypto > 0) {
                setComma(sb);
                sb.append("암호장비구동반");
            }
            
            if (ethernet1 > 0) {
                setComma(sb);
                sb.append("Ethernet #1");
            }
            
            if (ethernet2 > 0) {
                setComma(sb);
                sb.append("Ethernet #2");
            }
            
            if (flash > 0) {
                setComma(sb);
                sb.append("Flash");
            }

            val = sb.toString();
        }

        return val;
        
    }

    @JsonIgnore
    private void setComma(StringBuilder sb) {
        if (!sb.isEmpty()) {
            sb.append(", ");
        }
    }

    @JsonIgnore
    public String getErrCode() {
        return binaryString;
    }
}