/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MedAlarmInfo {

    @JsonProperty("alarm_type") private String alarmType;

    private String sev;
    private String time;

}
