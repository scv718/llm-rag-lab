/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.service.ProcessMonitorService;

import lombok.extern.slf4j.Slf4j;

@Service("ProcessMonitorService")
@Slf4j
public class ProcessMonitorServiceImpl implements ProcessMonitorService {

    private static final long TIME_WINDOW_MILLIS = 9000; // 9초
    private volatile long recentTime = 0;
    private volatile long recentErrTime = 0;

    @Override
    public void markReceivedNow() {
        recentTime = System.currentTimeMillis(); // 여러 스레드가 접근
    }

    @Override
    public void markReceivedErrNow() {
        recentErrTime = System.currentTimeMillis(); // 여러 스레드가 접근
    }

    @Override
    public boolean isRecentWithin9Seconds() {
        boolean isPass = true;
        long now = System.currentTimeMillis();

        if (recentTime == 0) {
            isPass = false; // 아직 수신한 적 없음
        }

        if (isPass) {
            isPass = ((now - recentTime) <= TIME_WINDOW_MILLIS);
        }

        return isPass;
    }

    @Override
    public boolean isRecentErrWithin9Seconds() {
        long now = System.currentTimeMillis();
        boolean isPass = true;

        if (recentErrTime == 0) {
            isPass = false; // 아직 수신한 적 없음
        }

        if (isPass) {
            isPass = ((now - recentErrTime) <= TIME_WINDOW_MILLIS);
        }

        return isPass;
    }
}
