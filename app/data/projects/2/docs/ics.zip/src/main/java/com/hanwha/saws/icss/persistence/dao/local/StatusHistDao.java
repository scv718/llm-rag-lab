/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;

public interface StatusHistDao {

    public void insertStatusHist(StatusHistModel param);

    public List<StatusHistModel> selectStatusHistSearch(StatusHistModel param);

    public int selectStatusSearchTotalCount(StatusHistModel param);

    public StatusHistModel selectLastStatusHistInfo(StatusHistModel param);

}