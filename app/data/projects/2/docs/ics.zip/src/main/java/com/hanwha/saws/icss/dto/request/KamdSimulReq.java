/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class KamdSimulReq {
    @JsonProperty("simul_no") private String simulNo;
    @JsonProperty("data") private List<KamdSimulArrReq> data;    

}
