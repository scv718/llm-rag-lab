/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PBit {

    @JsonProperty("v5_1") private int v5One = 0;
    @JsonProperty("v5_2") private int v5Two = 0;
    @JsonProperty("v12") private int vTwelve = 0;

    @JsonIgnore
    public String getAlarmInfo() {
        StringBuilder sb = new StringBuilder();
        String val = null;
        
        if ((v5One == 1) || (v5Two == 1) || (vTwelve == 1)) {

            if (v5One > 0) {
                setComma(sb);
                sb.append("5V 1");
            }

            if (v5Two > 0) {
                setComma(sb);
                sb.append("5V 2");
            }

            if (vTwelve > 0) {
                setComma(sb);
                sb.append("12V");
            }

            val = sb.toString();

        }
        
        return val;
    }

    @JsonIgnore
    private void setComma(StringBuilder sb) {
        if (!sb.isEmpty()) {
            sb.append(", ");
        }
    }
}