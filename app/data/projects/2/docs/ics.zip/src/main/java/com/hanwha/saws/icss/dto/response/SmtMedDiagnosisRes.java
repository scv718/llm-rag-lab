/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class SmtMedDiagnosisRes {

    @JsonProperty("process_yn") private String processYn = "N";
    @JsonProperty("network_yn") private String networkYn = "N";
    @JsonProperty("data_corrupt_yn") private String dataCorrupt = "N";
    @JsonProperty("no_data_yn") private String noData = "N";

    @JsonIgnore
    public void setDefault(String defStatus) {
        noData = defStatus;
        dataCorrupt = defStatus;
        networkYn = defStatus;
        processYn = defStatus;
    }
}
