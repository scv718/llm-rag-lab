/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.dto.code;

import lombok.Getter;

@Getter
public enum ResponseCode {
    C200(200, "성공"),
    C204(204, "클라이언트의 요구를 처리했으나 전송할 데이터가 없음"),
    C400(400, "요청 실패. 문법상 오류가 있어서 서버가 요청사항을 이해하지 못함"),
    C500(500, "서버 내부 오류 발생함");


    private int code;
    private String msg;

    private ResponseCode(int cCd, String cMsg) {
        this.code = cCd;
        this.msg = cMsg;
    }

}
