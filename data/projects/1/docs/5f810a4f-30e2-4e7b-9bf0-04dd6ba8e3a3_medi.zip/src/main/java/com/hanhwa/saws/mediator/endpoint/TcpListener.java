/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TcpListener{

    @Value("${mediator.mode}") private String mode;

    @Autowired @Qualifier("KamdListenerExecutor")
    private TaskExecutor kamdListenerExecutor;

    @Autowired private KamdQueueMonitor kamdQueueMonitor;

    @Autowired private KamdReceiverPoll kamdReceiverPoll;

    @Autowired private KamdReceiver kamdReceiver;

    @PostConstruct
    public void init() {
        if (!"kamd".equalsIgnoreCase(mode)) {
            log.debug("TCP Listener not running. mode: {}", mode);
            return;
        }

        kamdListenerExecutor.execute(kamdReceiver);
        kamdListenerExecutor.execute(kamdReceiverPoll);
        kamdListenerExecutor.execute(kamdQueueMonitor);

    }

}
