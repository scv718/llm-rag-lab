/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import com.hanwha.saws.icss.dto.request.McrcSimulRouteReq;
import com.hanwha.saws.icss.dto.request.McrcSimulTrackReq;

import lombok.Data;

@Data
public class McrcSimulModel {

    private int simulNo;
    private String mcrcCode;
    private String mcrcType;
    private Integer mcrcRoute;
    private String mcrcLocationX;
    private String mcrcLocationY;
    private String mcrcKnot;
    private String mcrcFeet;
    private String mcrcDirection;
    private String mcrcCount;
    private String sysId;
    private String createSys;

    public void setData(String sNo, McrcSimulTrackReq tReq,
            McrcSimulRouteReq routeReq, String cSysId) {

        simulNo = Integer.parseInt(sNo);
        
        mcrcCode = tReq.getMcrcCode();
        mcrcType = tReq.getMcrcType();
        mcrcRoute = routeReq.getMcrcRoute();
        mcrcLocationX = routeReq.getMcrcLocationX();
        mcrcLocationY = routeReq.getMcrcLocationY();
        
        if (routeReq.getMcrcKnot() != null) {
            mcrcKnot = routeReq.getMcrcKnot() + "";
        }

        if (routeReq.getMcrcFeet() != null) {
            mcrcFeet = routeReq.getMcrcFeet() + "";
        }

        if (tReq.getMcrcDirection() != null) {
            mcrcDirection = tReq.getMcrcDirection() + "";
        }

        if (tReq.getMcrcCount() != null) {
            mcrcCount = tReq.getMcrcCount() + "";
        }
        
        sysId = cSysId;
        createSys = routeReq.getCreateSys();

    }
}
