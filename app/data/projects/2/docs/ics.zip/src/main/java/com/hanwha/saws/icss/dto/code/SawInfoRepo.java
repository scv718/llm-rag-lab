/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.code;

public class SawInfoRepo {

    private static final SawInfoRepo ICSS_A = new SawInfoRepo("ICSS_A");
    private static final SawInfoRepo ICSS_B = new SawInfoRepo("ICSS_B");
    private static final SawInfoRepo OPERATION_ACTIVE = new SawInfoRepo("0");
    private static final SawInfoRepo OPERATION_STANDBY = new SawInfoRepo("1");

    private final String code;

    private SawInfoRepo(String cd) {
        this.code = cd;
    }

    public String getCode() {
        return code;
    }

//    public static SawInfoRepo getIcssA() {
//        return ICSS_A;
//    }
//
//    public static SawInfoRepo getIcssB() {
//        return ICSS_B;
//    }

    public static SawInfoRepo getOperationActive() {
        return OPERATION_ACTIVE;
    }

//    public static SawInfoRepo getOperationStandby() {
//        return OPERATION_STANDBY;
//    }

}