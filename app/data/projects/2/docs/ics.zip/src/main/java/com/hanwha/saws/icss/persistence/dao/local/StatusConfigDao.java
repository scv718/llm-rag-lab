/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.DefaultCodeModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;

public interface StatusConfigDao {

    public int updateNodeInfo(NodeModel param);

    public List<NodeModel> selectNodeInfoList();

    public List<StatusModel> selectStatusList();

    public int updateStatus(StatusModel param);

    public SawInfoModel selectSawInfo(String sysId);

    public List<SawInfoModel> selectSawList();

    public List<ThresholdModel> selectThresholdList();

    public List<ThresholdModel> selectThresholdInfo(ThresholdModel param);

    public DefaultCodeModel selectDefaultCodeInfo(Integer param);

    public List<DefaultCodeModel> selectDefaultCodeAll();

    public void updateDefaultCode(DefaultCodeModel param);

    public List<NodeModel> selectNodeAlarmStatus();

    public void updateThresholdInfo(ThresholdModel param);

    public void updateSawInfo(SawInfoModel param);

}
