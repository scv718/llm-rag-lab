/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.RecvMsgQueueBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.kiss.MissleTrackSduBean;
import com.hanwha.saws.icss.dto.miss.AirTrackSduBean;
import com.hanwha.saws.icss.endpoint.KissListener;
import com.hanwha.saws.icss.endpoint.MissListener;
import com.hanwha.saws.icss.persistence.dao.local.SimulDao;
import com.hanwha.saws.icss.persistence.model.KamdSimulModel;
import com.hanwha.saws.icss.persistence.model.McrcSimulModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SccMcrcSimulMgr {
    private static final int BFF = 0xFF;
    private static final byte MCRC_TRAIN_END = 0x05;
    private static final int N2 = 2;

    private List<String> simulList = null;
    private ArrayList<McrcSimulModel> tSendList = null;
    private McrcSimulModel qData = null;
    private List<McrcSimulModel> mcList = null;
    private int mSTmp = 0;

    @Value("${prop.ref-position}")
    int refPosition;

    @Autowired
    @Qualifier("mcrcSimulMap")
    private ConcurrentHashMap<String, Integer> mcrcSimulMap;

    @Value("${ics.group-byte-length}")
    int groupByteLength;
    @Value("${scc.send-port}")
    int sccPort;

    @Autowired
    PropConfig prop;

    @Autowired
    SimulDao simulDao;

    @Autowired
    private SccServiceImpl sccService;

    @Autowired
    MissListener missListener;

    @Scheduled(fixedDelayString = "3000", initialDelayString = "3000")
    public void monitor() {

        simulList = new ArrayList<String>(mcrcSimulMap.keySet());
        tSendList = new ArrayList<>();

        for (String key : simulList) {

            qData = new McrcSimulModel();
            qData.setSimulNo(Integer.parseInt(key));
            qData.setMcrcRoute(mcrcSimulMap.get(key));

            mcList = simulDao.selectMcrcSimulList(qData);

            if (mcList.size() == 0) {
                mcrcSimulMap.remove(key);
                log.debug("MCRC SIMUL SEND FINISH");
                simulEndAlarm(Integer.parseInt(key));
            } else {
                mSTmp = (mcrcSimulMap.get(key) + 1);
                mcrcSimulMap.put(key, mSTmp);
                tSendList.addAll(mcList);
            }
        }

        makeMcrcQueue(tSendList);

    }

    private void makeMcrcQueue(ArrayList<McrcSimulModel> tSendList) {
        AirTrackSduBean atBean = new AirTrackSduBean();
        ArrayList<byte[]> snList = null;
        String mIp = sccService.getSimulSenderIp();

        if (tSendList.size() > 0) {
            snList = atBean.getSimulEncode(tSendList, refPosition);

            for (byte[] bs : snList) {
                log.debug(HexByteUtil.getByteArrayToHexString(bs));
                missListener.putQueue(new RecvMsgQueueBean(bs, mIp));
            }
        }
    }

    private void simulEndAlarm(int simulNo) {
        ByteBuffer bBufTmp = ByteBuffer.allocate(groupByteLength);
        HashMap<Integer, NodeModel> nHList = prop.getNodeInfoHash();
        ByteBuffer bBuf = null;
        byte[] gB = null;
        byte[] rMsgB = null;

        for (int i = 0; i < groupByteLength; i++) {
            bBufTmp.put((byte) BFF);
        }

        gB = bBufTmp.array();
        bBuf = ByteBuffer.allocate((N2 + gB.length + N2));
        bBuf.put(STypeRepo.getCtlCmd().getCode());
        bBuf.put((byte) (gB.length + N2));
        bBuf.put(gB);
        bBuf.put(MCRC_TRAIN_END);
        bBuf.put((byte) simulNo);
        rMsgB = bBuf.array();

        sendUdp(nHList.get(NodeRepo.getSccA().getCode()), sccPort, rMsgB);
        sendUdp(nHList.get(NodeRepo.getSccB().getCode()), sccPort, rMsgB);
    }

    private boolean sendUdp(NodeModel info, int port, byte[] data) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress mcastaddr = InetAddress.getByName(info.getAddrIp());
            DatagramPacket packet = null;

            packet = new DatagramPacket(data, data.length, mcastaddr, port);

            socket.send(packet);

        } catch (IOException | RuntimeException e) {
            log.warn("SccService sendUdpData()" + e.toString());
            return false;
        }

        return true;
    }
}
