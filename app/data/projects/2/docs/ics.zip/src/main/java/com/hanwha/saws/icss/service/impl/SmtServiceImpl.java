/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.EmsTypeRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.code.OpCmdRepo;
import com.hanwha.saws.icss.dto.code.OpHistRltRepo;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.code.STypeRepo;
import com.hanwha.saws.icss.dto.code.StatusRepo;
import com.hanwha.saws.icss.dto.request.MedReq;
import com.hanwha.saws.icss.dto.request.SmtThresholdReq;
import com.hanwha.saws.icss.dto.request.SmtThresholdSetReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.dto.response.MedAlarmInfo;
import com.hanwha.saws.icss.dto.response.MedDiagnosisRes;
import com.hanwha.saws.icss.dto.response.OperationCodeRes;
import com.hanwha.saws.icss.dto.response.SmtDeviceStatusRes;
import com.hanwha.saws.icss.dto.response.SmtEmsHistListRes;
import com.hanwha.saws.icss.dto.response.SmtEmsHistRes;
import com.hanwha.saws.icss.dto.response.SmtIcsDiagnosisRes;
import com.hanwha.saws.icss.dto.response.SmtMedDiagnosisRes;
import com.hanwha.saws.icss.dto.response.SmtOperationHistListRes;
import com.hanwha.saws.icss.dto.response.SmtOperationHistRes;
import com.hanwha.saws.icss.dto.response.SmtStatListRes;
import com.hanwha.saws.icss.dto.response.SmtStatRes;
import com.hanwha.saws.icss.dto.response.SmtStatusHistListRes;
import com.hanwha.saws.icss.dto.response.SmtStatusHistRes;
import com.hanwha.saws.icss.dto.response.ThresholdRes;
import com.hanwha.saws.icss.persistence.dao.local.NonSyncHistDao;
import com.hanwha.saws.icss.persistence.dao.local.StatDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.dao.local.StatusHistDao;
import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.EmsHistModel;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;
import com.hanwha.saws.icss.persistence.model.SawInfoModel;
import com.hanwha.saws.icss.persistence.model.ServerAlarmStatModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.AsyncService;
import com.hanwha.saws.icss.service.IcsSyncService;
import com.hanwha.saws.icss.service.KissService;
import com.hanwha.saws.icss.service.MissService;
import com.hanwha.saws.icss.service.ProcessMonitorService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.service.SccService;
import com.hanwha.saws.icss.service.SmsService;
import com.hanwha.saws.icss.service.SmtService;
import com.hanwha.saws.icss.service.SyncHistInsertService;
import com.hanwha.saws.icss.util.NetworkPingUtil;
import com.hanwha.saws.icss.util.NodeUtil;

import lombok.extern.slf4j.Slf4j;

@Service("SmtService")
@Slf4j
public class SmtServiceImpl implements SmtService {

    private static final String RESET = "reset";
    private static final String DIAGNOSIS = "diagnosis";

    private static final int MODE_LOCAL = 0;
    private static final int MODE_REMOTE = 1;

    private static final int ACTIVE = 1;
    private static final int STANDBY = 0;  
    private static final int N1000 = 1000;
    private static final int N100 = 100;
    private static final int N1 = 1;
    private static final int N2 = 2;

    @Autowired PropConfig prop;
    @Autowired StatusConfigDao statusConfigDao;
    @Autowired RestClientService restClient;
    @Autowired IcsSyncService syncService;
    @Autowired SyncHistInsertService sHisInsServ;
    @Autowired NonSyncHistDao nonSyncHistDao;
    @Autowired AsyncService asyncService;

    @Autowired SmsService smsService;

    @Autowired AlarmService alarmService;

    @Autowired StatusHistDao statusHistDao;

    @Autowired ProcessMonitorService recvMonitor;

    @Autowired KissService kissService;
    @Autowired MissService missService;
    @Autowired SccService sccService;

    @Autowired StatDao statDao;

    @Autowired RdbSyncRtService rtSync;

    @Value("${prop.host-name}") String hostName;

    @Value("${med.send-port}") int medUrlPort;

    @Value("${prop.ref-position}") int refPosition;

    private boolean isFailover = false;

    @Override
    public boolean isFailingOver() {
        return isFailover;
    }

    @Override
    public BaseResponse failover(LoginSessionBean bean) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nodeInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OperationHistModel histBean = null;
        List<StatusModel> remoteStatusList = null;
        String cTmp = "";
        String rTmp = "";
        BaseResponse res = null;

        isFailover = true;

        if (prop.getActiveMode() != ACTIVE) {
            log.debug("its standby not failover");
            isFailover = false;

            return new BaseResponse(ResRepo.getC400());
        }

        try {

            histBean = getOpHistBean(bean, OpCmdRepo.getFailover(), nodeInfo);
            res = restClient.getHeartBeat(prop.getRIcsIp());
            remoteStatusList = syncService.getRemoteStatusList();

            if ((res == null) || (remoteStatusList == null)) {

                try {
                    cTmp = OpHistRltRepo.getResultFailed().getName();
                    rTmp = ResRepo.getC401().getMsg();

                    insertOperationHist(histBean, cTmp, rTmp);

                } catch (RuntimeException e) {
                    log.warn("insertOperationHist " + e.toString());
                }

                isFailover = false;

                return new BaseResponse(ResRepo.getC401());
            }

            setLocalStandby();
            res = setRemoteActive();
            histBean.setEndTime(new Date());

            if (res.getResCd() != ResRepo.getC200().getCode()) {

                setLocalActive();
                cTmp = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, cTmp, res.getResMsg());

            } else {

                syncStatusInfo();

                cTmp = OpHistRltRepo.getResultSuccess().getName();
                insertOperationHist(histBean, cTmp, hostName + " STANDBY");
                rTmp = "STANDBY";
                sHisInsServ.insertFailoverAlarmHist(new AlarmHistModel(), rTmp);
            }

            isFailover = false;
            return res;

        } catch (Exception e) {
            isFailover = false;
            log.warn("SmtService failover() " + e.toString());
            cTmp = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, cTmp, e.toString());
        }

        isFailover = false;

        return new BaseResponse(ResRepo.getC999()); // 오류 발생
    }

    private void syncStatusInfo() {

        try {
            List<StatusModel> sStatusList = statusConfigDao.selectStatusList();

            syncService.syncRemoteStatus(sStatusList);

        } catch (RuntimeException e) {
            log.warn("syncStatusInfo() " + e.toString());
        }
    }

    private OperationHistModel getOpHistBean(LoginSessionBean bean,
            OpCmdRepo code, NodeModel nm) {

        OperationHistModel model = new OperationHistModel();
        String tAdd = hostName + " " + nm.getName() + " " + nm.getAddrIp();
        String tCd = OpHistRltRepo.getResultSuccess().getName();

        model.setStartTime(new Date());
        model.setUserId(bean.getUserId());
        model.setUserName(bean.getName());
        model.setUserIp(bean.getIp());
        model.setOperation(code.getMsg());
        model.setAdditionalInfo(tAdd);
        model.setOperationResult(tCd);
        model.setEndTime(new Date());

        return model;
    }

    private void insertOperationHist(OperationHistModel bean, String resultCode,
            String msg) {

        try {
            bean.setOperationResult(resultCode);
            if (msg.length() > N1000) {
                msg = msg.substring(0, N1000);
            }

            bean.setAdditionalInfo(msg);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);
        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString(), e);
        }

    }

    private void insertOperationHist(OperationHistModel bean,
            String resultCode) {
        try {

            bean.setOperationResult(resultCode);
            bean.setEndTime(new Date());

            nonSyncHistDao.insertOperationHistInfo(bean);
        } catch (RuntimeException e) {
            log.warn("insertOperationHist() " + e.toString());
        }

    }

    /*
     * LOCAL STANDBY, LOCAL ACTIVE 이 부분은 FAILOVER라 다 끝나고 통 업데이트를 하기 때문에 불필요함
     */
    private void setLocalStandby() throws DataAccessException {

        StatusModel param = new StatusModel();
        StatusRepo sr = StatusRepo.getACTIVE();

        NodeUtil.setIcsStatusMode(hostName, param, sr, MODE_REMOTE);
        sr = StatusRepo.getSTANDBY();
        NodeUtil.setIcsStatusMode(hostName, param, sr, MODE_LOCAL);

        statusConfigDao.updateStatus(param);
        prop.setActiveMode(STANDBY);
    }

    /*
     * 실패시에는 저쪽 DB에서 INSERT 실패했기 때문에 DB업데이트 안해도 된다
     */
    private void setLocalActive() throws DataAccessException {

        StatusModel param = new StatusModel();
        StatusRepo sr = StatusRepo.getSTANDBY();

        NodeUtil.setIcsStatusMode(hostName, param, sr, MODE_REMOTE);
        sr = StatusRepo.getACTIVE();
        NodeUtil.setIcsStatusMode(hostName, param, sr, MODE_LOCAL);
        statusConfigDao.updateStatus(param);

        prop.setActiveMode(ACTIVE);
    }

    private BaseResponse setRemoteActive() {
        try {
            return restClient.setActiveMode(prop.getRIcsIp());
        } catch (RuntimeException e) {
            log.warn("setRemoteActive() " + e.toString());
            return new BaseResponse(ResRepo.getC999());
        }
    }

    @Override
    public BaseResponse reset(LoginSessionBean bean, int nodeId) {

        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo tCd = null;
        OperationHistModel opHMParam = null;

        boolean isKA = (nInfo.getNodeId() == NodeRepo.getKissA().getCode());
        boolean isKB = (nInfo.getNodeId() == NodeRepo.getKissB().getCode());
        boolean isMA = (nInfo.getNodeId() == NodeRepo.getMissA().getCode());
        boolean isMB = (nInfo.getNodeId() == NodeRepo.getMissB().getCode());
        boolean isIA = (nInfo.getNodeId() == NodeRepo.getIcssA().getCode());
        boolean isIB = (nInfo.getNodeId() == NodeRepo.getIcssB().getCode());
        boolean isSA = (nInfo.getNodeId() == NodeRepo.getSmsA().getCode());
        boolean isSB = (nInfo.getNodeId() == NodeRepo.getSmsB().getCode());

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("is standby reset fail");
            return new BaseResponse(ResRepo.getC400());
        }

        if (isKA || isKB || isMA || isMB) {
            tCd = OpCmdRepo.getResetMed();
            return medReset(getOpHistBean(bean, tCd, nInfo), nInfo);

        } else if (isIA || isIB) {

            tCd = OpCmdRepo.getResetIcs();
            return icsReset(getOpHistBean(bean, tCd, nInfo), nInfo, bean);

        } else if (isSA || isSB) {
            tCd = OpCmdRepo.getResetModem();
            opHMParam = getOpHistBean(bean, tCd, nInfo);
            return smsService.reset(opHMParam, nInfo, bean);
        }

        return null;
    }

    private BaseResponse icsReset(OperationHistModel histBean,
            NodeModel nodeInfo, LoginSessionBean bean) {
        BaseResponse res = null;
        String tcd = null;
        String tLog = "{} {} icsReset";
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nodeModel = NodeUtil.getNodeInfoP(hostName, nList);

        log.debug(tLog, nodeInfo.getName(), nodeInfo.getAddrIp());

        if (nodeInfo.getAddrIp().equals(nodeModel.getAddrIp())) {
            tcd = OpHistRltRepo.getResultSuccess().getName();
            tLog = nodeInfo.getName() + " reset success";
            insertOperationHist(histBean, tcd, tLog);
            resetAlarmHist(nodeModel);
            emsStopInsert();

            asyncService.resetIcs();
        } else {

            res = restClient.setIcsResetReq(nodeInfo.getAddrIp(), bean);

            if (res.getResCd() != ResRepo.getC200().getCode()) {
                tcd = OpHistRltRepo.getResultFailed().getName();
                insertOperationHist(histBean, tcd, res.getResMsg());
            }

            return res;
        }

        return new BaseResponse(ResRepo.getC200());
    }

    private void emsStopInsert() {

        try {
            EmsHistModel em = new EmsHistModel();

            em.setOperationType(EmsTypeRepo.getStop().getCode());
            em.setOperationResult(EmsTypeRepo.getSuccess().getCode());
            em.setInsertTime(new Date());

            nonSyncHistDao.insertEmsHistInfo(em);
        } catch (DataAccessException e) {
            log.warn(e.toString(), e);
        }
    }

    @Override
    public BaseResponse remoteIcsReset(LoginSessionBean bean) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel node = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo tCd = OpCmdRepo.getResetIcs();
        String tMsg = OpHistRltRepo.getResultSuccess().getName();
        OperationHistModel opHBean = null;

        opHBean = getOpHistBean(bean, tCd, node);
        insertOperationHist(opHBean, tMsg, node.getName() + " reset success");
        resetAlarmHist(node);
        asyncService.resetIcs();

        return new BaseResponse(ResRepo.getC200());
    }

    private BaseResponse medReset(OperationHistModel histBean,
            NodeModel nodeInfo) {
        MedReq mReqBean = new MedReq();
        BaseResponse res = null;
        String tLog = "{} {} medReset";
        String tMsg = null;

        log.debug(tLog, nodeInfo.getName(), nodeInfo.getAddrIp());
        mReqBean.setOpCode(RESET);

        res = restClient.getMedCommonReq(nodeInfo.getAddrIp(), mReqBean);

        if (res.getResCd() != ResRepo.getC200().getCode()) {
            tMsg = OpHistRltRepo.getResultFailed().getName();
            insertOperationHist(histBean, tMsg, res.getResMsg());
        } else {
            tMsg = OpHistRltRepo.getResultSuccess().getName();
            tLog = nodeInfo.getName() + " reset success";
            insertOperationHist(histBean, tLog, tLog);
            resetAlarmHist(nodeInfo);
        }

        return res;
    }

    private void resetAlarmHist(NodeModel node) {
        AlarmHistModel aHBean = new AlarmHistModel();

        aHBean.setTime();
        aHBean.setCurrUuid((UUID.randomUUID().toString().replace("-", "")));
        aHBean.setNodeId(node.getNodeId());
        aHBean.setNodeName(node.getName());
        aHBean.setAddrIp(node.getAddrIp());
        aHBean.setAlarmId(AlarmRepo.getAlmReset().getCode());
        aHBean.setAlarmName(AlarmRepo.getAlmReset().getMsg());
        aHBean.setServerity(AlarmRepo.getSvrInfo().getCode());
        aHBean.setLocation(node.getAddrIp());
        aHBean.setSummary(AlarmRepo.getAlmReset().getMsg());
        aHBean.setRecoverReason(null);
        aHBean.setRecoverTime(null);
        aHBean.setTally(1);
        aHBean.setFirstOccurrence(new Date());
        aHBean.setLastOccurrence(new Date());

        sHisInsServ.insertAlarmHist(aHBean);
    }

    @Override
    public BaseResponse diagnosis(LoginSessionBean bean, int nodeId) {

        NodeModel nInfo = prop.getNodeInfoHash().get(nodeId);
        OpCmdRepo tCode = null;
        OperationHistModel opHMParam = null;

        boolean isKA = (nInfo.getNodeId() == NodeRepo.getKissA().getCode());
        boolean isKB = (nInfo.getNodeId() == NodeRepo.getKissB().getCode());
        boolean isMA = (nInfo.getNodeId() == NodeRepo.getMissA().getCode());
        boolean isMB = (nInfo.getNodeId() == NodeRepo.getMissB().getCode());
        boolean isIA = (nInfo.getNodeId() == NodeRepo.getIcssA().getCode());
        boolean isIB = (nInfo.getNodeId() == NodeRepo.getIcssB().getCode());
        boolean isSA = (nInfo.getNodeId() == NodeRepo.getSmsA().getCode());
        boolean isSB = (nInfo.getNodeId() == NodeRepo.getSmsB().getCode());

        if (prop.getActiveMode() != ACTIVE) {
            log.trace("not active");
            return new BaseResponse(ResRepo.getC400());
        }

        if (isKA || isKB || isMA || isMB) {
            tCode = OpCmdRepo.getDiagnosisMed();
            return diagnosisMed(getOpHistBean(bean, tCode, nInfo), nInfo);
        } else if (isIA || isIB) {
            tCode = OpCmdRepo.getDiagnosisIcs();
            return diagnosisIcs(getOpHistBean(bean, tCode, nInfo), nInfo);
        } else if (isSA || isSB) {
            tCode = OpCmdRepo.getDiagnosisModem();
            opHMParam = getOpHistBean(bean, tCode, nInfo);
            return smsService.diagnosis(opHMParam, nInfo, bean);
        }

        return null;
    }

    private BaseResponse diagnosisIcs(OperationHistModel histBean,
            NodeModel nodeInfo) {

        String rCode = "";
        String histAdditionalInfo = "";
        SmtIcsDiagnosisRes resData = new SmtIcsDiagnosisRes();
        String tLog = null;
        List<StatusModel> statusList = null;
        int rMode = -1;

        try {
            tLog = "{} {} diagnosisIcs";
            log.debug(tLog, nodeInfo.getName(), nodeInfo.getAddrIp());

            resData.setDefault("N");

            if (!prop.isModemSendMode()) {
                resData.setMode("대기모드");
            }

            if (nodeInfo.getName().equals(hostName)) {

                if (!recvMonitor.isRecentWithin9Seconds()) {
                    resData.setNoData("Y");
                    resData.setSendErrYn("Y");
                }

                if (recvMonitor.isRecentErrWithin9Seconds()) {
                    resData.setDataCorrupt("Y");
                }

//                if (prop.getActiveMode() == 0) {
//                    resData.setActiveMode("Standby");
//                }

            } else {

                statusList = statusConfigDao.selectStatusList();
                for (StatusModel sm : statusList) {
                    rMode = NodeUtil.getIcsStatus(hostName, sm, MODE_REMOTE);

                    if (rMode == StatusRepo.getSTANDBY().getCode()) {
                        resData.setActiveMode("Standby");
                    } else if (rMode == StatusRepo.getUNKNOWN().getCode()) {
                        resData.setActiveMode("Unknown");
                    }
                }
            }

            rCode = OpHistRltRepo.getResultSuccess().getName();
            return new BaseResponse(ResRepo.getC200(), resData);

        } catch (RuntimeException e) {
            log.warn("diagnosisIcs() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            histBean.addAddtionalInfo(histAdditionalInfo);
            insertOperationHist(histBean, rCode);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    private BaseResponse diagnosisMed(OperationHistModel histBean,
            NodeModel nodeInfo) {
        String rCode = "";
        String histAdditionalInfo = "";
        SmtMedDiagnosisRes resData = new SmtMedDiagnosisRes();
        MedReq mRBean = new MedReq();
        MedDiagnosisRes res = null;
        int pingType = 0;
        String ip = nodeInfo.getAddrIp();
        List<MedAlarmInfo> alarmList = null;
        String noDCd = null;
        String currpCd = null;

        try {

            mRBean.setOpCode(DIAGNOSIS);
            res = restClient.getMedDiagnosisReq(ip, mRBean);
            resData.setDefault("N");

            if (res == null) {
                pingType = new NetworkPingUtil(ip, medUrlPort, N100).check();

                if (pingType == N1) {
                    resData.setNetworkYn("Y");
                }

                resData.setDataCorrupt("Y");
                resData.setNoData("Y");
                rCode = OpHistRltRepo.getResultFailed().getName();
                histAdditionalInfo = "med connect failed";

                return new BaseResponse(ResRepo.getC404());
            }

            resData.setProcessYn("Y");
            resData.setNetworkYn("Y");

            setAlarmInfo(res, nodeInfo);
            alarmList = res.getAlarmList();

            if (alarmList != null) {

                for (MedAlarmInfo medAlarmInfo : alarmList) {
                    noDCd = AlarmRepo.getAlmNodata().getCode();
                    currpCd = AlarmRepo.getAlmDataCorrupt().getCode();

                    if (medAlarmInfo.getAlarmType().equals(noDCd)) {
                        resData.setNoData("Y");
                    } else if (medAlarmInfo.getAlarmType().equals(currpCd)) {
                        resData.setDataCorrupt("Y");
                    }

                }
            }

            rCode = OpHistRltRepo.getResultSuccess().getName();

            return new BaseResponse(ResRepo.getC200(), resData);

        } catch (IOException | CompletionException e) {
            log.warn("diagnosisMed() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            histBean.addAddtionalInfo(histAdditionalInfo);
            insertOperationHist(histBean, rCode);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    private void setAlarmInfo(MedDiagnosisRes res, NodeModel nodeInfo) {

        ThresholdModel param = new ThresholdModel();
        StatusHistModel sHBean = new StatusHistModel();
        List<ThresholdModel> list = null;

        boolean isCpuGreen = true;
        int cpuLevel = -1;
        boolean isMemGreen = true;
        int memLevel = -1;
        boolean isHddGreen = true;
        int hddLevel = -1;
        boolean isAppGreen = true;
        StringBuilder sb = new StringBuilder();

        boolean isC = false;
        boolean isM = false;
        boolean isH = false;
        String summary = "";
        AlarmRepo acLv = null;
        String tType = "";
        AlarmRepo acNo = AlarmRepo.getAlmNodata();
        AlarmRepo acCur = AlarmRepo.getAlmDataCorrupt();

        boolean isNodataGreen = true;
        boolean isDataCorrputGreen = true;

        List<MedAlarmInfo> alarmList = null;

        param.setNodeId(nodeInfo.getNodeId());

        sHBean.setIpAddr(nodeInfo.getAddrIp());
        sHBean.setNodeId(nodeInfo.getNodeId());
        sHBean.setNodeName(nodeInfo.getName());
        sHBean.setType1(res.getCpu() + "");
        sHBean.setType2(res.getMem() + "");
        sHBean.setType3(res.getHdd() + "");

        sHisInsServ.insertStatusHist(sHBean);

        list = statusConfigDao.selectThresholdInfo(param);

        sb.append(nodeInfo.getName() + " ");

        if ((list != null) && (!list.isEmpty())) {
            list.sort(Comparator.comparingInt(ThresholdModel::getLevel));

            for (ThresholdModel m : list) {

                isC = (m.getType() == 0);
                isM = (m.getType() == N1);
                isH = (m.getType() == N2);

                if (isC && (res.getCpu() >= m.getData())) {
                    isCpuGreen = false;
                    cpuLevel = m.getLevel();
                    sb.append(res.getCpu() + " > " + m.getData());
                    break;
                } else if (isM && (res.getMem() >= m.getData())) {
                    isMemGreen = false;
                    memLevel = m.getLevel();
                    sb.append(res.getMem() + " > " + m.getData());
                    break;
                } else if (isH && (res.getHdd() >= m.getData())) {
                    isHddGreen = false;
                    hddLevel = m.getLevel();
                    sb.append(res.getHdd() + " > " + m.getData());
                    break;
                }

            }
        }

        summary = sb.toString();
        acLv = getLevelAlarmCode(cpuLevel);
        alarmUpdate(isCpuGreen, AlarmRepo.getAlmCpu(), nodeInfo, acLv, summary);
        acLv = getLevelAlarmCode(hddLevel);
        alarmUpdate(isHddGreen, AlarmRepo.getAlmHdd(), nodeInfo, acLv, summary);
        acLv = getLevelAlarmCode(memLevel);
        alarmUpdate(isMemGreen, AlarmRepo.getAlmMem(), nodeInfo, acLv, summary);

        alarmList = res.getAlarmList();

        sb = new StringBuilder();
        sb.append(nodeInfo.getName() + " ");

        if (alarmList != null) {

            for (MedAlarmInfo medAlarmInfo : alarmList) {
                tType = medAlarmInfo.getAlarmType();

                if (tType.equals(acNo.getCode())) {
                    isNodataGreen = false;
                    sb.append(acNo.getMsg());

                } else if (tType.equals(acCur.getCode())) {
                    isDataCorrputGreen = false;
                    sb.append(acCur.getMsg());
                }

            }
        }

        summary = sb.toString();
        acLv = AlarmRepo.getSvrMin();

        alarmUpdate(isNodataGreen, acNo, nodeInfo, acLv, summary);
        alarmUpdate(isDataCorrputGreen, acCur, nodeInfo, acLv, summary);

    }

    private void alarmUpdate(boolean status, AlarmRepo code, NodeModel nodeInfo,
            AlarmRepo levelCode, String summary) {
        alarmService.alarmUpdate(status, code, nodeInfo, levelCode, summary);
    }

    private AlarmRepo getLevelAlarmCode(int level) {
        AlarmRepo ac = null;

        if (level == 0) {
            ac = AlarmRepo.getSvrCri();
        } else if (level == N1) {
            ac = AlarmRepo.getSvrMaj();
        } else if (level == N2) {
            ac = AlarmRepo.getSvrMin();
        } else {
            ac = AlarmRepo.getSvrMin();
        }

        return ac;
    }

    @Override
    public BaseResponse sawStatusList(LoginSessionBean session,
            String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OperationHistModel opHBean = null;
        String rCode = "";
        String histAdditionalInfo = "";
        OpCmdRepo cCd = OpCmdRepo.getSawStatusList();
        List<StatusModel> statusList = null;
        StatusModel statusInfo = null;
        List<NodeModel> nAlarm = null;
        List<SawInfoModel> sawList = null;
        String opMode = "0";
        List<SmtDeviceStatusRes> data = null;
        SmtDeviceStatusRes dBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<SmtDeviceStatusRes>> resData = new HashMap<>();

        opHBean = getOpHistBean(session, cCd, nInfo);

        try {

            statusList = statusConfigDao.selectStatusList();
            if ((statusList == null) || (statusList.size() == 0)) {
                rCode = OpHistRltRepo.getResultFailed().getName();
                histAdditionalInfo = ResRepo.getC508().getMsg();

                return new BaseResponse(ResRepo.getC508());
            }

            statusInfo = statusList.get(0);

            nAlarm = statusConfigDao.selectNodeAlarmStatus();
            if ((nAlarm == null) || (nAlarm.size() == 0)) {
                rCode = OpHistRltRepo.getResultFailed().getName();
                histAdditionalInfo = ResRepo.getC508().getMsg();

                return new BaseResponse(ResRepo.getC508());
            }

            sawList = statusConfigDao.selectSawList();
            if ((sawList == null) || (sawList.size() == 0)) {
                rCode = OpHistRltRepo.getResultFailed().getName();
                histAdditionalInfo = ResRepo.getC508().getMsg();

                return new BaseResponse(ResRepo.getC508());
            }

            opMode = sawList.get(0).getOperation();

            data = new ArrayList<SmtDeviceStatusRes>();

            for (NodeModel nAInfo : nAlarm) {
                dBean = new SmtDeviceStatusRes();

                dBean.setData(statusInfo, nAInfo, opMode, refPosition);
                data.add(dBean);
            }

            resData.put("list", data);
            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "device status list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("sawStatusList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());

    }

    @Override
    public BaseResponse resourceHistList(LoginSessionBean session, HashMap body,
            String remoteAddr, String operation) {

        String rCode = "";
        String histAdditionalInfo = "";
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawResourceList();

        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);
        StatusHistModel sPrm = new StatusHistModel();

        Integer pSize = null;
        Integer lSize = null;

        SmtStatusHistListRes resData = new SmtStatusHistListRes();
        List<StatusHistModel> list = null;

        int tCnt = 0;
        int tPage = 0;

        SmtStatusHistRes hBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {
            sPrm.setStartTime((String) body.get("start_time"));
            sPrm.setEndTime((String) body.get("end_time"));
            if (body.get("node_id") != null) {
                sPrm.setNodeId((Integer) body.get("node_id"));
                nInfo = prop.getNodeInfoHash().get(body.get("node_id"));
                opHBean = getOpHistBean(session, cCd, nInfo);
            }

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statusHistDao.selectStatusHistSearch(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statusHistDao.selectStatusSearchTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (StatusHistModel hist : list) {
                hBean = new SmtStatusHistRes();
                hBean.setData(hist);
                resData.getList().add(hBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "resource history list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("resourceHistList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse thresholdInfo(LoginSessionBean session, HashMap body,
            String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawThresholdList();

        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";
        ThresholdModel tPrm = new ThresholdModel();
        List<ThresholdModel> list = null;
        ArrayList<ThresholdRes> resList = new ArrayList<>();
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<ThresholdRes>> resData = new HashMap<>();
        ThresholdRes tRBean = null;

        try {

            if (body.get("node_id") != null) {
                tPrm.setNodeId((Integer) body.get("node_id"));
                nInfo = prop.getNodeInfoHash().get(body.get("node_id"));
                opHBean = getOpHistBean(session, cCd, nInfo);
            }

            list = statusConfigDao.selectThresholdInfo(tPrm);

            for (ThresholdModel tm : list) {
                tRBean = new ThresholdRes();
                tRBean.setBean(tm);
                resList.add(tRBean);

            }

            resData.put("list", resList);
            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "threshold info list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("thresholdInfo() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse thresholdUpdate(LoginSessionBean session,
            SmtThresholdSetReq body, String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = nList.get(body.getNodeId());
        OpCmdRepo cCd = OpCmdRepo.getSawThresholdUpdate();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        ThresholdModel tPrm = new ThresholdModel();
        Integer lv = null;
        Integer ty = null;
        Integer dt = null;

        try {

            tPrm.setNodeId(body.getNodeId());

            if (body.getList() == null) {
                log.trace("threshold body null");
                return new BaseResponse(ResRepo.getC204());
            }

            for (SmtThresholdReq req : body.getList()) {
                tPrm = new ThresholdModel();
                tPrm.setNodeId(body.getNodeId());

                lv = req.getLevel();
                ty = req.getType();
                dt = req.getData();

                if ((lv != null) && (ty != null) && (dt != null)) {
                    tPrm.setData(req.getData());
                    tPrm.setLevel(req.getLevel());
                    tPrm.setType(req.getType());
                    statusConfigDao.updateThresholdInfo(tPrm);

                    rtSync.insertQueue(tPrm, "UPDATE");
                }

            }

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "threshold update";

            return new BaseResponse(ResRepo.getC200());
        } catch (RuntimeException e) {
            log.warn("thresholdUpdate() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse changeMode(LoginSessionBean session, HashMap body,
            String remoteAddr, String operation) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawChangeMode();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        SawInfoModel param = new SawInfoModel();
              
        try {
            param.setSysId(hostName);
            param.setOperation((String) body.get("mode"));
            statusConfigDao.updateSawInfo(param);

            rtSync.insertQueue(param, "UPDATE");
            
            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "operation mode change update ";
            histAdditionalInfo += param.getOperation();
            
            smsService.changeOpMode();
            
            prop.readNodeSawStatus();
            
            return new BaseResponse(ResRepo.getC200());
        } catch (RuntimeException e) {
            log.warn("changeMode() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse smtOperationCmdList(LoginSessionBean session,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawOperationIdList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";
        ArrayList<OperationCodeRes> resList = new ArrayList<>();
        List<OpCmdRepo> list = OpCmdRepo.getOpOnlyCodes();
        OperationCodeRes cBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<OperationCodeRes>> resData = new HashMap<>();

        try {

            for (OpCmdRepo opCCode : list) {
                cBean = new OperationCodeRes(opCCode);
                resList.add(cBean);
            }

            resData.put("list", resList);

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "operation id list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("smtOperationCmdList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse operationHistList(LoginSessionBean session,
            HashMap body, String remoteAddr, String operation) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawOperationHistList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);
        OpCmdRepo tCd = null;
        String rCode = "";
        String histAdditionalInfo = "";
        OperationHistModel oPrm = new OperationHistModel();
        Integer pSize = null;
        Integer lSize = null;
        List<OperationHistModel> list = null;
        SmtOperationHistListRes resData = new SmtOperationHistListRes();
        int tCnt = 0;
        int tPage = 0;
        SmtOperationHistRes hBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {

            oPrm.setSt((String) body.get("start_time"));
            oPrm.setEd((String) body.get("end_time"));

            if ((body.get("cmd") != null) && (!body.get("cmd").equals(""))) {
                tCd = OpCmdRepo.fromCode((String) body.get("cmd"));
                oPrm.setOperation(tCd.getMsg());
            }

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            oPrm.setPage(pSize, lSize);

            list = nonSyncHistDao.selectOperationHistList(oPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = nonSyncHistDao.selectOperationHistTotalCount(oPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + oPrm.getRowCount() - 1) / oPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (OperationHistModel hist : list) {
                hBean = new SmtOperationHistRes();
                hBean.setData(hist);
                resData.getList().add(hBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "operation history list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("operationHistList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse emsStartHistList(LoginSessionBean session, HashMap body,
            String remoteAddr, String requestURI) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSawEmsHistList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";
        Integer pSize = null;
        Integer lSize = null;
        String tTmp = null;
        List<EmsHistModel> list = null;
        SmtEmsHistListRes resData = new SmtEmsHistListRes();
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        EmsHistModel ePrm = null;

        int tCnt = 0;
        int tPage = 0;

        SmtEmsHistRes hBean = null;

        try {

            ePrm = new EmsHistModel();

            ePrm.setSt((String) body.get("start_time"));
            ePrm.setEd((String) body.get("end_time"));

            if (body.get("type") != null) {
                tTmp = (String) body.get("type");

                if (tTmp.equals("0")) {
                    ePrm.setOperationType(EmsTypeRepo.getStart().getCode());
                } else {
                    ePrm.setOperationType(EmsTypeRepo.getStop().getCode());
                }
            }

            if (body.get("result") != null) {
                tTmp = (String) body.get("result");

                if (tTmp.equals("0")) {
                    ePrm.setOperationResult(EmsTypeRepo.getSuccess().getCode());
                } else {
                    ePrm.setOperationResult(EmsTypeRepo.getFail().getCode());
                }
            }

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            ePrm.setPage(pSize, lSize);

            list = nonSyncHistDao.selectEmsHistList(ePrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = nonSyncHistDao.selectEmsHisTotalCount(ePrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + ePrm.getRowCount() - 1) / ePrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (EmsHistModel hist : list) {
                hBean = new SmtEmsHistRes();
                hBean.setData(hist);
                resData.getList().add(hBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "ems history list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("emsStartHistList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse sendRecvCodeList(LoginSessionBean session, HashMap body,
            String remoteAddr, String requestURI) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();

        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getDataSRCmdList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        ArrayList<OperationCodeRes> resList = new ArrayList<>();
        List<STypeRepo> list = null;
        OperationCodeRes cBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        HashMap<String, List<OperationCodeRes>> resData = new HashMap<>();

        try {

            list = STypeRepo.getOpOnlyCodes();
            for (STypeRepo dsrCode : list) {
                cBean = new OperationCodeRes(dsrCode);
                resList.add(cBean);
            }

            resData.put("list", resList);

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "data send recv code list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("sendRecvCodeList()  " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse sendRecvDataHistList(LoginSessionBean session,
            HashMap body, String remoteAddr, String requestURI) {

        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getDataSRList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        int tType = 0;
        STypeRepo dsrtCd = null;
        BaseResponse resp = null;
        byte chkB = 0;

        try {

            tType = Integer.parseInt((String) body.get("id"));
            dsrtCd = STypeRepo.fromCode((byte) tType);
            chkB = dsrtCd.getCode();

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = dsrtCd.getMsg() + " history list";

            if (chkB == STypeRepo.getAirTrackCmd().getCode()) {
                resp = missService.getMcrcHistList(body);
            } else if (chkB == STypeRepo.getAdcCmd().getCode()) {
                resp = sccService.getMsgHistList(body);
            } else if (chkB == STypeRepo.getEmCmd().getCode()) {
                resp = sccService.getEmHistList(body);
            } else if (chkB == STypeRepo.getMissleCmd().getCode()) {
                resp = kissService.getKamdHistList(body);
            } else if (chkB == STypeRepo.getAdwCmd().getCode()) {
                resp = sccService.getAirDefWarnHistList(body);
            } else if (chkB == STypeRepo.getAdwArCmd().getCode()) {
                resp = sccService.getAirDefWarnAirRaidHistList(body);
            } else {
                resp = new BaseResponse(ResRepo.getC204());
            }

            return resp;

        } catch (IOException | RuntimeException e) {
            log.warn("sendRecvDataHistList() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse icsAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getIcsStatList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        Integer pSize = null;
        Integer lSize = null;
        Integer isExcel = null;

        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();
        ServerAlarmStatModel sPrm = null;

        int tCnt = 0;
        int tPage = 0;

        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        isExcel = (Integer) body.get("is_excel");

        if ((isExcel != null) && (isExcel == 1)) {
            cCd = OpCmdRepo.getIcsStatListExcel();
            opHBean = getOpHistBean(session, cCd, nInfo);
        }

        try {

            sPrm = new ServerAlarmStatModel();

            sPrm.setSt((String) body.get("start_time"));
            sPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statDao.selectIcssAlarmStatList(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectIcssAlarmStatTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getIcssA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "ics stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("icsAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse misAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getMisStatList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        ServerAlarmStatModel sPrm = new ServerAlarmStatModel();
        Integer pSize = null;
        Integer lSize = null;
        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();

        int tCnt = 0;
        int tPage = 0;
        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {

            sPrm.setSt((String) body.get("start_time"));
            sPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statDao.selectMissAlarmStatList(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectMissAlarmStatTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getMissA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "mis stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("misAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse kisAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getKisStatList();

        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        Integer pSize = null;
        Integer lSize = null;

        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();

        int tCnt = 0;
        int tPage = 0;

        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());
        ServerAlarmStatModel sPrm = null;

        try {

            sPrm = new ServerAlarmStatModel();
            sPrm.setSt((String) body.get("start_time"));
            sPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statDao.selectKissAlarmStatList(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectKissAlarmStatTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getKissA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "kis stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("kisAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse modemAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getModemStatList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        ServerAlarmStatModel sPrm = new ServerAlarmStatModel();

        Integer pSize = null;
        Integer lSize = null;
        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();
        int tCnt = 0;
        int tPage = 0;
        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {

            sPrm.setSt((String) body.get("start_time"));
            sPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statDao.selectModemAlarmStatList(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectModemAlarmStatTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getSmsA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "modem stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("modemAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse switchAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getSwitchStatList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";

        ServerAlarmStatModel sAPrm = new ServerAlarmStatModel();

        Integer pSize = null;
        Integer lSize = null;
        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();

        int tCnt = 0;
        int tPage = 0;

        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {

            sAPrm.setSt((String) body.get("start_time"));
            sAPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sAPrm.setPage(pSize, lSize);

            list = statDao.selectSwitchAlarmStatList(sAPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectSwitchAlarmStatTotalCount(sAPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sAPrm.getRowCount() - 1) / sAPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getSwitchA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "switch stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("switchAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @Override
    public BaseResponse routerAlarmStat(LoginSessionBean session, HashMap body,
            String remoteAddr) {
        HashMap<Integer, NodeModel> nList = prop.getNodeInfoHash();
        NodeModel nInfo = NodeUtil.getNodeInfoP(hostName, nList);
        OpCmdRepo cCd = OpCmdRepo.getRouterStatList();
        OperationHistModel opHBean = getOpHistBean(session, cCd, nInfo);

        String rCode = "";
        String histAdditionalInfo = "";
        ServerAlarmStatModel sPrm = new ServerAlarmStatModel();

        Integer pSize = null;
        Integer lSize = null;

        List<ServerAlarmStatModel> list = null;
        SmtStatListRes resData = new SmtStatListRes();

        int tCnt = 0;
        int tPage = 0;

        SmtStatRes sBean = null;
        BaseResponse resp = new BaseResponse(ResRepo.getC200());

        try {

            sPrm.setSt((String) body.get("start_time"));
            sPrm.setEd((String) body.get("end_time"));

            pSize = (Integer) body.get("page");
            lSize = (Integer) body.get("list_size");

            sPrm.setPage(pSize, lSize);

            list = statDao.selectRouterAlarmStatList(sPrm);

            if ((list != null) && (list.size() > 0)) {
                tCnt = statDao.selectRouterAlarmStatTotalCount(sPrm);
                resData.setTotalCount(tCnt);
                tPage = (tCnt + sPrm.getRowCount() - 1) / sPrm.getRowCount();
                resData.setTotalPage(tPage);
            }

            for (ServerAlarmStatModel hist : list) {
                sBean = new SmtStatRes();
                sBean.setData(hist, NodeRepo.getRouterA());
                resData.getList().add(sBean);
            }

            resp.setData(resData);

            rCode = OpHistRltRepo.getResultSuccess().getName();
            histAdditionalInfo = "router stat list";

            return resp;
        } catch (RuntimeException e) {
            log.warn("routerAlarmStat() " + e.toString());
            rCode = OpHistRltRepo.getResultFailed().getName();
            histAdditionalInfo = e.toString();
        } finally {
            insertOperationHist(opHBean, rCode, histAdditionalInfo);
        }

        return new BaseResponse(ResRepo.getC999());
    }
}
