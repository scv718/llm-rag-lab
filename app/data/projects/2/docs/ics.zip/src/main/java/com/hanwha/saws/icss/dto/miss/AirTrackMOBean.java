/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.miss;

import java.io.IOException;
import java.nio.ByteBuffer;
import lombok.Data;

@Data
public class AirTrackMOBean {

    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N5 = 5;
    private static final int N6 = 6;
    private static final int N8 = 8;
    private static final int N9 = 9;
    private static final int N12 = 12;
    private static final int N14 = 14;
    private static final int N16 = 16;
    private static final int B00 = 0x00;
    private static final int B07 = 0x07;
    private static final int B08 = 0x08;
    private static final int B09 = 0x09;
    private static final int B0A = 0x0A;
    private static final int B0B = 0x0B;
    private static final int B0C = 0x0C;
    private static final int B0D = 0x0D;
    private static final int B0E = 0x0E;
    private static final int B0F = 0x0F;
    private static final int B10 = 0x10;
    private static final int B11 = 0x11;
    private static final int B12 = 0x12;
    private static final int B13 = 0x13;
    private static final int B14 = 0x14;
    private static final int B15 = 0x15;
    private static final int B16 = 0x16;
    private static final int B17 = 0x17;
    private static final int B18 = 0x18;
    private static final int B19 = 0x19;
    private static final int B1A = 0x1A;
    private static final int B1B = 0x1B;
    private static final int B1C = 0x1C;
    private static final int B1D = 0x1D;
    private static final int B1E = 0x1E;
    private static final int B1F = 0x1F;
    private static final int BFF = 0xFF;
    private static final int B0FFF = 0x0FFF;
    private static final int BFFFF = 0xFFFF;
    private static final double DP2 = 0.01;
    
    private static final int MO_SIZE = 11;
    private static final int MO_MAX_CNT = 5;

    private static final int SIM_MO_SIZE = 28;
    private static final int SIM_MO_MAX_CNT = 2;

    private final static String[] IDENTITY_STR = {
            "P", "U", "H", "F", "I", "A", "T",
            "S", "K", "N", "R", "C", "J"
    };

    boolean isSimulData = false;
    private byte mix1;
    private byte[] trackNumber = new byte[N3];
    private byte mix2;

    private byte[] position = new byte[N3];
    private byte xVelocity;
    private byte yVelocity;
    private byte altitude;

    private int refPosition = 0;
    private int simLiveState = 0;
    private int flightSize = 0;
    private int identity = 0;
    private int xPosition = 0;
    private int yPosition = 0;

    double longitude = 0L;
    double latitude = 0L;
    short speed = 0;
    short course = 0;

    private int amplication;
    private int simulation;
         
    public void decode(ByteBuffer buf, boolean isSimul) throws IOException {
        this.isSimulData = isSimul;
        trackNumber = isSimulData ? new byte[N5] : new byte[N3];
        mix1 = buf.get();
        buf.get(trackNumber);
        mix2 = buf.get();

        refPosition = ((mix1 & 0xff) & B0F);
        simLiveState = (mix1 >>> N4) & B0F;
        flightSize = mix2 & B0F;
        identity = ((mix2 & 0xff) >>> N4) & B0F;

        if (simLiveState != N2) {
            
            buf.get(position);
            xVelocity = buf.get();
            yVelocity = buf.get();
        } else {
            
            longitude = buf.getDouble();
            latitude = buf.getDouble();
            speed = buf.getShort();
            course = buf.getShort();
        }
        
        altitude = buf.get();
        
        if (simLiveState != N2) {
            setXYPostion(position);
        }
    }

    public byte[] encode() throws IOException {
        ByteBuffer byteB =  null;
        
        if (simLiveState != N2) {
            
            byteB = ByteBuffer.allocate(MO_SIZE);
            
            byteB.put(mix1); 
            byteB.put(trackNumber);
            byteB.put(mix2); 
            byteB.put(position);
            byteB.put(xVelocity);
            byteB.put(yVelocity);
            byteB.put(altitude);
            
            return byteB.array();
            
        } else {
            
            byteB = ByteBuffer.allocate(SIM_MO_SIZE);
            
            byteB.put(mix1); 
            byteB.put(trackNumber);
            byteB.put(mix2); 
            byteB.putDouble(longitude);
            byteB.putDouble(latitude);
            byteB.putShort(speed);
            byteB.putShort(course);
            byteB.put(altitude);
            
            return byteB.array();
        }
    }

    private void setXYPostion(byte[] b) {
        int part1 = (BFF & b[N0]) << N16;
        int part2 = (BFF & b[N1]) << N8;
        int part3 = BFF & b[N2];

        int rValue = (part1 | part2 | part3);
        
        this.xPosition = rValue & B0FFF;
        this.yPosition = (rValue >>> N12) & B0FFF;
    }
   
    public String getTrackNumberStr() {
        return (isSimulData ? new String(trackNumber) : getPTNo(trackNumber));
    }

    private String getPTNo(byte[] b) {

        int[] trackNumbers = new int[N5];

        StringBuilder sb = new StringBuilder();

        int part1 = (BFF & b[N0]) << N16;
        int part2 = (BFF & b[N1]) << N8;
        int part3 = BFF & b[N2];

        int rValue = (part1 | part2 | part3);

        trackNumbers[N0] = (rValue >>> N14) & B1F;
        trackNumbers[N1] = (rValue >>> N9) & B1F;
        trackNumbers[N2] = (rValue >>> N6) & B07;
        trackNumbers[N3] = (rValue >>> N3) & B07;
        trackNumbers[N4] = rValue & B07;

        for (int track : trackNumbers) {
            sb.append(getAlphanumeric(track));
        }
        return sb.toString();

    }

    private String getAlphanumeric(int number) {
        String result = null;
        
        if ((number >= B00) && (number <= B07)) {

            result = Integer.toString(number);

        } else if ((number > B07) && (number <= B1F)) {

            switch (number) {
                case B08: 
                    result = "A";
                    break;
                case B09:
                    result = "B";
                    break;
                case B0A:
                    result = "C";
                    break;
                case B0B:
                    result = "D";
                    break;
                case B0C:
                    result = "E";
                    break;
                case B0D:
                    result = "F";
                    break;
                case B0E:
                    result = "G";
                    break;
                case B0F:
                    result = "H";
                    break; // skip "I"
                case B10:
                    result = "J";
                    break;
                case B11:
                    result = "K";
                    break;
                case B12:
                    result = "L";
                    break;
                case B13:
                    result = "M";
                    break;
                case B14:
                    result = "N";
                    break; // skip "O"
                case B15:
                    result = "P";
                    break;
                case B16:
                    result = "Q";
                    break;
                case B17:
                    result = "R";
                    break;
                case B18:
                    result = "S";
                    break;
                case B19:
                    result = "T";
                    break;
                case B1A:
                    result = "U";
                    break;
                case B1B:
                    result = "V";
                    break;
                case B1C:
                    result = "W";
                    break;
                case B1D:
                    result = "X";
                    break;
                case B1E:
                    result = "Y";
                    break;
                case B1F:
                    result = "Z";
                    break;
                default:
                    break;
            }
            
        }
        
        return result;
    }

//    public String getIdentityStr() {
//        return IDENTITY_STR[identity];
//    }

//    public int getXVelocityInt() {
//        return xVelocity;
//    }

//    public int getYVelocityInt() {
//        return yVelocity;
//    }

    public int getAltitudeInt() {
        return altitude & BFF;

    }

}
