/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.dao.local;

import java.util.List;

import com.hanwha.saws.icss.persistence.model.AlarmHistModel;
import com.hanwha.saws.icss.persistence.model.CurrAlarmModel;

public interface AlarmDao {

    public List<CurrAlarmModel> selectCurrentAlarmList();

    public void insertAlarmHistInsert(AlarmHistModel param);

    public List<CurrAlarmModel> selectCurrentAlarmInfo(CurrAlarmModel param);

    public List<CurrAlarmModel> selectCurrentAlarmDeviceInfo(
            CurrAlarmModel param);

    public void updateCurrentAlarmTally(CurrAlarmModel param);

    public void updateAlarmHistTally(CurrAlarmModel param);

    public void insertCurrentAlarm(CurrAlarmModel param);

    public void deleteCurrentAlarm(CurrAlarmModel param);

    public List<CurrAlarmModel> selectCurrentAlarmSearch(CurrAlarmModel param);
    
    public List<CurrAlarmModel>
            selectCurrentAlarmSearchDate(CurrAlarmModel param);

    public List<CurrAlarmModel> selectCurrAlarmMsgSearch(CurrAlarmModel param);
    
    public List<AlarmHistModel> selectAlarmHistSearch(AlarmHistModel param);

    public int selectAlarmHistSearchTotalCount(AlarmHistModel param);

}
