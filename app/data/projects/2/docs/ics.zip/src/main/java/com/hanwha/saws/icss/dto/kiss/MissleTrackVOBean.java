/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.kiss;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;

import com.hanwha.saws.icss.persistence.model.KamdSimulModel;
import com.hanwha.saws.icss.util.HexByteUtil;

import lombok.Data;

@Data
public class MissleTrackVOBean {
    private static final int N2 = 2;
    private static final int N4 = 4;
    private static final int B01 = 0x01;
    private static final int BFF = 0xFF;
    private static final int B3FFF = 0x3FFF;
    private static final int N23 = 23;
    private static final int N15 = 15;
    private static final int N16 = 16;
    private static final int N8 = 8;
    private static final double D001 = 0.01;
    

    private static final int B_LEN3 = 3;
    private static final int B_LEN5 = 5;

    private static final int VO_SIZE = 53;
    private static final int SIMULATION_CODE = 1;

    private byte[] trackNumber = new byte[B_LEN5];
    private int impactTime;
    private byte[] impactLocLatitude = new byte[B_LEN3];
    private byte[] impactLocLongitude = new byte[B_LEN3];

    private float impactAltitude;
    private int launchTime;
    private byte[] launchLocLatitude = new byte[B_LEN3];
    private byte[] launchLocLongitude = new byte[B_LEN3];
    private float launchAltitude;
    private byte[] missileLocLatitude = new byte[B_LEN3];
    private byte[] missileLocLongitude = new byte[B_LEN3];
    private float missileAltitude;
    private byte[] velocityCourse = new byte[B_LEN3];
    private byte[] velocitySpeed = new byte[B_LEN3];
    private short type;
    private byte mix1;
    private byte cudm;

    private int amplication;
    private int simulation;
    
    public void decode(ByteBuffer buffer) throws IOException {

        byte apLoc = 0x7F;
        byte simLoc = 0x01;

        buffer.get(trackNumber);
        impactTime = buffer.getInt();
        buffer.get(impactLocLatitude);
        buffer.get(impactLocLongitude);
        impactAltitude = buffer.getFloat();
        launchTime = buffer.getInt();
        buffer.get(launchLocLatitude);
        buffer.get(launchLocLongitude);
        launchAltitude = buffer.getFloat();
        buffer.get(missileLocLatitude);
        buffer.get(missileLocLongitude);
        missileAltitude = buffer.getFloat();
        buffer.get(velocityCourse);
        buffer.get(velocitySpeed);
        type = buffer.getShort();
        mix1 = buffer.get();
        cudm = buffer.get();
        amplication = ((mix1 & 0xff) >>> 1) & (apLoc & 0xff);
        simulation = (mix1 & 0xff) & (simLoc & 0xff);
    }

    public byte[] encode() throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.allocate(VO_SIZE);
        
        byteBuffer.put(trackNumber);
        byteBuffer.putInt(impactTime);
        byteBuffer.put(impactLocLatitude);
        byteBuffer.put(impactLocLongitude);
        byteBuffer.putFloat(impactAltitude);
        byteBuffer.putInt(launchTime);
        byteBuffer.put(launchLocLatitude);
        byteBuffer.put(launchLocLongitude);
        byteBuffer.putFloat(launchAltitude);
        byteBuffer.put(missileLocLatitude);
        byteBuffer.put(missileLocLongitude);
        byteBuffer.putFloat(missileAltitude);
        byteBuffer.put(velocityCourse);
        byteBuffer.put(velocitySpeed);
        byteBuffer.putShort(type);
        byteBuffer.put(mix1);
        byteBuffer.put(cudm);
        return byteBuffer.array();
    }

    public byte[] getSimulEncode(KamdSimulModel model) throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.allocate(VO_SIZE);
        
        byteBuffer.put(model.getKamdCode().getBytes());
        byteBuffer.putInt(impactTime);
        byteBuffer.put(encodeLatLng(model.getKamdLocationYEnd()));
        byteBuffer.put(encodeLatLng(model.getKamdLocationXEnd()));
        impactAltitude = 0;
        byteBuffer.putFloat(impactAltitude);
        byteBuffer.putInt(launchTime);
        byteBuffer.put(encodeLatLng(model.getKamdLocationYStart()));
        byteBuffer.put(encodeLatLng(model.getKamdLocationXStart()));
        launchAltitude = 0;
        byteBuffer.putFloat(launchAltitude);
        byteBuffer.put(encodeLatLng(model.getKamdLocationY()));
        byteBuffer.put(encodeLatLng(model.getKamdLocationX()));
        byteBuffer.putFloat(Float.parseFloat(model.getKamdFeet()));
        byteBuffer.put(encodeVelocity(model.getKamdDirection()));
        byteBuffer.put(encodeVelocity(model.getKamdKnot()));

        byteBuffer.putShort((short) 0x0000);
        amplication = 0;
        mix1 = (byte) ((this.amplication << 1) | (SIMULATION_CODE & 0x01));
        byteBuffer.put(mix1);
        byteBuffer.put((byte) 0x00);
        
        return byteBuffer.array();

    }

    public static byte[] encodeVelocity(String vel)
            throws IllegalArgumentException {
        try {

            int dotP = vel.indexOf(".");

            String intP = (dotP > 0) ? vel.substring(0, dotP) : vel;
            String decP = (dotP > 0) ? vel.substring(dotP + 1) : "0";
            short val1 = Short.parseShort(intP);
            byte val2 = 0;
            String tmp = "";
            int rValue = 0;
            int tBMaxLen = 0xFFFF;
            int oBMaxLen = 0xFF;
            int locLen8 = N8;
            int locLen16 = N16;
            int len2 = N2;
            byte b1 = 0;
            byte b2 = 0;
            byte b3 = 0;

            if ((decP.length() >= len2)) {
                tmp = decP.substring(0, len2);
            } else {
                tmp = decP + "0".repeat(len2 - decP.length());
            }

            val2 = Byte.parseByte(tmp);

            rValue = ((tBMaxLen & val1) << locLen8) | (oBMaxLen & val2);

            b1 = (byte) ((rValue >>> locLen16) & oBMaxLen);
            b2 = (byte) ((rValue >>> locLen8) & oBMaxLen);
            b3 = (byte) (rValue & oBMaxLen);

            return new byte[] { b1, b2, b3 };

        } catch (NumberFormatException e) {

            throw new IllegalArgumentException("Invalid input vel: " + vel, e);
        }
    }

    public static byte[] encodeLatLng(String position)
            throws IllegalArgumentException {

        int dotP = -1;
        String intPart = null;
        String decPart = null;
        int val1 = 0;
        int val2 = 0;
        int symbol = 0;
        int rValue = 0;
        String tmp = null;
        int a0 = 0;
        int a1 = 0;
        int a2 = 0;
        byte[] rt = null;
        byte b0 = 0;
        byte b1 = 0;
        byte b2 = 0;
        
        try {
            
            dotP = position.indexOf(".");
            intPart = (dotP > 0) ? (position.substring(0, dotP)) : position;
            decPart = (dotP > 0) ? (position.substring(dotP + 1)) : "";

            val1 = Integer.parseInt(intPart);
            symbol = ((val1 < 0) ? 1 : 0);

            if (decPart.isEmpty()) {
                val2 = 0;
            } else {
                if (decPart.length() >= N4) {
                    val2 = Integer.parseInt(decPart.substring(0, N4));
                } else {
                    tmp = String.format("%-4s", decPart).replace(' ', '0');
                    val2 = Integer.parseInt(tmp);
                }
            }

            a0 = ((B01 & symbol) << N23);
            a1 = ((BFF & Math.abs(val1)) << N15);
            a2 = ((B3FFF & val2) << 1);
            
            rValue = a0 | a1 | a2;
            
            b0 = (byte) ((rValue >>> N16) & BFF);
            b1 = (byte) ((rValue >>> N8) & BFF);
            b2 = (byte) (rValue & BFF);

            rt = new byte[] { b0, b1, b2 };
            
            return rt;
            
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("err position: " + position, e);
        }
    }

    public String getTrackNumberString() {
        return new String(trackNumber);
    }

//    public String getTrackNumberHexString() {
//        return HexByteUtil.getByteArrayToHexString(trackNumber);
//    }

//    public double getImpactLocLatitudeDouble() {
//        return getLatLngDecode(impactLocLatitude);
//    }

//    public String getImpactLocLatitudeStr() {
//        return String.format("%.4f", getLatLngDecode(impactLocLatitude));
//    }

//    public double getImpactLocLongitudeDouble() {
//        return getLatLngDecode(impactLocLongitude);
//    }

//    public String getImpactLocLongitudeStr() {
//        return String.format("%.4f", getLatLngDecode(impactLocLongitude));
//    }

//    public double getLaunchLocLatitudeDouble() {
//        return getLatLngDecode(launchLocLatitude);
//    }

//    public String getLaunchLocLatitudeStr() {
//        return String.format("%.4f", getLatLngDecode(launchLocLatitude));
//    }

//    public double getLaunchLocLongitudeDouble() {
//        return getLatLngDecode(launchLocLongitude);
//    }

//    public String getLaunchLocLongitudeStr() {
//        return String.format("%.4f", getLatLngDecode(launchLocLongitude));
//    }

//    public double getMissileLocLatitudeDouble() {
//        return getLatLngDecode(missileLocLatitude);
//    }

    public String getMissileLocLatitudeStr() {
        return String.format("%.4f", getLatLngDecode(missileLocLatitude));
    }

//    public double getMissileLocLongitudeDouble() {
//        return getLatLngDecode(missileLocLongitude);
//    }

    public String getMissileLocLongitudeStr() {
        return String.format("%.4f", getLatLngDecode(missileLocLongitude));
    }

    // 해석은 최하단 [note 3] 주석 참조
//    public double getVelocityCourseDouble() {
//        return getVelocityDecode(velocityCourse);
//    }

    public String getVelocityCourseStr() {
        BigDecimal v = BigDecimal.valueOf(getVelocityDecode(velocityCourse));
        String result = v.setScale(0, RoundingMode.DOWN).toPlainString();
        
        return result;
    }

//    public double getVelocitySpeedDouble() {
//        return getVelocityDecode(velocitySpeed);
//    }

    public String getVelocitySpeedStr() {
        return String.format("%.2f", getVelocityDecode(velocitySpeed));
    }

    public int getCudmInt() {
        return cudm;
    }

    private double getVelocityDecode(byte[] b) {

        int len8 = N8;
        int len1 = 1;
        int len2 = N2;
        int oMaxLen = 0xFF;
        double dp2 = D001;

        short integerPart = (short) ((b[0] << len8) | (b[len1] & oMaxLen));
        double decimalPart = (b[len2] & oMaxLen) * dp2;

        return integerPart + decimalPart;

    }

    private double getLatLngDecode(byte[] b) {

        final int len16 = 16;
        final int len1 = 1;
        final int len2 = 2;
        final int len15 = 15;
        final int len23 = 23;
        final int oMaxLen = 0xFF;
        final int tMaxLen = 0x3FFF;
        final int oMinLen = 0x01;
        final double dp4 = 0.0001;

        int part1 = (oMaxLen & b[0]) << len16;
        int part2 = (oMaxLen & b[len1]) << N8;
        int part3 = oMaxLen & b[len2];
        int rValue = part1 | part2 | part3;
        int symbol = (((rValue >>> len23) & oMinLen) == 1) ? -1 : 1;
        double decodeIntegerPlace = ((rValue >>> len15) & oMaxLen);
        double decodeDecimalPlace = (((rValue >>> 1) & tMaxLen) * dp4);

        return symbol * (decodeIntegerPlace + decodeDecimalPlace);
    }

}
