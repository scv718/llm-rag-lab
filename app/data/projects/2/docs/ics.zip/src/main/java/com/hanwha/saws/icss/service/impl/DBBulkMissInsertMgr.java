/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hanwha.saws.icss.persistence.dao.local.McrcHistDao;
import com.hanwha.saws.icss.persistence.model.FileSaveIf;
import com.hanwha.saws.icss.persistence.model.McrcHistModel;
import com.hanwha.saws.icss.service.IcsSyncService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DBBulkMissInsertMgr {

    private static final int N50 = 50;

    @Value("${ics.failover-dir.mcrc}")
    String mcrcSyncFailDir;

    @Autowired
    @Qualifier("missBulkQueue")
    private ConcurrentLinkedQueue<McrcHistModel> missBulkQueue;

    @Autowired
    @Qualifier("missFileQueue")
    private ConcurrentLinkedQueue<McrcHistModel> missFileQueue;

    @Autowired McrcHistDao mcrcHistDao;
    @Autowired IcsSyncService syncService;
    
    ArrayList<McrcHistModel> bulkList = new ArrayList<>();

    @Scheduled(fixedDelayString = "300", initialDelayString = "3000")
    public void monitor() {
        McrcHistModel model = null;
        int bSize = 0;
        int qSize = 0;

        bulkList.clear();
        
        try {
            while (!missBulkQueue.isEmpty()) {
                model = missBulkQueue.poll();
                MDC.put("LOG_KEY", model.getLogKInfo());
                log.debug("AirTrack File Queue Insert");
                missFileQueue.offer(model);
                bulkList.add(model);

                bSize = bulkList.size();
                qSize = missBulkQueue.size();

                if ((bSize > N50) || (qSize == 0)) {
                    mcrcHistDao.insertMcrcHistBulkInsert(bulkList);

                    syncMissHist(bulkList);
                    bulkList.clear();
                }
            }

        } catch (RuntimeException e) {
            log.warn("missBulkInsertThread " + e.toString());
            bulkList.clear();
        }
    }

    private void syncMissHist(ArrayList<McrcHistModel> bulkList) {
        try {
            syncService.syncMcrcHistBulkInsert(bulkList);
        } catch (RuntimeException e) {
            log.warn("syncMissHist() " + e.toString() + ": filesave");
            makeSyncMissFile(bulkList);

        }
    }

    private void makeSyncMissFile(ArrayList<McrcHistModel> bulkList) {

        DateTimeFormatter fmter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dStr = fmter.format(LocalDateTime.now());
        String dirPath = mcrcSyncFailDir + "/" + dStr;

        try {

            if (!Files.exists(Paths.get(dirPath))) {
                Files.createDirectories(Paths.get(dirPath));
            }

        } catch (IOException | RuntimeException e) {
            log.warn("makeSyncMissFile() createFile/Dir " + e.toString());
        }

        try (ObjectOutputStream os = new ObjectOutputStream(
                new FileOutputStream(dirPath + "/" + UUID.randomUUID()))) {
            os.writeObject(bulkList);

        } catch (IOException | RuntimeException e2) {
            log.warn("makeSyncMcrcFile write " + e2.toString());
        }
    }

}
