/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.hanwha.saws.icss.dto.request.SccStatusReq;

import lombok.Data;

@Data
public class McrcHistDetailModel implements Serializable {
    
    private static final int N100 = 100;
    private static final int N1000 = 1000;
    
    private Timestamp insertTime;
    private long seqNo;
    private int simulMode;
    private String trackNumberEnc;
    private byte[] trackNumberHash;
    private String identityEnc;
    private byte[] identityHash;
    private String flightSizeEnc;
    private byte[] flightSizeHash;
    private BigDecimal speed;
    private BigDecimal direction;
    private float altitude;
    private String latitudeEnc;
    private byte[] latitudeHash;
    private String longitudeEnc;
    private byte[] longitudeHash;
    
    private String st;
    private String ed;
    
    private Integer speedSt;
    private Integer speedEd;
    private Integer attSt;
    private Integer attEd;
    private Integer dfSt;
    private Integer dfEd;
    
    private int idx;
    private int rowCount;
    private int startIdx;
    
    public void setPage(Integer page, Integer listCount) {
        
        if (page == null || page == 0) {
            page = 1;
        }
        
        if (listCount == null || listCount == 0) {
            listCount = N100;
        }
        
        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }
    
//    public void setTime() {
//        LocalDateTime now = LocalDateTime.now();
//        
//        now = now.plusNanos(System.nanoTime() % N1000); // 미세한 차이 추가
//        insertTime = Timestamp.valueOf(now);
//    }

    public void setSpeedStr(String speedStr) {
        if (speedStr == null || speedStr.isBlank()) {
            speed = null;        
        }
        speed = new BigDecimal(speedStr);
    }
    
    public void setDirectionStr(String dirStr) {
        if (dirStr == null || dirStr.isBlank()) {
            direction = null;        
        }
        direction = new BigDecimal(dirStr);
    }
    
    public void setDetailParam(SccStatusReq body, String uk, int pSize,
            int lSize) throws InvalidKeyException, NoSuchAlgorithmException {
        st = body.getStartTime();
        ed = body.getEndTime();
        setPage(pSize, lSize);
        speedSt = body.getSpeedSt();
        speedEd = body.getSpeedEd();
        attSt = body.getAttSt();
        attEd = body.getAttEd();
        dfSt = body.getDfSt();
        dfEd = body.getDfEd();

        if (body.getIdentity() != null) {
            identityHash = hmacSha256(body.getIdentity() + "", uk);
        }
        if (body.getTrackNumber() != null) {
            trackNumberHash = hmacSha256(body.getTrackNumber(), uk);
        }
    }
    
    private byte[] hmacSha256(String data, String key)
            throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] rawHmac = null;

        mac.init(new SecretKeySpec(key.getBytes(), "HmacSHA256"));
        rawHmac = mac.doFinal(data.getBytes());

        return rawHmac;
    }
}
