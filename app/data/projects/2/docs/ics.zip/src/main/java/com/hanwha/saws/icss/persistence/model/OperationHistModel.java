/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.sql.Timestamp;
import java.util.Date;

import lombok.Data;

@Data
public class OperationHistModel {
    private static final int N1000 = 1000;
    private static final int N10 = 10;
    
    private int idx;
    private long seqNo;
    private String userId;
    private String userName;
    private String userIp;
    private String operation;
    private String operationResult;
    private String additionalInfo;
    private Date startTime;
    private Date endTime;
    private Timestamp insertTime;

    private String st;
    private String ed;

    private int rowCount;
    private int startIdx;

    public void setPage(Integer page, Integer listCount) {
        
        if (page == null || page == 0) {
            page = 1;
        }

        if (listCount == null || listCount == 0) {
            listCount = N10;
        }

        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }

    public void addAddtionalInfo(String msg) {
        StringBuilder sb = null;
        String tmp = null;

        if (additionalInfo == null) {
            additionalInfo = msg;

        } else {
            sb = new StringBuilder();

            sb.append(additionalInfo);
            sb.append(" ");
            sb.append(msg);
            tmp = sb.toString();

            if (tmp.length() > N1000) {
                tmp = tmp.substring(0, N1000);
            }

            additionalInfo = tmp;
        }

    }
}
