/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.util;

import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.nbware.aria.magiccrypto.MagicCryptoUtil;

public class DataCrypt {

    private static final int IVLEN = 16;

//    static {
//        Security.addProvider(new BouncyCastleProvider());
//    }

//    public String encrypt(byte[] message, String key)
//            throws GeneralSecurityException {
//        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "ARIA");
//        Cipher cipher = Cipher.getInstance("ARIA/CBC/PKCS5Padding", "BC");
//        byte[] ivBytes = new byte[IVLEN];
//        byte[] encrypted = null;
//        ByteBuffer buffer = null;
//
//        new SecureRandom().nextBytes(ivBytes);
//        cipher.init(Cipher.ENCRYPT_MODE, keySpec, 
//                    new IvParameterSpec(ivBytes));
//
//        encrypted = cipher.doFinal(message);
//        buffer = ByteBuffer.allocate(IVLEN + encrypted.length);
//        buffer.put(ivBytes);
//        buffer.put(encrypted);
//
//        return Base64.getEncoder().encodeToString(buffer.array());
//    }

    public String encrypt(byte[] message, String key) 
            throws RuntimeException {

        // 1. IV 생성 (기존과 동일)
        byte[] iv = new byte[IVLEN];
        
        byte[] cipher = null;
        
        ByteBuffer buffer = null;
        
        new SecureRandom().nextBytes(iv);

        // 2. MagicCrypto 암호화 수행
        cipher = MagicCryptoUtil.encrypt(key.getBytes(), iv, message);

        // 3. 기존 포맷처럼 IV + CIPHER 를 Base64로 반환
        buffer = ByteBuffer.allocate(IVLEN + cipher.length);
        buffer.put(iv);
        buffer.put(cipher);

        return Base64.getEncoder().encodeToString(buffer.array());
    }
    
    public byte[] decrypt(String encrypted, String key)
            throws RuntimeException {

        // 1. Base64 decode
        byte[] decode = Base64.getDecoder().decode(encrypted);
        
        ByteBuffer buf = null;
        
        byte[] iv = null;
        
        byte[] cipher = null;

        if (decode.length < IVLEN) {
            //throw new RuntimeException("Invalid too short for IV");
            throw new IllegalArgumentException("Invalid too short for IV");
        }

        buf = ByteBuffer.wrap(decode);

        // 2. IV 추출
        iv = new byte[IVLEN];
        buf.get(iv);

        // 3. Cipher 추출
        cipher = new byte[buf.remaining()];
        buf.get(cipher);

        // 4. MagicCrypto 복호화
        return MagicCryptoUtil.decrypt(key.getBytes(), iv, cipher);
    }    
    
//    
//    public byte[] decrypt(String encrypted, String key)
//            throws GeneralSecurityException {
//        byte[] decode = Base64.getDecoder().decode(encrypted);
//        ByteBuffer buf = null;
//        byte[] ivBytes = new byte[IVLEN];
//        byte[] cipherBytes = null;
//        byte[] original = null;
//
//        SecretKeySpec skeySp = new SecretKeySpec(key.getBytes(), "ARIA");
//        Cipher cipher = Cipher.getInstance("ARIA/CBC/PKCS5Padding", "BC");
//
//        if (decode.length < IVLEN) {
//            throw new GeneralSecurityException("Invalid too short for IV");
//        }
//
//        buf = ByteBuffer.wrap(decode);
//        buf.get(ivBytes);
//
//        cipherBytes = new byte[buf.remaining()];
//        buf.get(cipherBytes);
//
//        cipher.init(Cipher.DECRYPT_MODE, skeySp,
//                    new IvParameterSpec(ivBytes));
//        original = cipher.doFinal(cipherBytes);
//
//        return original;
//
//    }
    
////  암호화 (CBC/NoPadding) - 벡터 검증용
//    public static byte[] encryptCbcNoPadding(byte[] plain, byte[] key,
//            byte[] iv) throws GeneralSecurityException {
//        SecretKeySpec skeySpec = new SecretKeySpec(key, "ARIA");
//        Cipher cipher = Cipher.getInstance("ARIA/CBC/NoPadding", "BC");
//        IvParameterSpec ivSpec = new IvParameterSpec(iv);
//
//        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivSpec);
//
//        return cipher.doFinal(plain);
//    }
//
////    복호화 (CBC/NoPadding) - 벡터 검증용     
//    public static byte[] decryptCbcNoPadding(byte[] cipherText, byte[] key,
//            byte[] iv) throws GeneralSecurityException {
//        SecretKeySpec skeySpec = new SecretKeySpec(key, "ARIA");
//        Cipher cipher = Cipher.getInstance("ARIA/CBC/NoPadding", "BC");
//        IvParameterSpec ivSpec = new IvParameterSpec(iv);
//
//        cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivSpec);
//
//        return cipher.doFinal(cipherText);
//    }

}
