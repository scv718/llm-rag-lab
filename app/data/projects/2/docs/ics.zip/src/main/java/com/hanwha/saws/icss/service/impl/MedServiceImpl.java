/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.code.AlarmRepo;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.request.MedAlarmReq;
import com.hanwha.saws.icss.dto.request.MedReq;
import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.dao.local.StatusConfigDao;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.StatusHistModel;
import com.hanwha.saws.icss.persistence.model.StatusModel;
import com.hanwha.saws.icss.persistence.model.ThresholdModel;
import com.hanwha.saws.icss.service.AlarmService;
import com.hanwha.saws.icss.service.MedService;
import com.hanwha.saws.icss.service.RdbSyncRtService;
import com.hanwha.saws.icss.service.RestClientService;
import com.hanwha.saws.icss.service.SyncHistInsertService;

import lombok.extern.slf4j.Slf4j;

@Service("MedService")
@Slf4j
public class MedServiceImpl implements MedService {

    private static final String HEART_BEAT = "heartbeat";
    private static final String RESET = "reset";
    private static final String DIAGNOSIS = "diagnosis";
    private static final String ROUTER_PING = "router";

    private static final int N200 = 200;
    private static final int N0 = 0;
    private static final int N1 = 1;
    private static final int N2 = 2;

    @Autowired RestClientService restClient;
    @Autowired StatusConfigDao statusConfigDao;

    @Autowired SyncHistInsertService syncHistInsertService;

    @Autowired AlarmService alarmService;

    @Autowired PropConfig prop;

    @Autowired RdbSyncRtService rtSync;

    @Value("${prop.host-name}") String hostName;

    @Override
    public void heartbeatRequest(NodeModel nodeInfo) {
        MedReq bean = new MedReq();

        String ip = nodeInfo.getAddrIp();
        boolean isDbStatus = false;
        boolean isHb = false;
        AlarmRepo ac = AlarmRepo.getAlmSystem();
        AlarmRepo lv = AlarmRepo.getSvrMin();
        BaseResponse res = null;
        List<StatusModel> statusList = null;
        int statusCode = -1;
        String msg = "";

        bean.setOpCode(HEART_BEAT);

        res = restClient.getMedCommonReq(ip, bean);

        statusList = statusConfigDao.selectStatusList();        
        if (nodeInfo.getNodeId() == NodeRepo.getMissA().getCode()) {
            statusCode = statusList.get(0).getMissA();
        } else if (nodeInfo.getNodeId() == NodeRepo.getMissB().getCode()) {
            statusCode = statusList.get(0).getMissB();
        } else if (nodeInfo.getNodeId() == NodeRepo.getKissA().getCode()) {
            statusCode = statusList.get(0).getKissA();
        } else if (nodeInfo.getNodeId() == NodeRepo.getKissB().getCode()) {
            statusCode = statusList.get(0).getKissB();
        }
        isDbStatus = ((statusCode == 0) ? true : false);

        if ((res != null) && (res.getResCd() == N200)) {
            isHb = true;
        }        
        if (isHb != isDbStatus) {         
            updateStatus(isHb, nodeInfo);

        }

        msg = nodeInfo.getName() + " " + ip + " connect problem";        
        alarmService.alarmUpdate(isHb, ac, nodeInfo, lv, msg);

    }

    @Override
    public boolean getMedRouterPing(String senderIp, String targetIp) {
        BaseResponse res = null;
        MedReq bean = new MedReq();
        boolean isHb = false;

        bean.setOpCode(ROUTER_PING);
        bean.setIp(targetIp);
        res = restClient.getMedCommonReq(senderIp, bean);

        if ((res != null) && (res.getResCd() == N200)) {
            isHb = true;
        }

        return isHb;

    }

    @Override
    public void medStatusReport(MedStatusReq req, String senderIp) {
        ArrayList<Integer> keys = null;
        NodeModel node = null;
        StatusHistModel bean = new StatusHistModel();
        ThresholdModel param = new ThresholdModel();
        List<ThresholdModel> list = null;
        boolean isCpuGreen = true;
        boolean isMemGreen = true;
        boolean isHddGreen = true;
        boolean isAppGreen = true;
        int cpuLevel = -1;
        int memLevel = -1;
        int hddLevel = -1;

        int nTy = 0;
        int nDa = 0;

        String summary = null;
        AlarmRepo ac = null;
        AlarmRepo lv = null;
        NodeModel info = null;
        boolean cChk = false;
        boolean mChk = false;
        boolean hChk = false;
        int cpuMData = -1;
        int memMData = -1;
        int hddMData = -1;

        keys = new ArrayList<>(prop.getNodeInfoHash().keySet());

        for (Integer key : keys) {
            info = prop.getNodeInfoHash().get(key);

            if (info.getAddrIp().equals(senderIp)) {
                node = info;
            }
        }

        if (node == null) {
            log.debug("Node is null");
            return;
        }

        bean.setIpAddr(node.getAddrIp());
        bean.setNodeId(node.getNodeId());
        bean.setNodeName(node.getName());
        bean.setType1(req.getCpu() + "");
        bean.setType2(req.getMem() + "");
        bean.setType3(req.getHdd() + "");
        syncHistInsertService.insertStatusHist(bean);

        param.setNodeId(node.getNodeId());
        list = statusConfigDao.selectThresholdInfo(param);

        if (list != null && !list.isEmpty()) {
            list.sort(Comparator.comparingInt(ThresholdModel::getLevel));

            for (ThresholdModel m : list) {
                nTy = m.getType();
                nDa = m.getData();

                if ((!cChk) && (nTy == 0) && (req.getCpu() >= nDa)) {
                    isCpuGreen = false;
                    cpuLevel = m.getLevel();
                    cpuMData = m.getData();
                    cChk = true;

                } else if ((!mChk) && (nTy == N1) && (req.getMem() >= nDa)) {
                    isMemGreen = false;
                    memLevel = m.getLevel();
                    memMData = m.getData();
                    mChk = true;

                } else if ((!hChk) && (nTy == N2) && (req.getHdd() >= nDa)) {
                    isHddGreen = false;
                    hddLevel = m.getLevel();
                    hddMData = m.getData();
                    hChk = true;

                }

                if (cChk && mChk && hChk) {
                    break;
                }
            }
        }

        if (!"Y".equals(req.getApp())) {
            isAppGreen = false;
        }

        summary = "";

        if (cpuMData > -1) {
            summary = (node.getName() + " " + req.getCpu() + " > " + cpuMData);
        }

        ac = AlarmRepo.getAlmCpu();
        lv = getLevelAlarmCode(cpuLevel);
        alarmService.alarmLevelUpdate(isCpuGreen, ac, node, lv, summary);
        summary = "";

        if (memMData > -1) {
            summary = (node.getName() + " " + req.getMem() + " > " + memMData);
        }

        ac = AlarmRepo.getAlmMem();
        lv = getLevelAlarmCode(memLevel);
        alarmService.alarmLevelUpdate(isMemGreen, ac, node, lv, summary);
        summary = "";

        if (hddMData > -1) {
            summary = (node.getName() + " " + req.getHdd() + " > " + hddMData);
        }

        ac = AlarmRepo.getAlmHdd();
        lv = getLevelAlarmCode(hddLevel);
        alarmService.alarmLevelUpdate(isHddGreen, ac, node, lv, summary);

        summary = "";

        if (!isAppGreen) {
            summary = (node.getName() + " connection problem");
        }

        ac = AlarmRepo.getAlmSystem();
        lv = getLevelAlarmCode(N2);
        alarmService.alarmUpdate(isAppGreen, ac, node, lv, summary);

    }

    private AlarmRepo getLevelAlarmCode(int level) {
        AlarmRepo ac = null;

        if (level == N0) {
            ac = AlarmRepo.getSvrCri();
        } else if (level == N1) {
            ac = AlarmRepo.getSvrMaj();
        } else if (level == N2) {
            ac = AlarmRepo.getSvrMin();
        } else {
            ac = AlarmRepo.getSvrMin();
        }

        return ac;
    }

    private void updateStatus(boolean heartBeatStatus, NodeModel nodeInfo) {
        StatusModel param = new StatusModel();

        if (nodeInfo.getNodeId() == NodeRepo.getMissA().getCode()) {
            param.setMissA((heartBeatStatus ? 0 : 1));
        } else if (nodeInfo.getNodeId() == NodeRepo.getMissB().getCode()) {
            param.setMissB((heartBeatStatus ? 0 : 1));
        } else if (nodeInfo.getNodeId() == NodeRepo.getKissA().getCode()) {
            param.setKissA((heartBeatStatus ? 0 : 1));
        } else if (nodeInfo.getNodeId() == NodeRepo.getKissB().getCode()) {
            param.setKissB((heartBeatStatus ? 0 : 1));
        }

        try {
            statusConfigDao.updateStatus(param);
            rtSync.insertQueue(param, "UPDATE");

        } catch (RuntimeException e) {
            log.warn("updateStatus() " + e.toString());
        }

    }

    @Override
    public void medAlarmReport(MedAlarmReq req, String senderIp) {
        ArrayList<Integer> keys = null;
        NodeModel node = null;
        NodeModel info = null;
        AlarmRepo code = AlarmRepo.getAlmNodata();
        String aType = "";
        boolean isClear = false;
        StringBuilder sb = new StringBuilder();
        AlarmRepo codeLevel = null;

        keys = new ArrayList<>(prop.getNodeInfoHash().keySet());

        for (Integer key : keys) {

            info = prop.getNodeInfoHash().get(key);

            if (info.getAddrIp().equals(senderIp)) {
                node = info;
            }

        }

        if (node == null) {
            log.debug("Node is null");
            return;
        }

        aType = req.getAlarmType();

        if (aType.equals(AlarmRepo.getAlmNodata().getCode())) {
            code = AlarmRepo.getAlmNodata();
        } else if (aType.equals(AlarmRepo.getAlmDataCorrupt().getCode())) {
            code = AlarmRepo.getAlmDataCorrupt();
        }

        codeLevel = AlarmRepo.getSvrMin();

        if (req.getSeverity().equals(AlarmRepo.getSvrCle().getCode())) {
            isClear = true;
            codeLevel = AlarmRepo.getSvrCle();
        } else if (req.getSeverity().equals(AlarmRepo.getSvrMin().getCode())) {
            codeLevel = AlarmRepo.getSvrMin();
        } else if (req.getSeverity().equals(AlarmRepo.getSvrMaj().getCode())) {
            codeLevel = AlarmRepo.getSvrMaj();
        } else if (req.getSeverity().equals(AlarmRepo.getSvrCri().getCode())) {
            codeLevel = AlarmRepo.getSvrCri();
        }

        sb.append(node.getName() + " ");
        sb.append(node.getAddrIp() + " ");
        sb.append(code.getMsg() + " ");
        sb.append(codeLevel.getMsg());

        alarmService.alarmUpdate(isClear, code, node, codeLevel, sb.toString());

    }

}
