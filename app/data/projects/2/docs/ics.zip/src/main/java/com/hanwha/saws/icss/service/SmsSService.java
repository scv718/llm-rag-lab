/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.SmsTcpEventBean;
import com.hanwha.saws.icss.dto.code.NodeRepo;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.persistence.model.OperationHistModel;

public interface SmsSService {

    BaseResponse sModuleInfo(int nodeId, LoginSessionBean data);

    BaseResponse sModuleDiagnosis(int nodeId, LoginSessionBean data);

    BaseResponse sModuleLogin(int nodeId, String pin, LoginSessionBean data);

    BaseResponse sModulePinChange(int nodeId, String oldPin, String pin,
            LoginSessionBean data);

    BaseResponse sModuleLogout(int nodeId, LoginSessionBean data);

    BaseResponse sModuleCryptoModeUpdate(int nodeId, int key,
            LoginSessionBean data);

    BaseResponse sModuleCryptoModeStatus(int nodeId, LoginSessionBean data);

    BaseResponse sModuleCryptoBoardStatus(int nodeId, LoginSessionBean data);

    public BaseResponse sModuleInsertKeyCode(int nodeId, String mode,
            String mModeCode, String keyNum, LoginSessionBean data);

}
