/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.modem;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TBit {
    private int fpga;
    private int dac;
    private int clk;
    private int pwr;
    
//    private int mdm;
//    private int dac;
//    private int clk;
//    private int plw;    
    @JsonProperty("modem_sync") private int modemSync;
    @JsonProperty("no_card") private int noCard;

    @JsonIgnore private String binaryString;

    @JsonIgnore
    public String getAlarmInfo() { // 세부상태는 기입하지 않음
        
        String val = null;
        
        boolean isN = (noCard == 1);
        boolean isF = (fpga == 1);
        boolean isDC = (dac == 1);
        boolean isC = (clk == 1);
        boolean isP = (pwr == 1);
        boolean isM = (modemSync == 1);
        
        if (isN || isF || isDC || isC || isP || isM) {
            
            val = "변복조반 오류";
            
        } 

        return val;
    }

    @JsonIgnore
    public String getErrCode() {
        return binaryString;
    }
}
