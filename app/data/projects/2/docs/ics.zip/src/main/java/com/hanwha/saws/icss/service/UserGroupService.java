/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.service;

import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.request.GroupReq;
import com.hanwha.saws.icss.dto.request.HistoryReq;
import com.hanwha.saws.icss.dto.request.UserReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;

public interface UserGroupService {

    public BaseResponse login(UserReq req, String remoteAddr);

    public BaseResponse logout(LoginSessionBean data, String remoteAddr);

    BaseResponse userPwChange(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse getUserList(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse userAdd(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse userModify(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse userDelete(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse getGroupList(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation);

    BaseResponse groupAdd(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation);

    BaseResponse groupModify(LoginSessionBean session, GroupReq data,
            String remoteAddr, String operation);

    BaseResponse getSessionList(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse forceLogout(LoginSessionBean session, UserReq data,
            String remoteAddr, String operation);

    BaseResponse getLoginHistoryList(LoginSessionBean session, HistoryReq data,
            String remoteAddr, String operation);

    public BaseResponse groupDelete(LoginSessionBean sb, GroupReq req,
            String ip, String uri);

}
