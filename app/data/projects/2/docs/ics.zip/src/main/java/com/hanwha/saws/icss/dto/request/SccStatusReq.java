/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SccStatusReq {

    @JsonProperty("login_type") private String loginType;
    @JsonProperty("login_id") private String loginId;
    @JsonProperty("login_name") private String loginName;

    @JsonProperty("start_time") private String startTime;

    @JsonProperty("end_time") private String endTime;
    
    @JsonProperty("type") private String type;
    
    @JsonProperty("page") private Integer page;
    
    @JsonProperty("identity") private Integer identity;
    
    @JsonProperty("list_size") private Integer listSize;

    @JsonProperty("speed_st") private Integer speedSt;
    @JsonProperty("speed_ed") private Integer speedEd;
    @JsonProperty("attitude_st") private Integer attSt;
    @JsonProperty("attitude_ed") private Integer attEd;
    @JsonProperty("direction_st") private Integer dfSt;
    @JsonProperty("direction_ed") private Integer dfEd;
    @JsonProperty("track_number") private String trackNumber;    
    
}
