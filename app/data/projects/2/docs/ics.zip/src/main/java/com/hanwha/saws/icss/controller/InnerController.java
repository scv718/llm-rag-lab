/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hanwha.saws.icss.config.PropConfig;
import com.hanwha.saws.icss.dto.LoginSessionBean;
import com.hanwha.saws.icss.dto.code.ResRepo;
import com.hanwha.saws.icss.dto.request.MedStatusReq;
import com.hanwha.saws.icss.dto.response.BaseResponse;
import com.hanwha.saws.icss.persistence.model.NodeModel;
import com.hanwha.saws.icss.service.AsyncService;
import com.hanwha.saws.icss.service.IcsEtcService;
import com.hanwha.saws.icss.service.LoginSessionService;
import com.hanwha.saws.icss.service.SmtService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@RestController
@Slf4j
public class InnerController {

    private static final int INIT_WAIT = 0;
    
    private static final int ACTIVE = 1;
    @Autowired PropConfig prop;
    @Autowired SmtService smtService;
    @Autowired IcsEtcService icsEtcService;
    @Autowired AsyncService asynsService;
    @Autowired LoginSessionService loginSessionService;

    @Value("${server.host-ip}") String hostIp;

    @RequestMapping(value = { "/v1/keepalive" }, method = RequestMethod.GET)
    public ResponseEntity<String> keepalive(HttpServletRequest request) {
        boolean isWait = (prop.getInitFlag() == INIT_WAIT);
        boolean isStandby = (prop.getActiveMode() != ACTIVE);

        ResponseEntity<String> rt = null;

        if (isWait || isStandby) {
            rt = ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } else {
            rt = ResponseEntity.status(HttpStatus.OK).build();
        }

        return rt;
    }

    @RequestMapping(value = { "/v1/syncReset" }, method = RequestMethod.POST)
    public BaseResponse syncReset(HttpServletRequest request,
            @RequestBody LoginSessionBean bean) {

        return smtService.remoteIcsReset(bean);
    }

    @PostMapping("/v1/icsStatusReport")
    public ResponseEntity<String> statusReport(HttpServletRequest request,
            @RequestBody MedStatusReq bean) {
        icsEtcService.icsStatusReport(bean, request.getRemoteAddr());
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping("/v1/req_diagnosis")
    public BaseResponse reqDiagnosis(HttpServletRequest request,
            @RequestBody MedStatusReq bean) {
        asynsService.diagnosis();
        return new BaseResponse(ResRepo.getC200());
    }

    @RequestMapping(value = { "/v1/syncSession" }, method = RequestMethod.POST)
    public BaseResponse syncSession(
            @RequestBody ConcurrentHashMap<String, LoginSessionBean> bean) {

        loginSessionService.syncSession(bean);
        return new BaseResponse(ResRepo.getC200());
    }

    @GetMapping("/v1/local_heartbeat")
    public BaseResponse localHeartbeat(HttpServletRequest request) {
        return ((prop.getInitFlag() == INIT_WAIT) ? null :
                new BaseResponse(ResRepo.getC200()));
    }

    @RequestMapping(value = { "/deepclient" }, method = RequestMethod.POST)
    public BaseResponse deepclient(HttpServletRequest request,
            @RequestBody Map bean) {

        loginSessionService.pSess(request.getRemoteAddr());
        return new BaseResponse(ResRepo.getC200());
    }

    @RequestMapping(value = { "/deepNode" }, method = RequestMethod.POST)
    public BaseResponse deepNode(HttpServletRequest request,
            @RequestBody NodeModel bean) {

        if (request.getRemoteAddr().equals("127.0.0.1")) {
            icsEtcService.icsNodeUpdate(bean);
            return new BaseResponse(ResRepo.getC200());
        }

        return new BaseResponse(ResRepo.getC999());
    }

    @PostMapping("/v1/innerFailover")
    public BaseResponse failover(HttpServletRequest request,
            @RequestBody HashMap body) {

        LoginSessionBean bean = new LoginSessionBean();
        
        bean.setUserId("console");
        bean.setName(prop.getHostName());
        bean.setIp(hostIp);
        
        return smtService.failover(bean);

    }
}
