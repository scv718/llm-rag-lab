/*
 * ICSS
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanwha.saws.icss.persistence.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class EmerHistModel implements Serializable {
    private static final int N10 = 10;
    private static final int N1000 = 1000;
    
    private Timestamp insertTime;
    private long seqNo;
    private int idx;
    private String sysId;
    private String dataName;
    private String recvGroup;
    private String data;
    private String dataType;
    private String dataTypeName;
    private String dataSize;
    private String errorFlag;
    private Date recvTime;
    private Date sentTime;

    private String st;
    private String ed;

    private int rowCount;
    private int startIdx;

    public void setPage(Integer page, Integer listCount) {
        
        if (page == null || page == 0) {
            page = 1;
        }
        
        if (listCount == null || listCount == 0) {
            listCount = N10;
        }
        
        startIdx = (page - 1) * listCount;
        rowCount = listCount;
    }

    public void setTime() {
        LocalDateTime now = LocalDateTime.now();

        now = now.plusNanos(System.nanoTime() % N1000); // 미세한 차이 추가
        insertTime = Timestamp.valueOf(now);
        recvTime = new Date();
        sentTime = new Date();
    }

}
