/*
 * MEDIATOR
 *
 * Version 1.0.0
 *
 * by NBware
 */
package com.hanhwa.saws.mediator.util;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class SduUtil {

    private static DateTimeFormatter dtf = null;

    private static final int N2 = 2;
    private static final int N3 = 3;
    private static final int N4 = 4;
    private static final int N8 = 8;
    private static final int N15 = 15;
    private static final int N16 = 16;
    private static final int N23 = 23;
    private static final int N24 = 24;
    private static final int B01 = 0x01;
    private static final int BFF = 0xFF;
    private static final int BFFFF = 0xFFFF;
    private static final int B3FFF = 0x3FFF;

    private SduUtil() {}

    public static byte[] encodeLatLng(String posi) {
        // 하이픈 / null / 빈값 방어
//        if (posi == null || posi.isBlank() || "-".equals(posi)) {
//            return new byte[] { 0x00, 0x00, 0x00 };
//        }

        String errMsg = "Invalid input for position: ";
        String padded = null;
        int dPoint = 0;
        String intPart = null;
        String decPart = null;
        int val1 = 0;
        int symbol = 0;
        int val2 = 0;
        int rValue = 0;

        int a0 = 0;
        int a1 = 0;
        int a2 = 0;

        try {
            dPoint = posi.indexOf(".");
            intPart = (dPoint > 0) ? posi.substring(0, dPoint) : posi;
            decPart = (dPoint > 0) ? posi.substring(dPoint + 1) : "";

            val1 = Integer.parseInt(intPart);
            symbol = (val1 < 0) ? 1 : 0;

            if (decPart.isEmpty()) {
                val2 = 0;
            } else {

                if (decPart.length() >= N4) {
                    padded = decPart.substring(0, N4);
                } else {
                    padded = String.format("%-4s", decPart).replace(' ', '0');
                }

                val2 = Integer.parseInt(padded);
            }

            a0 = ((B01 & symbol) << N23);
            a1 = ((BFF & Math.abs(val1)) << N15);
            a2 = ((B3FFF & val2) << 1);

            rValue = a0 | a1 | a2;

            return new byte[] { (byte) ((rValue >>> N16) & BFF),
                    (byte) ((rValue >>> N8) & BFF), (byte) (rValue & BFF) };

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(errMsg + posi, e);
        }
    }

    public static byte[] encodeVelocity(String vel) {

        String errMsg = "Invalid input for velocity: ";
        int dotPoint = 0;
        String intPart = null;
        String decPart = null;
        String paddedDecimal = null;
        short val1 = 0;
        byte val2 = 0;
        int rValue = 0;

        try {
            dotPoint = vel.indexOf(".");
            intPart = (dotPoint > 0) ? vel.substring(0, dotPoint) : vel;
            decPart = (dotPoint > 0) ? vel.substring(dotPoint + 1) : "0";

            if (decPart.length() >= N2) {
                paddedDecimal = decPart.substring(0, N2);
            } else {
                paddedDecimal = (decPart + "0".repeat(N2 - decPart.length()));

            }

            val1 = Short.parseShort(intPart);
            val2 = Byte.parseByte(paddedDecimal);

            rValue = ((BFFFF & val1) << N8) | (BFF & val2);

            return new byte[] { (byte) ((rValue >>> N16) & BFF),
                    (byte) ((rValue >>> N8) & BFF), (byte) (rValue & BFF) };
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(errMsg + vel, e);
        }
    }

    public static byte[] encodeTime(String time) {

        LocalDateTime dateTime = null;
        int epochSeconds = 0;

        if (dtf == null) {
            dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        }
        try {
            dateTime = LocalDateTime.parse(time, dtf);
        } catch (DateTimeException e) {
            dateTime = LocalDateTime.now(ZoneOffset.UTC);
            //dateTime = LocalDateTime.now(ZoneId.of("Asia/Seoul"));
        }


        //dateTime = LocalDateTime.parse(time, dtf);
        epochSeconds = (int) dateTime.toEpochSecond(ZoneOffset.UTC);

        return new byte[] { (byte) ((epochSeconds >> N24) & BFF),
                (byte) ((epochSeconds >> N16) & BFF),
                (byte) ((epochSeconds >> N8) & BFF),
                (byte) (epochSeconds & BFF) };

    }
}
